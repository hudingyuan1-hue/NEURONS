from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from white_records import WhiteRecords


def event(kind='dead'):
    return {'event_id':'event-17','patient_id':'patient-4',
            'truth':{'event_id':'event-17','patient_id':'patient-4','result':kind,'verified':True},
            'left':{'doc_id':'original-17','event_id':'event-17','patient_id':'patient-4','result':kind},
            'right':{'doc_id':'forged-17','event_id':'event-17','patient_id':'patient-4','result':'discharged' if kind=='dead' else 'taken'},
            'avatar_witnessed':False}

def identity():
    return {'conflict_id':'conflict-8','left':{'record_id':'person-a','status':'cancelled','face_id':'face-2','scar':'old-a'},
            'right':{'record_id':'person-b','status':'current','face_id':'face-2','scar':'old-b'}}

def label():
    return {'label_id':'name-1','name':'fixture-name','patient_id':'patient-4','body_id':'body-70','fee_id':'bill-71',
            'original_owner':'avatar','key_owned':True}

def model(room='bridge', attempt=1):
    m=WhiteRecords(attempt=attempt,event=event(),identity=identity(),label=label())
    context(m,room)
    return m

def context(m,room=None,**kw):
    return m.sync_context(attempt=kw.pop('attempt',m.attempt),epoch=kw.pop('epoch',m.epoch),
        room=room if room is not None else m.room,
        actors=kw.pop('actors',{'doublehead':'bridge','blankface':'index','doubleface':'identity'}),**kw)

def tok(m,n):
    return m.attempt,n

def complete_contradiction(m,base=0,**kw):
    assert m.start_contradiction(tok(m,base))
    assert m.hear_statement(tok(m,base+1),'left',**kw)
    assert m.hear_statement(tok(m,base+2),'right',**kw)

def complete_identity(m,base=0):
    assert m.start_identity(tok(m,base))
    for i,side in enumerate(('left','right')):
        assert m.read_identity(tok(m,base+1+4*i),side)
        assert m.match_identity(tok(m,base+2+4*i),side)
        assert m.see_match(tok(m,base+3+4*i),side)
        assert m.see_face(tok(m,base+4+4*i),side,turn_complete=True)

def begin_pull(m):
    assert m.open_original(tok(m,1))
    assert m.reach_label(tok(m,2))
    assert m.pinch_label(tok(m,3))

@pytest.mark.parametrize('kind',['dead','refused'])
def test_real_same_event_full_speech_once(kind):
    m=model();m.event=event(kind);original=deepcopy(m.event)
    complete_contradiction(m)
    assert m.effects==[{'id':('contradiction','event-17'),'hp':0,'sp':10}]
    assert m.event==original and not m.can_claim_witness
    complete_contradiction(m,10)
    assert len(m.effects)==1

@pytest.mark.parametrize('part,field,value',[
    ('truth','verified',False),('truth','result','alive'),('truth','patient_id','another'),
    ('truth','event_id','other'),('left','patient_id','another'),('right','patient_id','another'),
    ('left','event_id','other'),('right','event_id','other'),('left','result','discharged'),
    ('right','result','dead'),('right','doc_id','original-17')])
def test_no_manufactured_conflict(part,field,value):
    m=model();m.event[part][field]=value
    assert not m.start_contradiction(tok(m,1))
    assert not m.hear_statement(tok(m,2),'left')
    assert m.effects==[]

@pytest.mark.parametrize('partial_side',['left','right','both'])
def test_incomplete_hearing_does_not_damage(partial_side):
    m=model();assert m.start_contradiction(tok(m,0))
    assert m.hear_statement(tok(m,1),'left',complete=True,heard=partial_side not in ('left','both'))
    assert m.hear_statement(tok(m,2),'right',complete=True,heard=partial_side not in ('right','both'))
    assert not m.effects

def test_partial_speech_does_not_enable_right_or_damage():
    m=model();m.start_contradiction(tok(m,0))
    m.hear_statement(tok(m,1),'left',complete=False)
    assert not m.hear_statement(tok(m,2),'right')
    assert not m.effects

def test_screen_reading_is_not_hearing():
    m=model();m.read_event_screen(tok(m,1),'left');m.read_event_screen(tok(m,2),'right')
    assert not m.effects
    assert ('event_screen','original-17') in m.knowledge and ('event_screen','forged-17') in m.knowledge

def test_formal_speech_progresses_pause_physical_actions_do_not():
    m=model();m.start_contradiction(tok(m,0));context(m,paused=True)
    assert not m.read_event_screen(tok(m,1),'left')
    assert not m.hear_statement(tok(m,2),'left')
    assert m.hear_statement(tok(m,3),'left',formal_dialogue=True)
    assert m.hear_statement(tok(m,4),'right',formal_dialogue=True)
    assert len(m.effects)==1

@pytest.mark.parametrize('attempt',[2,6,1000000])
def test_save_dedup_and_partial_knowledge_survive_death(attempt):
    m=model();m.start_contradiction(tok(m,0));m.hear_statement(tok(m,1),'left')
    before=deepcopy(m.knowledge);context(m,dead=True)
    assert not m.hear_statement(tok(m,2),'right',formal_dialogue=True)
    context(m,attempt=attempt,epoch=1,dead=False)
    assert before<=m.knowledge
    complete_contradiction(m,20)
    assert len(m.effects)==1
    context(m,attempt=attempt+1,epoch=2)
    complete_contradiction(m,30)
    assert len(m.effects)==1

def test_prior_witness_requirement_not_inferred_from_records():
    m=model();complete_contradiction(m)
    assert not m.can_claim_witness
    m.event['avatar_witnessed']=True
    assert m.can_claim_witness

@pytest.mark.parametrize('missing',['left_document','right_document','left_match','right_match','left_face','right_face'])
def test_identity_requires_all_six_actual_observations(missing):
    m=model('identity');m.start_identity(tok(m,0))
    n=1
    for side in ('left','right'):
        if missing != side+'_document':m.read_identity(tok(m,n),side)
        n+=1;m.match_identity(tok(m,n),side);n+=1
        if missing != side+'_match':m.see_match(tok(m,n),side)
        n+=1
        if missing != side+'_face':m.see_face(tok(m,n),side,turn_complete=True)
        n+=1
    assert not m.effects

@pytest.mark.parametrize('field,value',[('record_id','person-a'),('status','cancelled'),('face_id','other-face'),('scar','old-a')])
def test_invalid_identity_does_not_merge_or_charge(field,value):
    m=model('identity');m.identity['right'][field]=value;before=deepcopy(m.identity)
    assert not m.start_identity(tok(m,0))
    assert not m.read_identity(tok(m,1),'left')
    assert not m.effects and m.identity==before

def test_identity_complete_once_and_original_ids_unchanged():
    m=model('identity');before=deepcopy(m.identity);complete_identity(m)
    assert m.effects==[{'id':('identity','conflict-8'),'hp':0,'sp':10}]
    context(m,'bridge');context(m,'identity')
    complete_identity(m,20)
    context(m,attempt=2,epoch=1)
    complete_identity(m,40)
    assert len(m.effects)==1 and m.identity==before

def test_identity_partial_can_resume_after_death():
    m=model('identity');m.read_identity(tok(m,0),'left')
    context(m,dead=True);context(m,attempt=2,epoch=1)
    assert ('identity','conflict-8','left','document') in m.knowledge
    complete_identity(m,10);assert len(m.effects)==1

def test_identity_no_result_before_actual_match_no_face_before_turn():
    m=model('identity');m.start_identity(tok(m,0))
    assert not m.see_match(tok(m,1),'left')
    m.match_identity(tok(m,2),'left',passed=False)
    assert not m.see_match(tok(m,3),'left')
    assert not m.see_face(tok(m,4),'right')
    assert not m.effects

@pytest.mark.parametrize('op',['start_identity','see_face','match_identity'])
def test_absent_doubleface_does_not_close_route(op):
    m=model('identity');context(m,actors={'doublehead':'bridge','blankface':'index'})
    if op=='start_identity':assert m.start_identity(tok(m,0))
    elif op=='see_face':assert not m.see_face(tok(m,0),'left')
    else:
        m.start_identity(tok(m,0));assert m.match_identity(tok(m,1),'left')
    assert not m.effects

@pytest.mark.parametrize('ms',[0,1,999])
def test_label_not_removed_before_full_second(ms):
    m=model('index');begin_pull(m);m.tick(ms)
    assert not m.label_removed and m.query_name(tok(m,10))=='found'
    m.tick(1000-ms)
    assert m.label_removed and m.query_name(tok(m,11))=='not_found'

def test_label_actual_removal_does_not_erase_entity_items_known_name():
    m=model('index');before=deepcopy(m.label);m.read_original(tok(m,0));begin_pull(m);m.tick(1000)
    assert m.label==before and ('name','fixture-name') in m.knowledge and not m.effects
    assert m.label['original_owner']=='avatar' and m.label['key_owned']
    assert m.label_owner=='blankface'
    assert m.query_name(tok(m,20))=='not_found'
    assert m.verify_ids(tok(m,21),body_patient='patient-4',fee_patient='patient-4')

def test_opening_original_is_not_reading_name():
    m=model('index');m.open_original(tok(m,1))
    assert ('name','fixture-name') not in m.knowledge
    assert not m.read_original(tok(m,2),readable=False)
    assert not m.verify_ids(tok(m,3),body_patient='patient-4',fee_patient='patient-40')

@pytest.mark.parametrize('absent,visible',[(True,True),(False,False)])
def test_no_label_trigger_without_actual_actor_witness(absent,visible):
    m=model('index')
    if absent:context(m,actors={})
    assert m.open_original(tok(m,1),visible_to_actor=visible)
    assert not m.label_used and m.label_phase=='idle'

def test_cancel_search_does_not_cancel_npc_label_action():
    m=model('index');m.open_original(tok(m,1));m.cancel_avatar_search(tok(m,2))
    context(m,'bridge',avatar_able=False)
    assert m.reach_label(tok(m,3)) and m.pinch_label(tok(m,4))
    m.tick(1000);assert m.label_removed

def test_world_pause_freezes_label_timer_and_actor_departure_interrupts():
    m=model('index');begin_pull(m);m.tick(600);context(m,paused=True);m.tick(10000)
    assert m.label_ms==600 and not m.label_removed
    context(m,actors={});m.tick(10000)
    assert m.label_phase=='interrupted' and not m.label_removed
    context(m);m.open_original(tok(m,10));assert m.label_phase=='interrupted'

def test_interrupt_before_and_after_removal():
    m=model('index');begin_pull(m);m.tick(999)
    assert m.interrupt_label(tok(m,4));m.tick(1000)
    assert not m.label_removed and m.label_used
    context(m,attempt=2,epoch=1);begin_pull(m);m.tick(1000)
    assert not m.interrupt_label(tok(m,4)) and m.label_removed

def test_no_duplicate_removed_label_after_reentry_reload_new_attempt():
    m=model('index');begin_pull(m);m.tick(1000)
    context(m,'identity');m=m.reload();context(m,'index');context(m,attempt=2,epoch=1)
    assert m.open_original(tok(m,1)) and m.label_phase=='idle' and m.label_removed
    assert not m.reach_label(tok(m,2))
    assert len([h for h in m.history if h[1]=='label_removed'])==1

@pytest.mark.parametrize('gate',['oldattempt','duplicate','paused','dead','epoch','wrongroom','unable'])
def test_callbacks_cannot_bypass_context(gate):
    m=model('index');token=tok(m,1)
    if gate=='oldattempt':token=(0,1)
    elif gate=='duplicate':assert m.open_original(token)
    elif gate=='paused':context(m,paused=True)
    elif gate=='dead':context(m,dead=True)
    elif gate=='epoch':context(m,epoch=1)
    elif gate=='wrongroom':context(m,'bridge')
    elif gate=='unable':context(m,avatar_able=False)
    before=deepcopy(m.__dict__)
    assert not m.open_original(token)
    assert m.__dict__==before


def test_empty_fixture_never_creates_story():
    m=WhiteRecords();context(m,'bridge')
    assert not m.start_contradiction(tok(m,1))
    context(m,'identity');assert not m.start_identity(tok(m,2))
    context(m,'index');assert not m.open_original(tok(m,3))
    assert not m.effects and not m.knowledge


def test_negative_time_rejected():
    m=model('index')
    with pytest.raises(ValueError):m.tick(-1)


class RecordsMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.m=model();self.serial=0
        self.original=(deepcopy(self.m.event),deepcopy(self.m.identity),deepcopy(self.m.label))
        self.ever_knowledge=set();self.ever_effects=set();self.removed=False
    def token(self):
        self.serial+=1;return tok(self.m,self.serial)
    @rule(room=st.sampled_from(['bridge','index','identity','elsewhere']),paused=st.booleans(),able=st.booleans(),present=st.booleans())
    def move(self,room,paused,able,present):
        context(self.m,room,paused=paused,avatar_able=able,actors={'doublehead':'bridge','blankface':'index','doubleface':'identity'} if present else {})
    @rule(action=st.sampled_from(['start','speech','screen','identity','read','match','result','face','open','read_original','reach','pinch','query','interrupt','cancel','observe','ids']),side=st.sampled_from(['left','right']),actual=st.booleans(),complete=st.booleans(),formal=st.booleans())
    def action(self,action,side,actual,complete,formal):
        m,t=self.m,self.token()
        if action=='start':m.start_contradiction(t,actual=actual,in_range=complete)
        elif action=='speech':m.hear_statement(t,side,actual=actual,complete=complete,heard=complete,formal_dialogue=formal)
        elif action=='screen':m.read_event_screen(t,side,actual=actual,visible=complete)
        elif action=='identity':m.start_identity(t,actual=actual,visible=complete)
        elif action=='read':m.read_identity(t,side,actual=actual,visible=complete)
        elif action=='match':m.match_identity(t,side,actual=actual,passed=complete)
        elif action=='result':m.see_match(t,side,actual=actual,visible=complete)
        elif action=='face':m.see_face(t,side,actual=actual,visible=complete,turn_complete=formal)
        elif action=='open':m.open_original(t,actual=actual,visible_to_actor=complete)
        elif action=='read_original':m.read_original(t,actual=actual,readable=complete)
        elif action=='reach':m.reach_label(t,actual=actual,path_clear=complete)
        elif action=='pinch':m.pinch_label(t,actual=actual)
        elif action=='query':m.query_name(t,actual=actual,visible=complete)
        elif action=='interrupt':m.interrupt_label(t,actual=actual)
        elif action=='cancel':m.cancel_avatar_search(t,actual=actual)
        elif action=='observe':m.observe_label(t,actual=actual,visible=complete)
        else:m.verify_ids(t,actual=actual,body_patient='patient-4',fee_patient='patient-4' if complete else 'other')
    @rule(ms=st.sampled_from([0,1,799,999,1000,1001,5000]))
    def tick(self,ms):
        old=self.m.label_ms;blocked=self.m.paused or self.m.dead or self.m.departed
        self.m.tick(ms)
        if blocked:assert self.m.label_ms==old
    @rule(kind=st.sampled_from(['death','revive','reload','leave']))
    def lifecycle(self,kind):
        if kind=='death':context(self.m,dead=True)
        elif kind=='revive':context(self.m,'bridge',attempt=self.m.attempt+1,epoch=self.m.epoch+1)
        elif kind=='leave':context(self.m,epoch=self.m.epoch+1)
        else:self.m=self.m.reload()
    @rule()
    def successful_route(self):
        if self.m.dead or self.m.departed:context(self.m,attempt=self.m.attempt+1,epoch=self.m.epoch+1)
        context(self.m,'bridge')
        m=self.m
        m.start_contradiction(self.token());m.hear_statement(self.token(),'left');m.hear_statement(self.token(),'right')
        context(m,'identity');m.start_identity(self.token())
        for side in ('left','right'):
            m.read_identity(self.token(),side);m.match_identity(self.token(),side);m.see_match(self.token(),side);m.see_face(self.token(),side,turn_complete=True)
        context(m,'index');m.open_original(self.token());m.reach_label(self.token());m.pinch_label(self.token());m.tick(1000)
    @invariant()
    def preserved_facts_unique_damage_actual_knowledge(self):
        m=self.m
        assert (m.event,m.identity,m.label)==self.original
        assert self.ever_knowledge<=m.knowledge;self.ever_knowledge=set(m.knowledge)
        assert self.ever_effects<=m.effect_ids;self.ever_effects=set(m.effect_ids)
        assert len(m.effects)==len(m.effect_ids)<=2
        assert all(e['hp']==0 and e['sp']==10 for e in m.effects)
        if ('contradiction','event-17') in m.effect_ids:
            assert all(('event','event-17',s,'complete') in m.knowledge for s in ('left','right'))
        if ('identity','conflict-8') in m.effect_ids:
            assert all(('identity','conflict-8',s,p) in m.knowledge for s in ('left','right') for p in ('document','match','face'))
        if self.removed:assert m.label_removed
        self.removed=m.label_removed
        assert m.label_owner==('blankface' if m.label_removed else 'index')
        assert not m.can_claim_witness

TestRecordsMachine=RecordsMachine.TestCase
TestRecordsMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None,database=None)


def test_hearing_existing_formal_speech_is_not_body_action():
    m=model();m.start_contradiction(tok(m,0))
    context(m,avatar_able=False,paused=True)
    assert m.hear_statement(tok(m,1),'left',formal_dialogue=True)
    assert m.hear_statement(tok(m,2),'right',formal_dialogue=True)
    assert len(m.effects)==1


def test_offroom_formal_callback_does_not_grant_hearing():
    m=model();m.start_contradiction(tok(m,0));m.hear_statement(tok(m,1),'left')
    context(m,'index',paused=True)
    assert not m.hear_statement(tok(m,2),'right',formal_dialogue=True)
    assert not m.effects


def test_replay_has_fresh_order_without_erasing_retained_knowledge():
    m=model();complete_contradiction(m)
    known=deepcopy(m.knowledge);m.start_contradiction(tok(m,20))
    assert not m.hear_statement(tok(m,21),'right')
    assert m.knowledge==known and len(m.effects)==1
