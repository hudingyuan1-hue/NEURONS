from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from white_routes import WhiteRoutes, LOOP


def make(room='exit', attempt=1):
    r = WhiteRoutes(attempt=attempt, epoch=10)
    r.sync_context(attempt=attempt, epoch=10, room=room,
                   actors={'face': 'exit', 'reverse': 'fork', 'twitch': 'rhythm'})
    return r


def token(r, value):
    return (r.attempt, value)


def ready(r):
    assert r.start_face(token(r, 'start'), key=True, opening=True)
    assert r.raise_face(token(r, 'raise'))
    r.tick(800)


def sync(r, **kw):
    params = dict(attempt=r.attempt, epoch=r.epoch, room=r.room, actors=r.actors,
                  paused=r.paused, dead=r.dead, active=r.active,
                  holder_free=r.holder_free, body_generation=r.body_generation)
    params.update(kw)
    return r.sync_context(**params)


@pytest.mark.parametrize('attempt', [1, 2, 5, 1000000])
def test_face_once_per_actual_attempt(attempt):
    r = make(attempt=attempt)
    ready(r)
    assert r.contact_face(token(r, 'touch'), actual_contact=True)
    assert r.effects == [{'id': (attempt, 'face'), 'hp': 0, 'sp': 15,
                          'hold': 1200, 'hold_ms': 1200}]
    assert not r.contact_face(token(r, 'twice'), actual_contact=True)
    r.tick(1200)
    sync(r, room='fork')
    sync(r, room='exit')
    assert not r.start_face(token(r, 'repeat'), key=True, opening=True)
    assert sync(r, attempt=attempt + 1, epoch=11)
    assert r.start_face(token(r, 'start'), key=True, opening=True)


@pytest.mark.parametrize('delay,ready_expected', [(0,False), (799,False), (800,True), (801,True)])
def test_face_windup_boundaries(delay, ready_expected):
    r = make()
    r.start_face(token(r,1), key=True, opening=True)
    r.raise_face(token(r,2))
    r.tick(delay)
    assert r.contact_face(token(r,3), actual_contact=True) == ready_expected
    assert len(r.effects) == int(ready_expected)


@pytest.mark.parametrize('delay,held_expected', [(0,True), (1199,True), (1200,False), (1201,False)])
def test_face_release_boundaries(delay, held_expected):
    r = make()
    ready(r)
    r.contact_face(token(r,3), actual_contact=True)
    r.tick(delay)
    assert r.held == held_expected
    assert len(r.releases) == int(not held_expected)
    assert len(r.effects) == 1


@pytest.mark.parametrize('bad', ['no_key','no_open','not_seen','elsewhere','absent','holder','not_actual','old_token','old_epoch','paused','dead','departed'])
def test_invalid_start_does_not_spend_opportunity(bad):
    r = make()
    kw = dict(key=True, opening=True)
    t = token(r, 1)
    if bad == 'no_key': kw['key'] = False
    if bad == 'no_open': kw['opening'] = False
    if bad == 'not_seen': kw['seen'] = False
    if bad == 'elsewhere': sync(r, room='fork')
    if bad == 'absent': sync(r, actors={})
    if bad == 'holder': sync(r, holder_free=False)
    if bad == 'not_actual': kw['actual'] = False
    if bad == 'old_token': t = (0,1)
    if bad == 'old_epoch': kw['callback_epoch'] = 9
    if bad == 'paused': sync(r, paused=True)
    if bad == 'dead': sync(r, dead=True)
    if bad == 'departed': sync(r, active=False)
    assert not r.start_face(t, **kw)
    assert not r.face_used and not r.effects


@pytest.mark.parametrize('outcome', ['miss','actual_interrupt','avatar_left','actor_left','level_left','death','body_taken'])
def test_spent_face_attempt_never_requeues(outcome):
    r = make()
    ready(r)
    if outcome == 'miss': assert r.contact_face(token(r, 3), actual_contact=False)
    if outcome == 'actual_interrupt': assert r.interrupt_face(token(r, 3))
    if outcome == 'avatar_left': sync(r, room='fork')
    if outcome == 'actor_left': sync(r, actors={'reverse':'fork'})
    if outcome == 'level_left': sync(r, active=False, epoch=11)
    if outcome == 'death': sync(r, dead=True)
    if outcome == 'body_taken': sync(r, holder_free=False, body_generation=1)
    assert r.face_phase == 'finished'
    assert not r.effects
    sync(r, room='exit', actors={'face':'exit'}, paused=False, dead=False,
         active=True, holder_free=True, body_generation=r.body_generation)
    assert not r.start_face(token(r, 'new'), key=True, opening=True)
    assert not r.contact_face(token(r, 'late'), actual_contact=True)


def test_stale_queue_cannot_take_over_after_other_holder_releases():
    r = make()
    ready(r)
    sync(r, body_generation=1, holder_free=False)
    sync(r, body_generation=2, holder_free=True)
    assert not r.contact_face(token(r,'late'), actual_contact=True, callback_generation=0)
    assert not r.effects and r.face_used


def test_held_release_not_conditioned_on_sp_skill_or_reply():
    r = make()
    ready(r)
    r.contact_face(token(r,'touch'),actual_contact=True)
    assert not r.interrupt_face(token(r,'fake_skill'),actual=True)
    sync(r,holder_free=False,body_generation=1)
    r.tick(1200)
    assert not r.held and len(r.effects)==1


@pytest.mark.parametrize('why', ['actor_left','dead','level_left'])
def test_actual_contact_releases_on_context_exit(why):
    r = make()
    ready(r)
    r.contact_face(token(r,'touch'),actual_contact=True)
    if why=='actor_left': sync(r,actors={})
    if why=='dead': sync(r,dead=True)
    if why=='level_left': sync(r,active=False,epoch=11)
    assert not r.held and len(r.releases)==1
    assert r.effects[0]['sp']==15


def test_dialogue_pause_freezes_npc_timing():
    r=make()
    r.start_face(token(r,1),key=True,opening=True)
    r.raise_face(token(r,2))
    sync(r,paused=True)
    before=deepcopy(r.__dict__)
    assert not r.tick(100000)
    assert before==r.__dict__
    sync(r,paused=False)
    r.tick(800)
    r.contact_face(token(r,3),actual_contact=True)
    sync(r,paused=True)
    r.tick(100000)
    assert r.hold_remaining==1200


@pytest.mark.parametrize('ms,crossing,count', [(0,True,0),(1199,True,0),(1200,False,1),(2699,False,1),(2700,True,1),(3900,False,2),(8100,True,3)])
def test_twitch_timing(ms,crossing,count):
    r=make('rhythm')
    r.tick(ms)
    assert r.crossing==crossing
    assert r.crossing_count==count
    assert not r.effects


@pytest.mark.parametrize('ms',[0,1199,1200,2699,2700])
def test_side_route_always_usable_and_preserves_target(ms):
    r=make('rhythm')
    r.approach_twitch(token(r,1),target='same_pending_search')
    r.tick(ms)
    assert r.pass_twitch(token(r,2),side=True)
    assert r.original_target=='same_pending_search'
    assert not r.effects and not r.waiting


def test_wait_ends_at_current_crossing_not_entire_loop():
    r=make('rhythm')
    r.approach_twitch(token(r,1),target=17)
    r.tick(1199)
    assert r.waiting
    assert not r.pass_twitch(token(r,2))
    r.tick(1)
    assert not r.waiting
    assert r.pass_twitch(token(r,2))
    r.tick(1500)
    assert not r.waiting
    assert r.original_target==17 and not r.effects


def test_skill_pause_only_avatar_does_not_pause_twitch_world():
    r=make('rhythm')
    sync(r,holder_free=False)
    r.tick(1200)
    assert not r.crossing
    assert not r.pass_twitch(token(r,1),side=True,actual_clear=False)
    assert not r.effects


@pytest.mark.parametrize('blocked', ['unseen','absent','known_exit','known_loop','wrong_room','not_actual'])
def test_false_guidance_conditions(blocked):
    r=make('fork')
    kw={}
    if blocked=='unseen': kw['seen']=False
    if blocked=='absent': sync(r,actors={})
    if blocked=='known_exit': kw['reliable_exit']=True
    if blocked=='known_loop': r.knowledge.add('fork_bridge_index_fork')
    if blocked=='wrong_room': sync(r,room='index')
    if blocked=='not_actual': kw['actual']=False
    assert not r.accept_guidance(token(r,1),**kw)
    assert not r.guidance


@pytest.mark.parametrize('cut',[0,1,2,3])
def test_partial_loop_does_not_grant_knowledge(cut):
    r=make('fork')
    assert r.accept_guidance(token(r,1))
    for i in range(cut): assert r.route_step(token(r,i+2),LOOP[i+1])
    assert not r.loop_known
    assert not r.recognize_loop(token(r,8),actual_landmark=False)
    assert r.interrupt_guidance(token(r,9))
    assert not r.recognize_loop(token(r,10))
    assert not r.loop_known and not r.effects


def test_actual_full_loop_recognition_survives_death_new_attempt():
    r=make('fork')
    r.accept_guidance(token(r,1))
    for i,d in enumerate(LOOP[1:]): assert r.route_step(token(r,i+2),d)
    assert r.recognize_loop(token(r,5))
    assert r.loop_known
    sync(r,dead=True)
    sync(r,attempt=2,epoch=11,dead=False,room='fork')
    assert r.loop_known
    assert not r.accept_guidance(token(r,1))
    assert not r.effects


def test_no_loop_teleport_or_fabricated_completion():
    r=make('fork')
    r.accept_guidance(token(r,1))
    assert not r.route_step(token(r,2),'index')
    assert not r.route_step(token(r,3),'fork')
    assert not r.route_step(token(r,4),'bridge',actual=False)
    assert r.route_index==0 and r.room=='fork' and not r.loop_known


def test_unrelated_actual_move_interrupts_guidance():
    r=make('fork')
    r.accept_guidance(token(r,1))
    sync(r,room='identity')
    assert not r.guidance
    assert not r.route_step(token(r,2),'bridge')


def test_original_callbacks_dedup_reload_and_new_epoch_rejected():
    r=make()
    ready(r)
    r.contact_face(token(r,'touch'),actual_contact=True,callback_epoch=10)
    r=r.reload()
    assert not r.contact_face(token(r,'touch'),actual_contact=True)
    sync(r,active=False,epoch=11)
    assert not r.contact_face(token(r,'late'),actual_contact=True,callback_epoch=10)
    assert len(r.effects)==1


class RouteMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.r=make()
        self.n=0
        self.known=False

    def t(self):
        self.n+=1
        return token(self.r,self.n)

    @rule(ms=st.integers(0,7000))
    def time(self,ms):
        r=self.r
        before=deepcopy(r.__dict__)
        r.tick(ms)
        if r.paused or r.dead or not r.active: assert r.__dict__==before

    @rule(room=st.sampled_from(['exit','fork','bridge','index','rhythm','identity']),
          present=st.booleans(),paused=st.booleans(),free=st.booleans(),body_change=st.booleans())
    def context(self,room,present,paused,free,body_change):
        sync(self.r,room=room,paused=paused,holder_free=free,
             body_generation=self.r.body_generation+int(body_change),
             actors={'face':'exit','reverse':'fork','twitch':'rhythm'} if present else {})

    @rule(key=st.booleans(),opening=st.booleans(),seen=st.booleans())
    def face_start(self,key,opening,seen):
        self.r.start_face(self.t(),key=key,opening=opening,seen=seen)

    @rule(actual=st.booleans())
    def face_approach(self,actual):
        self.r.raise_face(self.t(),reached=actual)

    @rule(contact=st.booleans(),stale=st.booleans())
    def face_contact(self,contact,stale):
        self.r.contact_face(self.t(),actual_contact=contact,
                            callback_generation=self.r.body_generation-int(stale))

    @rule(actual=st.booleans())
    def face_interrupt(self,actual):
        self.r.interrupt_face(self.t(),actual=actual)

    @rule(actual=st.booleans())
    def face_release(self,actual):
        self.r.release_face(self.t(),actual=actual)

    @rule(side=st.booleans(),clear=st.booleans())
    def twitch(self,side,clear):
        self.r.approach_twitch(self.t(),target='saved_search')
        self.r.pass_twitch(self.t(),side=side,actual_clear=clear)

    @rule(seen=st.booleans(),exit_known=st.booleans())
    def guidance(self,seen,exit_known):
        self.r.accept_guidance(self.t(),seen=seen,reliable_exit=exit_known)

    @rule(destination=st.sampled_from(['bridge','index','fork','exit']),actual=st.booleans())
    def arrival(self,destination,actual):
        self.r.route_step(self.t(),destination,actual=actual)

    @rule(landmark=st.booleans())
    def recognize(self,landmark):
        self.r.recognize_loop(self.t(),actual_landmark=landmark)

    @rule()
    def interrupt(self):
        self.r.interrupt_guidance(self.t())

    @rule()
    def death_restart(self):
        sync(self.r,dead=True)
        sync(self.r,attempt=self.r.attempt+1,epoch=self.r.epoch+1,
             room='exit',paused=False,dead=False,active=True,holder_free=True)

    @rule()
    def reload(self):
        self.r=self.r.reload()

    @rule()
    def old_callbacks(self):
        before=deepcopy(self.r.__dict__)
        assert not self.r.contact_face((self.r.attempt-1,'late'),actual_contact=True)
        assert not self.r.start_face(self.t(),key=True,opening=True,callback_epoch=self.r.epoch-1)
        assert self.r.__dict__==before

    @invariant()
    def exact_effect_and_once(self):
        ids=[e['id'] for e in self.r.effects]
        assert len(ids)==len(set(ids))
        assert all(e['hp']==0 and e['sp']==15 and e['hold_ms']==1200 for e in self.r.effects)
        assert self.r.hold_remaining<=1200
        if self.known: assert self.r.loop_known
        self.known=self.r.loop_known
        if self.r.held:
            assert self.r.face_used and self.r.room=='exit' and self.r.active and not self.r.dead


TestRoutes=RouteMachine.TestCase
TestRoutes.settings=settings(max_examples=225,stateful_step_count=70,deadline=None,database=None)


@pytest.mark.parametrize('change', ['actor_left','avatar_left'])
def test_wait_clears_when_actual_crossing_no_longer_blocks_this_avatar(change):
    r=make('rhythm')
    r.approach_twitch(token(r,1),target='keep_search')
    r.tick(200)
    assert r.waiting
    if change=='actor_left': sync(r,actors={'face':'exit','reverse':'fork'})
    else: sync(r,room='fork')
    assert not r.waiting
    assert r.original_target=='keep_search'
    assert not r.effects
