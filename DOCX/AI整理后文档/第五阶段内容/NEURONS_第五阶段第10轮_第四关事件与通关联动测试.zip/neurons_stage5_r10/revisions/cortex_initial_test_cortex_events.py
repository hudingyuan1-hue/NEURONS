from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from cortex_events import CortexEvents


def create(room='body', attempt=1):
    m = CortexEvents(attempt=attempt)
    m.sync_context(room=room, actors={'backturn':'atrium','mimic':'decision','clamp':'body'})
    return m


def token(m, label):
    return (m.attempt, label)


def windup(m):
    assert m.clamp_touch(token(m, 'touch'), actual_contact=True, hand_inside=True)
    for step in ('look', 'grip', 'pull'):
        assert m.clamp_step(token(m, step), step=step)


def hit(m):
    windup(m)
    m.tick(800)
    assert m.clamp_close(token(m, 'close'), actual_contact=True)


@pytest.mark.parametrize('elapsed,allowed', [(0,False),(799,False),(800,True),(801,True),(100000,True)])
def test_clamp_windup_boundary(elapsed,allowed):
    m=create(); windup(m); m.tick(elapsed)
    assert m.clamp_close(token(m,'close'),actual_contact=True)==allowed
    assert sum(x['hp'] for x in m.effects)==(10 if allowed else 0)


@pytest.mark.parametrize('elapsed,held',[(0,True),(999,True),(1000,False),(1001,False),(100000,False)])
def test_release_boundary(elapsed,held):
    m=create(); hit(m); m.tick(elapsed)
    assert (m.clamp_phase=='held')==held
    assert sum(x['hp'] for x in m.effects)==10


@pytest.mark.parametrize('contact,inside',[(False,False),(False,True),(True,False)])
def test_other_touch_not_event(contact,inside):
    m=create()
    assert not m.clamp_touch(token(m,'touch'),actual_contact=contact,hand_inside=inside)
    assert not m.clamp_used


@pytest.mark.parametrize('step',['grip','pull'])
def test_no_out_of_order_operation(step):
    m=create(); m.clamp_touch(token(m,'touch'),actual_contact=True,hand_inside=True)
    assert not m.clamp_step(token(m,'step'),step=step)
    assert not m.effects


def test_clamp_needs_visible_windup():
    m=create(); m.clamp_touch(token(m,'touch'),actual_contact=True,hand_inside=True)
    m.clamp_step(token(m,'look'),step='look'); m.clamp_step(token(m,'grip'),step='grip')
    assert not m.clamp_step(token(m,'pull'),step='pull',visible_windup=False)
    m.tick(800); assert not m.clamp_close(token(m,'close'),actual_contact=True)


@pytest.mark.parametrize('actual',[False,True])
def test_cancel_not_equal_actual_withdrawal(actual):
    m=create(); windup(m)
    assert m.hand_clear(token(m,'clear'),actual=actual)==actual
    m.tick(800); m.clamp_close(token(m,'close'),actual_contact=True)
    assert sum(x['hp'] for x in m.effects)==(0 if actual else 10)
    assert m.clamp_used


@pytest.mark.parametrize('actual',[False,True])
def test_kick_requires_actual_operator_hit(actual):
    m=create(); windup(m)
    assert m.clamp_interrupt(token(m,'kick'),actual_hit=actual)==actual
    m.tick(800); m.clamp_close(token(m,'close'),actual_contact=True)
    assert sum(x['hp'] for x in m.effects)==(0 if actual else 10)


def test_after_clamp_kick_does_not_erase_injury():
    m=create(); hit(m)
    assert not m.clamp_interrupt(token(m,'kick'),actual_hit=True)
    assert not m.hand_clear(token(m,'withdraw'),actual=True)
    assert m.clamp_phase=='held' and m.injury


def test_actual_attack_during_other_hold_no_second_holder():
    m=create(); windup(m); m.tick(800)
    m.avatar_blocked=True
    assert m.clamp_close(token(m,'close'),actual_contact=True,can_hold=False)
    assert sum(x['hp'] for x in m.effects)==10
    assert not any(x['hold_ms'] for x in m.effects)
    assert m.clamp_phase=='done'


@pytest.mark.parametrize('attempt',[1,5,1000000])
def test_once_per_actual_attempt_even_miss(attempt):
    m=create(attempt=attempt); windup(m); m.tick(800)
    assert m.clamp_close(token(m,'close'),actual_contact=False)
    assert not m.clamp_touch(token(m,'again'),actual_contact=True,hand_inside=True)
    assert not m.effects
    m.sync_context(attempt=attempt+1,epoch=1,room='body',actors=m.actors)
    assert m.clamp_touch(token(m,'again'),actual_contact=True,hand_inside=True)


@pytest.mark.parametrize('phase',['windup','held'])
def test_pause_freezes_physical_timers(phase):
    m=create(); windup(m)
    if phase=='held':
        m.tick(800); m.clamp_close(token(m,'close'),actual_contact=True)
    m.paused=True; old=deepcopy(m.__dict__)
    assert not m.tick(100000)
    assert not m.clamp_close(token(m,'late'),actual_contact=True)
    assert m.__dict__==old


@pytest.mark.parametrize('phase',['windup','held'])
def test_death_ends_pending_and_hold(phase):
    m=create(); windup(m)
    if phase=='held':
        m.tick(800); m.clamp_close(token(m,'close'),actual_contact=True)
    m.sync_context(room='body',actors=m.actors,dead=True)
    assert m.clamp_phase=='done'
    old=deepcopy(m.__dict__); m.tick(5000)
    assert not m.clamp_close(token(m,'late'),actual_contact=True)
    assert m.__dict__==old


def test_read_is_not_injury_or_contradiction():
    m=create(); assert m.clamp_read(token(m,'read'),lamp=True,record=True)
    assert not m.injury and not m.pain_contradiction_known
    hit(m); m.tick(1000)
    assert not m.pain_contradiction_known
    assert m.clamp_read(token(m,'lamp'),lamp=True,record=False)
    assert m.pain_contradiction_known


def test_unseen_injury_record_not_learned():
    m=create(); hit(m); m.tick(1000)
    assert not m.clamp_read(token(m,'read'),lamp=True,record=True,visible=False)
    assert not m.knowledge


def test_wound_history_and_knowledge_survive_new_attempt():
    m=create(); hit(m); m.tick(1000)
    m.clamp_read(token(m,'read'),lamp=True,record=True)
    m.sync_context(attempt=2,epoch=1,room='body',actors=m.actors)
    assert len([x for x in m.facts if x['kind']=='clamp_injury'])==1
    assert ('pain_lamp',1) in m.knowledge
    assert not m.injury and not m.pain_lamp and not m.pain_contradiction_known


def test_actual_callback_replay_and_effect_drain():
    m=create(); hit(m)
    assert not m.clamp_close(token(m,'close'),actual_contact=True)
    assert sum(x['hp'] for x in m.drain_effects())==10
    assert m.drain_effects()==[]
    m.tick(1000); assert [x['kind'] for x in m.drain_effects()]==['clamp_release']


@pytest.mark.parametrize('field,value',[('effective',False),('visible',False),('actual_movement',False),('movement','internal_fear'),('source','npc')])
def test_invalid_mimic_trigger(field,value):
    m=create('decision'); args=dict(event_id='e',movement='scratch',source='player',effective=True,visible=True,actual_movement=True)
    args[field]=value
    assert not m.mimic_witness(token(m,'witness'),**args)
    assert m.mimic_phase=='idle' and not m.actual_actions


@pytest.mark.parametrize('movement', sorted(CortexEvents.MOVES))
def test_visible_mimic_does_not_duplicate_effects(movement):
    m=create('decision')
    assert m.mimic_witness(token(m,'witness'),event_id='e',movement=movement)
    assert m.classifications=={}
    assert not m.mimic_write(token(m,'early'),actual_completed=True)
    assert m.mimic_complete(token(m,'copy'))
    assert m.classifications=={}
    assert m.mimic_write(token(m,'write'))
    key=(0,1,'e')
    assert m.classifications[key]=='自主行为'
    assert m.actual_actions[key]['source']=='player'
    assert m.effects==[] and m.knowledge==set()
    assert m.read_mimic(token(m,'read'))
    assert not m.mimic_witness(token(m,'again'),event_id='e2',movement=movement)


def test_full_control_start_alone_not_mimic():
    m=create('decision')
    assert not m.mimic_witness(token(m,'start'),event_id='e',movement='posture',source='full_control',actual_movement=False)
    assert m.mimic_witness(token(m,'moved'),event_id='e',movement='posture',source='full_control')


@pytest.mark.parametrize('choice',['接受','拒绝'])
def test_decision_classification_does_not_change_real_choice(choice):
    m=create('decision')
    assert m.decision_actual(token(m,'act'),event_id='d',choice=choice)
    assert m.actual_actions[(0,1,'d')]['choice']==choice
    assert m.classifications[(0,1,'d')]=='已同意'
    assert len(m.actual_actions)==1
    m.read_consent(token(m,'read')); assert len(m.actual_actions)==1


def test_reading_empty_board_does_not_invent_consent():
    m=create('decision'); m.read_consent(token(m,'read'))
    assert not m.actual_actions and not m.classifications


def test_backturn_order_and_not_forced_knowledge():
    m=create('atrium'); assert m.back_approach(token(m,'approach'))
    assert not m.back_turn(token(m,'early'),part='torso')
    assert m.back_turn(token(m,'head'),part='head')
    assert m.back_turn(token(m,'torso'),part='torso')
    assert not m.knowledge and not m.effects
    assert not m.back_approach(token(m,'again'))
    assert m.back_read(token(m,'front'),part='front',number=m.number)
    assert ('no_face',m.number) in m.knowledge
    assert not m.same_front_back_known and not m.recognized_number
    m.back_read(token(m,'back'),part='back',number=m.number)
    assert m.same_front_back_known
    m.back_read(token(m,'record'),part='record',number=m.number)
    assert m.recognized_number
    assert all('identity' not in str(x) for x in m.knowledge)


@pytest.mark.parametrize('part',['front','back','old_band','record'])
def test_number_needs_actual_legible_view(part):
    m=create('atrium')
    assert not m.back_read(token(m,'read'),part=part,number=m.number,readable=False)
    assert not m.knowledge


@pytest.mark.parametrize('operation',['clamp','mimic','backturn'])
def test_remote_missing_actor_no_event(operation):
    m=create({'clamp':'body','mimic':'decision','backturn':'atrium'}[operation]); m.actors[operation]=None
    if operation=='clamp': result=m.clamp_touch(token(m,'x'),actual_contact=True,hand_inside=True)
    elif operation=='mimic': result=m.mimic_witness(token(m,'x'),event_id='e',movement='scratch')
    else: result=m.back_approach(token(m,'x'))
    assert not result and not m.facts


def test_epoch_rejects_old_unseen_callback():
    m=create(); windup(m); m.tick(800)
    m.sync_context(epoch=1,room='body',actors=m.actors)
    assert not m.clamp_close(token(m,'old'),actual_contact=True,callback_epoch=0)
    assert not m.effects


def test_reload_preserves_consumed_event_not_replay():
    m=create(); hit(m); m.tick(1000); m.drain_effects(); restored=m.reload()
    assert not restored.clamp_touch(token(restored,'again'),actual_contact=True,hand_inside=True)
    assert restored.__dict__==m.__dict__ or restored.seen != m.seen


class CortexMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__(); self.m=create(); self.serial=0

    def t(self):
        self.serial+=1; return token(self.m,self.serial)

    @rule(room=st.sampled_from(['atrium','decision','body','elsewhere']), blocked=st.booleans())
    def move(self,room,blocked):
        self.m.sync_context(room=room,actors=self.m.actors,avatar_blocked=blocked)

    @rule(action=st.sampled_from(['touch','look','grip','pull','close','clear','kick']),actual=st.booleans())
    def clamp(self,action,actual):
        m=self.m
        if action=='touch': m.clamp_touch(self.t(),actual_contact=actual,hand_inside=actual)
        elif action in ('look','grip','pull'): m.clamp_step(self.t(),step=action,actual_completed=actual)
        elif action=='close': m.clamp_close(self.t(),actual_contact=actual,can_hold=not m.avatar_blocked)
        elif action=='clear': m.hand_clear(self.t(),actual=actual)
        else: m.clamp_interrupt(self.t(),actual_hit=actual)

    @rule(ms=st.sampled_from([0,1,799,800,999,1000,1001,5000]))
    def tick(self,ms): self.m.tick(ms)

    @rule(action=st.sampled_from(['witness','imitate','write','read','accept','refuse']),visible=st.booleans())
    def mimic(self,action,visible):
        m=self.m
        if action=='witness': m.mimic_witness(self.t(),event_id=self.serial,movement='scratch',visible=visible)
        elif action=='imitate': m.mimic_complete(self.t(),actual_completed=visible)
        elif action=='write': m.mimic_write(self.t(),actual_completed=visible)
        elif action=='read': m.read_mimic(self.t(),visible=visible)
        else: m.decision_actual(self.t(),event_id=self.serial,choice='接受' if action=='accept' else '拒绝')

    @rule(action=st.sampled_from(['approach','head','torso','front','back','record']),visible=st.booleans())
    def back(self,action,visible):
        m=self.m
        if action=='approach': m.back_approach(self.t(),actual_visible=visible)
        elif action in ('head','torso'): m.back_turn(self.t(),part=action,actual_completed=visible)
        else: m.back_read(self.t(),part=action,number=m.number,visible=visible)

    @rule()
    def pause(self):
        m=self.m; m.paused=True; before=deepcopy(m.__dict__)
        m.tick(5000)
        m.clamp_close((m.attempt,'paused'),actual_contact=True)
        assert m.__dict__==before
        m.paused=False

    @rule()
    def restart(self):
        m=self.m; facts=deepcopy(m.facts); known=set(m.knowledge)
        old_attempt=m.attempt; old_epoch=m.epoch
        m.sync_context(attempt=m.attempt+1,epoch=m.epoch+1,room='body',actors=m.actors)
        assert m.facts[:len(facts)]==facts and m.knowledge==known
        assert not m.clamp_touch((old_attempt,'stale'),actual_contact=True,hand_inside=True,callback_epoch=old_epoch)

    @rule()
    def reload(self): self.m=self.m.reload()

    @invariant()
    def source_truth_and_single_settlement(self):
        m=self.m
        attempts={x['attempt'] for x in m.facts}
        for n in attempts:
            assert len([x for x in m.facts if x['kind']=='clamp_injury' and x['attempt']==n])<=1
            assert len([x for x in m.facts if x['kind']=='mimic_written' and x['attempt']==n])<=1
        assert all(x['sp']==0 and x['hp'] in (0,10) for x in m.effects)
        for key,classification in m.classifications.items():
            assert key in m.actual_actions
            if classification=='自主行为': assert m.actual_actions[key]['source'] in ('player','full_control')
            else: assert m.actual_actions[key]['choice'] in ('接受','拒绝')
        assert m.windup_ms<=800 and m.held_ms<=1000
        if m.clamp_phase=='held': assert m.injury and m.hand_inside


TestCortexMachine=CortexMachine.TestCase
TestCortexMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None,derandomize=False)
