from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from archive_events import ArchiveEvents


def make(**kw):
    return ArchiveEvents(facts={'fixture_event':{'subject':'fixture_subject','kind':'transfer'}},**kw)

def tok(a,n): return (a.attempt,n)

def pinched(a):
    assert a.open_original(tok(a,'open'))
    assert a.reach_paper(tok(a,'reach'))
    assert a.pinch_paper(tok(a,'pinch'))
    return a

def video(a):
    a.sync_context(room='visual',actors={'stitched':True,'blind':True})
    assert a.watch(tok(a,'watch'),'fixture_event')
    return a

@pytest.mark.parametrize('ms',[0,1,999,1000,1999,2000,3000])
def test_tear_boundary(ms):
    a=pinched(make()); a.tick(ms)
    assert a.tear_ms==min(ms,2000)
    assert (a.paper_phase=='ended')==(ms>=2000)
    if ms==0: assert a.pieces=={'whole':'held'}
    elif ms<2000: assert a.pieces=={'corner':'held','remainder':'world'}
    else: assert a.pieces=={'corner':'held','remainder':'npc'}

@pytest.mark.parametrize('ms',[0,1,999,1000,1001])
def test_mask_boundary(ms):
    a=video(make()); a.operate_face(tok(a,'op'),'fixture_face_a'); a.tick(ms)
    assert ('fixture_face_a' in a.masked)==(ms>=1000)
    assert 'fixture_face_b' not in a.masked

@pytest.mark.parametrize('action',['pass','search_table_bottom','read_revision','search_tv'])
def test_unrelated_actions_do_not_trigger(action):
    a=make(); a.tick(99999)
    if action=='read_revision': a.read_fields(tok(a,1),'revision',['name'])
    assert a.paper_phase=='idle' and not a.paper_used and a.tear_ms==0

@pytest.mark.parametrize('phase',['approaching','reached','pinched'])
def test_actor_departure_aborts_paper(phase):
    a=make(); a.open_original(tok(a,'o'))
    if phase in ('reached','pinched'): a.reach_paper(tok(a,'r'))
    if phase=='pinched': a.pinch_paper(tok(a,'p')); a.tick(500)
    a.sync_context(actors={'stitched':False,'blind':False})
    assert a.paper_phase=='ended'
    damage=a.tear_ms; a.tick(3000); assert a.tear_ms==damage

@pytest.mark.parametrize('ms',[1,999,1999])
def test_paper_interrupt_keeps_partial(ms):
    a=pinched(make()); a.tick(ms); assert a.interrupt_paper(tok(a,'interrupt'))
    state=deepcopy(a.pieces); a.tick(10000)
    assert a.tear_ms==ms and a.pieces==state
    assert not a.open_original(tok(a,'again'))

@pytest.mark.parametrize('phase',['approaching','reached','pinched'])
def test_whole_owned_not_stolen(phase):
    a=make(); a.open_original(tok(a,'o'))
    if phase in ('reached','pinched'): a.reach_paper(tok(a,'r'))
    if phase=='pinched': a.pinch_paper(tok(a,'p'))
    assert a.acquire_paper(tok(a,'take'),'whole')
    a.tick(9999); a.cancel_reading(tok(a,'cancel'))
    assert a.pieces=={'whole':'avatar'} and a.tear_ms==0

@pytest.mark.parametrize('attempt',[1,5,1000000])
def test_owned_fragment_persists_attempt(attempt):
    a=pinched(make(attempt=attempt)); a.tick(300)
    assert a.acquire_paper(tok(a,'take'),'corner')
    a.cancel_reading(tok(a,'cancel')); a.tick(2000)
    a.sync_context(attempt=attempt+1,epoch=1)
    assert a.pieces=={'corner':'avatar','remainder':'npc'}
    assert not a.open_original(tok(a,'new'))
    assert not a.acquire_paper(tok(a,'duplicate'),'corner')


def test_cancel_not_acquisition():
    a=pinched(make()); a.cancel_reading(tok(a,'c')); a.tick(2000)
    assert a.pieces=={'corner':'world','remainder':'npc'}
    assert not any(x=='avatar' for x in a.pieces.values())

@pytest.mark.parametrize('stage',['approaching','reached'])
def test_npc_continues_after_avatar_leaves(stage):
    a=make(); a.open_original(tok(a,'o'))
    if stage=='reached': a.reach_paper(tok(a,'r'))
    a.cancel_reading(tok(a,'c')); a.sync_context(room='atrium')
    if stage=='approaching': assert a.reach_paper(tok(a,'r'))
    assert a.pinch_paper(tok(a,'p'))
    a.tick(2000); assert a.tear_ms==2000


def test_video_next_operation_after_avatar_leaves():
    a=video(make()); a.operate_face(tok(a,'op'),'fixture_face_a'); a.tick(1000)
    a.sync_context(room='atrium')
    assert a.operate_face(tok(a,'op2'),'fixture_face_b')
    a.tick(1000); assert len(a.masked)==2


def test_read_knowledge_only_actually_read_fields():
    a=make(); a.read_fields(tok(a,1),'original',['name'])
    a.read_fields(tok(a,2),'revision',['name','injury'])
    assert a.compare_field('name') and not a.compare_field('injury')
    assert not a.compare_field('signature')

@pytest.mark.parametrize('bad', ['different_event','different_subject'])
def test_no_cross_identity_comparison(bad):
    a=make(); a.read_fields(tok(a,1),'original',['name'])
    kw={'event_id':'other'} if bad=='different_event' else {'subject':'other'}
    a.read_fields(tok(a,2),'revision',['name'],**kw)
    assert not a.compare_field('name')

@pytest.mark.parametrize('flag',['visible','readable','material_available'])
def test_unreadable_fields_not_known(flag):
    a=make(); assert not a.read_fields(tok(a,1),'original',['name'],**{flag:False})
    assert not a.read_values


def test_read_original_after_tear_no_autocomplete():
    a=pinched(make()); a.read_fields(tok(a,1),'original',['name']); a.tick(2000)
    assert set(x[3] for x in a.read_values)=={'name'}


def test_masks_preserve_seen_identity_and_action():
    a=video(make()); a.observe_video(tok(a,'see'),faces=['fixture_face_a'],action=True)
    a.operate_face(tok(a,'op'),'fixture_face_a',visible=True); a.tick(1000)
    a.observe_video(tok(a,'after'),faces=['fixture_face_a'])
    assert ('face','fixture_event','fixture_face_a') in a.knowledge
    assert ('action','fixture_event') in a.knowledge
    assert ('saw_masking','fixture_event','fixture_face_a') in a.knowledge


def test_late_viewer_cannot_recognize_hidden_face_or_operator():
    a=video(make()); a.operate_face(tok(a,'op'),'fixture_face_a'); a.tick(1000)
    a.observe_video(tok(a,'after'),faces=['fixture_face_a'],action=True)
    assert ('face','fixture_event','fixture_face_a') not in a.knowledge
    assert ('saw_masking','fixture_event','fixture_face_a') not in a.knowledge


def test_interrupted_video_preserves_completed_only():
    a=video(make()); a.operate_face(tok(a,1),'fixture_face_a'); a.tick(1000)
    a.operate_face(tok(a,2),'fixture_face_b'); a.tick(999)
    assert a.interrupt_video(tok(a,3)); a.tick(9999)
    assert a.masked=={'fixture_face_a'}


def test_same_event_replay_no_new_fact_effect_or_unmask():
    a=video(make()); before=deepcopy(a.facts)
    a.operate_face(tok(a,1),'fixture_face_a'); a.tick(1000)
    assert a.watch(tok(a,2),'fixture_event',screen='curved')
    for i in range(3,8): assert a.replay(tok(a,i),'fixture_event')
    assert a.facts==before and not a.effects and a.masked=={'fixture_face_a'}


def test_no_masks_reassigned_to_different_event():
    a=make(); a.facts['other']={'subject':'other_patient','kind':'transfer'}; video(a)
    a.operate_face(tok(a,1),'fixture_face_a'); a.tick(1000)
    # This standalone scene is bound to its configured actual clip. A different
    # clip requires a separate record, not inheriting this clip's masks/faces.
    assert not a.watch(tok(a,2),'other')
    assert a.selected=='fixture_event'

@pytest.mark.parametrize('at_frame',[False,True])
def test_overlay_not_identity_or_personal_history(at_frame):
    a=video(make()); before=deepcopy(a.facts)
    assert a.overlay(tok(a,'overlay'),at_frame=at_frame)==at_frame
    assert a.facts==before and a.facts['fixture_event']['subject']=='fixture_subject'
    assert not a.effects


def test_death_paper_does_not_create_death_fact():
    a=make(); a.read_death_record(tok(a,1),'fixture_subject')
    assert ('record_says_dead','fixture_subject') in a.knowledge
    assert not a.confirmed_death('fixture_subject')
    a.facts['death']={'kind':'death','subject':'other'}
    assert a.confirmed_death('other') and not a.confirmed_death('fixture_subject')

@pytest.mark.parametrize('kind',['pause','death'])
def test_clock_stops(kind):
    a=pinched(make()); a.tick(500)
    a.sync_context(**({'paused':True} if kind=='pause' else {'dead':True}))
    a.tick(9999); assert a.tear_ms==500
    assert not a.acquire_paper(tok(a,'take'),'corner')


def test_duplicate_old_token_reload_remote_read():
    a=make(); assert a.open_original(tok(a,1)); assert not a.open_original(tok(a,1))
    a.sync_context(room='atrium'); assert not a.read_fields(tok(a,2),'original',['name'])
    a.sync_context(attempt=2,epoch=1,room='memory')
    assert not a.read_fields((1,3),'original',['name'])
    b=a.reload(); b.knowledge.add(('private',)); assert ('private',) not in a.knowledge

class ArchiveMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__(); self.a=make(); self.i=0
    def t(self): self.i+=1; return tok(self.a,self.i)
    @rule(action=st.sampled_from(['open','reach','pinch','cancel','interrupt','whole','corner','remainder']))
    def paper(self,action):
        methods={'open':self.a.open_original,'reach':self.a.reach_paper,'pinch':self.a.pinch_paper,
                 'cancel':self.a.cancel_reading,'interrupt':self.a.interrupt_paper}
        if action in methods: methods[action](self.t())
        else: self.a.acquire_paper(self.t(),action)
    @rule(ms=st.sampled_from([0,1,500,999,1000,1999,2000,10000]))
    def time(self,ms):
        before=(self.a.tear_ms,set(self.a.masked))
        frozen=self.a.paused or self.a.dead
        self.a.tick(ms)
        if frozen: assert before==(self.a.tear_ms,self.a.masked)
    @rule(room=st.sampled_from(['memory','visual','atrium']),pause=st.booleans(),blocked=st.booleans(),actor=st.booleans())
    def context(self,room,pause,blocked,actor):
        self.a.sync_context(room=room,paused=pause,avatar_blocked=blocked,actors={'stitched':actor,'blind':actor})
    @rule(action=st.sampled_from(['watch','op_a','op_b','interrupt','observe','overlay','replay']))
    def film(self,action):
        if action=='watch': self.a.watch(self.t(),'fixture_event')
        elif action.startswith('op'): self.a.operate_face(self.t(),'fixture_face_'+action[-1],visible=self.a.room=='visual')
        elif action=='interrupt': self.a.interrupt_video(self.t())
        elif action=='observe': self.a.observe_video(self.t(),faces=self.a.faces,action=True)
        elif action=='overlay': self.a.overlay(self.t(),at_frame=True)
        else: self.a.replay(self.t(),'fixture_event')
    @rule(version=st.sampled_from(['original','revision']),readable=st.booleans())
    def read(self,version,readable): self.a.read_fields(self.t(),version,['name'],readable=readable)
    @rule(jump=st.sampled_from([1,4,1000000]))
    def restart(self,jump):
        owned={k for k,v in self.a.pieces.items() if v=='avatar'}; knowledge=set(self.a.knowledge)
        self.a.sync_context(attempt=self.a.attempt+jump,epoch=self.a.epoch+1,dead=False,paused=False)
        assert owned <= {k for k,v in self.a.pieces.items() if v=='avatar'}
        assert knowledge<=self.a.knowledge
    @rule()
    def reload(self): self.a=self.a.reload()
    @invariant()
    def consistency(self):
        a=self.a
        assert 0<=a.tear_ms<=2000 and 0<=a.face_ms<1000
        assert not a.effects
        assert not ('whole' in a.pieces and len(a.pieces)>1)
        assert a.masked<=set(a.faces)
        assert a.facts=={'fixture_event':{'subject':'fixture_subject','kind':'transfer'}}
        assert a.paper_phase!='pinched' or a.actors.get('stitched')

TestArchiveMachine=ArchiveMachine.TestCase
TestArchiveMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None,database=None)


def test_matching_event_id_with_different_subject_rejected():
    a=make(); a.facts['fixture_event']['subject']='other_patient'
    a.sync_context(room='visual',actors={'stitched':True,'blind':True})
    assert not a.watch(tok(a,1),'fixture_event')
    assert a.selected is None


def test_offscreen_operation_cannot_be_witnessed():
    a=video(make()); a.sync_context(room='atrium')
    assert a.operate_face(tok(a,1),'fixture_face_a',visible=True)
    a.tick(1000); a.sync_context(room='visual')
    a.observe_video(tok(a,2))
    assert ('saw_masking','fixture_event','fixture_face_a') not in a.knowledge
