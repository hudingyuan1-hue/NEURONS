"""S3:P1063-1075,1120-1160; S4:T17R2,P200-207.

Room/contact/visibility facts are supplied by an adapter, not inferred as 3D
collision. Tokens are (actual_attempt, callback_id); queued callbacks must also
carry callback_epoch when crossing a scene-generation boundary.
"""
from copy import deepcopy


class CortexEvents:
    ROOMS = {'backturn': 'atrium', 'mimic': 'decision', 'clamp': 'body'}
    MOVES = {'scratch', 'hold_abdomen', 'tremble', 'turn_head', 'press_lips',
             'kick', 'withdraw', 'step_back', 'look_skin', 'expression', 'posture'}

    def __init__(self, attempt=1, epoch=0, number='fixture-case-number'):
        self.attempt, self.epoch, self.number = attempt, epoch, number
        self.room = None
        self.actors = dict.fromkeys(self.ROOMS)
        self.paused = self.dead = self.avatar_blocked = False
        self.seen = set()
        self.facts = []
        self.knowledge = set()
        self.actual_actions = {}
        self.classifications = {}
        self.effects = []
        self._reset_local()

    def _reset_local(self):
        self.back_phase = 'idle'
        self.mimic_phase = 'idle'
        self.mimic_event = None
        self.clamp_phase = 'idle'
        self.clamp_used = False
        self.hand_inside = False
        self.windup_ms = self.held_ms = 0
        self.pain_lamp = False
        self.injury = False

    def _fact(self, kind, **data):
        row = {'kind': kind, 'attempt': self.attempt, 'epoch': self.epoch, **data}
        self.facts.append(row)
        return row

    def _effect(self, kind, **data):
        self.effects.append({'id': ('cortex', self.epoch, self.attempt, len(self.facts)),
                             'kind': kind, 'hp': 0, 'sp': 0, 'hold_ms': 0, **data})

    def sync_context(self, *, attempt=None, epoch=None, room=None, actors=None,
                     paused=False, dead=False, avatar_blocked=False):
        attempt = self.attempt if attempt is None else attempt
        epoch = self.epoch if epoch is None else epoch
        if attempt < self.attempt or epoch < self.epoch:
            return False
        if attempt > self.attempt:
            self._cancel_clamp('new_attempt')
            self.attempt, self.epoch = attempt, epoch
            self._reset_local()
            self.seen.clear()
        elif epoch != self.epoch:
            self._cancel_clamp('epoch_changed')
            if self.back_phase not in ('idle', 'front'):
                self.back_phase = 'ended'
            if self.mimic_phase not in ('idle', 'recorded'):
                self.mimic_phase = 'ended'
            self.epoch = epoch
        old_room = self.room
        self.room, self.paused, self.dead = room, bool(paused), bool(dead)
        self.avatar_blocked = bool(avatar_blocked)
        if actors is not None:
            self.actors = {key: actors.get(key) for key in self.ROOMS}
        if dead:
            self._cancel_clamp('death')
        elif self.clamp_phase not in ('idle', 'done'):
            if self.actors['clamp'] != 'body' or room != 'body':
                self._cancel_clamp('left')
            elif avatar_blocked and self.clamp_phase != 'held':
                self._cancel_clamp('body_unavailable')
        # An actor that really leaves cannot finish an old animation remotely.
        if self.actors['backturn'] != 'atrium' and self.back_phase in ('approach', 'head'):
            self.back_phase = 'ended'
        if self.actors['mimic'] != 'decision' and self.mimic_phase in ('watching', 'imitated'):
            self.mimic_phase = 'ended'
        return True

    def _node(self, token, actor=None, *, callback_epoch=None, avatar=False):
        if (not isinstance(token, tuple) or len(token) != 2 or token[0] != self.attempt
                or self.paused or self.dead or token in self.seen
                or (callback_epoch is not None and callback_epoch != self.epoch)):
            return False
        if actor is not None and (self.room != self.ROOMS[actor]
                                  or self.actors.get(actor) != self.ROOMS[actor]):
            return False
        if avatar and (self.avatar_blocked or self.clamp_phase == 'held'):
            return False
        self.seen.add(token)
        return True

    def back_approach(self, token, *, actual_visible=True, actual_near=True, callback_epoch=None):
        if not self._node(token, 'backturn', callback_epoch=callback_epoch):
            return False
        if not actual_near or not actual_visible or self.back_phase != 'idle':
            return False
        self.back_phase = 'approach'
        self._fact('backturn_started')
        return True

    def back_turn(self, token, *, part, actual_completed=True, callback_epoch=None):
        if not self._node(token, 'backturn', callback_epoch=callback_epoch):
            return False
        required = {'head': 'approach', 'torso': 'head'}
        if not actual_completed or required.get(part) != self.back_phase:
            return False
        self.back_phase = 'head' if part == 'head' else 'front'
        self._fact('backturn_' + part)
        return True

    def back_read(self, token, *, part, number=None, visible=True, readable=True,
                  callback_epoch=None):
        if not self._node(token, callback_epoch=callback_epoch, avatar=True):
            return False
        if self.room != 'atrium' or not visible or not readable:
            return False
        if part not in ('front', 'back', 'old_band', 'record'):
            return False
        if part in ('front', 'back') and self.actors['backturn'] != 'atrium':
            return False
        if part == 'front' and self.back_phase != 'front':
            return False
        if number != self.number:
            return False
        self.knowledge.add((part, number))
        if part == 'front':
            self.knowledge.add(('no_face', number))
        self._fact('number_read', part=part, number=number)
        return True

    @property
    def same_front_back_known(self):
        return all((part, self.number) in self.knowledge for part in ('front', 'back'))

    @property
    def recognized_number(self):
        return (('record', self.number) in self.knowledge
                and any((part, self.number) in self.knowledge for part in ('front', 'back', 'old_band')))

    def mimic_witness(self, token, *, event_id, movement, source='player', effective=True,
                     visible=True, actual_movement=True, callback_epoch=None):
        if not self._node(token, 'mimic', callback_epoch=callback_epoch):
            return False
        if (self.mimic_phase != 'idle' or not effective or not visible
                or not actual_movement or movement not in self.MOVES
                or source not in ('player', 'full_control')):
            return False
        self.mimic_event = (self.epoch, self.attempt, event_id)
        actual = {'movement': movement, 'source': source}
        if self.mimic_event in self.actual_actions and self.actual_actions[self.mimic_event] != actual:
            return False
        self.actual_actions[self.mimic_event] = actual
        self.mimic_phase = 'watching'
        self._fact('mimic_witness', event=self.mimic_event, **actual)
        return True

    def mimic_complete(self, token, *, actual_completed=True, callback_epoch=None):
        if not self._node(token, 'mimic', callback_epoch=callback_epoch):
            return False
        if not actual_completed or self.mimic_phase != 'watching':
            return False
        self.mimic_phase = 'imitated'
        self._fact('mimic_completed', event=self.mimic_event)
        return True

    def mimic_write(self, token, *, actual_completed=True, callback_epoch=None):
        if not self._node(token, 'mimic', callback_epoch=callback_epoch):
            return False
        if not actual_completed or self.mimic_phase != 'imitated':
            return False
        self.classifications[self.mimic_event] = '自主行为'
        self.mimic_phase = 'recorded'
        self._fact('mimic_written', event=self.mimic_event)
        return True

    def read_mimic(self, token, *, visible=True, readable=True, callback_epoch=None):
        if not self._node(token, callback_epoch=callback_epoch, avatar=True):
            return False
        if self.room != 'decision' or not visible or not readable or self.mimic_phase != 'recorded':
            return False
        self.knowledge.add(('mimic_record', self.mimic_event))
        return True

    def decision_actual(self, token, *, event_id, choice, actual=True, callback_epoch=None):
        if not self._node(token, callback_epoch=callback_epoch, avatar=True):
            return False
        key = (self.epoch, self.attempt, event_id)
        if self.room != 'decision' or not actual or choice not in ('接受', '拒绝') or key in self.actual_actions:
            return False
        self.actual_actions[key] = {'choice': choice, 'source': 'actual_decision'}
        self.classifications[key] = '已同意'
        self._fact('decision_recorded', event=key, choice=choice)
        return True

    def read_consent(self, token, *, visible=True, readable=True, callback_epoch=None):
        if not self._node(token, callback_epoch=callback_epoch, avatar=True):
            return False
        if self.room != 'decision' or not visible or not readable:
            return False
        self.knowledge.add(('consent_routing', '接受/拒绝→已同意'))
        return True

    def clamp_touch(self, token, *, actual_contact, hand_inside, callback_epoch=None):
        if not self._node(token, 'clamp', callback_epoch=callback_epoch, avatar=True):
            return False
        if self.clamp_used or not actual_contact or not hand_inside:
            return False
        self.clamp_used = True
        self.hand_inside = True
        self.clamp_phase = 'approach'
        self._fact('clamp_started')
        return True

    def clamp_step(self, token, *, step, actual_completed=True, visible_windup=True,
                   callback_epoch=None):
        if not self._node(token, 'clamp', callback_epoch=callback_epoch):
            return False
        stages = {'look': ('approach', 'looked'), 'grip': ('looked', 'gripped'),
                  'pull': ('gripped', 'windup')}
        if step not in stages or not actual_completed or stages[step][0] != self.clamp_phase:
            return False
        if step == 'pull' and (not visible_windup or self.avatar_blocked):
            return False
        self.clamp_phase = stages[step][1]
        self._fact('clamp_' + step)
        return True

    def hand_clear(self, token, *, actual, callback_epoch=None):
        if not self._node(token, callback_epoch=callback_epoch, avatar=True):
            return False
        if not actual or self.room != 'body' or self.clamp_phase == 'held':
            return False
        self.hand_inside = False
        self._fact('hand_cleared')
        return True

    def clamp_interrupt(self, token, *, actual_hit, callback_epoch=None):
        if not self._node(token, 'clamp', callback_epoch=callback_epoch):
            return False
        if not actual_hit or self.clamp_phase in ('idle', 'held', 'done'):
            return False
        self._cancel_clamp('operator_interrupted')
        return True

    def clamp_close(self, token, *, actual_contact, can_hold=True, callback_epoch=None):
        if not self._node(token, 'clamp', callback_epoch=callback_epoch):
            return False
        if self.clamp_phase != 'windup' or self.windup_ms < 800:
            return False
        if self.avatar_blocked or not can_hold:
            self._cancel_clamp('body_unavailable')
            return False
        if not self.hand_inside or not actual_contact:
            self.clamp_phase = 'done'
            self._fact('clamp_missed_reset')
            return True
        self.clamp_phase = 'held'
        self.held_ms = 0
        self.injury = self.pain_lamp = True
        self._fact('clamp_injury', hp=10, sp=0, region='hand')
        self._effect('clamp_hit', hp=10, sp=0, hold_ms=1000, region='hand', cancel_search=True)
        return True

    def _cancel_clamp(self, reason):
        if self.clamp_phase in ('idle', 'done'):
            return False
        held = self.clamp_phase == 'held'
        self.clamp_phase = 'done'
        self._fact('clamp_released' if held else 'clamp_cancelled', reason=reason)
        if held:
            self._effect('clamp_release', release=True)
        return True

    def clamp_read(self, token, *, lamp, record, visible=True, callback_epoch=None):
        if not self._node(token, callback_epoch=callback_epoch, avatar=True):
            return False
        if self.room != 'body' or not visible:
            return False
        if lamp and self.pain_lamp:
            self.knowledge.add(('pain_lamp', self.attempt))
        if record:
            self.knowledge.add(('record_normal', self.attempt))
        return bool((lamp and self.pain_lamp) or record)

    @property
    def pain_contradiction_known(self):
        return all((kind, self.attempt) in self.knowledge for kind in ('pain_lamp', 'record_normal'))

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if self.paused or self.dead:
            return False
        if self.clamp_phase == 'windup':
            self.windup_ms = min(800, self.windup_ms + ms)
        if self.clamp_phase == 'held':
            self.held_ms = min(1000, self.held_ms + ms)
            if self.held_ms >= 1000:
                self._cancel_clamp('timeout')
        return True

    def drain_effects(self):
        result, self.effects = self.effects, []
        return result

    def reload(self):
        return deepcopy(self)
