"""S3:P1185-1196, P1219-1257; S4:T17R5/R9. Abstract actual-event inputs.

No navigation/raycast simulation, key/lock mutation, resource reward or awakening.
Tokens are (actual_attempt, id), optionally coupled with callback_epoch for async use.
"""
from dataclasses import dataclass, field
from copy import deepcopy

LOOP = ('fork', 'bridge', 'index', 'fork')


@dataclass
class WhiteRoutes:
    attempt: int = 1
    epoch: int = 0
    room: str | None = None
    actors: dict = field(default_factory=dict)
    paused: bool = False
    dead: bool = False
    active: bool = True
    holder_free: bool = True
    body_generation: int = 0
    seen: set = field(default_factory=set)
    knowledge: set = field(default_factory=set)
    facts: list = field(default_factory=list)
    effects: list = field(default_factory=list)
    releases: list = field(default_factory=list)
    twitch_ms: int = 0
    crossing_count: int = 0
    waiting: bool = False
    original_target: object = None
    guidance: bool = False
    route_index: int = 0
    loop_arrived: bool = False
    face_used: bool = False
    face_phase: str = 'idle'
    face_elapsed: int = 0
    face_generation: int | None = None

    def _valid(self, token, actual=True, callback_epoch=None):
        return (actual and self.active and not self.dead and not self.paused
                and isinstance(token, tuple) and len(token) == 2
                and token[0] == self.attempt and token not in self.seen
                and (callback_epoch is None or callback_epoch == self.epoch))

    def _commit(self, token, action):
        self.seen.add(token)
        self.facts.append((self.attempt, action, token))

    @property
    def loop_known(self):
        return 'fork_bridge_index_fork' in self.knowledge

    @property
    def crossing(self):
        return self.twitch_ms < 1200 and self.actors.get('twitch') == 'rhythm'

    @property
    def held(self):
        return self.face_phase == 'held'

    @property
    def hold_remaining(self):
        return max(0, 1200 - self.face_elapsed) if self.held else 0

    def _finish_face(self, outcome):
        was_held = self.held
        self.face_phase = 'finished'
        self.face_elapsed = 0
        if was_held:
            self.releases.append((self.attempt, 'face', outcome))
        self.facts.append((self.attempt, 'face_end', outcome))

    def sync_context(self, *, attempt, epoch, room, actors, paused=False,
                     dead=False, active=True, holder_free=True, body_generation=0):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        if attempt > self.attempt:
            # Only a real attempt transition resets one-shot NPC opportunities.
            if self.held:
                self._finish_face('new_attempt')
            keep = {n: getattr(self, n) for n in ('knowledge', 'facts', 'effects', 'releases')}
            fresh = WhiteRoutes(attempt=attempt, epoch=epoch)
            self.__dict__.update(fresh.__dict__)
            self.__dict__.update(keep)
        elif epoch != self.epoch:
            # Old map callbacks may not resume after a level transition.
            if self.face_phase not in ('idle', 'finished'):
                self._finish_face('epoch_changed')
            self.guidance = self.loop_arrived = self.waiting = False
        self.epoch, self.room, self.actors = epoch, room, dict(actors)
        self.paused, self.dead, self.active = paused, dead, active
        self.holder_free, self.body_generation = holder_free, body_generation
        if self.face_phase not in ('idle', 'finished'):
            if dead or not active or room != 'exit' or actors.get('face') != 'exit':
                self._finish_face('context_left')
            elif self.face_phase != 'held' and (
                    not holder_free or self.face_generation != body_generation):
                self._finish_face('body_taken')
        if dead or not active:
            self.guidance = self.loop_arrived = self.waiting = False
        elif self.guidance and room != LOOP[self.route_index]:
            # Unrelated actual movement interrupts; route_step is the arrival API.
            self.guidance = self.loop_arrived = False
        return True

    def approach_twitch(self, token, *, target=None, actual=True, callback_epoch=None):
        if not self._valid(token, actual, callback_epoch) or self.room != 'rhythm':
            return False
        self._commit(token, 'approach_twitch')
        self.original_target = target
        self.waiting = self.crossing
        return True

    def pass_twitch(self, token, *, side=False, actual_clear=True, actual=True,
                    callback_epoch=None):
        if (not self._valid(token, actual, callback_epoch) or self.room != 'rhythm'
                or not actual_clear or (self.crossing and not side)):
            return False
        self._commit(token, 'side_pass' if side else 'gap_pass')
        self.waiting = False
        return True

    def observe_twitch(self, token, *, saw_stopped_feet_and_drag=True, callback_epoch=None):
        if (not self._valid(token, saw_stopped_feet_and_drag, callback_epoch)
                or self.room != 'rhythm' or self.actors.get('twitch') != 'rhythm'
                or 'twitch_drag' in self.knowledge):
            return False
        self._commit(token, 'observed_drag')
        self.knowledge.add('twitch_drag')
        return True

    def accept_guidance(self, token, *, seen=True, reliable_exit=False, actual=True,
                        callback_epoch=None):
        if (not self._valid(token, actual, callback_epoch) or self.room != 'fork'
                or self.actors.get('reverse') != 'fork' or not seen
                or reliable_exit or self.loop_known or self.guidance):
            return False
        self._commit(token, 'accept_guidance')
        self.guidance, self.loop_arrived, self.route_index = True, False, 0
        return True

    def route_step(self, token, destination, *, actual=True, clear=True, callback_epoch=None):
        """Record one actual door traversal; never teleport remaining route steps."""
        if (not self._valid(token, actual and clear, callback_epoch) or not self.guidance
                or self.route_index >= 3 or self.room != LOOP[self.route_index]
                or destination != LOOP[self.route_index + 1]):
            return False
        self._commit(token, ('route_arrival', destination))
        self.route_index += 1
        self.room = destination
        self.loop_arrived = self.route_index == 3
        return True

    def recognize_loop(self, token, *, actual_landmark=True, callback_epoch=None):
        if (not self._valid(token, actual_landmark, callback_epoch) or not self.guidance
                or not self.loop_arrived or self.room != 'fork'):
            return False
        self._commit(token, 'loop_recognized')
        self.knowledge.add('fork_bridge_index_fork')
        self.guidance = self.loop_arrived = False
        return True

    def interrupt_guidance(self, token, *, actual=True, callback_epoch=None):
        if not self._valid(token, actual, callback_epoch) or not self.guidance:
            return False
        self._commit(token, 'guidance_interrupted')
        self.guidance = self.loop_arrived = False
        return True

    def start_face(self, token, *, key, opening, seen=True, actual=True, callback_epoch=None):
        if (not self._valid(token, actual, callback_epoch) or self.face_used
                or self.room != 'exit' or self.actors.get('face') != 'exit'
                or not key or not opening or not seen or not self.holder_free):
            return False
        self._commit(token, 'face_approach')
        self.face_used, self.face_phase = True, 'approach'
        self.face_generation, self.face_elapsed = self.body_generation, 0
        return True

    def raise_face(self, token, *, reached=True, callback_epoch=None):
        if (not self._valid(token, reached, callback_epoch) or self.face_phase != 'approach'
                or self.room != 'exit' or self.actors.get('face') != 'exit'
                or not self.holder_free or self.face_generation != self.body_generation):
            return False
        self._commit(token, 'face_raise')
        self.face_phase, self.face_elapsed = 'raising', 0
        return True

    def contact_face(self, token, *, actual_contact, callback_generation=None,
                     callback_epoch=None):
        if (not self._valid(token, True, callback_epoch) or self.face_phase != 'ready'
                or self.room != 'exit' or self.actors.get('face') != 'exit'
                or not self.holder_free or self.face_generation != self.body_generation
                or (callback_generation is not None and callback_generation != self.body_generation)):
            return False
        self._commit(token, 'face_contact' if actual_contact else 'face_miss')
        if not actual_contact:
            self._finish_face('missed')
            return True
        self.face_phase, self.face_elapsed = 'held', 0
        self.effects.append({'id': (self.attempt, 'face'), 'hp': 0, 'sp': 15,
                             'hold': 1200, 'hold_ms': 1200})
        return True

    def interrupt_face(self, token, *, actual=True, callback_epoch=None):
        """Actual pre-contact interruption; skill success alone is insufficient."""
        if (not self._valid(token, actual, callback_epoch)
                or self.face_phase not in ('approach', 'raising', 'ready')):
            return False
        self._commit(token, 'face_interrupted')
        self._finish_face('interrupted')
        return True

    def release_face(self, token, *, actual=True, callback_epoch=None):
        if not self._valid(token, actual, callback_epoch) or not self.held:
            return False
        self._commit(token, 'face_released')
        self._finish_face('actual_release')
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative time')
        if self.paused or self.dead or not self.active:
            return False
        if self.actors.get('twitch') == 'rhythm':
            old = self.twitch_ms
            total = old + ms
            self.crossing_count += (total + 1500) // 2700 - (old + 1500) // 2700
            if self.waiting and old < 1200 and ms >= 1200 - old:
                self.waiting = False
            self.twitch_ms = total % 2700
        if self.face_phase == 'raising':
            self.face_elapsed = min(800, self.face_elapsed + ms)
            if self.face_elapsed == 800:
                self.face_phase = 'ready'
        elif self.held:
            self.face_elapsed += ms
            if self.face_elapsed >= 1200:
                self._finish_face('elapsed')
        return True

    def reload(self):
        return deepcopy(self)
