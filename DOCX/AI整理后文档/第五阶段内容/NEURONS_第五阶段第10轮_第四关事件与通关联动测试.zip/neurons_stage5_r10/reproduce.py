"""Reproduce R10 evidence without overwriting the original reports.
Modes: affected (default), current, failures, test-error. Use --list for selection.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
FILES = ['test_archive_events.py', 'test_cortex_events.py',
         'test_white_records.py', 'test_white_routes.py', 'test_s4_session.py']
AFFECTED = ['archive_impacted', 'archive_witness_impacted', 'cortex_impacted',
            'records_retest', 'routes_wait_fix', 'session_impacted']
ERROR = 'test_s4_session.py::test_mimic_does_not_duplicate_actual_skill_evidence_or_resources'
BATCHES = [
 ('archive_initial', 'archive_events.py', 'archive_events_initial.py', 'test_archive_events.py', 'archive_tests_initial.py'),
 ('archive_boundary_initial', 'archive_events.py', 'archive_events_initial.py', 'test_archive_events.py', 'archive_tests_boundary.py'),
 ('archive_witness_initial', 'archive_events.py', 'archive_events_pre_witness.py', 'test_archive_events.py', 'archive_tests_pre_witness.py'),
 ('cortex_initial', 'cortex_events.py', 'cortex_initial_cortex_events.py', 'test_cortex_events.py', 'cortex_initial_test_cortex_events.py'),
 ('records_initial', 'white_records.py', 'records_initial_white_records.py', 'test_white_records.py', 'records_initial_test_white_records.py'),
 ('records_boundary', 'white_records.py', 'records_initial_white_records.py', 'test_white_records.py', 'records_boundary_test_white_records.py'),
 ('routes_wait_boundary', 'white_routes.py', 'routes_pre_wait_fix_white_routes.py', 'test_white_routes.py', 'routes_pre_wait_fix_test_white_routes.py'),
 ('session_initial', 's4_session.py', 'session_initial_s4_session.py', 'test_s4_session.py', 'session_initial_test_s4_session.py'),
]

def rows(name):
    return json.loads((ROOT / 'results' / (name + '.json')).read_text(encoding='utf-8'))['tests']

def run(cwd, nodes, label, stamp, seed):
    report = ROOT / 'results' / f'reproduced_{stamp}_{label}.json'
    log = report.with_suffix('.log')
    env = dict(os.environ, RUN_REPORT=str(report))
    command = [sys.executable, '-m', 'pytest', *nodes, '-q',
               f'--hypothesis-seed={seed}', '--hypothesis-show-statistics']
    with log.open('w', encoding='utf-8') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    print(f'{label}: exit={result.returncode}; {log.name}')
    return result.returncode, report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', nargs='?', choices=['affected','current','failures','test-error'], default='affected')
    parser.add_argument('--seed', type=int, default=2026101310)
    parser.add_argument('--list', action='store_true', help='Show selected tests; do not execute')
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    if args.mode in ('affected', 'current'):
        nodes = FILES if args.mode == 'current' else sorted({r['test'] for name in AFFECTED for r in rows(name)})
        if args.list:
            print('\n'.join(nodes)); return 0
        return run(ROOT, nodes, args.mode, stamp, args.seed)[0]
    valid = True
    for label, module, old_module, test_file, old_tests in BATCHES:
        nodes = [r['test'] for r in rows(label) if r['outcome'] == 'failed'
                 and ((r['test'] == ERROR) == (args.mode == 'test-error'))]
        if not nodes:
            continue
        if args.list:
            print(label + ':\n' + '\n'.join(nodes)); continue
        with tempfile.TemporaryDirectory(prefix='neurons_r10_') as directory:
            temporary = Path(directory)
            for file in ROOT.glob('*.py'):
                shutil.copy2(file, temporary / file.name)
            shutil.copy2(ROOT / 'revisions' / old_module, temporary / module)
            shutil.copy2(ROOT / 'revisions' / old_tests, temporary / test_file)
            code, report = run(temporary, nodes, args.mode + '_' + label, stamp, args.seed)
            data = json.loads(report.read_text(encoding='utf-8')) if report.exists() else {}
            actual = {r['test']: r['outcome'] for r in data.get('tests', [])}
            expected = {node: 'failed' for node in nodes}
            # This mode succeeds only when the recorded pre-fix failures recur.
            if code != 1 or actual != expected:
                valid = False
                print('Unexpected reproduction result; inspect the new log.')
    return 0 if valid else 1

if __name__ == '__main__':
    raise SystemExit(main())
