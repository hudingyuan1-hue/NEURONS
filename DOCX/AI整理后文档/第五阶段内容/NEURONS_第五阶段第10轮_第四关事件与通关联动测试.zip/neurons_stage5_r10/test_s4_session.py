from collections import deque
from copy import deepcopy
import pytest
from hypothesis import settings,strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant
from s4_session import S4Session,EDGES,POINT_ROOMS,ACTOR_ROOMS
from archive_events import ArchiveEvents
from white_records import WhiteRecords
from ward_final_session import WardFinalSession

def records_fixture():
    event={'event_id':'refusal_fixture','patient_id':'patient_fixture',
        'truth':{'event_id':'refusal_fixture','patient_id':'patient_fixture','result':'refused','verified':True},
        'left':{'doc_id':'original','event_id':'refusal_fixture','patient_id':'patient_fixture','result':'refused'},
        'right':{'doc_id':'edited','event_id':'refusal_fixture','patient_id':'patient_fixture','result':'taken'},'avatar_witnessed':False}
    identity={'conflict_id':'identity_fixture','left':{'record_id':'id_a','status':'cancelled','face_id':'face_a','scar':'old'},
        'right':{'record_id':'id_b','status':'current','face_id':'face_a','scar':'new'}}
    label={'label_id':'name_tag','name':'fixture_name','patient_id':'patient_fixture','body_id':'body_fixture','fee_id':'fee_fixture','original_owner':'world','key_owned':False}
    return WhiteRecords(event=event,identity=identity,label=label)

class Driver:
    def __init__(self,key=61,attempt=1):
        self.s=S4Session(targets=tuple(range(7))+(28,)+tuple(range(31,38))+(61,),key_point=key,
            records=records_fixture(),archive=ArchiveEvents(facts={'fixture_event':{'subject':'fixture_subject','kind':'transfer'}}))
        self.s.life.attempts[4]=attempt;self.s.search.attempt=attempt;self.seq=0;self.s._sync()
    def n(self):self.seq+=1;return(self.s.life.epoch,self.seq)
    def a(self,group,name,**kw):return self.s.action(self.n(),group,name,**kw)
    def go(self,dest):
        q=deque([(self.s.position,[])]);seen={self.s.position}
        while q:
            room,path=q.popleft()
            if room==dest:
                for nextroom in path:assert self.s.move(self.n(),nextroom)
                return
            for e in EDGES:
                if room in e:
                    n=next(iter(e-{room}))
                    if n not in seen:seen.add(n);q.append((n,path+[n]))
        assert False,'no physical route'
    def clamp(self):
        self.go('body');self.s.actors['clamp']='body'
        ident=self.s.start_search(self.n(),28);assert ident
        assert self.a('cortex','clamp_touch',actual_contact=True,hand_inside=True)
        for step in ('look','grip','pull'):assert self.a('cortex','clamp_step',step=step)
        return ident
    def face(self,open_door=True):
        self.go('exit');self.s.search.key_owner='avatar';self.s.actors['face']='exit'
        assert self.s.begin_open(self.n())
        assert self.a('routes','raise_face')
        if open_door:assert self.s.unlock(self.n()) and self.s.push_door(self.n())
        assert self.s.tick(self.n(),800)
    def contradiction(self):
        self.go('bridge');self.s.actors['doublehead']='bridge'
        assert self.a('records','start_contradiction')
        for side in ('left','right'):assert self.a('records','hear_statement',side=side)
    def identity(self):
        self.go('identity');self.s.actors['doubleface']='identity'
        assert self.a('records','start_identity')
        for side in ('left','right'):
            assert self.a('records','read_identity',side=side)
            assert self.a('records','match_identity',side=side)
            assert self.a('records','see_match',side=side)
            assert self.a('records','see_face',side=side,turn_complete=True)

def test_canonical_graph_all_62_points_reachable_without_second_key_or_npc():
    s=S4Session()
    assert len(POINT_ROOMS)==62 and len(s.distances())==11
    assert list(POINT_ROOMS).count('atrium')==3
    assert sum(r in ('atrium','memory','visual','decision','body') for r in POINT_ROOMS)==31
    assert not s.life.rest()
    assert 'ward' not in s.distances() and 'S3' not in s.distances()

@pytest.mark.parametrize('seed',[0,1,5,6,1000000,2026101310])
def test_sampler_balances_floors_and_does_not_reroll_on_load_or_cancel(seed):
    s=S4Session(rng_seed=seed);original=(s.targets,s.search.key_point)
    assert len(set(s.targets))==16 and sum(p<31 for p in s.targets)==8 and s.search.key_point in s.targets
    s=s.reload();s.cancel_current();assert (s.targets,s.search.key_point)==original

def test_planner_cannot_read_hidden_key_and_bypasses_occupied_points():
    a=Driver(key=0).s;b=Driver(key=61).s
    assert a.next_point()==b.next_point()==0
    assert a.next_point(occupied=[0,1,2])==b.next_point(occupied=[0,1,2])
    assert a.search.used==b.search.used==0

def test_sixteen_canceled_attempts_do_not_end_level_or_block_seventeenth_search():
    d=Driver();s=d.s;start=(s.life.total,s.life.attempts[4],s.life.epoch)
    for _ in range(16):
        assert s.start_search(d.n(),0);assert s.cancel_action(d.n())
    assert s.search.used==16 and s.decision()=='search' and s.life.economy.n==5
    assert s.start_search(d.n(),0) and s.search.used==17
    assert (s.life.total,s.life.attempts[4],s.life.epoch)==start and not s.life.rest()

def test_first_floor_key_uses_second_floor_exit_without_optional_people():
    d=Driver(key=0);s=d.s;ident=s.start_search(d.n(),0)
    assert s.tick(d.n(),7000) and s.complete_search(d.n(),ident)
    assert s.decision()=='exit';d.go('exit');assert s.begin_open(d.n())
    assert s.unlock(d.n()) and s.push_door(d.n())
    assert s.damage_or_exit(d.n(),crossed=True)=='exit'
    assert s.life.progress==5 and s.life.place=='S5_atrium' and s.position=='atrium'
    assert not s.start_search(d.n(),0)

@pytest.mark.parametrize('attempt',[1,5,6,1000000])
def test_clamp_windup_release_damage_and_cancelled_search(attempt):
    d=Driver(attempt=attempt);ident=d.clamp();s=d.s
    assert s.tick(d.n(),799) and not d.a('cortex','clamp_close',actual_contact=True)
    assert s.life.hp==100
    assert s.tick(d.n(),1) and d.a('cortex','clamp_close',actual_contact=True)
    assert (s.life.hp,s.life.sp,s.holder)==(90,100,'clamp')
    assert ident not in s.search.pending and s.life.economy.n==5
    assert s.tick(d.n(),999) and s.holder=='clamp'
    assert s.tick(d.n(),1) and s.holder is None
    assert s.tick(d.n(),800) and s.gap==800
    assert not d.a('cortex','clamp_touch',actual_contact=True,hand_inside=True)

@pytest.mark.parametrize('withdraw',[False,True])
def test_cancel_search_is_not_automatic_hand_dodge(withdraw):
    d=Driver();d.clamp();s=d.s;assert s.cancel_action(d.n())
    if withdraw:assert d.a('cortex','hand_clear',actual=True)
    assert s.tick(d.n(),800) and d.a('cortex','clamp_close',actual_contact=True)
    assert s.life.hp==(100 if withdraw else 90) and s.search.used==1

def test_actual_operator_hit_cancels_pending_clamp_without_refund_or_damage():
    d=Driver();d.clamp();s=d.s
    assert d.a('cortex','clamp_interrupt',actual_hit=True)
    assert s.tick(d.n(),800) and not d.a('cortex','clamp_close',actual_contact=True)
    assert s.life.hp==100 and s.cortex.clamp_used

@pytest.mark.parametrize('sp',[1,10,100])
def test_contradiction_effect_once_per_save_not_attempt(sp):
    d=Driver();s=d.s;s.life.sp=sp;d.contradiction()
    assert s.life.sp==max(0,sp-10)
    assert s.tick(d.n(),1000);d.contradiction()
    assert s.life.sp==max(0,sp-10)
    assert s.damage_or_exit(d.n(),hp=100)=='death' and s.revive()
    d.contradiction();assert s.life.sp==100 and not s.awareness.evidence

def test_formal_statement_damage_can_finish_but_world_timers_remain_paused():
    d=Driver();d.go('bridge');s=d.s;s.actors['doublehead']='bridge'
    assert d.a('records','start_contradiction');s.paused=True
    for side in ('left','right'):assert d.a('records','hear_statement',side=side,formal_dialogue=True)
    assert s.life.sp==90 and not s.tick(d.n(),10000)

def test_identity_partial_completion_survives_room_return_only_complete_group_hurts():
    d=Driver();d.go('identity');s=d.s;s.actors['doubleface']='identity'
    assert d.a('records','start_identity')
    for side in ('left','right'):
        assert d.a('records','read_identity',side=side)
        assert d.a('records','match_identity',side=side)
        assert d.a('records','see_match',side=side)
    assert d.a('records','see_face',side='left') and s.life.sp==100
    d.go('exit');d.go('identity')
    assert d.a('records','see_face',side='right',turn_complete=True) and s.life.sp==90
    assert s.damage_or_exit(d.n(),hp=100)=='death' and s.revive();d.identity();assert s.life.sp==100

def test_label_removal_while_avatar_elsewhere_preserves_known_name_and_key():
    d=Driver();d.go('index');s=d.s;s.actors['blankface']='index';s.search.key_owner='avatar'
    assert d.a('records','read_original') and d.a('records','open_original')
    assert d.a('records','reach_label') and d.a('records','pinch_label')
    assert s.tick(d.n(),999);assert not s.records.label_removed
    d.go('bridge');assert s.tick(d.n(),1);assert s.records.label_removed
    assert ('name','fixture_name') in s.records.knowledge and s.search.key_owner=='avatar'
    d.go('index');assert d.a('records','query_name')=='not_found' and s.life.sp==100

def test_paper_search_and_reading_separate_npc_continues_after_leaving():
    d=Driver();d.go('memory');s=d.s;s.actors['stitched']='memory'
    ident=s.start_search(d.n(),4);assert ident and s.archive.paper_phase=='idle'
    assert s.cancel_action(d.n()) and d.a('archive','open_original')
    d.go('visual');assert d.a('archive','reach_paper') and d.a('archive','pinch_paper')
    assert s.tick(d.n(),1000) and s.archive.tear_ms==1000
    assert d.a('archive','interrupt_paper')
    assert s.tick(d.n(),5000) and s.archive.tear_ms==1000
    assert (s.life.hp,s.life.sp,s.life.economy.n)==(100,100,5)

def test_owned_page_and_read_information_survive_real_death_and_no_extra_key():
    d=Driver();d.go('memory');s=d.s;s.actors['stitched']='memory'
    assert d.a('archive','open_original')
    assert d.a('archive','read_fields',version='original',fields=['name'])
    assert d.a('archive','acquire_paper',piece='whole')
    assert s.damage_or_exit(d.n(),hp=100)=='death' and s.revive()
    assert s.archive.pieces=={'whole':'avatar'} and s.archive.read_values
    assert s.search.key_owner=='hidden' and s.position=='atrium'

def test_mimic_does_not_duplicate_actual_skill_evidence_or_resources():
    d=Driver();d.go('decision');s=d.s;s.actors['mimic']='decision'
    assert s.awareness.observe('actual_cast','skin',('decision','search',17))
    before=(s.life.hp,s.life.sp,s.life.economy.n,s.life.economy.c,len(s.awareness.evidence),s.awareness.stage)
    assert d.a('cortex','mimic_witness',event_id='actual_cast',movement='scratch')
    assert d.a('cortex','mimic_complete') and d.a('cortex','mimic_write')
    assert before==(s.life.hp,s.life.sp,s.life.economy.n,s.life.economy.c,len(s.awareness.evidence),s.awareness.stage)
    assert s.cortex.classifications[(s.life.epoch,s.life.attempts[4],'actual_cast')]=='自主行为'

def test_twitch_gap_or_side_keeps_target_no_search_charge_or_damage():
    d=Driver();d.go('rhythm');s=d.s;s.actors['twitch']='rhythm'
    assert d.a('routes','approach_twitch',target=35)
    assert not d.a('routes','pass_twitch',side=False)
    assert d.a('routes','pass_twitch',side=True)
    assert s.routes.original_target==35 and s.search.used==0 and s.life.hp==100

def test_actual_three_segment_loop_learned_and_survives_revive():
    d=Driver();d.go('fork');s=d.s;s.actors['reverse']='fork'
    assert d.a('routes','accept_guidance')
    assert not s.follow_guidance(d.n(),'index')
    for room in ('bridge','index','fork'):assert s.follow_guidance(d.n(),room)
    assert not s.routes.loop_known
    assert d.a('routes','recognize_loop',actual_landmark=True) and s.routes.loop_known
    assert s.damage_or_exit(d.n(),hp=100)=='death' and s.revive()
    d.go('fork');s.actors['reverse']='fork';assert not d.a('routes','accept_guidance')
    assert s.awareness.stage==0 and not s.life.economy.awakening

@pytest.mark.parametrize('door_open',[False,True])
def test_face_contact_releases_without_relocking_or_taking_key(door_open):
    d=Driver();d.face(open_door=door_open);s=d.s
    assert s.face_contact(d.n(),actual_contact=True)=='alive'
    assert (s.life.hp,s.life.sp,s.holder)==(100,85,'face') and s.search.key_owner=='avatar'
    assert s.door_open==door_open
    assert s.tick(d.n(),1199) and s.holder=='face'
    assert s.tick(d.n(),1) and s.holder is None
    assert s.begin_open(d.n()) and s.unlock(d.n()) and s.push_door(d.n())
    assert s.damage_or_exit(d.n(),crossed=True)=='exit' and s.life.sp==85

def test_actual_early_face_release_unblocks_authoritative_body_immediately():
    d=Driver();d.face();s=d.s;assert s.face_contact(d.n(),actual_contact=True)=='alive'
    assert s.tick(d.n(),200)
    assert d.a('routes','release_face',actual=True)
    assert s.holder is None and s.hold_remaining==0 and not s.blocked()

@pytest.mark.parametrize('sp,hp,expected',[(100,0,'exit'),(10,0,'exit'),(100,100,'death')])
def test_same_frame_face_contact_and_actual_exit_damage_before_transition(sp,hp,expected):
    d=Driver();d.face();s=d.s;s.life.sp=sp
    result=s.face_contact(d.n(),actual_contact=True,crossed=True,hp=hp)
    assert result==expected and s.life.sp==max(0,sp-15) and s.holder is None
    assert s.life.progress==(5 if expected=='exit' else 4)
    assert not d.a('routes','raise_face')

def test_pause_freezes_clamp_windup_and_npc_document_operations():
    d=Driver();d.clamp();s=d.s;s.paused=True
    assert not s.tick(d.n(),10000) and s.cortex.windup_ms==0
    assert not d.a('cortex','clamp_close',actual_contact=True)
    s.paused=False;assert s.tick(d.n(),800) and d.a('cortex','clamp_close',actual_contact=True)

def test_actual_s3_exit_binds_new_models_to_existing_epoch_and_preserves_life():
    source=WardFinalSession();source.life.epoch=7;source.life.progress=4;source.life.place='S4';source.life.hp=63
    s=S4Session.from_s3(source,records=records_fixture());d=Driver();d.s=s
    assert s.life.hp==63 and s.life.epoch==7 and 'corner' in s.prior
    d.go('bridge');s.actors['doublehead']='bridge';assert d.a('records','start_contradiction')

def test_death_clears_controls_but_preserves_wounds_and_rejects_old_callbacks():
    d=Driver();d.clamp();s=d.s;assert s.tick(d.n(),800)
    assert d.a('cortex','clamp_close',actual_contact=True);old=d.n()
    assert s.damage_or_exit(d.n(),hp=100)=='death' and s.holder is None
    total=s.life.total;attempt=s.life.attempts[4];assert s.revive()
    assert s.life.total==total+3 and s.life.attempts[4]==attempt+1
    assert any(f['kind']=='clamp_injury' for f in s.cortex.facts)
    assert not s.action(old,'cortex','clamp_close',actual_contact=True)

class S4Machine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.d.s.actors.update(ACTOR_ROOMS)
    @rule(dest=st.sampled_from(list(ACTOR_ROOMS.values())))
    def move(self,dest):self.d.s.move(self.d.n(),dest)
    @rule(point=st.integers(0,61))
    def search(self,point):self.d.s.start_search(self.d.n(),point)
    @rule()
    def complete(self):
        for t in list(self.d.s.search.pending):self.d.s.complete_search(self.d.n(),t)
    @rule()
    def cancel(self):self.d.s.cancel_action(self.d.n())
    @rule(ms=st.sampled_from([0,1,799,800,999,1000,1199,1200,2000,7000]))
    def tick(self,ms):self.d.s.tick(self.d.n(),ms)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused
    @rule()
    def touch(self):self.d.a('cortex','clamp_touch',actual_contact=True,hand_inside=True)
    @rule(step=st.sampled_from(['look','grip','pull']))
    def clampstep(self,step):self.d.a('cortex','clamp_step',step=step)
    @rule(contact=st.booleans())
    def close(self,contact):self.d.a('cortex','clamp_close',actual_contact=contact)
    @rule(name=st.sampled_from(['open_original','reach_label','pinch_label','query_name']))
    def index(self,name):self.d.a('records',name)
    @rule()
    def door(self):self.d.s.begin_open(self.d.n())
    @rule()
    def face(self):self.d.s.face_contact(self.d.n(),actual_contact=True,crossed=True)
    @rule()
    def death(self):self.d.s.damage_or_exit(self.d.n(),hp=100)
    @rule()
    def revive(self):self.d.s.revive()
    @rule()
    def reload(self):self.d.s=self.d.s.reload()
    @invariant()
    def consequences(self):
        s=self.d.s
        assert 0<=s.life.hp<=100 and 0<=s.life.sp<=100
        assert s.life.progress in (4,5) and not s.life.economy.awakening
        assert s.awareness.stage==0 and not s.awareness.evidence
        assert len(s.targets)==16 and sum(p<31 for p in s.targets)==8
        assert s.search.key_point in s.targets
        assert 0<=s.hold_remaining<=1200
        if s.life.phase=='dead' or s.life.progress==5:assert s.holder is None

TestS4Machine=S4Machine.TestCase
TestS4Machine.settings=settings(max_examples=250,stateful_step_count=85,deadline=None)
