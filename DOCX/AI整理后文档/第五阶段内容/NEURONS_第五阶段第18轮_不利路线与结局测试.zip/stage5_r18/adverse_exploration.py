"""R18 F exploration witnesses, S4:P264-276/T24-T28.

This is a finite policy over native rule models, not a navigation controller.
Graph-edge traversal, safe eating, and S1 arrival at/completion of ordinary bed
rest are supplied actual-event fixtures. No geometry, animation, spawn frequency
or universal survival claim is made. Target choice sees PublicPlan only.
"""
from collections import deque

from exploration_operations import ExplorationOperations
from rules import Life, search_ms
from search_sampling import AttemptSampler, CONFIG, build_host, next_point
from s2_skill_adapter import S2SkillAdapter
from s3_skill_adapter import S3SkillAdapter
from s4_skill_adapter import S4SkillAdapter


def graph_for(level):
    if level == 1:
        return set()
    if level == 2:
        return {frozenset(('waiting', r)) for r in ('ward', 'exam', 'pharmacy', 'office')}
    if level == 3:
        from s3_session import EDGES
    else:
        from s4_session import EDGES
    return EDGES


def room_for(level, host):
    return 'bedroom' if level == 1 else host.room if level == 2 else host.position


def paths_from(origin, edges):
    distance, paths, todo = {origin: 0}, {origin: []}, deque([origin])
    while todo:
        current = todo.popleft()
        for edge in sorted(edges, key=lambda x: sorted(map(str, x))):
            if current not in edge:
                continue
            dest = next(iter(edge - {current}))
            if dest not in paths:
                distance[dest] = distance[current] + 1
                paths[dest] = paths[current] + [dest]
                todo.append(dest)
    return distance, paths


def _record(trace, host, level, event, **facts):
    trace.append(dict(level=level, event=event, attempt=host.life.attempts[level],
                      n=host.life.economy.n, c=host.life.economy.c,
                      hp=host.life.hp, sp=host.life.sp, **facts))


def _absent(level, host):
    if level == 1:
        assert not host.dog and host.cat == 'absent'
        assert host.mother == host.father == 'absent'
    elif level == 2:
        host.people.patient_present = False
        host.people.assistant_present = False
        host.people.guard_present = False
        host.hospital.nurse_present = False
        host.transfer.guide_present = False
        host.transfer.patient_present = False
        host.transfer.worker_present = False
        host._pull()
    else:
        host.actors = dict.fromkeys(host.actors)
        host._sync()


def _configure(level, seed, life=None, source=None):
    if source is not None:
        if life is not None or level == 1 or source.life.progress != level:
            raise ValueError('source must have completed the preceding actual exit')
        if source.life.phase != 'alive':
            raise ValueError('a dead/transitioning source cannot enter exploration')
        if level == 2:
            host, sampler = build_host(2, seed, life=source.life)
        else:
            sampler = AttemptSampler(seed)
            plan = sampler.sync(source.life)
            if level == 3:
                from ward_final_session import WardFinalSession
                host = WardFinalSession.from_hospital(source)
                # Fresh entry only: from_hospital has a default Search fixture.
                # Install actual-attempt placement before any gameplay action.
                host.search = sampler.new_search(level)
                host.targets = plan.targets
            else:
                from s4_session import S4Session
                host = S4Session.from_s3(source, targets=plan.targets,
                                         key_point=sampler.placement(4).key_point,
                                         rng_seed=seed)
            sampler.bind_restarted_host(host)
    else:
        life = life if life is not None else Life(progress=level, place=f'S{level}')
        host, sampler = build_host(level, seed, life=life)
    _absent(level, host)
    op = None if level == 1 else ExplorationOperations(
        {2: S2SkillAdapter, 3: S3SkillAdapter, 4: S4SkillAdapter}[level](host))
    return host, sampler, op


def _move(level, host, op, destination, trace):
    origin = room_for(level, host)
    _, paths = paths_from(origin, graph_for(level))
    assert destination in paths, (level, origin, destination)
    for step in paths[destination]:
        before = room_for(level, host)
        identity = op.begin_autonomous('move', step)
        assert identity is not None
        facts = {'room': step} if level == 2 else {'dest': step}
        assert not op.complete_autonomous(identity, actual=False,
                                           route_clear=True, actual_crossing=True, **facts)
        assert op.complete_autonomous(identity, route_clear=True,
                                      actual_crossing=True, **facts)
        assert frozenset((before, room_for(level, host))) in graph_for(level)
        _record(trace, host, level, 'move', origin=before, destination=step)


def _wait_stun(level, host, op, trace):
    if not host.life.stun:
        return
    before_n, wait = host.life.economy.n, host.life.stun
    if level == 1:
        host.tick(wait - 1)
    else:
        assert op.tick(wait - 1)
    assert host.life.stun == 1
    if level == 1:
        host.tick(1)
    else:
        assert op.tick(1)
    assert host.life.stun == 0 and host.life.economy.n == before_n
    _record(trace, host, level, 'stun_wait', milliseconds=wait)


def choose_food(life):
    if life.hp <= 50:
        chocolate = next((k for k, v in life.food.items() if v == 'chocolate'), None)
        if chocolate is not None:
            return chocolate
    if life.sp <= 50:
        for kind in ('porridge', 'candy', 'chocolate'):
            item = next((k for k, v in life.food.items() if v == kind), None)
            if item is not None:
                return item
    return None


def _one_food(level, host, op, trace):
    """At most one existing food per actual safe decision gap, then reassess."""
    item = choose_food(host.life)
    if item is None:
        return False
    kind = host.life.food[item]
    used = host.search.used
    if level == 1:
        host.tick(1500)
        assert host.complete_eating(item)
        assert not host.complete_eating(item)
    else:
        identity = op.begin_food(automatic=True, safe=True)
        assert identity is not None
        assert op.tick(1499)
        assert not op.complete_food(identity)
        assert op.tick(1)
        assert op.complete_food(identity)
        assert not op.complete_food(identity)
    assert host.search.used == used and item not in host.life.food
    _record(trace, host, level, 'food', item=item, kind=kind, used=used)
    return True


def _rest(level, host, sampler, op, trace):
    assert level <= 3 and host.search.key_owner != 'avatar'
    old_attempt, old_total = host.life.attempts[level], host.life.total
    if level == 1:
        # Family has no ordinary-bed endpoint; these are actual reached-bed and
        # completed-safe-rest fixtures, not a timer or merely an intent to rest.
        _record(trace, host, level, 'bed_arrival', actual=True, room='bedroom')
        assert host.life.rest()
        host.search.restart(host.search.key_point)
        host._new_attempt()
    elif level == 2:
        _move(level, host, op, 'ward', trace)
        assert not host.rest(op.token('incomplete-bed-rest'), completed=False)
        assert host.rest(op.token('actual-bed-rest'), completed=True)
    else:
        _move(level, host, op, (1, 'ward'), trace)
        assert host.begin_rest(op.token('arrived-bed'))
        assert not host.complete_rest(op.token('incomplete-bed-rest'), actual=False)
        assert host.complete_rest(op.token('actual-bed-rest'), actual=True)
    assert host.life.attempts[level] == old_attempt + 1
    assert host.life.total == old_total + 1
    assert host.life.hp == host.life.sp == 100
    assert host.search.used == 0
    sampler.bind_restarted_host(host)
    _absent(level, host)
    _record(trace, host, level, 'rest', actual=True, used=host.search.used)


def _search(level, host, sampler, op, point, trace, cancel=False):
    before_n, income = host.life.economy.n, host.search.income
    ident = host.start_search(point) if level == 1 else op.start_search(point)
    assert ident is not None, (level, point, host.life.sp, host.search.used)
    if cancel:
        if level == 1:
            assert host.settle(ident, complete=False)
        else:
            # Voluntary actual hand withdrawal/cancel, never a paid skill.
            assert op.adapter.cancel_current_search()
        assert point not in host.search.complete and ident not in host.search.pending
        assert host.search.income == income and host.life.economy.n == before_n
        _record(trace, host, level, 'cancel', point=point, used=host.search.used)
        return
    duration = search_ms(level, 'normal', host.life.attempts[level], host.life.sp)
    if level == 1:
        host.tick(duration)
        assert host.settle(ident)
        assert not host.settle(ident)
    else:
        assert op.tick(duration - 1)
        assert not op.complete_search(ident)
        assert op.tick(1)
        assert op.complete_search(ident)
        assert not op.complete_search(ident)
        assert host.finish_feedback(op.token('feedback-finished'))
    assert host.search.income == income + 1
    assert host.life.economy.n == before_n + 1
    _record(trace, host, level, 'search', point=point, used=host.search.used,
            milliseconds=duration, room=room_for(level, host),
            acquired_key=host.search.key_owner == 'avatar')


def _exit(level, host, op, trace):
    assert host.search.key_owner == 'avatar'
    before_n, before_c = host.life.economy.n, host.life.economy.c
    if level == 1:
        assert host.cross_door() == 'S2'
    elif level == 2:
        _move(level, host, op, 'waiting', trace)
        assert not op.adapter.control('exit', actual_crossing=False)
        assert op.adapter.control('exit', actual_crossing=True)
    elif level == 3:
        _move(level, host, op, (2, 'stairs'), trace)
        assert host.damage_or_exit(op.token('actual-original-exit'), exit_actual=True) == 'exit'
    else:
        _move(level, host, op, 'exit', trace)
        assert host.begin_open(op.token('actual-key-open'), actual=True, seen=False)
        assert host.unlock(op.token('actual-unlock'))
        assert host.push_door(op.token('actual-push'))
        assert host.damage_or_exit(op.token('actual-original-exit'), crossed=True) == 'exit'
    assert host.life.progress == level + 1 and host.life.phase == 'alive'
    assert host.life.economy.n == before_n + 3
    assert host.life.economy.c == before_c + 2
    assert not host.search.pending
    _record(trace, host, level, 'exit', destination=level + 1)


def exploration_route(level, seed=2026101318, life=None, source=None, trace=None,
                      cancel_first=False):
    """Return the native host after a real key/door exit; no random NPC gifts.

    cancel_first=True cancels one start. An integer requests that many starts,
    allowing the S4 16-used/not-completed boundary without consulting the key.
    """
    trace = trace if trace is not None else []
    host, sampler, op = _configure(level, seed, life, source)
    cancelled_left = int(cancel_first)
    if cancelled_left < 0 or cancelled_left > 16:
        raise ValueError('finite fixture cancellation count must be 0..16')
    _record(trace, host, level, 'entry', optional_npcs_present=False)
    _wait_stun(level, host, op, trace)
    for _ in range(100):
        if host.search.key_owner == 'avatar':
            _exit(level, host, op, trace)
            host.adverse_trace = trace
            return host
        _one_food(level, host, op, trace)
        if level < 4 and (host.life.sp < 50 or host.search.used >= CONFIG[level][1]):
            _rest(level, host, sampler, op, trace)
            continue
        plan = sampler.sync(host.life)
        room = room_for(level, host)
        distances, _ = paths_from(room, graph_for(level))
        point = next_point(plan, room=room, distances=distances,
                           completed=host.search.complete,
                           pending=[p for _, p in host.search.pending.values()],
                           key_acquired=False)
        assert point is not None
        _move(level, host, op, plan.room_for(point), trace)
        _search(level, host, sampler, op, point, trace, cancel=cancelled_left > 0)
        cancelled_left = max(0, cancelled_left - 1)
    raise AssertionError('finite route witness exceeded its explicit 100-action bound')
