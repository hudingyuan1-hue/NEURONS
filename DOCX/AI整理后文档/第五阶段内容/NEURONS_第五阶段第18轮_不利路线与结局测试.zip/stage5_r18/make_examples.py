"""Produce two reviewable witnesses; not additional pytest/Hypothesis counts."""
from pathlib import Path
import json
from fractions import Fraction
from adverse_campaign import complete_campaign
from adverse_hidden import ready_hidden_route, evade_to_e1

def simple(x):
    if isinstance(x,Fraction):return {'numerator':x.numerator,'denominator':x.denominator}
    if isinstance(x,(set,frozenset)):return sorted(x,key=repr)
    raise TypeError(type(x).__name__)

root=Path(__file__).resolve().parent
dest=root/'examples';dest.mkdir(exist_ok=True)
j,hosts,out=complete_campaign(seed=17,sp=0,attempt=5,cancel_first=True)
normal=dict(route='S1 -> S2 -> S3 -> S4 -> S5 -> S6 -> E2',
 starting_fixture=dict(hp=1,sp=0,n=0,c=0,s1_attempt=5,initial_pending_stun_ms=1000),
 result=out,resource_account=out['trace'][-1],
 scope='Finite native-rule witness; actual movement/collision supplied. Full prehistory and engine navigation not established.')
route=ready_hidden_route(attempt=5)
assert evade_to_e1(route,side='right',paused_ms=40000)=='E1'
hidden=dict(route='S1 father carry -> hidden Street -> E1',events=route.trace,
 native_attack_facts=route.hidden.combat.facts,hp=route.life.hp,sp=route.life.sp,
 ending=route.life.phase,hunter_hp=route.hidden.hunter_hp,
 scope='Father trigger already satisfied; actual carry, fountain route and missed contact supplied.')
for name,data in [('normal_E2_trace.json',normal),('hidden_E1_trace.json',hidden)]:
    (dest/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=simple)+'\n')
print(json.dumps({'normal_events':len(out['trace']),'hidden_events':len(route.trace),
                  'normal_resources':normal['resource_account']},ensure_ascii=False))
