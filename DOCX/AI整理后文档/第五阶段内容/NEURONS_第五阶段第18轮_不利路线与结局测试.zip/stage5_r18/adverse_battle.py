"""R18 finite adverse S5 -> Street -> E2 routes through native model APIs.

Authority: S4:P264-288/T24R6-R8/T25R6-R9/T26/T28. The helper supplies
explicit actual navigation/visibility/contact facts, never a geometry proof.
Resources and player state are inputs: no free medicine, keys, kills or skills.
"""
from collections import deque
from copy import deepcopy

from s5_deep_session import CONNECTIONS
from deep_combat import DEEP_SPECS
from street_combat import STREET_SPECS


class BattleTrace:
    def __init__(self, journey, rows=None):
        self.j = journey
        self.rows = rows if rows is not None else []

    def state(self):
        h, life = self.j.current, self.j.life
        return dict(mode=self.j.mode, room=h.position, phase=life.phase,
                    hp=life.hp, sp=life.sp, stun=life.stun,
                    n=life.economy.n, c=life.economy.c,
                    attempts=life.attempts.copy(), epoch=life.epoch,
                    clock=h.combat.clock)

    def event(self, action, fn, **facts):
        before = self.state()
        result = fn()
        self.rows.append(dict(action=action, facts=deepcopy(facts),
                              before=before, result=deepcopy(result), after=self.state()))
        return result

    def call(self, method, *args, **facts):
        api = self.j.s5_call if self.j.mode == 's5' else self.j.street_call
        return self.event(method, lambda: api(self.j.token(method), method, *args, **facts),
                          args=args, **facts)

    def tick(self, ms):
        result = self.event('tick', lambda: self.j.tick(self.j.token('route_clock'), ms), ms=ms)
        assert result
        return result

    def move(self, dest):
        facts = dict(actual=True, passable=True)
        if self.j.mode == 's5' and self.j.life.progress == 5:
            # Failure inputs for all optional groups. A pre-admitted hostile
            # retains its one identity and cannot roll again.
            facts['rolls'] = dict.fromkeys(self.j.s5.schedule.groups, 9999)
        result = self.event('move', lambda: self.j.move(self.j.token('route_step'), dest, **facts),
                            destination=dest, **facts)
        assert result, (self.state(), dest)
        return result

    def walk(self, target):
        start = self.j.s5.host.position
        q, seen = deque([(start, [])]), {start}
        while q:
            room, path = q.popleft()
            if room == target:
                for dest in path:
                    self.move(dest)
                return
            for dest in sorted(CONNECTIONS[room]):
                if dest not in seen:
                    seen.add(dest)
                    q.append((dest, path + [dest]))
        raise AssertionError((start, target))

    def pause_probe(self):
        for paused, loading in ((True, False), (False, True)):
            self.j.set_pause(paused, loading=loading)
            before = self.state()
            clock = self.j.current.combat.clock
            assert not self.event('frozen_tick', lambda: self.j.tick(self.j.token('frozen'), 9000),
                                  paused=paused, loading=loading)
            dest = 'narrow' if self.j.mode == 'street' else next(iter(sorted(CONNECTIONS[self.j.current.position])))
            assert not self.event('frozen_move', lambda: self.j.move(self.j.token('frozen_move'), dest), destination=dest)
            assert self.state() == before and self.j.current.combat.clock == clock
            self.j.set_pause(False)


def evade_attack(t, actor, destination, *, pause_probe=False):
    """One actual windup, real adjacent departure, invalid remote hit, finite finish."""
    j = t.j
    specs = DEEP_SPECS if j.mode == 's5' else STREET_SPECS
    # A completed stun releases movement immediately, but a NEW grab still
    # needs the source's 800 ms free-body interval. Actual room callbacks do
    # not invent travel time or satisfy this interval by themselves.
    if specs[actor]['grab'] and j.current.free_gap < 800:
        t.tick(800 - j.current.free_gap)
    assert t.call('observe', actor, actual_visible=True)
    aid = t.call('start_attack', actor, direction=(1, 0), actual_seen=True,
                 range_ready=True, route_safe=True)
    assert aid is not None
    if pause_probe:
        t.pause_probe()
    hp, sp = j.life.hp, j.life.sp
    source = j.current.position
    t.move(destination)
    entity = j.s5.host.entity(actor) if j.mode == 's5' else j.street.people.entities[actor]
    assert not entity.sees_avatar
    t.tick(specs[actor]['windup'])
    assert t.call('frame', contacts=[dict(attack_id=aid, actual_contact=True)]) == 'alive'
    assert (j.life.hp, j.life.sp) == (hp, sp)
    assert not j.current.combat.attacks[aid]['hit_targets']
    t.tick(specs[actor]['active'] + specs[actor]['recovery'] + specs[actor]['cooldown'])
    assert j.current.combat.attacks[aid]['phase'] == 'finished'
    t.rows.append(dict(action='finite_threat_evaded', actor=actor, source=source,
                       destination=destination, attack_id=aid,
                       geometry_status='actual callbacks supplied; travel time not measured'))
    return aid


def _first_layers(t, optional_hostiles):
    j = t.j
    assert j.mode == 's5' and j.s5.host.position == 'atrium'
    if j.life.progress == 5:
        rolls = dict.fromkeys(j.s5.schedule.groups, 9999)
        if optional_hostiles:
            rolls['s5_father'] = 0
        t.event('s5_actual_initial_entry', lambda: j.s5.enter_current(j.token('arrival'), rolls=rolls), rolls=rolls)
        if optional_hostiles:
            batch = t.event('admit_hostile', lambda: j.s5.admit(j.token('father_ready'), ready=('S1_father',)),
                            actual_ready=('S1_father',))
            assert batch == ('S1_father',)
            evade_attack(t, 'father', 'decision')
    t.walk('hippocampus')
    assert j.s5.host.deep.original.present and j.s5.host.deep.original.alive
    assert not any(j.s5.host.entity(a).present for a in ('dog', 'nurse', 'corner', 'blank'))


def _deep_exit(t, pause_probe=False):
    j = t.j
    t.walk('thalamus')
    assert j.s5.host.deep.original.room == 'thalamus'
    evade_attack(t, 'original', 'cerebellum', pause_probe=pause_probe)
    assert j.s5.host.deep.original.mode == 'inspect'
    t.move('thalamus')
    t.move('brainstem')
    env = j.s5.host.environment
    # Wait only in a supplied reachable refuge: no contact is inferred from
    # merely being in the brainstem room. Then a real warning/active/gap cycle
    # is traversed by leaving and returning over the documented edge.
    if env.clock % 6000:
        t.move('thalamus')
        t.tick(6000 - env.clock % 6000)
        t.move('brainstem')
    assert env.phase == 'warning'
    hp = j.life.hp
    t.move('thalamus')
    t.tick(1500)
    assert env.phase == 'active'
    assert t.call('frame', pulse_contacts=[dict(entity='avatar', actual_contact=True,
                                               callback_cycle=env.cycle)]) == 'alive'
    assert j.life.hp == hp and not env.effects
    t.tick(300)
    assert env.phase == 'gap'
    t.move('brainstem')
    assert t.call('frame', cross_to_street=True) == 'street'
    assert j.mode == 'street' and len(j.street.people.entities) == 45


def _actual_street_death(t):
    """Deliberately fail to evade a finite sequence of real father contacts."""
    j = t.j
    assert j.street.position == 'plaza'
    t.call('enter_pending', entry_free=True)
    assert t.call('observe', 'n01', actual_visible=True)
    old_total, old_s5, old_s6 = j.life.total, j.life.attempts[5], j.life.attempts[6]
    for _ in range(7):  # native 15 HP contacts, HP is at most 100.
        aid = t.call('start_attack', 'n01', range_ready=True, route_safe=True)
        assert aid is not None
        t.tick(800)
        result = t.call('frame', contacts=[dict(attack_id=aid, actual_contact=True)])
        if result == 'death':
            break
        assert result == 'alive'
        t.tick(2400)
    else:
        raise AssertionError('seven completed 15 HP contacts must be fatal')
    assert j.life.phase == 'dead'
    assert t.event('revive', lambda: j.revive(j.token('actual_revival')))
    assert (j.life.total, j.life.attempts[5], j.life.attempts[6]) == (old_total+3, old_s5, old_s6+1)
    assert j.mode == 's5' and j.pending_registration is not None
    j.invariant()


def _street_exit(t, pause_probe=False):
    j = t.j
    for actor, dest in (('n01','narrow'), ('n12','street'), ('n17','node'), ('n32','exit')):
        t.call('enter_pending', entry_free=True)
        evade_attack(t, actor, dest, pause_probe=pause_probe and actor == 'n01')
    t.call('enter_pending', entry_free=True)
    evade_attack(t, 'n40', 'node')
    t.move('exit')
    assert t.call('frame', actual_body_exit=True) == 'E2'
    assert j.street.people.boost_layers == 0
    assert all(e.alive for e in j.street.people.entities.values())
    assert not any(e.activated for e in j.street.people.entities.values() if e.home in ('side','maintenance'))
    assert not j.street.support.used
    return j.street.ending


def battle_route(journey, trace=None, *, return_death=False,
                 pause_probe=False, optional_hostiles=False):
    """Complete native S5 (all floors) -> S6 -> E2; fixture must start in S5 atrium.

    State/resource fixtures belong to the caller. Optional hostile is the father,
    never a friendly source. No direct Life.finish_exit or fake success flag.
    """
    t = BattleTrace(journey, trace)
    life = journey.life
    initial = t.state()
    # A supplied zero-SP start must pass the canonical one-second first-empty
    # verdict. No repeated SP zero damage can renew that interval.
    assert t.call('frame') == 'alive'
    if life.stun:
        t.tick(life.stun)
    _first_layers(t, optional_hostiles)
    _deep_exit(t, pause_probe)
    if return_death:
        schedule = deepcopy(journey.s5.schedule.records), deepcopy(journey.s5.schedule.history)
        _actual_street_death(t)
        _first_layers(t, False)
        _deep_exit(t, pause_probe)
        assert (journey.s5.schedule.records, journey.s5.schedule.history) == schedule
    result = _street_exit(t, pause_probe)
    assert all(e.alive for e in journey.s5.host.entity_map().values())
    assert not journey.s5.host.support.used
    assert life.phase == 'ended' and result == 'E2'
    return dict(ending=result, initial=initial, final=t.state(), trace=t.rows,
                s5_random_friendly_used=False, healing_used=False, kills=0,
                street_registered=45, street_activated=sum(e.activated for e in journey.street.people.entities.values()),
                navigation_proof=False)
