"""R18 finite route coordinator, with no additional game effects.

S4:T24 normal S1 -> S6 -> E2. Native exits precede every handoff. Actual
navigation/contact/animation facts remain fixture inputs. This is not an AI
navigation implementation, a save schema, or an infinite-play proof.
"""
from copy import deepcopy

from adverse_exploration import exploration_route
from adverse_battle import battle_route
from rules import Life
from s5_deep_session import S5DeepSession
from spawn_host import SpawnHost
from return_journey import ReturnJourney


def attach_fresh_s5(source, seed=2026101318):
    """Wrap only a native, actual S4 exit; retain its canonical copied ledger.

    SpawnHost has no native-host injection API. Its unused construction fixture
    is discarded in full; only S5DeepSession.from_s4 creates the actual host.
    No value from that unused Life is ever transferred or credited.
    """
    native = S5DeepSession.from_s4(source)
    wrapper = SpawnHost(5, seed=seed, attempt=native.life.attempts[5])
    wrapper.host = native
    wrapper.bound = (native.life.epoch, native.life.attempts[5], native.life.total)
    wrapper.refresh()
    return ReturnJourney(wrapper)


def explore_campaign(seed=2026101318, sp=49, attempt=1, cancel_first=False, trace=None):
    rows = trace if trace is not None else []
    life = Life(hp=1, sp=sp, total=attempt)
    life.attempts[1] = attempt  # k-1 prior ordinary S1 rests, then actual damage.
    if sp == 0:
        life.stun, life.emptied = 1000, True  # actual depletion, first stop pending.
    life.economy.n = life.economy.c = 0
    life.economy.skills['skin'].resistance = 4
    life.economy.global_r = 2
    hosts = []
    for level in range(1, 5):
        host = exploration_route(level, seed=seed+level, life=life if level == 1 else None,
                                 source=hosts[-1] if hosts else None, trace=rows,
                                 cancel_first=cancel_first)
        assert host.life.progress == level+1 and host.life.phase == 'alive'
        assert not host.life.food and not host.life.economy.awakening
        assert host.life.economy.global_r == 2
        assert host.life.economy.skills['skin'].resistance == 4
        hosts.append(host)
    before = deepcopy(hosts[-1].life)
    journey = attach_fresh_s5(hosts[-1], seed)
    assert journey.life.economy.n == before.economy.n + 1  # native first atrium.
    assert journey.life.economy.c == before.economy.c
    assert journey.life.total == before.total and journey.life.attempts == before.attempts
    assert journey.life.economy.paid - before.economy.paid == {('explore',5,1,'atrium')}
    rows.append(dict(action='actual_S4_S5_handoff', n_before=before.economy.n,
                     n_after=journey.life.economy.n, c=journey.life.economy.c,
                     total=journey.life.total, attempts=journey.life.attempts.copy()))
    return journey, hosts, rows


def complete_campaign(seed=2026101318, sp=49, attempt=1, cancel_first=False, trace=None):
    j, hosts, rows = explore_campaign(seed,sp,attempt,cancel_first,trace)
    out = battle_route(j, rows)
    assert out['ending'] == 'E2' and j.life.progress == 6
    assert j.life.economy.c == 10  # five once-only unlocks, no food/conversion.
    assert {x for x in j.life.economy.paid if x[0]=='unlock'} == {
        ('unlock',k) for k in range(2,7)}
    assert j.life.economy.all_blocked()
    assert not j.life.economy.awakening and not j.life.food
    assert not j.street.support.used and not j.s5.host.support.used
    # Independent accounting: actual search completions + five 3N unlocks
    # + one N per distinct battle room. The initial low-SP safe rest alone
    # tops zero N up to five; later exhausted-budget rests already have >=5N.
    # Search/unlock income is >=5 before battle, so no battle regen is eligible.
    search_income = sum(h.search.income for h in hosts)
    explored_rooms = len([k for k in j.life.economy.paid if k[0]=='explore'])
    expected_n = search_income + 15 + explored_rooms + (5 if sp<50 else 0)
    assert j.life.economy.n == expected_n
    rows.append(dict(action='independent_final_resource_account',
                     search_completed=search_income, unlock_n=15, unlock_c=10,
                     battle_rooms=explored_rooms, initial_rest_floor=5 if sp<50 else 0,
                     battle_regeneration=0, n_expected=expected_n,
                     n_actual=j.life.economy.n, c_actual=j.life.economy.c))
    return j, hosts, out
