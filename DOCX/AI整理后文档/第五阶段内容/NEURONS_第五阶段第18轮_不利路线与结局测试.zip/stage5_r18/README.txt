NEURONS 第五阶段第18轮：F组不利配置路线与结局

结果
217个唯一测试节点最新均通过：探索83、战斗66、隐藏46、全流程22。
Hypothesis 6.169.0 实际最新通过样本308；无效5，不算通过。
首败17节点、17次失败观测；原始快照、日志、缩减反例与受影响复测均保留。
本轮结束F组既定模型范围，模型待处理0项，预计0轮。实机验收另计。

已做
S1–S4低精神/零资源/无可选人物：搜索、实际钥匙、原图出口、必要返床、食物优先级、S4取消16次后继续。
S5三层→S6→E2：无随机友军、无治疗、无击杀；活敌人实际起手、避让及有限恢复；Street死亡返回保留S5后再通关。
S1父亲实际带出→隐藏Street→E1：活猎手避让、致死边界、死亡重试、暂停/加载门控；另测母亲与高级救援替代出口。
连续S1→E2：原生跨关交接、真实JSON磁盘存读后继续、完整资源独立对账。
关键周目1/2/4/5/6/10^9；SP0/19/20/49/50及食品阈值；神经元4/5/9/10与兑换、重连边界。

失败分类与修订
1. 新增路线漏等抓握所需0.8秒身体自由空档：补真实计时，不改攻击规则。
2. 测试把250毫秒普通受击停顿当作重复失神：分别核验并等待正确停顿。
3. 新增HiddenRoute复活入口缺暂停/加载门控：拒绝冻结中提交，不消费回调。
4. S2缺席夹具漏掉转运患者与工人：补齐标记与直接检查。
5. S4高周目夹具误用休息总周目：改按死亡重启累计。
6. 全流程SP0初态漏挂首个1000毫秒失神：补正确初态并验证先等再返床。
7. 高抗性夹具超出全局抗性上限2：改用针对抗性承载高压值。
其中第3项为新增协调器行为缺陷；其余6类为测试/输入夹具问题。继承业务模型、原文、数值和对白均未改。
复测范围按依赖限定；共享夹具变化会影响其整个测试文件，未重跑A–E旧套件。

可复核证据
results/SUMMARY.json：去重后的最终节点、版本、真实样本数、各次运行顺序。
results/FAILURE_HISTORY.json：完整失败信息及快照/日志索引。
results/COVERAGE.json：原文锚点、已测范围、未覆盖与收尾判断。
snapshots/：每次执行前的Python文件及SHA256；历史失败不能用当前修订覆盖。
examples/normal_E2_trace.json：127个事件，示例实际搜寻22次，解锁15N/10C，探索14N，首休保底5N，结局56N/10C。
examples/hidden_E1_trace.json：实际带行、攻击事实和活猎手E1见证。
prior_round17/：先前证据归档，不计作本轮重新运行。
sources/：四份合并修订原文摘取与SHA256，已与第17轮逐字节核对不变。

运行
python3 -m pip install -r requirements.txt
python3 reproduce.py
只复测某项：python3 reproduce.py 'test_adverse_hidden.py::test_hidden_death_frozen_revive_does_not_commit_new_attempt_until_resumed'
重现历史失败（预期非零退出）：
python3 reproduce_failure.py r18_first_hidden_frozen_boundary 'test_adverse_hidden.py::test_hidden_death_frozen_revive_does_not_commit_new_attempt_until_resumed'
python3 summarize_round18.py
python3 make_examples.py
复现输出另存reproduction/，不会覆盖交付证据。示例导出不计入pytest或Hypothesis数量。

方法依据
https://hypothesis.readthedocs.io/en/latest/stateful.html
https://hypothesis.readthedocs.io/en/latest/tutorial/replaying-failures.html
本轮查阅页面版本6.169.0，依赖同版固定。组合生成配合明确断言；失败保留缩减输入、实际事件链、版本与快照。状态相等之外另有原文常量和逐项资源oracle。

边界与自省
这是条件明确的有限规则路线，零资源是起步状态，途中合法收入、休息及死亡恢复仍生效。
起始数值为边界压力夹具；不声称所有参数组合都具有已验证的完整前史。
实际通路、抓握、视线、接触与动画完成由外部事实夹具提供。移动耗时、物理避让窗口、全体敌人并发AI、未生成序列、无限周目及产品实机均未验收。
未新增对白或剧情，没有把规则模拟写成实机通过。范围未跑偏。
