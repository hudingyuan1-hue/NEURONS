"""R18 source-led S1 father -> hidden Street coordinator.

S3:P177-195/P312-337; S4:T24R9/P263-269. The opening parent draw is
already satisfied in these scenarios. Actual entry, approach, closed grasp,
carry, route clearance and collision are explicit test-fixture facts, not
computed geometry. No combatant is removed or resource supplied by this layer.
"""
from dataclasses import dataclass, field
from family import Family
from family_skill_bridge import FamilySkillBridge
from hidden_street import HiddenStreet


@dataclass
class HiddenRoute:
    family: Family = field(default_factory=Family)
    paused: bool = False
    loading: bool = False
    hidden: object = None
    trace: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    serial: int = 0

    def __post_init__(self):
        self.rescue = FamilySkillBridge(self.family)

    @property
    def life(self):
        return self.family.life

    def token(self, name):
        self.serial += 1
        return self.life.epoch, name, self.serial

    def _fresh(self, token):
        return (isinstance(token, tuple) and len(token) == 3
                and token[0] == self.life.epoch and token not in self.seen
                and self.life.phase == 'alive' and not self.paused and not self.loading)

    def _record(self, token, event, **facts):
        self.seen.add(token)
        self.trace.append(dict(token=token, event=event, facts=facts,
            hp=self.life.hp, sp=self.life.sp, neurons=self.life.economy.n,
            place=self.life.place, father=self.family.father))

    def set_pause(self, *, paused=False, loading=False):
        self.paused, self.loading = paused, loading
        self.rescue.paused, self.rescue.loading = paused, loading
        if self.hidden is not None:
            self.hidden.set_pause(paused=paused, loading=loading)

    def enter_father(self, token, *, actual_entry=False, entry_free=False):
        if not self._fresh(token) or not self.family.alive_home() or not actual_entry or not entry_free:
            return False
        result = self.family.appear('father')
        if result:
            self._record(token, 'father_actual_entry', branch=result)
        return result

    def father_action(self, token, action, *, actual_complete=False):
        """Complete the visible native phase only with its physical proof.

        This fixture uses the inherited canonical 2s approach, 1s visible
        grasp windup and 2s turn/carry phases. A blocked route is not an
        assertion of actual completion and cannot trigger the next phase.
        """
        phases = {'approach': ('approach', 2000), 'grasp': ('windup', 1000),
                  'carry': ('turn', 2000)}
        if (not self._fresh(token) or not actual_complete or action not in phases
                or not self.family.alive_home()):
            return False
        phase, elapsed = phases[action]
        if self.family.father != phase:
            return False
        self.rescue.tick(elapsed)
        self._record(token, 'father_' + action, actual_complete=True, game_ms=elapsed)
        return True

    def wait_home(self, token, ms):
        if (not self._fresh(token) or not self.family.alive_home()
                or self.family.father not in ('carry', 'saved', 'gone', 'absent')):
            return False
        if not self.rescue.tick(ms):
            return False
        self._record(token, 'home_game_time', game_ms=ms)
        return True

    def carry_crossing(self, token, *, actual_carry=False, actual_crossing=False, entry_free=False):
        if (not self._fresh(token) or not actual_carry or not actual_crossing or not entry_free
                or not self.family.alive_home() or self.family.father != 'carry'
                or not self.family.grabbed or not self.family.blood_gate or self.life.stun):
            return False
        # Family owns the only actual Life transition. HiddenStreet.enter()
        # cannot be called again after that transition: it would be a second
        # entry and epoch change. Initialize the encounter around the same Life.
        result = self.family.cross_door()
        if result != 'hiddenStreet':
            return False
        self.rescue.book.end_context('hidden_street_enter')
        self.rescue.effects.clear_transients()
        self.life.economy.battle = True
        self.hidden = HiddenStreet(life=self.life, entered=True, hunter_present=True)
        self.hidden.events.append(('actual_father_carry_entry', self.life.epoch))
        self._record(token, 'hidden_entry', actual_carry=True, actual_crossing=True, entry_free=True)
        return self.hidden

    def revive(self, token):
        if (not isinstance(token, tuple) or len(token) != 3 or token[0] != self.life.epoch
                or token in self.seen or not self.hidden or self.life.phase != 'dead'
                or self.paused or self.loading):
            return False
        # Family.revive owns S1 relocation and per-attempt event reset; it
        # delegates exactly once to Life.revive. Do not revive twice.
        if not self.family.revive():
            return False
        self.hidden = None
        self.rescue = FamilySkillBridge(self.family)
        self.paused = self.loading = False
        self._record(token, 's1_revive')
        return True


def ready_hidden_route(*, hp=16, sp=1, neurons=0, clusters=0, targeted_resistance=99,
                       attempt=1, cats_and_dog=False):
    """Adverse starting save, then genuine native event progression.

    The chosen initial HP/SP/resources/resistance are source-range fixture
    inputs, not changes mid-route or a proof that the full pre-save history is
    reachable. Global resistance stays at the two-awakening cap; arbitrarily
    high pressure is per-skill targeted resistance. No skill node beyond the
    default skin is granted.
    """
    family = Family(dog=cats_and_dog, cat='fighting' if cats_and_dog else 'absent')
    life = family.life
    life.hp, life.sp = hp, sp
    life.economy.n, life.economy.c, life.economy.global_r = neurons, clusters, 2
    life.economy.skills['skin'].resistance = targeted_resistance
    life.attempts[1] = attempt
    life.total = attempt  # a consistent initial save after k-1 ordinary rests
    route = HiddenRoute(family)
    assert route.enter_father(route.token('entry'), actual_entry=True, entry_free=True) == 'force'
    for action in ('approach', 'grasp', 'carry'):
        assert route.father_action(route.token(action), action, actual_complete=True)
    if life.stun:
        assert route.wait_home(route.token('finish_stun'), int(life.stun))
    assert route.carry_crossing(route.token('carry_exit'), actual_carry=True,
                                actual_crossing=True, entry_free=True)
    return route


def evade_to_e1(route, *, side='left', paused_ms=0):
    """Finite real-action fixture: visible lunge misses beside the fountain.

    Each actual_move/passable/occluded flag describes the fixture's supplied
    physical facts. There is no claim that this proves engine navigation.
    """
    if side not in ('left', 'right'):
        raise ValueError('fixture must choose a fountain side')
    h = route.hidden
    assert h and h.hunter_hp == 60 and h.hunter_present
    assert h.observe(h.token('seen'), 'entry', actual_visible=True)
    attack = h.start_attack(h.token('lunge'), actual_seen=True, range_ready=True, route_safe=True)
    assert attack is not None
    if paused_ms:
        before = h.life.hp, h.life.sp, h.life.economy.n, h.combat.clock
        route.set_pause(paused=True)
        assert not h.tick(h.token('paused'), paused_ms)
        assert (h.life.hp, h.life.sp, h.life.economy.n, h.combat.clock) == before
        route.set_pause()
    assert h.tick(h.token('windup'), 1000)
    assert h.move(h.token('sidestep'), 'fountain_' + side, actual_move=True, passable=True)
    assert h.frame(h.token('miss'), contacts=[dict(attack_id=attack, actual_contact=False)]) == 'alive'
    assert h.lose_sight(h.token('occluded'), actually_occluded=True)
    assert h.advance_attack(h.token('obstacle'), attack, actual_distance=0.6, actual_obstacle=True)
    assert h.check_last_seen(h.token('last_seen'), 'entry', actual_arrival=True, actual_check=True)
    assert h.patrol_arrival(h.token('patrol'), 'bench', actual_arrival=True, reachable=True, blocks_exit=False)
    assert h.move(h.token('exit_move'), 'exit', actual_move=True, passable=True)
    result = h.frame(h.token('actual_exit'), actual_exit_crossing=True)
    route.trace.append(dict(event='fountain_evade_exit', side=side, paused_ms=paused_ms,
                            attack_id=attack, outcome=result, hunter_hp=h.hunter_hp,
                            hunter_present=h.hunter_present, hp=h.life.hp, sp=h.life.sp))
    return result
