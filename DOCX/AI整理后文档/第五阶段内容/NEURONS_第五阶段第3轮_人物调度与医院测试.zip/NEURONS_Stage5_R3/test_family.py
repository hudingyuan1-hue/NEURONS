from copy import deepcopy
from itertools import product
import pytest
from hypothesis import given, settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, initialize, rule, invariant
from rules import Life, Economy, Skill, Search
from family import Family, ParentDraws, mother_branch, father_branch

def make(cat=False,dog=False,sp=100,hp=100):
    f=Family(dog=dog,cat='occupying' if cat else 'absent',life=Life(sp=sp,hp=hp),search=Search(key_point=9))
    e=f.life.economy; e.n=200; e.c=0
    # Test-only fixtures: known unlocked actions. Does not grant these in gameplay.
    for name,cost,power,cd in [('skin',1,1,2000),('gut',1,1,2000),('ear',1,1,2000),
        ('pores',1,1,2000),('withdraw',2,2,4000),('knee',2,2,4000),('startle',2,2,4000),
        ('fear',3,3,8000),('joy',3,3,8000),('control',5,4,20000)]:
        e.skills[name]=Skill(cost,power,cd)
    return f

@pytest.mark.parametrize('sp,cat,dog',list(product([0,99,100],[False,True],[False,True])))
def test_mother_branch_matrix(sp,cat,dog):
    f=make(cat,dog,sp)
    expected='porridge' if sp<100 else 'cat_chocolate' if cat else 'door_gift' if dog else 'leave'
    assert f.appear('mother')==expected
    assert not f.appear('mother')
    assert f.life.economy.n==200 and not f.life.food

@pytest.mark.parametrize('cat,dog',list(product([False,True],repeat=2)))
def test_father_branch_matrix(cat,dog):
    f=make(cat,dog)
    assert f.appear('father')==('force' if cat==dog else 'cat' if cat else 'dog')
    assert not f.appear('father')

@pytest.mark.parametrize('first',['mother','father'])
@pytest.mark.parametrize('cat,dog',list(product([False,True],repeat=2)))
def test_actual_parent_overlap_exclusive_collapse(first,cat,dog):
    f=make(cat,dog,sp=99)
    f.appear(first)
    assert f.appear('father' if first=='mother' else 'mother')=='collapse'
    assert f.life.phase=='dead' and f.life.hp==f.life.sp==0
    assert not f.complete_gift() and not f.complete_kill_dog() and not f.cross_door()
    assert f.revive() and not f.revive()
    assert (f.life.total,f.life.attempts[1],f.life.intruder)==(4,2,100001)
    assert f.life.economy.global_r==1

def test_parent_queue_does_not_mean_actual_overlap():
    p=ParentDraws()
    assert p.normal(2,0,0)==['mother','father']
    f=make(sp=100)
    f.appear(p.queue.pop(0)) # no animals, mother leaves.
    assert f.mother=='gone'
    assert f.appear(p.queue.pop(0))=='force' and f.life.phase=='alive'

@pytest.mark.parametrize('k,mother_limit,father_limit',[(1,12,8),(3,16,12),(5,20,16),(99,20,16)])
def test_parent_probability_boundaries(k,mother_limit,father_limit):
    p=ParentDraws(k=k)
    assert p.normal(2,mother_limit,father_limit)==[]
    assert p.normal(2,0,0)==[]
    assert p.normal(4,mother_limit-1,father_limit-1)==['mother','father']
    assert p.normal(6,0,0)==[]

def test_parent_checks_not_from_dialogue_or_extra_spam():
    p=ParentDraws()
    assert p.normal(2,0,0,paused=True)==[]
    assert p.normal(2,0,0,event_active=True)==[]
    assert p.normal(1,0,0)==[]
    assert p.extra('mother',0,paused=True) is False
    assert not p.extra('mother',99)
    assert not p.extra('mother',0)
    assert p.extra_used

def test_cat_three_turns_only_avatar_settlements():
    f=make(cat=True)
    f.tick(20000); assert f.cat_rounds==0
    for p in (2,3,4):
        token=f.start_search(p); assert token
        assert f.settle(token)
        assert not f.settle(token)
    assert f.cat=='exited' and f.cat_rounds==3 and f.cat_jumps==1 and f.cat_hits==0

def test_cat_blocked_key_is_not_completed_on_natural_exit():
    f=make(cat=True); f.search.key_point=1
    for _ in range(3): assert f.settle(f.start_search(1))
    assert f.search.used==3 and f.search.income==0 and 1 not in f.search.complete
    assert f.cat=='exited' and f.search.key_owner=='hidden'
    assert f.settle(f.start_search(1))
    assert f.search.key_owner=='avatar' and f.search.income==1

@pytest.mark.parametrize('prior_turns',[0,1,2])
def test_startle_reads_precancel_cat_target(prior_turns):
    f=make(cat=True)
    for p in range(2,2+prior_turns): f.settle(f.start_search(p))
    f.start_search(1)
    assert f.skill('skin')=='reacted'
    assert (f.life.hp,f.life.sp)==(90,90)
    assert f.cat_hits==f.cat_jumps==1 and f.cat=='exited'
    assert f.search.income==prior_turns

@pytest.mark.parametrize('mode',['resisted','no_external','wrong_point','preview'])
def test_no_spurious_cat_attack(mode):
    f=make(cat=True)
    f.start_search(2 if mode=='wrong_point' else 1)
    if mode=='resisted': f.life.economy.skills['skin'].resistance=1
    if mode!='preview': f.skill('skin',external=mode!='no_external')
    assert f.cat_hits==0 and f.life.hp==100

def test_lethal_cat_scratch_cannot_be_overridden_by_key():
    f=make(cat=True,hp=10)
    f.start_search(1); f.skill('skin')
    assert f.life.phase=='dead' and f.life.hp==0 and not f.cross_door()

def test_fight_pauses_both_animals_then_mother_only_evicts_cat():
    f=make(cat=True,dog=True)
    for p in (2,3,4):
        t=f.start_search(p,dog_point=5); assert len(f.search.pending)==1
        f.settle(t)
    assert f.cat_rounds==0 and f.search.dog_completed==0
    f.appear('mother'); assert f.selected_mother=='cat_chocolate'
    f.complete_cat_evict(); assert f.cat=='exited' and f.dog
    assert f.cat_hits==0
    f.complete_gift()
    assert list(f.life.food.values())==['chocolate'] and not f.gift_floor

def test_dog_starts_with_tenth_avatar_search():
    f=make(dog=True)
    for p in range(9): f.settle(f.start_search(p))
    token=f.start_search(10,dog_point=9)
    assert token and any(a=='dog' for a,p in f.search.pending.values())

def test_avatar_cancel_keeps_dog_action_and_no_double_reward():
    f=make(dog=True)
    avatar=f.start_search(2,dog_point=3)
    dog=next(t for t,(a,p) in f.search.pending.items() if a=='dog')
    f.skill('skin')
    assert avatar not in f.search.pending and dog in f.search.pending
    assert f.settle(dog) and not f.settle(dog)
    assert f.search.income==1 and f.life.economy.n==200

def test_father_kills_dog_and_drops_unhanded_key_without_healing():
    f=make(dog=True,sp=30,hp=30)
    f.start_search(2,dog_point=9)
    dog=next(t for t,(a,p) in f.search.pending.items() if a=='dog')
    f.settle(dog)
    assert f.search.key_owner=='dog'
    f.appear('father'); assert f.complete_kill_dog()
    assert not f.complete_kill_dog()
    assert f.search.key_owner=='ground' and not f.dog
    assert (f.life.hp,f.life.sp)==(30,30) and not f.unlock_s2
    assert f.life.economy.global_r==0
    assert f.life.economy.pending_g=={'dog_killed_by_father'}

@pytest.mark.parametrize('gifted',[False,True])
def test_collapse_cancels_unfinished_gift_but_keeps_delivered(gifted):
    f=make(sp=40); f.appear('mother')
    if gifted: assert f.complete_gift()
    before=(f.life.economy.n,f.life.economy.c)
    f.appear('father')
    assert list(f.life.food.values())==(['porridge'] if gifted else [])
    assert not f.complete_gift() and not f.complete_mother_rest()
    assert not f.unlock_s2 and (f.life.economy.n,f.life.economy.c)==before

def test_completed_eating_survives_collapse_once():
    f=make(sp=40); f.appear('mother'); f.complete_gift()
    item=next(iter(f.life.food))
    assert f.complete_eating(item) and not f.complete_eating(item)
    assert (f.life.economy.n,f.life.economy.c)==(205,1)
    f.appear('father'); f.revive()
    assert (f.life.economy.n,f.life.economy.c)==(205,1) and not f.life.food

@pytest.mark.parametrize('roll,expected',[(0,['candy']),(59,['candy']),(60,['chocolate']),(89,['chocolate']),(90,['candy','chocolate']),(99,['candy','chocolate'])])
def test_door_gift_draw_once_and_pickup_before_inventory(roll,expected):
    f=make(dog=True)
    f.appear('mother'); assert f.complete_gift(roll)
    assert list(f.gift_floor.values())==expected and not f.life.food
    assert not f.complete_gift(99-roll)
    item=next(iter(f.gift_floor)); assert f.pickup_gift(item) and not f.pickup_gift(item)
    assert not f.unlock_s2 and f.life.economy.n==200

def test_rest_interrupt_then_complete_unlock_once():
    f=make(sp=40); f.appear('mother'); f.complete_gift()
    item=next(iter(f.life.food)); f.complete_eating(item)
    assert f.life.sp==100 and f.mother=='bed'
    assert not f.complete_mother_rest(interrupted=True)
    assert f.life.total==1 and not f.unlock_s2
    assert f.complete_mother_rest() and not f.complete_mother_rest()
    assert f.life.total==2 and f.life.attempts[1]==2 and f.unlock_s2
    assert (f.life.economy.n,f.life.economy.c)==(208,3)
    assert f.cross_door()=='S2'
    assert (f.life.economy.n,f.life.economy.c)==(208,3)

def test_mother_branch_does_not_reroll_after_sp_changes():
    f=make(cat=True,sp=99); f.appear('mother')
    f.verdict([('heal_sp',1)])
    assert f.complete_gift() and list(f.life.food.values())==['porridge']

def test_new_attempt_allows_parents_again_after_mother_rest():
    f=make(sp=99); f.appear('mother'); f.complete_gift(); f.complete_mother_rest()
    assert f.appear('mother')=='leave'

@pytest.mark.parametrize('sp,delay',[(59,0),(60,1000),(61,2000),(100,41000)])
def test_cat_thought_threshold(sp,delay):
    f=make(cat=True,sp=sp); f.appear('father'); f.complete_cat_pickup()
    if delay:
        f.tick(delay-1); assert f.father=='thought'
        f.tick(1)
    assert f.father=='approach' and f.blood_gate

def test_pause_and_half_speed_pressure_clock():
    f=make(cat=True); f.appear('father'); f.complete_cat_pickup()
    f.tick(82000,paused=True,scale=.5); assert f.life.sp==100
    f.tick(81998,scale=.5); assert f.life.sp==60 and f.father=='thought'
    f.tick(2,scale=.5); assert f.life.sp==59 and f.father=='approach'

def test_already_effective_skill_wins_threshold_node():
    f=make(cat=True,sp=60); f.appear('father'); f.complete_cat_pickup()
    f.skill('fear'); f.tick(1000)
    assert f.father=='gone' and f.life.sp==45 and not f.rescue_exit
    assert not f.cross_door() # Thought expulsion does not grant S2 exit without key.

def test_late_skill_cannot_restore_thought_branch():
    f=make(cat=True,sp=60); f.appear('father'); f.complete_cat_pickup()
    f.tick(1000); assert f.father=='approach'
    f.skill('skin')
    assert f.father=='approach' and f.blood_gate

def test_food_does_not_revert_forced_carry_to_thought():
    f=make(cat=True,sp=60); f.appear('father'); f.complete_cat_pickup(); f.tick(1000)
    f.life.food['p']='porridge'; f.complete_eating('p')
    assert f.life.sp==100 and f.father=='approach' and f.blood_gate

def test_force_has_warning_and_no_double_pressure():
    f=make(); f.appear('father')
    f.tick(2999); assert not f.grabbed
    f.tick(1); assert f.grabbed and f.father=='turn' and f.life.sp==97
    assert not f.cross_door()
    f.tick(2000); assert f.father=='carry' and f.life.sp==95
    f.search.key_owner='avatar'
    assert f.cross_door()=='hiddenStreet'
    assert f.life.progress==1 and f.life.sp==95

@pytest.mark.parametrize('name',['fear','joy'])
def test_advanced_force_rescue_frees_grip_without_key(name):
    f=make(sp=10); f.appear('father'); f.tick(3000)
    assert f.grabbed
    assert f.skill(name)=='reacted'
    assert not f.grabbed and not f.blood_gate and f.rescue_exit
    if name=='fear':
        assert f.life.sp==0 and f.life.stun==1000 and not f.cross_door()
        f.tick(1000)
    assert f.cross_door()=='S2'

@pytest.mark.parametrize('hit,roll,expected',[(False,0,False),(True,69,True),(True,70,False),(True,99,False)])
def test_knee_rescue_probability_requires_actual_hit(hit,roll,expected):
    f=make(sp=50); f.appear('father')
    f.skill('knee',hit=hit,roll=roll)
    assert f.life.sp==(60 if expected else 50)
    assert (f.father=='stunned')==expected
    assert f.blood_gate and not f.rescue_exit

def test_startle_special_release_once_without_opening_gate():
    f=make(sp=50); f.appear('father'); f.tick(3000)
    assert f.skill('startle')=='reacted'
    assert not f.grabbed and f.life.sp==52 and f.blood_gate
    assert f.skill('startle')=='invalid' and f.life.sp==52

def test_withdraw_and_control_cannot_release_existing_grip():
    f=make(); f.appear('father'); f.tick(3000)
    before=f.life.economy.n
    assert f.skill('withdraw')==f.skill('control')=='invalid'
    assert f.grabbed and f.life.economy.n==before

@pytest.mark.parametrize('reason',['no_resource','resisted','interrupted'])
def test_failed_rescue_neither_clears_gate_nor_heals(reason):
    f=make(sp=50); f.appear('father'); f.tick(3000)
    if reason=='no_resource': f.life.economy.n=0
    if reason=='resisted': f.life.economy.skills['joy'].resistance=3
    f.skill('joy',actual=reason!='interrupted')
    assert f.grabbed and f.blood_gate and f.life.sp==47

class FamilySequence(RuleBasedStateMachine):
    @initialize(cat=st.booleans(),dog=st.booleans(),sp=st.sampled_from([0,19,49,59,60,99,100]))
    def start(self,cat,dog,sp):
        self.f=make(cat,dog,sp); self.tokens=[]
        self.dead=0; self.rests=0

    @rule(point=st.integers(0,10),dog_point=st.integers(0,10))
    def search(self,point,dog_point):
        t=self.f.start_search(point,dog_point)
        if t: self.tokens.append(t)

    @rule(index=st.integers(0,30),completed=st.booleans())
    def settle(self,index,completed):
        pending=list(self.f.search.pending)
        if pending: self.f.settle(pending[index%len(pending)],completed)

    @rule(parent=st.sampled_from(['mother','father']))
    def parent(self,parent): self.f.appear(parent)

    @rule(name=st.sampled_from(['skin','fear','joy','knee','startle']),hit=st.booleans(),roll=st.integers(0,99))
    def skill(self,name,hit,roll): self.f.skill(name,hit=hit,dodge=hit,roll=roll)

    @rule(ms=st.integers(0,10000),paused=st.booleans(),half=st.booleans())
    def time(self,ms,paused,half): self.f.tick(ms,paused,.5 if half else 1)

    @rule(action=st.sampled_from(['pickup_cat','evict_cat','kill_dog','gift','delivery','rest','door']))
    def complete(self,action):
        funcs={'pickup_cat':self.f.complete_cat_pickup,'evict_cat':self.f.complete_cat_evict,
            'kill_dog':self.f.complete_kill_dog,'gift':self.f.complete_gift,'delivery':self.f.complete_dog_delivery,
            'rest':self.f.complete_mother_rest,'door':self.f.cross_door}
        if funcs[action]() and action=='rest': self.rests+=1

    @rule()
    def eat(self):
        if self.f.life.food: self.f.complete_eating(next(iter(self.f.life.food)))

    @rule()
    def revive(self):
        if self.f.revive(): self.dead+=1

    @rule()
    def snapshot(self): self.f=deepcopy(self.f)

    @invariant()
    def valid_state(self):
        f=self.f
        assert 0<=f.life.hp<=100 and 0<=f.life.sp<=100
        assert f.life.economy.n>=0
        assert f.search.dog_completed<=3
        assert f.life.total==1+3*self.dead+self.rests
        assert f.life.intruder==100000+self.dead
        assert f.life.attempts[1]==1+self.dead+self.rests
        assert f.search.attempt==f.life.attempts[1]
        assert not(f.grabbed and not f.blood_gate)
        if f.life.phase=='dead': assert not f.search.pending
        if f.life.place=='S2': assert not f.blood_gate and not f.grabbed

TestFamilySequence=FamilySequence.TestCase
TestFamilySequence.settings=settings(max_examples=300,stateful_step_count=70,deadline=None,database=None)

@given(actions=st.lists(st.tuples(st.integers(1,10),st.integers(0,99),st.integers(0,99),st.booleans()),min_size=1,max_size=40), k=st.sampled_from([1,3,5,999]))
@settings(max_examples=300,deadline=None,database=None)
def test_parent_draw_sequences(actions,k):
    p=ParentDraws(k=k)
    for node,m,f,paused in actions:
        p.normal(node,m,f,paused=paused)
        p.extra('mother',f,paused=paused)
        assert len(p.queue)==len(set(p.queue))<=2
        assert p.checked_nodes <= {2,4,6,8}
