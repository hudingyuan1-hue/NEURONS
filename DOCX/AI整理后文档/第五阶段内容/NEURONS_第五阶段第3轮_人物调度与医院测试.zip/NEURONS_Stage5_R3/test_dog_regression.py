"""New S3:P48/P50/P97 expectations against the existing round-1 model."""
from rules import Search

def test_interrupted_dog_search_does_not_spend_three_completions():
    s=Search(key_point=9)
    for p in range(3):
        t=s.start(p,'dog'); assert t
        s.settle(t,'cancel')
    assert s.start(3,'dog') is not None

def test_dog_key_delivery_cancels_avatar_unfinished_search():
    s=Search(key_point=0)
    s.settle(s.start(0,'dog'))
    avatar=s.start(1)
    assert s.deliver()
    assert avatar not in s.pending
    assert not s.settle(avatar)
    assert s.income==1 and s.used==1

def test_avatar_key_stops_unfinished_dog_search():
    s=Search(key_point=0)
    dog=s.start(1,'dog'); avatar=s.start(0)
    assert s.settle(avatar)
    assert dog not in s.pending
    assert not s.settle(dog)
    assert s.income==1
