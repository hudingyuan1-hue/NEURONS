"""S1 integration: verdict batches and parent scheduling.

Caller supplies real action/arrival completion, not a click or queued actor.
This model does not simulate navigation, animations or frame-time collision.
Events with the same node must arrive in ONE batch; late partial batches are
rejected, not silently merged after a verdict. Node = (Life.epoch, node_id).
"""
from dataclasses import dataclass, field
from random import Random
from copy import deepcopy
from family import Family, ParentDraws

@dataclass
class S1Session:
    family: Family = field(default_factory=Family)
    seed: int = 2026101203
    paused: bool = False
    settled: int = 0
    feedback: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    arrival_nodes: set = field(default_factory=set)
    boundary_nodes: set = field(default_factory=set)

    def __post_init__(self):
        self.rng=Random(self.seed)
        self.epoch=self.family.life.epoch
        self.draws=ParentDraws(k=self.family.life.attempts[1])

    def sync(self):
        f=self.family
        if self.epoch!=f.life.epoch:
            self.epoch=f.life.epoch
            self.draws=ParentDraws(k=f.life.attempts[1])
            self.settled=0; self.feedback.clear(); self.seen.clear()
            self.arrival_nodes.clear(); self.boundary_nodes.clear()
        if not f.alive_home():
            self.feedback.clear(); self.draws.queue.clear()

    def active(self, node=None):
        self.sync()
        return (not self.paused and self.family.alive_home()
                and (node is None or node[0]==self.epoch))

    def record_avatar_settlement(self):
        self.settled+=1
        self.feedback.append(self.settled)

    def start_search(self, point, dog_point=None):
        if not self.active() or self.feedback: return None
        return self.family.start_search(point,dog_point)

    def finish_feedback(self, node, mother_roll=None, father_roll=None, first=None):
        if not self.active(node) or not self.feedback: return []
        counts=self.feedback[:]; self.feedback.clear()
        selected=[]
        for count in counts:
            if count not in (2,4,6,8) or self.family.event_busy(): continue
            m=self.rng.randrange(100) if mother_roll is None else mother_roll
            p=self.rng.randrange(100) if father_roll is None else father_roll
            order=self.rng.choice(('mother','father')) if first is None else first
            selected+=self.draws.normal(count,m,p,first=order)
        return selected

    def event_boundary(self, node, kind, other_roll=None):
        if (not self.active(node) or kind not in ('entry','gift_done','pre_grab','pre_door')
                or (node,kind) in self.boundary_nodes): return False
        self.boundary_nodes.add((node,kind))
        f=self.family
        present=('mother' if f.mother not in ('absent','gone') else
                 'father' if f.father not in ('absent','gone','saved') else None)
        if present is None: return False
        if self.draws.extra_used: return False
        other='father' if present=='mother' else 'mother'
        if other in self.draws.selected or other in f.appeared: return False
        roll=self.rng.randrange(100) if other_roll is None else other_roll
        return self.draws.extra(present,roll)

    def arrive_next(self, node, legal_boundary=True, extra_roll=None):
        # Actual entry completion at a legal boundary is an external fact.
        if (not self.active(node) or not legal_boundary or self.feedback
                or not self.draws.queue or node in self.arrival_nodes or node in self.seen): return False
        parent=self.draws.queue.pop(0)
        self.arrival_nodes.add(node)
        if parent in self.family.appeared: return False
        self.batch(node,[('arrive',parent)])
        self.event_boundary(node,'entry',extra_roll)
        return parent

    def batch(self, node, events):
        if not self.active(node) or node in self.seen: return 'ignored'
        self.seen.add(node)
        f=self.family
        ev=list(events)
        arrivals={v for k,v in ev if k=='arrive' and v in ('mother','father') and v not in f.appeared}
        # Physical presence in the same event space locks the exclusive scene
        # BEFORE an uncommitted gift/rest/exit can remove the first parent.
        active_parents={p for p,s in [('mother',f.mother),('father',f.father)]
                        if s not in ('absent','gone','saved')}
        if len(arrivals | active_parents)==2:
            f.appeared.update(arrivals); f.collapse(); self.sync(); return 'collapse'
        for parent in sorted(arrivals): f.appear(parent)

        physical=[('hp_damage',v) for k,v in ev if k=='damage']
        physical += [('sp_damage',v) for k,v in ev if k=='sp_damage']
        # Swallowed food is an actual completed effect. Duplicate item ids are
        # harmless because Life consumes the inventory entry exactly once.
        if not f.life.stun and not f.grabbed:
            physical += [('food',v) for k,v in ev if k=='eat']
        if physical:
            f.verdict(physical)
            if not f.alive_home(): self.sync(); return 'death'

        # Both searches already completed: settle helper first so key pickup
        # only cancels genuinely unfinished work. No fabricated completion.
        completed={v for k,v in ev if k=='search_done' and v in f.search.pending}
        pending=dict(f.search.pending)
        for token in sorted(completed,key=lambda t:(pending[t][0]!='dog',t)):
            actor=pending[token][0]
            if f.settle(token) and actor=='avatar': self.record_avatar_settlement()
        cancelled={v for k,v in ev if k=='search_cancel'}-completed
        for token in sorted(cancelled):
            actor=f.search.pending.get(token,(None,None))[0]
            if f.settle(token,False) and actor=='avatar': self.record_avatar_settlement()
        if any(k=='delivery' and v for k,v in ev): f.complete_dog_delivery()
        if any(k=='gift' for k,v in ev):
            f.complete_gift(next(v for k,v in ev if k=='gift'))
        if any(k=='exit' and v for k,v in ev): f.cross_door()
        if f.alive_home() and any(k=='rest' and v for k,v in ev): f.complete_mother_rest()
        self.sync()
        return f.life.phase

    def skill(self, name, **kwargs):
        if not self.active(): return 'invalid'
        f=self.family
        before={t for t,(a,p) in f.search.pending.items() if a=='avatar'}
        result=f.skill(name,**kwargs)
        if f.alive_home() and before-set(f.search.pending): self.record_avatar_settlement()
        self.sync()
        return result

    def tick(self, ms):
        if self.active(): self.family.tick(ms)
        self.sync()

    def revive(self):
        result=self.family.revive(); self.sync(); return result

    def reload(self):
        # Deep copy represents identical persisted state, not a tested disk save.
        return deepcopy(self)
