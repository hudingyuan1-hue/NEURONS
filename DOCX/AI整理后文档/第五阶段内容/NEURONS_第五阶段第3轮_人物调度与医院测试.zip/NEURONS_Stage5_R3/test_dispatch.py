from copy import deepcopy
import pytest
from hypothesis import given, settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, initialize, rule, invariant
from dispatch import S1Session
from family import Family
from rules import Search, Skill

def make(sp=99, dog=False, cat=False):
    s=S1Session(Family(dog=dog,cat='occupying' if cat else 'absent',search=Search(key_point=10)))
    s.family.life.sp=sp
    return s

def settle_two(s, roll_m=99, roll_f=99, first='mother'):
    for i in range(2):
        t=s.start_search(i+2)
        s.batch((s.epoch,i*3+1),[('search_done',t)])
        selected=s.finish_feedback((s.epoch,i*3+2),roll_m,roll_f,first)
    return selected

def snapshot(s):
    return (deepcopy(s.family),s.settled,list(s.feedback),deepcopy(s.draws),s.rng.getstate())

@pytest.mark.parametrize('outcome',['complete','cancel','cat_block'])
def test_only_actual_avatar_settlements_open_draws(outcome):
    s=make(cat=outcome=='cat_block')
    for i in range(2):
        t=s.start_search(1 if outcome=='cat_block' else i+2)
        assert s.settled==i
        s.batch((0,i*3+1),[('search_cancel' if outcome=='cancel' else 'search_done',t)])
        assert s.settled==i+1
        assert not s.start_search(8) # feedback must finish
        selected=s.finish_feedback((0,i*3+2),0,99)
        assert selected==(['mother'] if i==1 else [])
    assert s.draws.checked_nodes=={2}
    assert s.family.search.income==(2 if outcome=='complete' else 0)

def test_dog_settlement_does_not_add_avatar_node():
    s=make(dog=True); a=s.start_search(2,3)
    d=next(t for t,(actor,p) in s.family.search.pending.items() if actor=='dog')
    s.batch((0,1),[('search_done',d)])
    assert s.settled==0 and not s.feedback
    s.batch((0,2),[('search_done',a)])
    assert s.settled==1

def test_actual_skill_cancel_counts_once():
    s=make(); s.start_search(2)
    assert s.skill('skin')=='reacted'
    assert s.settled==1 and s.family.search.income==0
    s.skill('skin'); assert s.settled==1

@pytest.mark.parametrize('first',['mother','father'])
def test_both_selected_requires_two_actual_entry_nodes(first):
    s=make(); assert settle_two(s,0,0,first)==[first,'father' if first=='mother' else 'mother']
    assert not s.family.appeared and s.family.life.phase=='alive'
    assert s.arrive_next((0,8))==first
    assert not s.arrive_next((0,8))
    assert s.family.life.phase=='alive' and len(s.draws.queue)==1
    assert s.arrive_next((0,9))
    assert s.family.life.phase=='dead' and not s.draws.queue

def test_departed_parent_not_forced_to_wait_for_second():
    s=make(sp=100); settle_two(s,0,0)
    assert s.arrive_next((0,8))=='mother'
    assert s.family.mother=='gone'
    assert s.arrive_next((0,9))=='father'
    assert s.family.life.phase=='alive'

@pytest.mark.parametrize('k,limit',[(1,8),(2,10),(5,16),(6,16),(1000000,16)])
@pytest.mark.parametrize('hit',[False,True])
def test_extra_draw_once_at_actual_boundary(k,limit,hit):
    s=make(); s.family.life.attempts[1]=k; s.draws.k=k
    settle_two(s,0,99)
    assert s.arrive_next((0,8),extra_roll=limit-int(hit))=='mother'
    assert s.draws.extra_used
    assert s.draws.queue==(['father'] if hit else [])
    for kind in ('entry','gift_done','pre_grab','pre_door'):
        assert not s.event_boundary((0,9),kind,0)
    if hit:
        assert s.arrive_next((0,10))=='father'
        assert s.family.life.phase=='dead'

def test_paused_dialogue_does_not_draw_or_advance():
    s=make(); settle_two(s,0,99); s.paused=True
    before=snapshot(s)
    for i in range(15):
        s.arrive_next((0,i+10)); s.event_boundary((0,i+10),'entry',0)
        s.tick(1000); s.finish_feedback((0,i+10),0,0)
        s.batch((0,i+10),[('damage',10)])
    assert snapshot(s)==before
    s.paused=False
    assert s.arrive_next((0,30),extra_roll=99)=='mother'

def test_reload_preserves_draw_queue_attempt_and_rng():
    s=make(); settle_two(s,0,0)
    s.arrive_next((0,8)); t=s.reload()
    assert snapshot(t)==snapshot(s)
    assert s.arrive_next((0,9))==t.arrive_next((0,9))
    assert snapshot(t)==snapshot(s)

@pytest.mark.parametrize('ending',['death','rest','exit'])
def test_attempt_end_cancels_queue_and_stale_callbacks(ending):
    s=make(); settle_two(s,0,0)
    if ending=='death': s.batch((0,10),[('damage',100)]); s.revive()
    elif ending=='rest':
        s.arrive_next((0,10)); s.batch((0,11),[('gift',0)])
        s.batch((0,12),[('rest',True)])
    else:
        s.family.search.key_owner='avatar'
        s.batch((0,10),[('exit',True)])
    assert not s.draws.queue and not s.feedback
    before=snapshot(s)
    assert s.batch((0,99),[('damage',100),('arrive','father')])=='ignored'
    assert snapshot(s)==before
    if ending!='exit':
        assert s.settled==0 and not s.family.appeared
        assert s.draws.k==2 and s.family.life.attempts[1]==2

def test_repeated_batch_does_not_repeat_gift_or_resources():
    s=make(); s.batch((0,1),[('arrive','mother')]); s.batch((0,2),[('gift',0)])
    food=next(iter(s.family.life.food)); s.batch((0,3),[('eat',food)])
    before=snapshot(s)
    assert s.batch((0,3),[('eat',food)])=='ignored'
    assert snapshot(s)==before

def test_delivery_still_waits_for_actual_contact_and_cannot_bypass_grip():
    s=make(dog=True); s.family.search.key_owner='dog'; s.family.grabbed=True
    s.batch((0,1),[('delivery',True),('exit',True)])
    assert s.family.search.key_owner=='dog' and s.family.life.progress==1

def test_already_consumed_gift_not_undone_by_later_collapse():
    s=make(); s.batch((0,1),[('arrive','mother')]); s.batch((0,2),[('gift',0)])
    item=next(iter(s.family.life.food)); s.batch((0,3),[('eat',item)])
    n,c=s.family.life.economy.n,s.family.life.economy.c
    s.batch((0,4),[('arrive','father')])
    assert s.family.life.phase=='dead' and not s.family.life.food
    assert (s.family.life.economy.n,s.family.life.economy.c)==(n,c)

def test_reusing_consumed_node_cannot_drop_queued_parent():
    s=make(); settle_two(s,0,0)
    before=snapshot(s)
    assert not s.arrive_next((0,4)) # already search settlement node
    assert snapshot(s)==before

@settings(max_examples=300,deadline=None)
@given(k=st.integers(1,1000000),m=st.integers(0,99),f=st.integers(0,99),first=st.sampled_from(['mother','father']))
def test_integrated_probability_thresholds(k,m,f,first):
    s=make(); s.family.life.attempts[1]=k; s.draws.k=k
    actual=settle_two(s,m,f,first)
    step=min(k-1,4)
    expected={p for p,roll,limit in [('mother',m,12+2*step),('father',f,8+2*step)] if roll<limit}
    assert set(actual)==expected and len(actual)==len(expected)
    assert not s.family.appeared

class S1IntegratedMachine(RuleBasedStateMachine):
    @initialize(sp=st.sampled_from([0,49,50,59,60,99,100]),dog=st.booleans(),cat=st.booleans())
    def init(self,sp,dog,cat):
        self.s=make(sp,dog,cat); self.counter=100
    def node(self):
        self.counter+=1
        return (self.s.family.life.epoch,self.counter)
    @rule(point=st.integers(0,10),dog_point=st.integers(0,10))
    def start(self,point,dog_point): self.s.start_search(point,dog_point)
    @rule(complete=st.booleans())
    def finish(self,complete):
        ev=[('search_done' if complete else 'search_cancel',t) for t in self.s.family.search.pending]
        node=self.node(); self.s.batch(node,ev)
        before=snapshot(self.s); self.s.batch(node,ev); assert snapshot(self.s)==before
    @rule(m=st.integers(0,99),f=st.integers(0,99),first=st.sampled_from(['mother','father']))
    def feedback(self,m,f,first): self.s.finish_feedback(self.node(),m,f,first)
    @rule(roll=st.integers(0,99),legal=st.booleans())
    def entry(self,roll,legal): self.s.arrive_next(self.node(),legal,roll)
    @rule(paused=st.booleans())
    def pause(self,paused): self.s.paused=paused
    @rule(ms=st.sampled_from([0,1,999,1000,2999,5000]))
    def tick(self,ms): self.s.tick(ms)
    @rule(kind=st.sampled_from(['gift','rest','delivery','exit']),roll=st.integers(0,99))
    def action(self,kind,roll): self.s.batch(self.node(),[(kind,roll if kind=='gift' else True)])
    @rule()
    def skin(self): self.s.skill('skin')
    @rule()
    def eat(self):
        for item in list(self.s.family.life.food): self.s.batch(self.node(),[('eat',item)])
    @rule()
    def reload(self):
        before=snapshot(self.s); self.s=self.s.reload(); assert snapshot(self.s)==before
    @rule()
    def death_revival(self):
        self.s.batch(self.node(),[('damage',100)]); self.s.revive()
    @invariant()
    def safety(self):
        s=self.s; f=s.family
        assert 0<=f.life.hp<=100 and 0<=f.life.sp<=100
        assert 0<=s.settled<=10 and f.search.dog_completed<=3
        assert len(s.draws.queue)==len(set(s.draws.queue))
        assert set(s.draws.queue)<=s.draws.selected
        assert not set(s.draws.queue)&f.appeared
        assert f.life.economy.n>=0 and f.life.economy.c>=0
        assert len(f.search.complete)==f.search.income or f.search.attempt>1
        if f.life.phase=='dead': assert not f.search.pending and not s.draws.queue

TestS1Integrated=S1IntegratedMachine.TestCase
TestS1Integrated.settings=settings(max_examples=300,stateful_step_count=70,deadline=None)
