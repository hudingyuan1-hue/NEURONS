"""Actual simultaneous facts, not input clicks.

REPLAY_LEGACY=1 audits exposed round-2 Family calls in callback order.
It does not claim that Unity uses this adapter or has these defects.
"""
import os
from itertools import permutations
import pytest
from rules import Search
from family import Family

def apply(f, events):
    if os.environ.get('REPLAY_LEGACY') == '1':
        for kind, value in events:
            if kind == 'arrive': f.appear(value)
            elif kind == 'gift': f.complete_gift(value)
            elif kind == 'rest': f.complete_mother_rest()
            elif kind == 'eat': f.complete_eating(value)
            elif kind == 'damage': f.verdict([('hp_damage', value)])
            elif kind == 'search_done': f.settle(value)
            elif kind == 'search_cancel': f.settle(value, False)
            elif kind == 'delivery': f.complete_dog_delivery()
            elif kind == 'exit': f.cross_door()
        return
    from dispatch import S1Session
    S1Session(family=f).batch((f.life.epoch, 1), events)

@pytest.mark.parametrize('order',list(permutations(range(2))))
def test_simultaneous_completed_searches_keep_both_rewards(order):
    f=Family(dog=True,search=Search(key_point=0))
    a=f.start_search(0,1)
    d=next(t for t,(actor,_) in f.search.pending.items() if actor=='dog')
    ev=[('search_done',a),('search_done',d)]
    apply(f,[ev[i] for i in order])
    assert f.search.complete=={0,1}
    assert f.search.income==2 and f.life.economy.n==7
    assert f.search.key_owner=='avatar' and not f.search.pending

@pytest.mark.parametrize('order',list(permutations(range(2))))
def test_dog_delivery_preserves_same_node_actual_avatar_completion(order):
    f=Family(dog=True,search=Search(key_point=1))
    a=f.start_search(0,1)
    d=next(t for t,(actor,_) in f.search.pending.items() if actor=='dog')
    f.settle(d)
    ev=[('search_done',a),('delivery',True)]
    apply(f,[ev[i] for i in order])
    assert f.search.complete=={0,1} and f.search.income==2
    assert f.search.key_owner=='avatar'

@pytest.mark.parametrize('order',list(permutations(range(2))))
def test_actual_overlap_beats_uncommitted_porch_gift(order):
    f=Family(dog=True)
    f.appear('mother')
    ev=[('arrive','father'),('gift',99)]
    apply(f,[ev[i] for i in order])
    assert f.life.phase=='dead' and f.life.economy.pending_g=={'parent_collapse'}
    assert not f.gift_floor and not f.life.food

@pytest.mark.parametrize('order',list(permutations(range(2))))
def test_actual_overlap_beats_uncommitted_rest(order):
    f=Family(); f.life.sp=99
    f.appear('mother'); f.complete_gift()
    original_food=dict(f.life.food)
    ev=[('arrive','father'),('rest',True)]
    apply(f,[ev[i] for i in order])
    assert f.life.phase=='dead' and not f.unlock_s2
    assert f.life.total==1 and f.life.epoch==0
    assert f.life.food==original_food

@pytest.mark.parametrize('order',list(permutations(range(3))))
def test_same_node_lethal_damage_not_erased_by_food_or_exit(order):
    f=Family(); f.life.hp=10; f.life.food['c']='chocolate'; f.search.key_owner='avatar'
    ev=[('eat','c'),('damage',10),('exit',True)]
    apply(f,[ev[i] for i in order])
    assert f.life.phase=='dead' and f.life.progress==1
    assert f.life.food=={'c':'chocolate'} and f.life.economy.n==5

@pytest.mark.parametrize('order',list(permutations(range(2))))
def test_actual_completion_precedes_same_node_cancellation_request(order):
    f=Family(search=Search(key_point=9)); a=f.start_search(0)
    ev=[('search_done',a),('search_cancel',a)]
    apply(f,[ev[i] for i in order])
    assert f.search.income==1 and f.search.complete=={0}

