"""Reproduce archived failures in temporary directories, without reverting fixes."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
cases=[
    ('legacy_order', {'rules.py':'revisions/r2_rules.py','family.py':'revisions/r2_family.py',
                      'test_s1_atomic.py':'test_s1_atomic.py'},
     ['test_s1_atomic.py'], {'REPLAY_LEGACY':'1'}),
    ('queue_node', {'rules.py':'rules.py','family.py':'family.py',
                    'dispatch.py':'revisions/dispatch_initial.py','test_dispatch.py':'test_dispatch.py'},
     ['test_dispatch.py','-k','reusing_consumed_node'], {}),
]
for name,files,selected,extra in cases:
    with tempfile.TemporaryDirectory(prefix='neurons-r3-') as tmp:
        for dest,src in files.items(): shutil.copy2(ROOT/src,Path(tmp)/dest)
        env=dict(os.environ); env.update(extra)
        run=subprocess.run([sys.executable,'-m','pytest','-q',*selected,
                            '--hypothesis-seed=2026101203'],cwd=tmp,env=env,
                           text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        output=ROOT/'results'/f'reproduced_{name}.log'
        output.write_text(run.stdout,encoding='utf-8')
        print(f'{name}: expected pytest exit 1; actual {run.returncode}; {output.name}')
        if run.returncode!=1: raise SystemExit('Failure reproduction did not return the expected result.')
