from copy import deepcopy
from itertools import product
import pytest
from hypothesis import given, settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from hospital import Hospital


def cup(h):
    assert h.give_prescription()
    assert h.prepare()
    assert h.take_cup()
    assert h.raise_cup()


def guard(h):
    h.guard_present = True
    assert h.file_report()
    assert h.receive_report()
    assert h.approach_guard()


@pytest.mark.parametrize('sp,expected,decision',[(100,85,'search'),(65,50,'search'),(64,49,'bed'),(15,0,'bed'),(0,0,'bed')])
def test_medicine_actual_effect_and_low_sp_route(sp,expected,decision):
    h=Hospital(sp=sp)
    cup(h)
    assert not h.swallow()
    h.tick(999)
    assert not h.swallow()
    h.tick(1)
    assert h.sp == sp
    assert h.swallow() and h.sp == expected and h.hp == 100
    assert not h.swallow()
    assert h.route_decision(key=True) == 'wait_effect'
    h.tick(999)
    assert h.route_decision() == 'wait_effect'
    h.tick(1)
    assert h.route_decision() == decision
    assert h.route_decision(key=True) == 'exit'
    assert h.medication_count == 1


@pytest.mark.parametrize('stage', ['prescription','prepared','held','raising'])
def test_interrupted_handover_is_not_swallow_or_refusal(stage):
    h=Hospital()
    assert not h.give_prescription(actual=False)
    assert h.give_prescription()
    if stage=='prescription':
        assert not h.prepare(actual_handover=False)
        assert h.cup == 'none'
    else:
        assert h.prepare()
        if stage in ('held','raising'):
            assert h.take_cup()
            if stage=='raising':
                assert h.raise_cup()
                h.tick(999)
            ident=h.cup_id
            assert h.interrupt_cup()
            assert h.take_cup() and h.cup_id==ident
    assert h.sp==100 and not h.medicine_closed and not h.refusal_witnessed


@pytest.mark.parametrize('closed', ['refuse','swallow'])
def test_medicine_closed_cannot_reopen_by_new_order(closed):
    h=Hospital()
    cup(h)
    h.tick(1000)
    assert getattr(h,closed)()
    for prescription in ('patient','replacement','new-order'):
        h.give_prescription(prescription)
        assert not h.prepare()
    assert h.medication_count == int(closed=='swallow')


@pytest.mark.parametrize('witness,complete_seen',list(product([False,True],repeat=2)))
def test_false_label_not_actual_medicine(witness,complete_seen):
    h=Hospital()
    h.give_prescription();h.prepare()
    assert h.refuse(nurse_witness=witness)
    assert h.complete_false_label(witnessed_complete=complete_seen)==witness
    assert h.false_label_known == (witness and complete_seen)
    assert h.sp==100 and h.medication_count==0 and h.cup=='refused'
    assert not h.complete_false_label(witnessed_complete=True)


def test_nurse_cannot_witness_from_another_room_during_bandage():
    h=Hospital(hp=50)
    h.start_bandage()
    h.give_prescription();h.prepare();h.refuse(nurse_witness=True)
    assert not h.complete_false_label(True)
    assert not h.healed


@pytest.mark.parametrize('knowledge', ['drug','false_label'])
def test_medication_danger_memory_survives_real_attempt(knowledge):
    h=Hospital()
    h.drug_history=knowledge=='drug'
    h.false_label_known=knowledge=='false_label'
    h.new_attempt();h.give_prescription();h.prepare()
    assert h.take_cup() and h.cup=='refused' and h.sp==100


def test_pause_and_joy_do_not_remove_drug_stop():
    h=Hospital(sp=15);cup(h);h.tick(1000);h.swallow()
    assert (h.drug_stop,h.empty_stop)==(1000,1000)
    h.restore_sp(20)
    assert h.sp==20 and h.drug_stop==1000
    h.paused=True
    before=deepcopy(h.__dict__)
    h.tick(100000)
    assert h.__dict__==before
    h.paused=False;h.tick(1000)
    assert h.route_decision()=='bed'


@pytest.mark.parametrize('delay,valid',[(0,True),(1999,True),(2000,True),(2001,False),(3999,False)])
def test_sample_completion_bounded_by_grip_deadline(delay,valid):
    h=Hospital()
    h.begin_exam();h.grip_exam();h.tick(delay)
    assert h.hp==100
    assert h.insert_needle()
    h.tick(10000)
    assert h.hp==95 and h.needle_count==1
    assert h.sample_valid==valid
    assert h.sample_interrupted != valid
    assert h.holder is None and h.exam_closed
    assert not h.insert_needle() and not h.begin_exam()


@pytest.mark.parametrize('elapsed',[0,1,1999])
def test_interrupted_sample_preserves_damage_not_sample(elapsed):
    h=Hospital();h.begin_exam();h.grip_exam();h.insert_needle();h.tick(elapsed)
    assert not h.withdraw()
    assert not h.doctor_hit_releases(actual=False)
    assert h.doctor_hit_releases()
    h.tick(10000)
    assert h.hp==95 and not h.sample_valid and h.sample_interrupted
    assert h.give_prescription() and h.prepare()


def test_no_needle_if_grip_missing_and_no_phantom_sample_on_death():
    h=Hospital(hp=5)
    h.begin_exam()
    assert not h.insert_needle()
    h.grip_exam();h.insert_needle();h.tick(10000)
    assert h.dead and not h.sample_valid and h.holder is None


@pytest.mark.parametrize('dangerous', [False,True])
def test_pregrip_evade_and_departure(dangerous):
    h=Hospital()
    assert not h.begin_exam(departing=True)
    assert h.begin_exam(dangerous=dangerous)
    assert h.withdraw()
    assert not h.grip_exam()
    assert h.hp==100 and h.give_prescription()


@pytest.mark.parametrize('seen,warned,continued',list(product([False,True],repeat=3)))
def test_report_requires_actual_observed_continuation(seen,warned,continued):
    h=Hospital()
    assert h.file_report(seen,warned,continued)==(seen and warned and continued)
    assert h.hp==h.sp==100


@pytest.mark.parametrize('present,busy,actual',list(product([False,True],repeat=3)))
def test_report_delivery_presence_busy_and_actual(present,busy,actual):
    h=Hospital(guard_present=present,guard_busy=busy)
    h.file_report()
    accepted=present and not busy and actual
    assert h.receive_report(actual)==accepted
    assert h.report==('received' if accepted else 'desk')
    assert h.route_decision(key=True)=='exit'


def test_absent_guard_report_stays_for_later_actual_delivery():
    h=Hospital();h.file_report()
    assert not h.receive_report() and h.report=='desk'
    assert h.route_decision()=='search'
    h.guard_present=True
    assert h.receive_report() and not h.receive_report()
    assert h.approach_guard() and h.hp==100
    assert h.grip_guard() and (h.hp,h.sp)==(95,90)
    h.tick(6000)
    assert h.holder is None and h.guard_closed
    assert not h.receive_report() and not h.grip_guard()


@pytest.mark.parametrize('release',['timeout','blocked','reached'])
def test_guard_damage_once_and_bounded_release(release):
    h=Hospital();guard(h);h.grip_guard()
    assert not h.withdraw()
    h.tick(5999)
    assert h.holder=='guard' and (h.hp,h.sp)==(95,90)
    if release=='timeout':h.tick(1)
    elif release=='blocked':h.tick(0,route=False)
    else:assert h.release_guard()
    assert h.holder is None and h.guard_damage_count==1
    assert h.route_decision(key=True)=='exit'


@pytest.mark.parametrize('miss', ['not_found','grab_miss','withdraw'])
def test_guard_failed_attempt_closes_without_damage(miss):
    h=Hospital(guard_present=True);h.file_report();h.receive_report()
    if miss=='not_found':h.approach_guard(target_found=False)
    else:
        h.approach_guard()
        h.grip_guard(actual=False) if miss=='grab_miss' else h.withdraw()
    assert h.guard_closed and h.hp==h.sp==100 and not h.receive_report()


def test_grip_is_exclusive_and_lethal_guard_damage_releases():
    h=Hospital(hp=5)
    h.begin_exam();h.grip_exam();guard(h)
    assert not h.grip_guard()
    h.end_exam()
    assert h.grip_guard()
    assert h.dead and h.holder is None


@pytest.mark.parametrize('hp,expected',[(1,11),(90,100),(95,100),(99,100)])
def test_bandage_accumulates_then_heals_once(hp,expected):
    h=Hospital(hp=hp);assert h.start_bandage()
    h.tick(1499);h.interrupt_bandage();h.tick(99999)
    assert h.hp==hp and h.bandage_ms==1499
    h.start_bandage();h.tick(1500)
    assert h.hp==hp
    h.tick(1)
    assert h.hp==expected and h.healing_count==1
    assert not h.start_bandage()


def test_full_hp_and_sleep_do_not_spend_healing():
    h=Hospital()
    assert not h.start_bandage()
    h.hp=70
    assert not h.start_bandage(sleeping=True)
    assert h.start_bandage()
    h.tick(3000)
    assert h.hp==80
    h.new_attempt();h.hp=60;assert h.start_bandage()


@pytest.mark.parametrize('interrupt', ['nurse_dies','contact','damage','pause'])
def test_bandage_interruption_and_pause(interrupt):
    h=Hospital(hp=70);h.start_bandage();h.tick(2999)
    if interrupt=='nurse_dies':h.interrupt_bandage(nurse_dies=True);h.tick(1)
    elif interrupt=='contact':h.tick(1,contact=False)
    elif interrupt=='damage':h.tick(1,damage=1)
    else:h.paused=True;h.tick(1)
    assert h.hp==(69 if interrupt=='damage' else 70)
    assert h.healing_count==0 and h.bandage_ms==2999


@pytest.mark.parametrize('hp', [1,5,10,99])
def test_lethal_same_frame_precedes_finished_bandage(hp):
    h=Hospital(hp=hp);h.start_bandage();h.tick(2999)
    h.tick(1,damage=hp)
    assert h.dead and h.hp==0 and h.healing_count==0
    assert not h.start_bandage()


@given(st.lists(st.integers(min_value=0,max_value=2500), min_size=1,max_size=25))
@settings(max_examples=200,deadline=None,database=None)
def test_segmented_bandage_matches_independent_elapsed_threshold(parts):
    h=Hospital(hp=42)
    accumulated=0
    for ms in parts:
        h.start_bandage();h.tick(ms);h.interrupt_bandage()
        accumulated += ms
        assert h.hp==(52 if accumulated>=3000 else 42)
        assert h.healing_count==int(accumulated>=3000)


class HospitalMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.h=Hospital(hp=80)

    @rule(action=st.sampled_from(['give','prepare','take','raise','swallow','refuse','cup_interrupt','false_label',
                                  'exam','grip_exam','needle','end_exam','withdraw','report','receive','approach',
                                  'grip_guard','release','bandage','interrupt_bandage','joy']))
    def action(self,action):
        methods={'give':'give_prescription','prepare':'prepare','take':'take_cup','raise':'raise_cup',
                 'swallow':'swallow','refuse':'refuse','cup_interrupt':'interrupt_cup','false_label':'complete_false_label',
                 'exam':'begin_exam','grip_exam':'grip_exam','needle':'insert_needle','end_exam':'end_exam',
                 'withdraw':'withdraw','report':'file_report','receive':'receive_report','approach':'approach_guard',
                 'grip_guard':'grip_guard','release':'release_guard','bandage':'start_bandage',
                 'interrupt_bandage':'interrupt_bandage'}
        if action=='joy':self.h.restore_sp(20)
        else:getattr(self.h,methods[action])()

    @rule(ms=st.sampled_from([0,1,999,1000,1999,2000,2999,3000,3999,4000,5999,6000]), paused=st.booleans(),
          present=st.booleans(),busy=st.booleans())
    def time(self,ms,paused,present,busy):
        self.h.paused=paused
        self.h.guard_present=present
        self.h.guard_busy=busy
        before=deepcopy(self.h.__dict__)
        self.h.tick(ms)
        if paused:assert self.h.__dict__==before

    @rule()
    def actual_new_attempt(self):
        self.h.new_attempt()

    @invariant()
    def bounded_actual_effects(self):
        h=self.h
        assert 0<=h.hp<=100 and 0<=h.sp<=100
        assert h.medication_count<=1 and h.needle_count<=1 and h.guard_damage_count<=1 and h.healing_count<=1
        assert not h.sample_valid or h.needle_count==1
        assert not h.false_label or (h.cup=='refused' and h.medication_count==0)
        if h.dead:assert h.hp==0 and h.holder is None
        if h.holder=='doctor':assert h.hold_ms<4000 and not h.exam_closed
        if h.holder=='guard':assert h.guard_ms<6000 and not h.guard_closed


TestHospitalMachine=HospitalMachine.TestCase
TestHospitalMachine.settings=settings(max_examples=200,stateful_step_count=60,deadline=None,database=None)
