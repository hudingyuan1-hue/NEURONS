"""Integration harness connects documented commits; excludes physical navigation."""
from copy import deepcopy
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant, initialize
from rules import Economy, Search, Life

class ExplorationSequence(RuleBasedStateMachine):
    @initialize(level=st.integers(1,4),n=st.integers(0,5),sp=st.sampled_from([0,19,20,49,50,100]),r=st.integers(0,3),key=st.integers(0,9))
    def begin(self,level,n,sp,r,key):
        self.x=Life(progress=level,place=f'S{level}',sp=sp,economy=Economy(n=n,c=0))
        self.x.economy.skills['skin'].resistance=r
        self.s=Search(level=level,key_point=key)
        self.tokens=[]; self.serial=0; self.ledger=n; self.rewarded=set()

    @rule(point=st.integers(0,16),dog=st.booleans())
    def start(self,point,dog):
        if self.x.phase!='alive' or self.x.stun: return
        token=self.s.start(point,'dog' if dog else 'avatar')
        if token: self.tokens.append(token)

    @rule(index=st.integers(0,99),complete=st.booleans())
    def settle(self,index,complete):
        if self.x.phase!='alive' or not self.tokens: return
        token=self.tokens[index%len(self.tokens)]; action=self.s.pending.get(token)
        if not self.s.settle(token,'complete' if complete else 'cancel'): return
        if complete:
            reward=(self.s.attempt,action[1])
            if reward not in self.rewarded:
                self.rewarded.add(reward); self.ledger+=1
                assert self.x.economy.credit(('search',*reward),1)

    @rule()
    def skin_intervention(self):
        before=deepcopy(self.s.pending)
        result=self.x.economy.cast(valid=not self.x.stun)
        if result!='invalid': self.ledger-=1
        if result=='reacted':
            for token,(a,p) in list(self.s.pending.items()):
                if a=='avatar': self.s.settle(token,'cancel')
        else: assert self.s.pending==before

    @rule()
    def dog_delivery(self):
        if self.x.phase=='alive': self.s.deliver()

    @rule()
    def safe_bed_completed(self):
        if self.x.phase=='alive' and not self.s.pending and self.s.action(self.x.sp)=='bed':
            assert self.x.rest()
            self.s.restart(self.s.key_point)
            self.ledger=max(5,self.ledger)

    @rule()
    def lethal_hit(self):
        self.serial+=1
        if self.x.frame((self.x.epoch,self.serial),[('hp_damage',100)])=='death':
            for token in list(self.s.pending): self.s.settle(token,'cancel')

    @rule()
    def revive(self):
        if self.x.revive():
            self.s.restart(self.s.key_point)
            self.ledger=max(5,self.ledger)

    @rule(ms=st.integers(0,8000),paused=st.booleans())
    def clock(self,ms,paused): self.x.tick(ms,paused)

    @rule()
    def save_load(self): self.x,self.s=deepcopy((self.x,self.s))

    @invariant()
    def coupled_accounting(self):
        assert self.x.economy.n==self.ledger
        assert self.x.economy.c==0
        assert self.x.attempts[self.s.level]==self.s.attempt
        assert self.s.income==len(self.rewarded)
        assert not self.x.economy.battle
        if self.s.key_owner=='avatar' and self.x.phase=='alive':
            assert self.s.action(self.x.sp)=='exit'

TestExplorationSequence=ExplorationSequence.TestCase
TestExplorationSequence.settings=settings(max_examples=200,stateful_step_count=60,deadline=None,database=None)

def test_resisted_skill_cannot_remove_pending_key_search():
    s=Search(key_point=0); token=s.start(0)
    e=Economy(n=1); e.skills['skin'].resistance=1
    assert e.cast()=='resisted' and e.n==0
    assert token in s.pending
    assert s.settle(token) and s.key_owner=='avatar'
    e.credit(('search',1,0),1)
    assert e.n==1 and s.action(0)=='exit'

def test_no_npcs_zero_resources_s4_still_searches():
    e=Economy(n=0,c=0,global_r=2)
    s=Search(level=4,key_point=0)
    assert s.action(0)=='search'
    token=s.start(0)
    assert e.cast()=='invalid'
    assert s.settle(token)
    e.credit(('search',1,0),1)
    assert e.n==1 and s.action(0)=='exit'
