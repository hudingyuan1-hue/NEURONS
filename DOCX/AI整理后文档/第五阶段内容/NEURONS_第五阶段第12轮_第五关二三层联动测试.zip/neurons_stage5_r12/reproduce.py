"""Reproduce R12 latest batch or retained actual counterexamples.
Run with Python containing requirements.txt. No Unity project is modified.
"""
from pathlib import Path
import argparse,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
FILES=['test_deep_combat.py','test_personalities.py','test_deep_world.py','test_deep_environment.py','test_s5_deep_session.py']
parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['latest','failure-deep','failure-session','failure-interop','failure-history'],default='latest')
a=parser.parse_args();env=os.environ.copy()
out=ROOT/'results'/'reproduce';out.mkdir(parents=True,exist_ok=True)
cmd=[sys.executable,'-m','pytest','-q','--hypothesis-seed=2026101312','--hypothesis-show-statistics']
env['RUN_REPORT']=str(out/(a.phase+'.json'))
if a.phase=='latest':
 result=subprocess.run(cmd+FILES,cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
else:
 with tempfile.TemporaryDirectory(prefix='neurons_r12_repro_') as name:
  work=Path(name)
  for p in ROOT.glob('*.py'):
   if p.name!='reproduce.py':shutil.copy2(p,work/p.name)
  if a.phase=='failure-deep':
   snap=ROOT/'snapshots/deep_initial'
   shutil.copy2(snap/'deep_world.py',work/'deep_world.py');shutil.copy2(snap/'test_deep_world.py',work/'test_deep_world.py')
   selection=['test_deep_world.py','-k','unrelated_record_does_not_substitute']
  elif a.phase=='failure-session':
   snap=ROOT/'snapshots/session_initial'
   for file in ('s5_deep_session.py','test_s5_deep_session.py'):shutil.copy2(snap/file,work/file)
   selection=['test_s5_deep_session.py','-k','grab_and_pulse_same_frame and avatar']
  elif a.phase=='failure-interop':
   snap=ROOT/'snapshots/session_initial'
   shutil.copy2(snap/'s5_deep_session.py',work/'s5_deep_session.py')
   shutil.copy2(snap/'test_s5_deep_session_extra.py',work/'test_s5_deep_session.py')
   selection=['test_s5_deep_session.py','-k','actual_blank_walk_away or retaliation_uses_actual_damage_target or second_floor_formal']
  else:
   shutil.copy2(ROOT/'snapshots/session_after_fix1.py',work/'s5_deep_session.py')
   shutil.copy2(ROOT/'snapshots/session_after_fix1_tests.py',work/'test_s5_deep_session.py')
   selection=['test_s5_deep_session.py','-k','enemy_collateral_damages or doublehead_can_reacquire']
  result=subprocess.run(cmd+selection,cwd=work,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/(a.phase+'.log')).write_text(result.stdout,encoding='utf-8')
print(result.stdout)
if a.phase!='latest':print('This mode intentionally replays an archived real failure; nonzero pytest exit is expected.')
raise SystemExit(result.returncode)
