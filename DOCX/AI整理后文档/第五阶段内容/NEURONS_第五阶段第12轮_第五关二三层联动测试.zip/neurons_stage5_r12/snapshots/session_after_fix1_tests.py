from copy import deepcopy
from collections import deque
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s5_deep_session import S5DeepSession, CONNECTIONS, EDGES, F1,F2,F3
from deep_combat import DEEP_SPECS
from rules import Skill

class Driver:
    def __init__(self):self.s=S5DeepSession();self.serial=0
    def n(self):self.serial+=1;return(self.s.life.epoch,self.serial)
    def tick(self,ms):return self.s.tick(self.n(),ms)
    def go(self,dest):
        q=deque([(self.s.position,[])]);seen={self.s.position}
        while q:
            here,path=q.popleft()
            if here==dest:
                for room in path:assert self.s.move(self.n(),room)
                return
            for room in sorted(CONNECTIONS[here]-seen):seen.add(room);q.append((room,path+[room]))
        raise AssertionError('unknown route')
    def add(self,actor,room=None):
        # Explicit encounter fixture, not a random-spawn or geometry test.
        e=self.s.entity(actor);e.present=True;e.room=room or getattr(e,'home','thalamus')
        if hasattr(e,'spawn'):e.spawn.state='present'
        if actor=='assistant':e.bed_room=e.room
        self.s._sync();return e
    def attack(self,actor,room=None,target='avatar'):
        e=self.s.entity(actor);self.go(room or getattr(e,'home','thalamus'));self.add(actor,self.s.position)
        if target=='avatar':assert self.s.observe(self.n(),actor)
        aid=self.s.start_attack(self.n(),actor,target=target);assert aid
        self.tick(DEEP_SPECS[actor]['windup']);return aid
    def control(self,remaining=6000):
        s=self.s;s.life.economy.skills['control']=Skill(5,1,20000)
        return s.adopt_control(self.n(),cast_id='already_paid_control',remaining_ms=remaining,authorised=True)

def test_eighteen_scenes_graph_and_only_canonical_cross_floor_edges():
    assert len(F1|F2|F3)==18
    assert {e for e in EDGES if len(e&F3)==1}=={frozenset(('exit','hippocampus'))}
    assert CONNECTIONS['thalamus']==F3-{'thalamus'}
    assert {'thalamus','amygdala'}==CONNECTIONS['cerebellum']
    assert {'thalamus','basal'}==CONNECTIONS['hypothalamus']
    assert CONNECTIONS['brainstem']=={'thalamus'}

@pytest.mark.parametrize('hp,sp,n,r',[(1,0,0,999),(1,19,0,999),(20,0,0,999),(100,0,0,999),(100,100,0,999),(100,100,5,0)])
def test_minimal_connected_route_without_keys_people_skills_or_clearance(hp,sp,n,r):
    d=Driver();s=d.s;s.life.hp=hp;s.life.sp=sp;s.life.emptied=sp==0
    s.life.economy.n=n;s.life.economy.c=0;s.life.economy.global_r=r
    d.go('brainstem')
    assert not any(e.present for e in (*s.people.entities.values(),*s.middle.entities.values()))
    assert s.deep.original.present and s.deep.original.hp==80
    assert not s.life.rest() and not hasattr(s,'search')
    assert s.frame(d.n(),cross_to_street=True)=='street'
    assert (s.life.hp,s.life.sp,s.life.progress)==(hp,sp,6)
    assert s.street_registration['attempt']==1 and not s.exit_snapshot['deep'].witnessed

def test_original_mandatory_unique_at_core_not_entrance_and_not_rng():
    d=Driver();s=d.s;d.go('hippocampus');e=s.deep.original
    assert e.present and e.room=='thalamus' and e.position=='core_side'
    assert not s.spawn_check(d.n(),'original',9999)
    for _ in range(3):d.go('exit');d.go('hippocampus');assert s.deep.original is e
    assert sum(a=='original' for a in s.entity_map())==1

def test_first_visits_once_all18_and_no_reset_on_revisit_reload_or_death():
    d=Driver();s=d.s;before=s.life.economy.n
    for room in sorted(F1|F2|F3):d.go(room)
    assert s.life.economy.n==before+17
    paid=deepcopy(s.life.economy.paid);d.s=s=s.reload()
    for room in sorted(F1|F2|F3):d.go(room)
    assert s.life.economy.paid==paid
    assert s.frame(d.n(),hp_damage=100)=='death';assert s.revive()
    for room in sorted(F1|F2|F3):d.go(room)
    assert s.life.economy.paid==paid

@pytest.mark.parametrize('actor',['father','mother','assistant','twitch','face','doublehead'])
def test_f1_f2_actor_boundary_retains_entity_hp_attack_cooldown(actor):
    d=Driver();s=d.s;d.go('exit');e=d.add(actor,'exit');e.hp-=5
    assert s.observe(d.n(),actor)
    if actor=='doublehead':s.combat.register_damage(s._t('actual_damage'),amount=5,source='avatar',survived=True)
    aid=s.start_attack(d.n(),actor,target='avatar');assert aid
    before=deepcopy(s.combat.attacks[aid]);epoch=s.life.epoch
    assert s.move(d.n(),'hippocampus') and not s.actor_move(d.n(),actor,'hippocampus')
    assert s.entity(actor) is e and s.life.epoch==epoch
    assert s.combat.attacks[aid]==before and e.hp==e.max_hp-5
    d.tick(DEEP_SPECS[actor]['windup']);s.frame(d.n(),contacts=[dict(attack_id=aid,actual_contact=True)])
    assert s.life.hp==100
    assert s.move(d.n(),'exit') and s.entity(actor) is e
    assert s.combat.current(actor)['phase']=='active'

def test_original_cannot_cross_to_f2_nor_attack_new_landing():
    d=Driver();s=d.s;d.go('hippocampus');assert s.actor_move(d.n(),'original','hippocampus')
    e=s.deep.original;assert s.observe(d.n(),'original');aid=s.start_attack(d.n(),'original');assert aid
    assert s.move(d.n(),'exit') and not s.actor_move(d.n(),'original','exit')
    d.tick(800);s.frame(d.n(),contacts=[dict(attack_id=aid,actual_contact=True,grip_closed=True)])
    assert s.life.hp==100 and s.holder is None and e.room=='hippocampus'
    assert s.combat.current('original')['phase']=='active'

def test_f1_pursuer_reaches_f2_along_actual_graph_no_replacement():
    d=Driver();s=d.s;e=d.add('father','decision');e.hp=43
    for dest in ('bridge','index','fork','exit'):
        assert s.actor_move(d.n(),'father',dest)
        assert s.people.entities['father'] is e and e.hp==43
    assert not s.actor_move(d.n(),'father','hippocampus')
    assert not s.actor_move(d.n(),'father','rhythm')

@pytest.mark.parametrize('actor,hp',[('twitch',20),('reverse',20),('face',15),('original',10)])
def test_shared_actual_attack_chain_values_once_per_action(actor,hp):
    d=Driver();aid=d.attack(actor);s=d.s;c=dict(attack_id=aid,actual_contact=True)
    assert s.frame(d.n(),contacts=[c,c])=='alive';s.frame(d.n(),contacts=[c])
    assert (s.life.hp,s.life.sp)==(100-hp,100) and not s.life.economy.awakening

def test_doublehead_actual_avatar_hit_arms_only_one_revenge_no_npc_misattribution():
    d=Driver();s=d.s;d.go('bridge');e=d.add('doublehead');assert s.observe(d.n(),'doublehead')
    assert not s.start_attack(d.n(),'doublehead',target='avatar')
    assert s.kick_contact(d.n(),'doublehead',authorised=True)
    assert e.hp==45 and s.combat.revenge_armed
    assert not s.start_attack(d.n(),'doublehead',target='avatar',hit_recovery_complete=False)
    aid=s.start_attack(d.n(),'doublehead',target='avatar');assert aid
    assert s.kick_contact(d.n(),'doublehead',authorised=True) and e.hp==30
    d.tick(600+1500)
    assert not s.combat.revenge_armed and not s.start_attack(d.n(),'doublehead',target='avatar')

def test_enemy_collateral_damages_neutral_without_revenge_or_avatar_resource_reward():
    d=Driver();s=d.s;d.go('bridge');dh=d.add('doublehead');d.add('father','bridge')
    aid=s.start_attack(d.n(),'father',target='doublehead');assert aid;d.tick(800)
    before=(s.life.economy.n,s.life.economy.c)
    s.frame(d.n(),contacts=[dict(attack_id=aid,target='doublehead',actual_contact=True)])
    assert dh.hp==45 and not s.combat.revenge_armed and (s.life.economy.n,s.life.economy.c)==before
    assert s.middle.history[-1]['source']=='father'

def test_cart_progress_and_dead_person_preserved_on_f3_return_and_reload():
    d=Driver();s=d.s;d.go('index');blank=d.add('blank');m=s.middle
    assert m.start_cart(m.token('start'),actual_approach=True,parking_clear=True)
    for stage in ('inspect','approach','grip'):assert m.cart_step(m.token(stage),stage,actual=True)
    assert m.cart_step(m.token('push'),'push',actual=True,progress=.4)
    m.damage(m.token('fatal'),'blank',100,source='avatar')
    assert m.base_path_open and not blank.alive
    d.go('hippocampus');d.go('index');d.s=s=s.reload()
    assert s.middle.cart_progress==.4 and not s.middle.entities['blank'].alive

def test_control_preserved_across_floor_but_ends_at_real_level_exit_with20s_cd():
    d=Driver();s=d.s;assert d.control(5000)
    d.go('hippocampus');d.tick(1000)
    assert s.control_remaining==4000 and s.awareness.control=='already_paid_control'
    d.go('exit');d.go('brainstem');assert s.control_remaining==4000
    n,c=s.life.economy.n,s.life.economy.c
    assert s.frame(d.n(),cross_to_street=True)=='street'
    assert s.control_remaining==0 and not s.life.economy.control and s.awareness.control is None
    assert s.life.economy.skills['control'].remaining==20000
    assert (s.life.economy.n,s.life.economy.c)==(n+3,c+2)

def test_pause_loading_freeze_attack_pulse_control_regen_together():
    d=Driver();s=d.s;d.go('brainstem');assert d.control(6000)
    d.add('original','brainstem');assert s.observe(d.n(),'original');aid=s.start_attack(d.n(),'original');assert aid
    d.tick(500);before=(s.combat.clock,s.environment.clock,s.control_remaining,s.life.economy.n,s.deep.time_ms)
    for field in ('paused','loading'):
        setattr(s,field,True);assert not d.tick(50000)
        assert (s.combat.clock,s.environment.clock,s.control_remaining,s.life.economy.n,s.deep.time_ms)==before
        setattr(s,field,False)
    d.tick(300);assert s.combat.current('original')['phase']=='active' and s.control_remaining==5200

def test_control_held_time_runs_but_no_move_or_magic_release():
    d=Driver();s=d.s;d.go('thalamus');assert d.control(5000)
    aid=d.attack('original','thalamus');s.frame(d.n(),contacts=[dict(attack_id=aid,actual_contact=True,grip_closed=True)])
    assert s.holder=='original';left=s.control_remaining
    assert not s.move(d.n(),'brainstem')
    d.tick(500);assert s.holder=='original' and s.control_remaining==left-500
    d.tick(700);assert s.holder is None

@pytest.mark.parametrize('target',['avatar','original'])
def test_pulse_once_per_entity_actual_hp20_and_no_wall_extra_damage(target):
    d=Driver();s=d.s;d.go('brainstem');d.add('original','brainstem');d.tick(1500)
    before=(s.life.hp,s.deep.original.hp)
    hit=dict(entity=target,actual_contact=True,actual_displacement_m=3,obstructed_limit_m=.25)
    s.frame(d.n(),pulse_contacts=[hit,hit]);s.frame(d.n(),pulse_contacts=[hit])
    assert (s.life.hp,s.deep.original.hp)==(before[0]-(20 if target=='avatar' else 0),before[1]-(20 if target=='original' else 0))
    assert s.environment.effects[-1]['knockback_m']==.25

@pytest.mark.parametrize('target',['avatar','original'])
def test_real_pulse_knockback_breaks_grip_warning_does_not(target):
    d=Driver();s=d.s;d.go('brainstem');aid=d.attack('original','brainstem')
    s.frame(d.n(),contacts=[dict(attack_id=aid,actual_contact=True,grip_closed=True)])
    assert s.holder=='original';old=(s.life.hp,s.deep.original.hp)
    s.frame(d.n(),pulse_contacts=[dict(entity=target,actual_contact=True)])
    assert s.holder=='original' and (s.life.hp,s.deep.original.hp)==old
    d.tick(700);s.frame(d.n(),pulse_contacts=[dict(entity=target,actual_contact=True,actual_displacement_m=1)])
    assert s.holder is None and s.combat.current('original')['phase']=='recovery'
    assert (s.life.hp,s.deep.original.hp)==(old[0]-(20 if target=='avatar' else 0),old[1]-(20 if target=='original' else 0))

@pytest.mark.parametrize('target',['avatar','original'])
def test_grab_and_pulse_same_frame_damage_both_but_no_held_after_knockback(target):
    d=Driver();s=d.s;d.go('brainstem');d.tick(700);aid=d.attack('original','brainstem')
    assert s.environment.phase=='active'
    s.frame(d.n(),contacts=[dict(attack_id=aid,actual_contact=True,grip_closed=True)],pulse_contacts=[dict(entity=target,actual_contact=True)])
    assert (s.life.hp,s.deep.original.hp)==(70 if target=='avatar' else 90,80 if target=='avatar' else 60)
    assert s.holder is None

@pytest.mark.parametrize('hp,expected',[(19,'death'),(20,'death'),(21,'street'),(100,'street')])
def test_pulse_and_exit_same_frame_damage_before_exit_death_wins(hp,expected):
    d=Driver();s=d.s;d.go('brainstem');s.life.hp=hp;s.life.sp=13;d.tick(1500)
    token=d.n();before=(s.life.economy.n,s.life.economy.c)
    assert s.frame(token,pulse_contacts=[dict(entity='avatar',actual_contact=True)],cross_to_street=True)==expected
    assert s.life.hp==max(0,hp-20) and s.life.sp==13
    if expected=='death':assert s.life.progress==5 and s.exit_snapshot is None and (s.life.economy.n,s.life.economy.c)==before
    else:assert s.life.progress==6 and s.exit_snapshot is not None and (s.life.economy.n,s.life.economy.c)==(before[0]+3,before[1]+2)
    assert s.frame(token,cross_to_street=True)=='ignored'

def test_actual_exit_snapshot_preserves_dead_npc_cart_bandage_and_hp_no_heal():
    d=Driver();s=d.s;d.go('index');d.add('blank');s.middle.cart_progress=.7
    s.middle.damage(s.middle.token('dead'),'blank',40,source='avatar')
    s.support.used=True;s.life.hp=32;s.life.sp=7;s.life.food={'item7':'candy'};s.awareness.hints.add('actual_hospital_file')
    d.go('brainstem');assert s.frame(d.n(),cross_to_street=True)=='street';snap=s.exit_snapshot
    assert snap['middle'].cart_progress==.7 and not snap['middle'].entities['blank'].alive
    assert snap['support'].used and (s.life.hp,s.life.sp)==(32,7)
    assert s.life.food=={'item7':'candy'} and 'actual_hospital_file' in s.awareness.hints
    assert s.people.dead and s.middle.dead and s.deep.dead and not s.combat.active
    assert not s.revive()

def test_death_restarts_only_s5_preserves_longterm_and_rejects_old_callbacks():
    d=Driver();s=d.s;d.go('thalamus');e=s.deep.original;assert d.control(6000)
    aid=d.attack('original','thalamus');old=d.n();attempts=s.life.attempts.copy()
    s.deep.prior_seen.add('actual_patient');s.middle.prior_knowledge.add('real_route')
    assert s.frame(d.n(),hp_damage=100)=='death';assert s.revive()
    assert s.position=='atrium' and s.life.progress==5
    assert s.life.attempts[5]==attempts[5]+1 and s.life.attempts[6]==attempts[6]
    assert s.deep.original is not e and not s.deep.original.present
    assert s.deep.prior_seen=={'actual_patient'} and s.middle.prior_knowledge=={'real_route'}
    assert s.life.economy.skills['control'].remaining==20000
    assert s.frame(old,contacts=[dict(attack_id=aid,actual_contact=True)])=='ignored'
    d.go('hippocampus');assert s.deep.original.present and s.deep.original.hp==80

def test_cold_local_both_entities_pause_heat_and_exit_only_cold_removed():
    d=Driver();s=d.s;d.go('hypothalamus');assert s.actor_move(d.n(),'original','hypothalamus');env=s.environment
    for a in ('avatar','original'):assert env.set_cold(a,True,token=s._t(a));assert env.speed_multiplier(a)==.8
    assert env.set_heat(actual_effect=True,token=s._t('heat'));assert env.speed_multiplier('avatar')==1
    d.tick(1000);assert env.heat_remaining==2000
    assert s.move(d.n(),'basal');assert env.speed_multiplier('avatar')==1.25 and env.speed_multiplier('original')==.8
    d.tick(2000);assert env.speed_multiplier('avatar')==1

def test_original_death_stops_grip_without_boost_and_exit_remains_open():
    d=Driver();s=d.s;d.go('brainstem');d.tick(700);aid=d.attack('original','brainstem');s.deep.original.hp=20
    s.frame(d.n(),contacts=[dict(attack_id=aid,actual_contact=True,grip_closed=True)],pulse_contacts=[dict(entity='original',actual_contact=True)])
    assert not s.deep.original.alive and s.holder is None
    d.tick(250);assert s.frame(d.n(),cross_to_street=True)=='street'
    assert not s.life.economy.awakening and s.people.street_boost==0

class SessionMachine(RuleBasedStateMachine):
    def __init__(self):super().__init__();self.d=Driver()
    @rule(dest=st.sampled_from(sorted(F1|F2|F3)))
    def move(self,dest):
        s=self.d.s
        if s.life.progress==5 and s.life.phase=='alive' and dest in CONNECTIONS[s.position]:s.move(self.d.n(),dest)
    @rule(ms=st.sampled_from([0,1,249,250,600,800,1200,1500,1800,3000,6000,20000]))
    def tick(self,ms):self.d.tick(ms)
    @rule(paused=st.booleans(),loading=st.booleans())
    def flags(self,paused,loading):self.d.s.paused=paused;self.d.s.loading=loading;self.d.s._sync()
    @rule(amount=st.sampled_from([0,1,19,20,80,100]))
    def damage(self,amount):self.d.s.frame(self.d.n(),hp_damage=amount)
    @rule()
    def revive(self):self.d.s.revive()
    @rule()
    def reload(self):self.d.s=self.d.s.reload()
    @rule()
    def pulse_exit(self):self.d.s.frame(self.d.n(),pulse_contacts=[dict(entity='avatar',actual_contact=True),dict(entity='original',actual_contact=True)],cross_to_street=True)
    @rule(actor=st.sampled_from(['father','face','twitch','doublehead','original']))
    def encounter(self,actor):
        s=self.d.s
        if not s.active():return
        e=s.entity(actor)
        if actor=='original':
            if e.present and s.position==e.room:s.observe(self.d.n(),actor);s.start_attack(self.d.n(),actor,target='avatar')
        elif s.position==e.home:
            s.spawn_check(self.d.n(),actor,0,first=True);s.enter_pending(self.d.n())
            s.observe(self.d.n(),actor);s.start_attack(self.d.n(),actor,target='avatar')
    @rule()
    def actual_contacts(self):
        s=self.d.s;c=[dict(attack_id=a['id'],actual_contact=True,grip_closed=True) for a in s.combat.attacks.values() if a['phase']=='active'];s.frame(self.d.n(),contacts=c)
    @invariant()
    def invariants(self):
        s=self.d.s
        assert 0<=s.life.hp<=100 and 0<=s.life.sp<=100
        assert s.life.economy.n>=0 and s.life.economy.c>=0
        assert 0<=s.control_remaining<=6000 and s.combat.slots<=2
        assert s.deep.original.room in F3
        assert all(e.room not in F3 for e in (*s.people.entities.values(),*s.middle.entities.values()))
        assert len([x for x in s.life.economy.paid if isinstance(x,tuple) and x[:2]==('explore',5)])<=18
        if s.life.progress==6:assert s.exit_snapshot is not None and s.control_remaining==0
        if s.life.phase=='dead':assert s.life.hp==0 and s.holder is None

TestSessionMachine=SessionMachine.TestCase
TestSessionMachine.settings=settings(max_examples=250,stateful_step_count=80,deadline=None)

def test_actual_blank_walk_away_interrupts_cart_and_keeps_position():
    d=Driver();s=d.s;d.go('index');d.add('blank');m=s.middle
    assert m.start_cart(m.token('start'),actual_approach=True,parking_clear=True)
    for stage in ('inspect','approach','grip'):assert m.cart_step(m.token(stage),stage,actual=True)
    assert m.cart_step(m.token('push'),'push',actual=True,progress=.3)
    assert s.actor_move(d.n(),'blank','bridge')
    assert m.cart_phase=='interrupted' and m.cart_progress==.3

def test_doublehead_retaliation_uses_actual_damage_target_without_external_target_override():
    d=Driver();s=d.s;d.go('bridge');e=d.add('doublehead');assert s.observe(d.n(),'doublehead')
    assert s.kick_contact(d.n(),'doublehead',authorised=True)
    assert e.target=='avatar'
    assert s.start_attack(d.n(),'doublehead')
    d.tick(800+300+600)
    assert e.target is None

def test_second_floor_formal_dialogue_pauses_actual_session():
    d=Driver();s=d.s;d.go('identity');d.add('doubleface');m=s.middle
    assert m.witness_intervention(m.token('witness'),'actualcast',effective=True,visible_reaction=True,witnessed=True)
    assert s.speak(d.n(),'doubleface')=='䶹䶱䴕䲈䶼䴡䵿䶳䴴䵳䶸䴵！'
    before=(s.combat.clock,s.environment.clock)
    assert s.paused and not d.tick(10000)
    assert (s.combat.clock,s.environment.clock)==before


def test_doublehead_can_reacquire_after_actual_room_return_without_new_retaliation():
    d=Driver();s=d.s;d.go('exit');e=d.add('doublehead','exit')
    assert s.observe(d.n(),'doublehead');assert s.kick_contact(d.n(),'doublehead',authorised=True)
    assert s.move(d.n(),'hippocampus') and s.move(d.n(),'exit')
    assert s.observe(d.n(),'doublehead')
    assert s.start_attack(d.n(),'doublehead')
