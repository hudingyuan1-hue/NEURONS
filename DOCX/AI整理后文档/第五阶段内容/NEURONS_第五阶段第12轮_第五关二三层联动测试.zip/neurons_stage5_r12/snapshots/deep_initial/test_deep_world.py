from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from deep_world import DeepWorld, Token, ROOMS, EDGES, AVATAR_EDGES, IDENTITY


def live(room='hippocampus', **kwargs):
    w = DeepWorld(avatar_room=room, **kwargs)
    assert w.enter_layer(w.token('entry'))
    return w


def original_with_avatar(room='thalamus', **kwargs):
    w = live(**kwargs)
    w.sync_context(avatar_room=room)
    if room != 'thalamus':
        assert w.move_original(w.token('approach'), room)
    return w


def consent(number, time, choice):
    return {'number': number, 'time': time, 'choice': choice}


def test_exact_seven_room_hub_and_two_short_routes():
    expected = {frozenset(('thalamus', x)) for x in ROOMS if x != 'thalamus'}
    expected |= {frozenset(('amygdala','cerebellum')),frozenset(('basal','hypothalamus'))}
    assert EDGES == expected and len(ROOMS) == 7 and len(EDGES) == 8
    assert AVATAR_EDGES - EDGES == {frozenset(('exit','hippocampus'))}


@pytest.mark.parametrize('attempt',[1,2,5,100,1000000])
def test_one_original_always_appears_without_prior_encounter_or_probability(attempt):
    w=DeepWorld(attempt=attempt)
    assert w.enter_layer(w.token('entry'))
    assert (w.original.identity,w.original.hp,w.original.room,w.original.position)==(
        'cross_level_patient',80,'thalamus','core_side')
    original=w.original
    for i in range(3):
        assert not w.enter_layer(w.token(f'repeat{i}'))
        assert w.original is original
    assert not w.witnessed and not w.prior_seen


def test_blocked_entry_defers_same_single_entity_without_rng_absence():
    w=DeepWorld()
    assert not w.enter_layer(w.token('a'),entry_free=False)
    assert not w.original.present
    assert w.enter_layer(w.token('a'),entry_free=True)
    assert w.original.present


@pytest.mark.parametrize('room', ['exit','bridge','atrium','Street','unknown'])
def test_initialization_outside_third_floor_rejected(room):
    w=DeepWorld(avatar_room=room)
    assert not w.enter_layer(w.token('entry'))


def test_dead_original_not_respawned_by_door_or_reload():
    w=live(); assert w.damage(w.token('kill'),80)
    w.sync_context(avatar_room='exit');w.sync_context(avatar_room='hippocampus')
    assert not w.enter_layer(w.token('again'))
    assert w.original.hp==0 and not w.original.alive
    c=w.snapshot(); assert not c.enter_layer(c.token('load'))
    assert c.original.mode=='dead'


def test_floor_boundary_preserves_hp_cooldown_entity_and_knowledge():
    w=live(prior_seen={IDENTITY},prior_details={('white_coat','cuff')})
    w.damage(w.token('hurt'),15);w.original.cooldown_ms=1250
    original=w.original;w.history.append(('prior','blood_door'))
    assert w.avatar_move(w.token('out'),'exit')
    assert w.avatar_move(w.token('back'),'hippocampus')
    assert w.original is original and w.original.hp==65
    assert w.original.cooldown_ms==1250 and w.attempt==1 and w.epoch==0
    assert w.prior_seen=={IDENTITY} and w.history==[('prior','blood_door')]


@pytest.mark.parametrize('dest',['exit','bridge','atrium','Street'])
def test_original_never_crosses_to_first_second_or_sixth_floor(dest):
    w=original_with_avatar('hippocampus');before=deepcopy(w.original)
    assert not w.move_original(w.token('bad'),dest)
    assert w.original==before


def test_original_requires_actual_vision_in_same_room():
    w=live();assert not w.observe(w.token('wall'),actual_seen=True)
    w.sync_context(avatar_room='thalamus')
    assert not w.observe(w.token('blocked'),actual_seen=False)
    assert w.observe(w.token('seen'),actual_seen=True,position='core_east')
    assert w.original.target=='avatar' and w.original.last_seen==('thalamus','core_east')
    assert not w.witnessed


def test_occlusion_tracks_last_seen_not_avatar_unknown_new_side():
    w=original_with_avatar();w.observe(w.token('seen'),actual_seen=True,position='core_east')
    w.lose_sight(w.token('wall'))
    assert w.original.mode=='inspect' and w.original.investigation==('thalamus','core_east')
    assert w.original.position=='core_side'
    w.sync_context(avatar_room='basal')
    assert w.original.investigation==('thalamus','core_east')
    assert not w.move_original(w.token('clairvoyance'),'basal',pursuing=True)


def test_no_corner_fixed_wait_or_teleport_and_reacquisition_actual_only():
    w=original_with_avatar('cerebellum')
    w.observe(w.token('turn'),actual_seen=True,position='corner1');w.lose_sight(w.token('hide'))
    pos=w.original.position
    w.tick(1000);assert w.original.position==pos
    assert w.reposition(w.token('actualturn'),'corner1',actual_step=True,passable=True)
    assert not w.observe(w.token('stillhidden'),actual_seen=False)
    assert w.observe(w.token('visibleagain'),actual_seen=True,position='outer_path')
    assert w.original.mode=='chase'


def test_investigation_requires_actual_arrival_and_completed_check():
    w=original_with_avatar();w.observe(w.token('seen'),actual_seen=True)
    w.lose_sight(w.token('lost'))
    assert not w.finish_inspection(w.token('early'),actually_at_target=False,completed=True)
    assert not w.finish_inspection(w.token('early2'),actually_at_target=True,completed=False)
    assert w.finish_inspection(w.token('done'),actually_at_target=True,completed=True)
    assert w.original.mode=='idle'


@pytest.mark.parametrize('dry',[False,True])
def test_actual_rack_collision_sound_once_until_settled_even_dry_mouth(dry):
    w=live();assert w.rack_collision(w.token('phantom'),actual_collision=False) is None
    s=w.rack_collision(w.token('hit'),actual_collision=True,dry_mouth=dry)
    assert s['kind']=='object_collision' and len(w.sounds)==1
    assert w.rack_collision(w.token('frame2'),actual_collision=True) is None
    assert not w.settle_rack(w.token('notsettled'),actually_settled=False)
    assert w.settle_rack(w.token('settled'),actually_settled=True)
    assert w.rack_collision(w.token('newhit'),actual_collision=True)['id']!=s['id']
    assert len(w.sounds)==2


def test_sound_real_audible_in_range_only_changes_inspection_not_hidden_avatar_location():
    w=live();s=w.rack_collision(w.token('hit'),actual_collision=True)
    assert not w.hear(w.token('far'),s,actually_audible=True,in_range=False)
    assert not w.hear(w.token('inaudible'),s,actually_audible=False,in_range=True)
    assert w.hear(w.token('sound'),s,actually_audible=True,in_range=True)
    assert w.original.investigation==('hippocampus','clothes_rack')
    w.sync_context(avatar_room='basal')
    assert w.original.investigation==('hippocampus','clothes_rack')
    assert w.next_step()=='hippocampus'
    assert w.move_original(w.token('next'),'hippocampus',pursuing=True)
    assert not w.hear(w.token('repeat'),s,actually_audible=True,in_range=True)


def test_visible_target_has_priority_over_rack_noise():
    w=original_with_avatar('hippocampus');s=w.rack_collision(w.token('hit'),actual_collision=True)
    w.observe(w.token('visible'),actual_seen=True,position='leftlane')
    assert not w.hear(w.token('noise'),s,actually_audible=True,in_range=True)
    assert w.original.last_seen==('hippocampus','leftlane') and w.original.target=='avatar'


@pytest.mark.parametrize('kind',['tinnitus','dry_mouth','alarm_light','invented_object'])
def test_internal_or_uncreated_noise_is_not_external_lure(kind):
    w=live();s={'id':(1,0,'fake',1),'room':'hippocampus','position':'rack','kind':kind}
    assert not w.hear(w.token('fake'),s,actually_audible=True,in_range=True)
    assert w.original.mode=='idle'


@pytest.mark.parametrize('flag',['paused','dead','loading','active'])
def test_nonruntime_guards_prevent_actions_timer_and_noise(flag):
    w=original_with_avatar();w.original.cooldown_ms=1200
    w.sync_context(**{flag:False if flag=='active' else True})
    before=deepcopy(w)
    assert not w.observe(w.token('seen'),actual_seen=True)
    assert not w.damage(w.token('hit'),15)
    assert not w.tick(9999)
    assert not w.move_original(w.token('go'),'basal')
    assert w==before


def test_stale_epoch_attempt_and_repeated_contact_cannot_damage_again():
    w=live();t=w.token('hit')
    assert w.damage(t,15) and not w.damage(t,15)
    old=w.token('late');w.sync_context(epoch=1)
    assert not w.damage(old,15)
    w.sync_context(attempt=2,epoch=2);w.enter_layer(w.token('new'))
    assert not w.damage(t,80) and w.original.hp==80


def test_death_stops_chase_and_sound_perception_without_exit_gate_or_reward():
    w=original_with_avatar('hippocampus');w.observe(w.token('vision'),actual_seen=True)
    assert w.damage(w.token('lethal'),80)
    s=w.rack_collision(w.token('rack'),actual_collision=True)
    assert not w.hear(w.token('deadhear'),s,actually_audible=True,in_range=True)
    assert not w.observe(w.token('deadsee'),actual_seen=True)
    assert w.original.mode=='dead' and w.resources==(0,0)
    assert w.avatar_move(w.token('go'),'thalamus')
    assert w.avatar_move(w.token('exitpath'),'brainstem')


@pytest.mark.parametrize('known',[False,True])
def test_old_garment_recognition_needs_actual_prior_detail_and_no_second_item(known):
    prior={('white_coat','cuff')} if known else set()
    w=live(prior_details=prior,original_items={'actual_s1_coat'})
    assert w.observe_garment(w.token('no'),'white_coat','cuff',actual_read=False) is None
    v=w.observe_garment(w.token('yes'),'white_coat','cuff',actual_read=True)
    assert v['recognized'] is known and v['pickup'] is False
    assert w.original_items=={'actual_s1_coat'} and w.resources==(0,0)


def test_record_comparison_does_not_rewrite_real_history_or_invent_injuries():
    w=live(history=[('real','refused')]);w.sync_context(avatar_room='thalamus')
    assert not w.observe_record(w.token('bad'),'number_versions',actual_read=True,same_number=False,versions_differ=True)
    assert not w.observe_record(w.token('same'),'number_versions',actual_read=True,same_number=True,versions_differ=False)
    assert w.observe_record(w.token('actual'),'number_versions',actual_read=True,same_number=True,versions_differ=True)
    assert w.history==[('real','refused')] and w.original.identity==IDENTITY
    assert w.avatar_hp==w.avatar_sp==100 and w.forced_choice is None


def test_unrelated_record_does_not_substitute_actual_garment_comparison():
    w=live();w.sync_context(avatar_room='cerebellum')
    assert w.observe_record(w.token('training'),'training',actual_read=True)
    w.sync_context(avatar_room='hippocampus')
    assert not w.observe_record(w.token('unseenclothes'),'garment_revision',actual_read=True)
    assert w.dialogue(w.token('falsecomparison'),'garment_revision',safe=True) is None


@pytest.mark.parametrize('changed',['number','time'])
def test_consent_pair_different_identity_or_time_not_spliced(changed):
    w=live();w.sync_context(avatar_room='basal')
    original=consent('A','t1','refuse');stamped=consent('A','t1','accept')
    stamped[changed]='different'
    assert not w.observe_consent_pair(w.token('bad'),original,stamped,actual_read=True)
    assert not w.consent_records


def test_consent_evidence_keeps_each_record_identity_time_and_never_submits_choice():
    w=live();w.sync_context(avatar_room='basal')
    for i,choice in enumerate(['accept','refuse']):
        assert w.observe_consent_pair(w.token(str(i)),consent('A',f't{i}',choice),
                                      consent('A',f't{i}','accept'),actual_read=True)
    assert w.consent_records=={('A','t0'):('accept','accept'),('A','t1'):('refuse','accept')}
    assert w.consent_comparison() and w.forced_choice is None
    assert w.dialogue(w.token('unsafe'),'consent',safe=False) is None
    assert w.dialogue(w.token('safe'),'consent',safe=True)==('写了‘拒绝’，最后还是‘同意’。',)
    assert w.avatar_hp==w.avatar_sp==100 and w.resources==(0,0)


def test_amygdala_calm_side_requires_passage_not_window_and_no_auto_heal():
    w=original_with_avatar('amygdala');w.avatar_hp=30;w.avatar_sp=0
    w.observe(w.token('seen'),actual_seen=True)
    assert not w.move_amygdala_side(w.token('window'),'calm',via_internal_passage=False,actual_step=True)
    assert w.move_amygdala_side(w.token('door'),'calm',via_internal_passage=True,actual_step=True)
    w.tick(10000)
    assert (w.avatar_hp,w.avatar_sp)==(30,0) and w.original.mode=='chase'


@pytest.mark.parametrize('known,witnessed,recognized',[(False,False,False),(True,False,False),(False,True,False),(True,True,True)])
def test_original_recognition_requires_actual_prior_identity_and_current_witness(known,witnessed,recognized):
    w=original_with_avatar(prior_seen={IDENTITY} if known else set())
    if witnessed:
        w.witness_original(w.token('witness'),actual_seen=True)
    lines=w.dialogue(w.token('line'),'original',safe=True,actual_heard=True)
    assert lines[0]=='号码……还在。' and ('是他。' in lines) is recognized


@pytest.mark.parametrize('record,room',[
    ('garment_revision','hippocampus'),('number_versions','thalamus'),
    ('training','cerebellum'),('monitor','hypothalamus'),
    ('both_room_records','amygdala'),('life_and_injury','brainstem')])
def test_observation_dialogue_needs_actual_record_and_safe_same_site(record,room):
    w=live();w.sync_context(avatar_room=room)
    assert w.dialogue(w.token('before'),record,safe=True) is None
    if record=='garment_revision':
        w.observe_garment(w.token('garment'),'white_coat','cuff',actual_read=True)
    assert w.observe_record(w.token('record'),record,actual_read=True,same_number=True,versions_differ=True)
    assert w.dialogue(w.token('unsafe'),record,safe=False) is None
    assert w.dialogue(w.token('safe'),record,safe=True)
    assert w.dialogue(w.token('repeat'),record,safe=True) is None


def test_actual_attempt_reset_clears_local_entity_but_keeps_real_memory():
    w=live(prior_seen={IDENTITY},prior_details={('blood_gown','tag')},history=[('actual','wound')])
    w.observe_garment(w.token('read'),'blood_gown','tag',actual_read=True)
    w.damage(w.token('death'),80);w.rack_collision(w.token('sound'),actual_collision=True)
    old=w.original;w.sync_context(attempt=2,epoch=1,avatar_room='atrium',dead=False)
    assert w.original is not old and w.original.hp==80 and not w.original.present
    assert not w.sounds and not w.rack_moving
    assert w.observed=={('blood_gown','tag')}
    assert w.history==[('actual','wound')] and w.prior_seen=={IDENTITY}
    assert not w.sync_context(attempt=1)


class DeepMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.w=live();self.serial=0

    def t(self):
        self.serial+=1;return self.w.token(str(self.serial))

    @rule(room=st.sampled_from(ROOMS+('exit',)))
    def move_avatar(self,room):
        before=self.w.avatar_room
        ok=self.w.avatar_move(self.t(),room)
        if ok:
            assert frozenset((before,room)) in AVATAR_EDGES

    @rule(visible=st.booleans())
    def perception(self,visible):
        if visible:
            self.w.observe(self.t(),actual_seen=True,position=f'p{self.serial}')
        else:
            self.w.lose_sight(self.t())

    @rule(room=st.sampled_from(ROOMS+('exit',)),blocked=st.booleans())
    def npc_physical_step(self,room,blocked):
        old=self.w.original.room
        ok=self.w.move_original(self.t(),room,passable=not blocked)
        if ok: assert frozenset((old,room)) in EDGES

    @rule(collision=st.booleans(),settled=st.booleans(),hear=st.booleans())
    def sound(self,collision,settled,hear):
        self.w.settle_rack(self.t(),actually_settled=settled)
        s=self.w.rack_collision(self.t(),actual_collision=collision)
        if s:self.w.hear(self.t(),s,actually_audible=hear,in_range=hear)

    @rule(amount=st.integers(0,100))
    def damage(self,amount):
        old=self.w.original.hp;t=self.t()
        ok=self.w.damage(t,amount)
        if ok:
            assert self.w.original.hp==max(0,old-amount)
            assert not self.w.damage(t,amount)

    @rule(ms=st.integers(0,5000),pause=st.booleans())
    def time(self,ms,pause):
        self.w.sync_context(paused=pause);pos=self.w.original.position
        old=self.w.time_ms;self.w.tick(ms)
        assert self.w.time_ms==old+(0 if pause else ms)
        assert self.w.original.position==pos
        self.w.sync_context(paused=False)

    @rule()
    def actual_new_attempt(self):
        old=self.t();self.w.sync_context(attempt=self.w.attempt+1,epoch=self.w.epoch+1,
                                        avatar_room='hippocampus')
        assert self.w.enter_layer(self.t())
        assert not self.w.damage(old,80)

    @rule()
    def reload(self):
        before=deepcopy(self.w);self.w=self.w.snapshot();assert self.w==before

    @invariant()
    def core(self):
        e=self.w.original
        assert 0<=e.hp<=80 and e.room in ROOMS and e.identity==IDENTITY
        assert e.alive==(e.hp>0)
        assert not e.sees_avatar or (e.room==self.w.avatar_room and e.alive and e.mode=='chase')
        assert self.w.resources==(0,0) and self.w.forced_choice is None
        assert self.w.avatar_hp==self.w.avatar_sp==100
        assert len({s['id'] for s in self.w.sounds})==len(self.w.sounds)


TestDeepMachine=DeepMachine.TestCase
TestDeepMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
