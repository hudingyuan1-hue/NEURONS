from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from personalities import Personalities, Token, ROSTER, TEXT, EDGES


def arrived(actor='blank', **kwargs):
    p = Personalities(**kwargs)
    e = p.entities[actor]
    p.sync_context(avatar_room=e.home)
    assert p.check_spawn(p.token('spawn'), actor, 0, first=True)
    assert p.enter_pending(p.token('enter'), e.home) == (actor,)
    return p


def push_ready(p):
    assert p.start_cart(p.token('start'), actual_approach=True, parking_clear=True)
    for stage in ('inspect', 'approach', 'grip'):
        assert p.cart_step(p.token(stage), stage, actual=True)


def witness(p, cast='cast', **kwargs):
    args = dict(effective=True, visible_reaction=True, witnessed=True)
    args.update(kwargs)
    return p.witness_intervention(p.token('event-' + cast), cast, **args)


@pytest.mark.parametrize('actor,home,side,hp', [(a,*v[:3]) for a,v in ROSTER.items()])
def test_six_single_identities_health(actor, home, side, hp):
    p = arrived(actor)
    e = p.entities[actor]
    assert (e.home,e.alignment,e.hp)==(home,side,hp)
    assert len(p.entities)==6 and len({e.identity for e in p.entities.values()})==6
    assert all('original' not in a for a in p.entities)


@pytest.mark.parametrize('attempt,pct', [(1,55),(2,60),(4,70),(5,75),(99,75)])
def test_spawn_probability_boundary_and_half_reentry(attempt,pct):
    p=Personalities(attempt=attempt)
    assert p.check_spawn(p.token('miss'),'doublehead',pct*100,first=True)
    assert p.entities['doublehead'].spawn.state=='unseen'
    p.sync_context(avatar_room='index'); p.tick(20000); p.sync_context(avatar_room='bridge')
    assert p.check_spawn(p.token('second'),'doublehead',pct*50-1)
    assert p.entities['doublehead'].spawn.state=='pending'


def test_spawn_three_attempts_pending_and_blocked_entry():
    p=Personalities()
    for n in range(3):
        if n:
            p.sync_context(avatar_room='index');p.tick(20000);p.sync_context(avatar_room='bridge')
        assert p.check_spawn(p.token(str(n)),'doublehead',9999,first=n==0)
    p.sync_context(avatar_room='index');p.tick(20000);p.sync_context(avatar_room='bridge')
    assert not p.check_spawn(p.token('four'),'doublehead',0)
    p=Personalities()
    p.check_spawn(p.token('once'),'doublehead',0,first=True)
    assert not p.enter_pending(p.token('blocked'),'bridge',entry_free=False)
    assert p.entities['doublehead'].spawn.checks==1
    assert not p.check_spawn(p.token('reroll'),'doublehead',0)
    assert p.enter_pending(p.token('free'),'bridge')==('doublehead',)
    assert not p.enter_pending(p.token('again'),'bridge')


def test_cart_actual_order_obstacle_and_progress_only():
    p=arrived();push_ready(p)
    assert p.cart_progress==0 and p.base_path_open
    assert not p.cart_step(p.token('fake'),'push',actual=False,progress=.8)
    assert p.cart_step(p.token('wall'),'push',actual=True,blocked=True,progress=.8)
    assert p.cart_progress==0 and p.cart_blocked
    assert p.cart_step(p.token('move'),'push',actual=True,progress=.6)
    assert not p.cart_step(p.token('reverse'),'push',actual=True,progress=.5)
    assert p.cart_step(p.token('finish'),'push',actual=True,progress=1)
    assert p.cart_step(p.token('stable'),'park',actual=True)
    assert p.cart_phase=='yield' and not p.start_cart(p.token('repeat'),actual_approach=True,parking_clear=True)
    assert p.resources==(0,0) and p.street_boost==p.awakening==0


def test_cart_hit_resume_retirement_preserves_actual_position():
    p=arrived();push_ready(p)
    p.cart_step(p.token('half'),'push',actual=True,progress=.4)
    assert p.damage(p.token('hit'),'blank',5,source='avatar')['hp_loss']==5
    assert p.cart_phase=='interrupted' and p.entities['blank'].target is None
    assert not p.cart_step(p.token('stale'),'push',actual=True,progress=1)
    assert p.start_cart(p.token('resume'),actual_approach=True,parking_clear=True)
    for s in ('inspect','approach','grip'): p.cart_step(p.token('r'+s),s,actual=True)
    assert p.cart_progress==.4
    p.damage(p.token('lethal'),'blank',40,source='avatar')
    assert not p.entities['blank'].alive and p.base_path_open and p.cart_progress==.4
    assert not p.cart_step(p.token('dead'),'push',actual=True,progress=1)


def test_cart_room_layer_reload_preserves_but_actual_new_attempt_resets():
    p=arrived(prior_knowledge={'name_removed'},current_forms=('initial',),wound_history=('actual_cut',))
    push_ready(p);p.cart_step(p.token('half'),'push',actual=True,progress=.5)
    p.sync_context(avatar_room='hippocampus')
    p=Personalities.restore(p.snapshot());p.sync_context(avatar_room='index')
    assert p.cart_progress==.5 and p.prior_knowledge=={'name_removed'}
    assert p.entities['blank'].spawn.checks==1
    p.sync_context(attempt=2,epoch=1)
    assert p.cart_progress==0 and p.cart_phase=='idle'
    assert p.prior_knowledge=={'name_removed'} and p.wound_history==('actual_cut',)
    assert p.entities['blank'].spawn.k==2


def test_chase_defers_text_not_cart_and_formal_text_once():
    p=arrived(chased=True);push_ready(p)
    assert not p.friend_dialogue(p.token('unsafe'),'blank')
    p.cart_step(p.token('motion'),'push',actual=True,progress=.25)
    p.sync_context(chased=False)
    assert p.friend_dialogue(p.token('safe'),'blank')==TEXT['blank']
    assert p.friend_dialogue(p.token('twice'),'blank') is None
    p.sync_context(avatar_room='bridge');p.sync_context(avatar_room='index')
    assert p.friend_dialogue(p.token('return'),'blank') is None


@pytest.mark.parametrize('invalid',[
    {'effective':False},{'visible_reaction':False},{'witnessed':False},
    {'same_room':False},{'wall_blocked':True},{'kind':'preview'},
    {'kind':'upgrade'},{'kind':'menu'},{'kind':'control','control_action':False},
])
def test_doubleface_requires_actual_visible_effective_reaction(invalid):
    p=arrived('doubleface')
    assert not witness(p,**invalid)
    assert p.turn_phase=='idle' and not p.witnessed_casts


def test_doubleface_full_control_visible_action_is_valid():
    p=arrived('doubleface')
    assert witness(p,kind='control',control_action=True)
    assert p.turn_phase=='turning'


def test_turn_pause_interrupt_no_replay_new_cast_gaze():
    p=arrived('doubleface');assert witness(p)
    p.sync_context(paused=True)
    assert not p.finish_turn(p.token('paused'),actual_back_to_camera=True)
    p.tick(100000)
    assert p.turn_phase=='turning' and not p.back_to_camera
    p.sync_context(paused=False)
    p.damage(p.token('hit'),'doubleface',5,source='avatar')
    assert p.turn_phase=='interrupted' and p.entities['doubleface'].target is None
    assert not witness(p) and not p.finish_turn(p.token('old'),actual_back_to_camera=True)
    assert witness(p,'new')
    assert p.finish_turn(p.token('complete'),actual_back_to_camera=True)
    assert witness(p,'another') and p.turn_phase=='gaze'
    assert not p.finish_turn(p.token('spin'),actual_back_to_camera=True)
    assert p.awakening==p.street_boost==0 and p.resources==(0,0)


def test_face_forms_wounds_only_history_not_future_or_stitches():
    p=arrived('face',current_forms=('initial','awake1'),wound_history=('left_knee',))
    data=p.appearance('face')
    assert data['known_forms']==('initial','awake1')
    assert data['actual_wounds']==('left_knee',)
    e=p.entities['face'];p.damage(p.token('kill'),'face',60,source='avatar')
    p.sync_context(avatar_room='identity');p.sync_context(avatar_room='exit')
    assert e.hp==0 and not e.present
    assert not p.check_spawn(p.token('peel_new_life'),'face',0)


@pytest.mark.parametrize('actor',list(ROSTER))
def test_boundary_hippocampus_unreachable_for_all_six(actor):
    p=arrived(actor);e=p.entities[actor]
    e.room='exit'
    assert not p.move(p.token('thirdfloor'),actor,'hippocampus')
    assert p.move(p.token('back'),actor,'fork')


def test_pause_dead_loading_stale_token_cannot_mutate():
    p=arrived();push_ready(p)
    for mode in ('paused','dead','loading'):
        p.sync_context(**{mode:True});before=p.snapshot()
        assert not p.cart_step(p.token(mode),'push',actual=True,progress=1)
        assert not p.damage(p.token('hit'+mode),'blank',5,source='avatar')
        assert not p.tick(100)
        assert p==before
        p.sync_context(**{mode:False})
    assert not p.cart_step(Token(0,'old',0),'push',actual=True,progress=1)
    assert not p.cart_step(Token(1,'old',99),'push',actual=True,progress=1)


def test_enemy_observation_not_avatar_identity_knowledge():
    p=arrived('reverse',prior_seen={'S4_reverse'})
    assert p.observe(p.token('npc_eye'),'reverse',(1,2))
    assert not p.recognizes_previous_identity('reverse')
    assert p.witness_actor(p.token('avatar_eye'),'reverse')
    assert p.recognizes_previous_identity('reverse')


class PersonalityMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__(); self.p=Personalities(prior_knowledge={'name_removed','wrong_route_known'})
        self.seq=0;self.last_progress=0;self.last_attempt=1

    def tok(self):
        self.seq+=1;return self.p.token(self.seq)

    @rule(actor=st.sampled_from(tuple(ROSTER)),roll=st.integers(0,9999),ms=st.integers(0,22000))
    def spawn_reentry(self,actor,roll,ms):
        p=self.p;e=p.entities[actor]
        p.sync_context(avatar_room='outside');p.tick(ms);p.sync_context(avatar_room=e.home)
        p.check_spawn(self.tok(),actor,roll,first=e.spawn.checks==0)
        p.enter_pending(self.tok(),e.home)

    @rule(ms=st.integers(0,10000),pause=st.booleans())
    def time(self,ms,pause):
        self.p.sync_context(paused=pause);self.p.tick(ms)

    @rule(actor=st.sampled_from(tuple(ROSTER)),amount=st.integers(0,100),actual=st.booleans())
    def damage(self,actor,amount,actual):
        p=self.p;p.sync_context(avatar_room=p.entities[actor].room or p.entities[actor].home)
        p.damage(self.tok(),actor,amount,source='avatar',actual=actual)

    @rule(stage=st.sampled_from(('inspect','approach','grip','push','park')),
          step=st.integers(0,10),blocked=st.booleans(),actual=st.booleans())
    def cart(self,stage,step,blocked,actual):
        p=self.p;p.sync_context(avatar_room='index')
        p.start_cart(self.tok(),actual_approach=actual,parking_clear=not blocked)
        p.cart_step(self.tok(),stage,actual=actual,blocked=blocked,progress=step/10)

    @rule(cast=st.integers(0,8),valid=st.booleans(),complete=st.booleans())
    def turn(self,cast,valid,complete):
        p=self.p;p.sync_context(avatar_room='identity')
        p.witness_intervention(self.tok(),cast,effective=valid,visible_reaction=valid,witnessed=valid)
        p.finish_turn(self.tok(),actual_back_to_camera=complete)

    @rule(actor=st.sampled_from(tuple(ROSTER)),dest=st.sampled_from(('bridge','index','fork','exit','identity','rhythm','hippocampus')))
    def npc_move(self,actor,dest):
        p=self.p;before=p.entities[actor].room
        moved=p.move(self.tok(),actor,dest)
        if moved: assert frozenset((before,dest)) in EDGES
        assert p.entities[actor].room!='hippocampus'

    @rule(actor=st.sampled_from(('blank','doubleface')),chased=st.booleans())
    def dialogue(self,actor,chased):
        p=self.p;p.sync_context(chased=chased,avatar_room=p.entities[actor].room or 'bridge')
        result=p.friend_dialogue(self.tok(),actor)
        if result: assert not chased and result==TEXT[actor]

    @rule()
    def reload(self):
        before=self.p.snapshot();self.p=Personalities.restore(before)
        assert self.p==before

    @rule()
    def new_attempt(self):
        self.p.sync_context(attempt=self.p.attempt+1,epoch=self.p.epoch+1,dead=False)

    @invariant()
    def identity_health_history_economy(self):
        p=self.p
        assert set(p.entities)==set(ROSTER)
        assert len({e.identity for e in p.entities.values()})==6
        for e in p.entities.values():
            assert 0<=e.hp<=e.max_hp and 0<=e.spawn.checks<=3
            if e.hp==0: assert not e.alive and not e.present
        assert p.base_path_open and 0<=p.cart_progress<=1
        if self.last_attempt==p.attempt: assert p.cart_progress>=self.last_progress
        self.last_attempt=p.attempt;self.last_progress=p.cart_progress
        assert p.resources==(0,0) and p.street_boost==p.awakening==0
        assert p.prior_knowledge=={'name_removed','wrong_route_known'}
        assert len(p.witnessed_casts)<=9


TestPersonalityMachine=PersonalityMachine.TestCase
TestPersonalityMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
