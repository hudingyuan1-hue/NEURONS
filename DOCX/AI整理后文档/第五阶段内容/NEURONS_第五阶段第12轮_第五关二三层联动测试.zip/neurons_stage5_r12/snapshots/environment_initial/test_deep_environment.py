from copy import deepcopy

import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, invariant, rule

from deep_environment import Environment


def make(room='brainstem'):
    return Environment(epoch=12, room=room)


def sync(e, **kw):
    values = dict(attempt=e.attempt, epoch=e.epoch, paused=e.paused,
                  dead=e.dead, loading=e.loading, active=e.active, room=e.room,
                  entity_rooms=e.entity_rooms, entity_alive=e.entity_alive)
    values.update(kw)
    e.sync_context(**values)


@pytest.mark.parametrize('entity', ['avatar','original'])
def test_cold_requires_actual_local_contact_and_never_stacks(entity):
    e=make('hypothalamus')
    assert e.speed_multiplier(entity)==1
    for i in range(4):
        assert e.set_cold(entity, True)
        assert e.speed_multiplier(entity)==0.8
    assert e.set_cold(entity,False)
    assert e.speed_multiplier(entity)==1
    assert not e.effects


@pytest.mark.parametrize('room', ['hippocampus','thalamus','amygdala','brainstem','basal','cerebellum'])
def test_room_entry_is_not_cold_zone(room):
    e=make(room)
    assert not e.set_cold('avatar',True)
    assert e.speed_multiplier('avatar')==1
    assert not e.effects


def test_cold_and_heat_multiply_and_each_expires_independently():
    e=make('hypothalamus')
    e.set_cold('avatar',True); e.set_cold('original',True)
    assert e.set_heat(actual_effect=True,token=(1,'heat'))
    assert e.speed_multiplier('avatar')==1
    assert e.speed_multiplier('original')==0.8
    e.tick(2999)
    e.set_cold('avatar',False)
    assert e.speed_multiplier('avatar')==1.25
    e.set_cold('avatar',True)
    e.tick(1)
    assert e.speed_multiplier('avatar')==0.8
    assert not e.effects


def test_actual_room_exit_removes_only_cold():
    e=make('hypothalamus')
    e.set_cold('avatar',True)
    e.set_heat(actual_effect=True)
    sync(e,room='thalamus')
    assert e.speed_multiplier('avatar')==1.25 and e.heat_remaining==3000
    sync(e,room='hypothalamus')
    assert e.speed_multiplier('avatar')==1.25
    e.set_cold('avatar',True)
    assert e.speed_multiplier('avatar')==1


@pytest.mark.parametrize('invalid', ['original','failed','preview','old_epoch','old_attempt','zero','long','float'])
def test_heat_requires_real_authorized_avatar_effect(invalid):
    e=make()
    args=dict(actual_effect=True, token=(1,'heat'))
    if invalid=='original': args['entity']='original'
    if invalid in ('failed','preview'): args['actual_effect']=False
    if invalid=='old_epoch': args['callback_epoch']=11
    if invalid=='old_attempt': args['token']=(0,'heat')
    if invalid=='zero': args['duration_ms']=0
    if invalid=='long': args['duration_ms']=3001
    if invalid=='float': args['duration_ms']=100.5
    assert not e.set_heat(**args)
    assert e.heat_remaining==0 and not e.effects


def test_heat_duplicate_does_not_refresh_timer_or_stack():
    e=make()
    assert e.set_heat(actual_effect=True,token=(1,'same-cast'))
    e.tick(500)
    assert not e.set_heat(actual_effect=True,token=(1,'same-cast'))
    assert e.heat_remaining==2500
    assert e.speed_multiplier('avatar')==1.25


@pytest.mark.parametrize('ms,phase,cycle', [(0,'warning',0),(1499,'warning',0),
    (1500,'active',0),(1799,'active',0),(1800,'gap',0),(5999,'gap',0),
    (6000,'warning',1),(7499,'warning',1),(7500,'active',1),(7800,'gap',1),
    (12000,'warning',2)])
def test_pulse_phase_boundaries_and_own_warning(ms,phase,cycle):
    e=make(); e.tick(ms)
    assert e.phase==phase and e.cycle==cycle
    assert e.warnings==[(1,c,c*6000) for c in range(cycle+1)]
    assert not e.effects


@pytest.mark.parametrize('flag', ['paused','loading','dead','inactive'])
def test_world_stop_freezes_heat_pulse_and_rejects_contacts(flag):
    e=make();e.set_heat(actual_effect=True);e.tick(1500)
    sync(e,**({'active':False} if flag=='inactive' else {flag:True}))
    e.tick(60000)
    assert e.clock==1500 and e.heat_remaining==1500
    assert not e.contact('avatar',actual_contact=True)
    assert not e.set_heat(actual_effect=True)
    assert not e.set_cold('avatar',False)
    sync(e,paused=False,loading=False,dead=False,active=True)
    assert e.contact('avatar',actual_contact=True)
    e.tick(300)
    assert e.phase=='gap' and e.heat_remaining==1200


@pytest.mark.parametrize('entity', ['avatar','original'])
def test_one_pulse_damages_each_entity_once_even_multiple_colliders(entity):
    e=make();e.tick(1500)
    assert e.contact(entity,actual_contact=True,token=(1,'collider1'))
    assert not e.contact(entity,actual_contact=True,token=(1,'collider2'))
    assert e.effects[0]['hp']==20 and e.effects[0]['sp']==0
    assert len(e.effects)==1
    e.tick(6000)
    assert e.contact(entity,actual_contact=True,token=(1,'next-pulse'))
    assert len(e.effects)==2


def test_both_bodies_apply_same_damage_no_unhit_collateral():
    e=make();e.tick(1500)
    assert e.contact('avatar',actual_contact=True)
    assert len(e.effects)==1
    assert e.contact('original',actual_contact=True)
    assert [x['hp'] for x in e.effects]==[20,20]
    assert len({x['id'] for x in e.effects})==2


@pytest.mark.parametrize('invalid', ['warning','gap','not_contact','safe_segment','other_room',
    'entity_dead','old_epoch','old_attempt','old_cycle','future_cycle','unknown_entity'])
def test_invalid_contact_no_effect_and_no_spent_hit(invalid):
    e=make();e.tick(1500)
    args=dict(actual_contact=True,token=(1,'contact'))
    entity='avatar'
    if invalid=='warning': e=make()
    if invalid=='gap':e.tick(300)
    if invalid=='not_contact':args['actual_contact']=False
    if invalid=='safe_segment':args['affected_segment']=False
    if invalid=='other_room':sync(e,room='thalamus')
    if invalid=='entity_dead':sync(e,entity_alive={'avatar':False,'original':True})
    if invalid=='old_epoch':args['callback_epoch']=11
    if invalid=='old_attempt':args['token']=(0,'contact')
    if invalid=='old_cycle':args['callback_cycle']=-1
    if invalid=='future_cycle':args['callback_cycle']=1
    if invalid=='unknown_entity':entity='nurse'
    assert not e.contact(entity,**args)
    assert not e.effects and not e.hit_entities


@pytest.mark.parametrize('requested,limit,expected', [(1,1,1),(5,5,1),(.6,1,.6),
    (1,.2,.2),(1,0,0),(0,1,0)])
def test_knockback_is_physically_limited_without_bonus_damage(requested,limit,expected):
    e=make();e.tick(1500)
    assert e.contact('avatar',actual_contact=True,actual_displacement_m=requested,
                     obstructed_limit_m=limit)
    hit=e.effects[-1]
    assert hit['knockback_m']==expected
    assert hit['interrupt']==(expected>0)
    assert hit['hp']==20 and hit['sp']==0


@pytest.mark.parametrize('distance', [-1,float('inf'),float('nan'),'one'])
def test_invalid_physics_distance_does_not_settle_contact(distance):
    e=make();e.tick(1500)
    assert not e.contact('avatar',actual_contact=True,actual_displacement_m=distance)
    assert not e.effects


def test_warning_never_releases_hold_or_emits_damage():
    e=make();e.tick(1499)
    assert not e.contact('avatar',actual_contact=True)
    assert not e.effects


def test_room_reentry_preserves_cycle_and_never_backfills_damage():
    e=make();e.tick(1400)
    sync(e,room='thalamus');e.tick(410)
    assert e.phase=='gap' and not e.effects
    sync(e,room='brainstem')
    assert e.clock==1810 and not e.contact('avatar',actual_contact=True)
    e.tick(5690)
    assert e.cycle==1 and e.phase=='active'
    assert e.contact('avatar',actual_contact=True)


def test_real_entry_during_live_pulse_requires_actual_contact_not_entry_callback():
    e=make('thalamus');e.tick(1600)
    sync(e,room='brainstem')
    assert not e.effects
    assert not e.contact('avatar',actual_contact=False)
    assert e.contact('avatar',actual_contact=True)


def test_same_epoch_and_reload_keep_hit_cycle_and_timers():
    e=make();e.tick(1550);e.contact('avatar',actual_contact=True)
    sync(e,epoch=13)
    restored=deepcopy(e)
    assert restored.clock==1550 and len(restored.effects)==1
    assert not restored.contact('avatar',actual_contact=True)
    assert not restored.contact('original',actual_contact=True,callback_epoch=12)
    assert restored.contact('original',actual_contact=True,callback_epoch=13)


def test_new_attempt_clears_only_local_environment_ledger():
    e=make();e.set_heat(actual_effect=True);e.tick(1500)
    e.contact('avatar',actual_contact=True)
    sync(e,attempt=2,epoch=13,room='hippocampus')
    assert e.clock==0 and e.cycle==0 and e.phase=='warning'
    assert not e.effects and not e.hit_entities and not e.cold
    assert e.heat_remaining==0
    assert not e.contact('avatar',actual_contact=True,token=(1,'old'))


class EnvironmentMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.e=make('hypothalamus')
        self.clock=0;self.heat=0;self.cold=set();self.hits=set();self.effects=[]
        self.room='hypothalamus';self.rooms={'avatar':self.room,'original':self.room}
        self.pause=False;self.loading=False;self.attempt=1

    @rule(ms=st.integers(0,24000))
    def wait(self,ms):
        self.e.tick(ms)
        if not (self.pause or self.loading):
            self.clock+=ms;self.heat=max(0,self.heat-ms)

    @rule(paused=st.booleans(), loading=st.booleans())
    def stop(self,paused,loading):
        self.pause=paused;self.loading=loading
        sync(self.e,paused=paused,loading=loading)

    @rule(entity=st.sampled_from(['avatar','original']),room=st.sampled_from(['hypothalamus','brainstem','thalamus']))
    def move(self,entity,room):
        self.rooms[entity]=room
        if entity=='avatar':self.room=room
        if room!='hypothalamus':self.cold.discard(entity)
        sync(self.e,room=self.room,entity_rooms=self.rooms)

    @rule(entity=st.sampled_from(['avatar','original']),inside=st.booleans())
    def zone(self,entity,inside):
        valid=not (self.pause or self.loading) and (not inside or self.rooms[entity]=='hypothalamus')
        assert self.e.set_cold(entity,inside)==valid
        if valid:
            if inside:self.cold.add(entity)
            else:self.cold.discard(entity)

    @rule(effective=st.booleans())
    def heat_skill(self,effective):
        valid=effective and not(self.pause or self.loading)
        assert self.e.set_heat(actual_effect=effective)==valid
        if valid:self.heat=3000

    @rule(entity=st.sampled_from(['avatar','original']),contact=st.booleans(),danger=st.booleans(),distance=st.sampled_from([0,.3,1,2]))
    def collide(self,entity,contact,danger,distance):
        target=(self.attempt,self.clock//6000,entity)
        valid=(not (self.pause or self.loading) and contact and danger
               and self.rooms[entity]=='brainstem' and 1500<=self.clock%6000<1800
               and target not in self.hits)
        assert self.e.contact(entity,actual_contact=contact,affected_segment=danger,
                              actual_displacement_m=distance)==valid
        if valid:
            self.hits.add(target);self.effects.append((entity,self.clock//6000,min(distance,1)))

    @rule()
    def reload(self):
        self.e=deepcopy(self.e)

    @rule()
    def restart(self):
        self.attempt+=1
        sync(self.e,attempt=self.attempt,epoch=self.e.epoch+1)
        self.clock=0;self.heat=0;self.cold=set();self.hits=set();self.effects=[]

    @invariant()
    def state_agrees(self):
        assert self.e.clock==self.clock and self.e.heat_remaining==self.heat
        for entity in ['avatar','original']:
            expected=(.8 if entity in self.cold else 1)*(1.25 if entity=='avatar' and self.heat else 1)
            assert self.e.speed_multiplier(entity)==expected
        assert [(x['entity'],x['cycle'],x['knockback_m']) for x in self.e.effects]==self.effects
        assert all(x['hp']==20 and x['sp']==0 and 0<=x['knockback_m']<=1 for x in self.e.effects)
        assert len({x['id'] for x in self.e.effects})==len(self.e.effects)
        assert self.e.warnings==[(self.attempt,c,c*6000) for c in range(self.clock//6000+1)]


TestEnvironmentMachine=EnvironmentMachine.TestCase
TestEnvironmentMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
