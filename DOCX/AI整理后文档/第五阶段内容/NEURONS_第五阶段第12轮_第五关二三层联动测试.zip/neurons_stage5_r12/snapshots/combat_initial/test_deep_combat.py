from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from deep_combat import DeepCombatFlow, DEEP_SPECS
from combat_flow import SPECS

NEW = ['doublehead', 'twitch', 'reverse', 'face', 'original']
EXPECTED = {'doublehead': (15,0,800,300,600,1500), 'twitch': (20,0,1200,600,800,2000),
            'reverse': (20,0,1200,600,800,2000), 'face': (15,0,800,300,600,1500),
            'original': (10,0,800,300,600,1500)}

def make():
    f=DeepCombatFlow()
    f.sync_context(attempt=1,epoch=0,actors={a:dict(alive=True,room='bridge') for a in DEEP_SPECS})
    return f

def token(f, x): return (f.attempt, str(x))
def arm(f): return f.register_damage(token(f,('arm',len(f.seen))),'doublehead',amount=15)
def launch(f, actor, **kwargs):
    if actor=='doublehead': arm(f)
    a=f.start(token(f,('start',actor,len(f.attacks))),actor,**kwargs)
    assert a is not None
    f.tick(DEEP_SPECS[actor]['windup'])
    return a

@pytest.mark.parametrize('actor', NEW)
def test_exact_windup_boundary_and_single_physical_hit(actor):
    f=make()
    if actor=='doublehead': arm(f)
    a=f.start(token(f,'a'),actor); hp,sp,w,*_=EXPECTED[actor]
    f.tick(w-1); assert f.contact(token(f,'c'),a) is None
    f.tick(1); e=f.contact(token(f,'c'),a)
    assert (e['hp'],e['sp'],e['hold_ms'])==(hp,sp,0)
    assert f.contact(token(f,'another-contact'),a) is None
    assert sum(e['hp'] for e in f.effects)==hp

@pytest.mark.parametrize('actor', NEW)
def test_active_recovery_cooldown_boundaries_remain_sequential(actor):
    f=make(); a=launch(f,actor); _,_,w,d,r,c=EXPECTED[actor]
    f.tick(d-1); assert f.attacks[a]['phase']=='active'
    f.tick(1); assert f.attacks[a]['phase']=='recovery'
    f.tick(r-1); assert f.slots==1 and f.start(token(f,'next'),actor) is None
    f.tick(1); assert f.attacks[a]['phase']=='cooldown' and f.slots==0
    if actor=='doublehead': arm(f)
    f.tick(c-1); assert f.start(token(f,'next'),actor) is None
    f.tick(1); assert f.start(token(f,'next'),actor) is not None

@pytest.mark.parametrize('actor', NEW)
@pytest.mark.parametrize('kind',['no-contact','blocked','dead-actor','paused'])
def test_false_physics_and_inactive_sources_never_deal_damage(actor,kind):
    f=make(); a=launch(f,actor)
    if kind=='dead-actor':
        actors=deepcopy(f.actors);actors[actor]['alive']=False
        f.sync_context(attempt=1,epoch=0,actors=actors)
    if kind=='paused': f.sync_context(attempt=1,epoch=0,actors=f.actors,paused=True)
    assert f.contact(token(f,'hit'),a,actual_contact=kind!='no-contact',obstructed=kind=='blocked') is None
    assert not f.effects

@pytest.mark.parametrize('actor', NEW)
def test_actual_interrupt_cancels_future_hit_not_previous_hit(actor):
    f=make(); a=launch(f,actor)
    assert not f.interrupt(actor,actual_body_hit=False)
    e=f.contact(token(f,'hit'),a)
    assert f.interrupt(actor)
    assert f.contact(token(f,'later'),a) is None
    assert f.effects==[e]

@pytest.mark.parametrize('actor', NEW)
def test_pause_and_room_change_preserve_direction_and_clock(actor):
    f=make(); direction=[1,0]; a=launch(f,actor,direction=direction)
    direction[0]=9
    f.move_actor(actor,'other')
    before=deepcopy(f.attacks[a]); clock=f.clock
    f.sync_context(attempt=1,epoch=0,actors=f.actors,paused=True)
    assert not f.tick(50000)
    assert not f.interrupt(actor)
    assert not f.release(actor)
    assert f.attacks[a]==before and f.clock==clock
    f.sync_context(attempt=1,epoch=0,actors=f.actors)
    assert f.attacks[a]['direction']==[1,0] and f.attacks[a]['room']=='other'

@pytest.mark.parametrize('actor', NEW)
def test_old_epoch_callback_cannot_affect_restarted_attempt(actor):
    f=make();a=launch(f,actor)
    f.sync_context(attempt=2,epoch=1,actors=f.actors)
    assert f.contact(token(f,'late'),a) is None
    assert f.start(token(f,'new'),actor,callback_epoch=0) is None
    assert not f.effects

@pytest.mark.parametrize('source,actual,amount,survived',[
    ('other_npc',True,15,True),('avatar',False,15,True),('avatar',True,0,True),
    ('avatar',True,15,False),('self',True,15,True)])
def test_doublehead_only_survived_actual_avatar_damage_arms(source,actual,amount,survived):
    f=make()
    assert not f.register_damage(token(f,'d'),source=source,actual=actual,amount=amount,survived=survived)
    assert not f.revenge_armed
    assert f.start(token(f,'a'),'doublehead') is None


def test_doublehead_recovers_then_one_retaliation_without_queued_rehit():
    f=make(); assert arm(f)
    assert f.start(token(f,'a'),'doublehead',hit_recovery_complete=False) is None
    a=f.start(token(f,'a'),'doublehead',hit_recovery_complete=True)
    f.tick(800);e=f.contact(token(f,'hit'),a)
    assert e['hp']==15 and e['hold_ms']==0
    assert f.interrupt('doublehead')
    assert arm(f)  # physical hit accepted, no extra retaliation order
    f.tick(2100)
    assert not f.revenge_armed
    assert f.start(token(f,'next'),'doublehead') is None
    assert arm(f)
    assert f.start(token(f,'next'),'doublehead') is not None


def test_doublehead_target_lost_checked_last_position_abandons_only_pursuit():
    f=make();arm(f)
    assert not f.abandon_retaliation(actual_lost=True,checked_last_seen=False)
    assert f.abandon_retaliation(actual_lost=True,checked_last_seen=True)
    assert not f.revenge_armed
    arm(f);a=f.start(token(f,'a'),'doublehead')
    assert not f.abandon_retaliation(actual_lost=True,checked_last_seen=True)
    assert f.attacks[a]['phase']=='windup'


def test_twitch_mimic_uses_actual_history_at_windup_only():
    f=make()
    assert not f.register_knee(token(f,'preview'),actual_effective=False,pose='fake')
    first=f.start(token(f,'a'),'twitch')
    assert f.attacks[first]['knee_pose'] is None
    pose={'leg':'left'}
    assert f.register_knee(token(f,'real'),actual_effective=True,pose=pose)
    pose['leg']='future'
    assert f.attacks[first]['knee_pose'] is None
    f.tick(4600)
    second=f.start(token(f,'b'),'twitch')
    assert f.attacks[second]['knee_pose']=={'leg':'left'}
    f.register_knee(token(f,'new'),actual_effective=True,pose={'leg':'right'})
    assert f.attacks[second]['knee_pose']=={'leg':'left'}
    assert f.effects==[]  # mimic emits no damage, skill cast, or income


def test_twitch_second_heel_locks_direction_before_charge():
    f=make();a=f.start(token(f,'a'),'twitch',direction='north')
    assert f.aim_twitch(token(f,'heel1'),a,'west')
    assert f.aim_twitch(token(f,'heel2'),a,'south',second_heel=True)
    assert not f.aim_twitch(token(f,'heel3'),a,'east')
    f.tick(1200)
    assert not f.aim_twitch(token(f,'active'),a,'east')
    assert f.contact(token(f,'hit'),a)['direction']=='south'

@pytest.mark.parametrize('actor',['twitch','reverse'])
def test_charge_or_lunge_obstacle_ends_motion_without_self_damage(actor):
    f=make();a=launch(f,actor,direction='backward')
    assert not f.stop_motion(a,actual_obstacle=False)
    assert f.stop_motion(a)
    assert f.contact(token(f,'late'),a) is None
    assert f.effects==[] and f.attacks[a]['direction']=='backward'


def test_reverse_lunge_and_twitch_charge_use_distinct_source_distance_caps():
    assert DEEP_SPECS['reverse']['max_move']==1.8
    assert DEEP_SPECS['twitch']['max_move']==3.0


def test_original_closed_grip_releases_at_1200_without_repeated_damage():
    f=make();a=launch(f,'original')
    e=f.contact(token(f,'touch'),a,grip_closed=False)
    h=f.contact(token(f,'close'),a,grip_closed=True)
    assert (e['hp'],e['hold_ms'],h['hp'],h['hold_ms'])==(10,0,0,1200)
    f.tick(1199);assert f.attacks[a]['phase']=='held'
    assert f.contact(token(f,'tickdamage'),a) is None
    f.tick(1); assert f.attacks[a]['phase']=='recovery'
    assert len(f.releases)==1 and sum(x['hp'] for x in f.effects)==10

@pytest.mark.parametrize('body,gap',[(False,800),(True,0),(True,799)])
def test_original_grab_requires_actor_actual_freedom_and_800_gap(body,gap):
    f=make()
    assert f.start(token(f,'a'),'original',body_free=body,free_gap_ms=gap) is None


def test_original_grip_does_not_stack_with_existing_holder_but_hit_counts():
    f=make();a=f.start(token(f,'a'),'mother','father');b=f.start(token(f,'b'),'original')
    f.tick(800)
    assert f.contact(token(f,'m'),a,grip_closed=True)['hold_ms']==1200
    e=f.contact(token(f,'o'),b,grip_closed=True)
    assert (e['hp'],e['hold_ms'])==(10,0)


def test_two_attack_slots_and_800_start_spacing_apply_to_new_and_old_actors():
    f=make();f.start(token(f,'a'),'twitch');f.tick(799)
    assert f.start(token(f,'b'),'face') is None
    f.tick(1); assert f.start(token(f,'b'),'face') is not None
    f.tick(800);assert f.slots==2
    assert f.start(token(f,'c'),'reverse') is None
    f.tick(900);assert f.slots==1
    assert f.start(token(f,'c'),'reverse') is not None

@pytest.mark.parametrize('actor',list(SPECS))
def test_inherited_f1_specs_and_contact_contract_remain_compatible(actor):
    f=make();a=launch(f,actor);e=f.contact(token(f,'hit'),a)
    assert DEEP_SPECS[actor]==SPECS[actor]
    assert (e['hp'],e['sp'])==(SPECS[actor]['hp'],SPECS[actor]['sp'])

class DeepCombatMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.f=make();self.i=0;self.starts=[]
    def tok(self):
        self.i+=1;return token(self.f,self.i)
    @rule(actor=st.sampled_from(NEW),seen=st.booleans(),free=st.booleans(),gap=st.sampled_from([0,799,800]))
    def begin(self,actor,seen,free,gap):
        before=self.f.clock
        a=self.f.start(self.tok(),actor,actual_seen=seen,body_free=free,free_gap_ms=gap)
        if a is not None: self.starts.append((self.f.epoch,self.f.attempt,before,a))
    @rule(ms=st.sampled_from([0,1,299,300,599,600,799,800,1199,1200,2000,5000]))
    def tick(self,ms): self.f.tick(ms)
    @rule(source=st.sampled_from(['avatar','npc']),actual=st.booleans(),survived=st.booleans())
    def hurt_double(self,source,actual,survived):
        self.f.register_damage(self.tok(),source=source,amount=15,actual=actual,survived=survived)
    @rule(actor=st.sampled_from(NEW),real=st.booleans(),blocked=st.booleans(),closed=st.booleans())
    def contact(self,actor,real,blocked,closed):
        a=self.f.current(actor)
        if a:self.f.contact(self.tok(),a['id'],actual_contact=real,obstructed=blocked,grip_closed=closed)
    @rule(actor=st.sampled_from(NEW),real=st.booleans())
    def interrupt(self,actor,real):self.f.interrupt(actor,actual_body_hit=real)
    @rule(paused=st.booleans())
    def pause(self,paused):self.f.sync_context(attempt=self.f.attempt,epoch=self.f.epoch,actors=self.f.actors,paused=paused)
    @rule(actor=st.sampled_from(NEW),room=st.sampled_from(['bridge','rhythm','index','exit']))
    def ordinary_move(self,actor,room): self.f.move_actor(actor,room)
    @rule(effective=st.booleans(),pose=st.sampled_from(['left','right']))
    def mimic(self,effective,pose): self.f.register_knee(self.tok(),actual_effective=effective,pose=pose)
    @rule()
    def restart(self):self.f.sync_context(attempt=self.f.attempt+1,epoch=self.f.epoch+1,actors=self.f.actors)
    @invariant()
    def accounting(self):
        assert self.f.slots<=2
        assert sum(a['phase']=='held' and a['hold_target']=='avatar' for a in self.f.attacks.values())<=1
        assert len({e['id'] for e in self.f.effects})==len(self.f.effects)
        totals={}
        for e in self.f.effects:
            key=e['attack_id'],e['target'];totals[key]=totals.get(key,0)+e['hp']
            assert totals[key] <= EXPECTED[e['actor']][0]
            assert e['sp']==0
        for left,right in zip(self.starts,self.starts[1:]):
            if left[:2]==right[:2]: assert right[2]-left[2]>=800

TestDeepCombatMachine=DeepCombatMachine.TestCase
TestDeepCombatMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
