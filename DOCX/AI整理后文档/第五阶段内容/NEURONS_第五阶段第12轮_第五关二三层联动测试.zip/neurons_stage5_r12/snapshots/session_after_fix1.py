"""R12 S5 whole-map integration, focused on F2/F3 and real Street entry.
Actual visibility/contact/navigation are supplied callbacks, not Unity proof.
S1:P419-473; S2:P82; S3:P1511-1585; S4:P242-247/T27R6.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from rules import Skill
from s5_session import S5Session
from s5_people import EDGES as F1_EDGES
from personalities import Personalities, EDGES as F12_EDGES
from deep_combat import DeepCombatFlow, DEEP_SPECS
from deep_world import DeepWorld
from deep_environment import Environment

F1 = {'atrium','memory','visual','decision','body'}
F2 = {'bridge','rhythm','index','fork','identity','exit'}
F3 = {'hippocampus','thalamus','cerebellum','hypothalamus','basal','amygdala','brainstem'}
EDGES = F12_EDGES | {frozenset(('exit','hippocampus'))} | {
    frozenset(('thalamus', r)) for r in F3-{'thalamus'}} | {
    frozenset(('amygdala','cerebellum')),frozenset(('basal','hypothalamus'))}
CONNECTIONS = {r:{next(iter(e-{r})) for e in EDGES if r in e} for r in F1|F2|F3}

@dataclass
class S5DeepSession(S5Session):
    middle: Personalities=field(default_factory=Personalities)
    deep: DeepWorld=field(default_factory=DeepWorld)
    environment: Environment=field(default_factory=Environment)
    combat: DeepCombatFlow=field(default_factory=DeepCombatFlow)
    control_remaining: int=0
    exit_snapshot: dict|None=None
    street_registration: dict|None=None

    def _visit(self,room):
        floor=1 if room in F1 else 2 if room in F2 else 3
        self.life.economy.credit(('explore',5,floor,room),1)

    def entity(self,actor):
        if actor=='original':return self.deep.original
        return self.people.entities.get(actor) or self.middle.entities.get(actor)

    def entity_map(self):
        return {**self.people.entities,**self.middle.entities,'original':self.deep.original}

    def _module(self,actor):
        return self.people if actor in self.people.entities else self.middle

    def _sync(self):
        invalid=self.life.phase!='alive' or self.life.progress!=5
        common=dict(attempt=self.life.attempts[5],epoch=self.life.epoch,paused=self.paused,
                    loading=self.loading,dead=invalid,avatar_room=self.position)
        self.people.sync_context(**common,chased=self.chased)
        self.middle.sync_context(**common,chased=self.chased)
        self.deep.sync_context(**common)
        actors=self.entity_map()
        self.combat.sync_context(attempt=self.life.attempts[5],epoch=self.life.epoch,
            paused=self.paused or self.loading,dead=invalid,active=self.life.progress==5,
            actors={a:{'alive':e.alive and e.present,'room':e.room} for a,e in actors.items()})
        current=self.combat.current(self.holder) if self.holder else None
        if self.holder and (not current or current['phase']!='held' or current['hold_target']!='avatar'):
            self._release()
        self.support.sync_context(attempt=self.life.attempts[5],epoch=self.life.epoch,
            paused=self.paused or self.loading,dead=invalid,hp=self.life.hp,avatar_room=self.position,
            actors={a:{'alive':e.alive,'present':e.present,'room':e.room} for a,e in actors.items()},
            chased=self.chased,body_blocked=self.blocked(),known_connections=CONNECTIONS)
        self.environment.sync_context(attempt=self.life.attempts[5],epoch=self.life.epoch,
            paused=self.paused,loading=self.loading,dead=invalid,active=self.life.progress==5,
            room=self.position,entity_rooms={'avatar':self.position,'original':self.deep.original.room},
            entity_alive={'avatar':not invalid,'original':self.deep.original.alive and self.deep.original.present})
        dh=self.middle.entities['doublehead']
        current_dh=self.combat.current('doublehead')
        if not self.combat.revenge_armed and (current_dh is None or current_dh['phase'] in {'cooldown','finished'}):
            dh.target=None
        self.awareness.mode='battle';self.awareness.paused=self.paused or self.loading
        self.awareness.alive=not invalid

    def move(self,token,dest,*,actual=True,passable=True):
        if not self.node(token) or self.blocked() or not actual or not passable or dest not in CONNECTIONS[self.position]:return False
        previous=self.position
        self.position=dest;self.life.place='S5_'+dest;self._visit(dest);self._sync()
        if previous not in F3 and dest in F3:
            self.deep.enter_layer(self.deep.token(self._t('enter_layer')),actual_entry=True,entry_free=True)
            for entity in (*self.people.entities.values(),*self.middle.entities.values()):
                entity.sees_avatar=False
                if entity.target=='avatar':entity.target=None
        elif previous in F3 and dest not in F3:
            self.deep.lose_sight(self.deep.token(self._t('leave_layer')),actually_occluded=True)
        self._sync();return True

    def spawn_check(self,token,actor,roll,*,first=False):
        if not self.node(token) or actor=='original':return False
        module=self._module(actor)
        return module.check_spawn(module.token(self._t('spawn')),actor,roll,first=first)

    def enter_pending(self,token,*,entry_free=True):
        if not self.node(token):return ()
        if self.position in F3:return ()
        module=self.people if self.position in F1 else self.middle
        result=module.enter_pending(module.token(self._t('enter')),self.position,entry_free=entry_free)
        self._sync();return result

    def actor_move(self,token,actor,dest,*,passable=True,bed_passable=True,actual=True):
        if not self.node(token) or not actual or not passable:return False
        e=self.entity(actor)
        if not e or not e.alive or not e.present or frozenset((e.room,dest)) not in EDGES:return False
        if actor=='original':
            if dest not in F3:return False
            result=self.deep.move_original(self.deep.token(self._t('npc_step')),dest,passable=passable,actual_step=actual)
        else:
            if dest in F3 or actor=='assistant' and not bed_passable:return False
            # F1 actors may traverse the F2 graph. This is a real movement callback,
            # not a teleport instruction or reroll. The same entity/attack survives.
            if actor in self.middle.entities:
                result=self.middle.move(self.middle.token(self._t('npc_step')),actor,dest,passable=passable)
            else:
                e.room=dest;e.sees_avatar=False
                if actor=='assistant':e.bed_room=dest
                result=True
        self._sync();return result

    def observe(self,token,actor,*,actual_visible=True,avatar_pos=(0,0)):
        if not self.node(token):return False
        if actor=='original':
            return self.deep.observe(self.deep.token(self._t('see')),actual_seen=actual_visible,position=avatar_pos)
        module=self._module(actor)
        return module.observe(module.token(self._t('see')),actor,avatar_pos,actual_visible=actual_visible)

    def start_attack(self,token,actor,*,target=None,direction=(1,0),actual_seen=True,
                     range_ready=True,route_safe=True,hit_recovery_complete=True):
        if not self.node(token) or actor not in DEEP_SPECS:return None
        e=self.entity(actor)
        target=target or e.target
        if not e.present or not e.alive or not target:return None
        if target=='avatar':
            if e.room!=self.position or not e.sees_avatar:return None
        else:
            other=self.entity(target)
            if not other or not other.present or not other.alive or other.room!=e.room:return None
        aid=self.combat.start(self._t('start'),actor,target=target,direction=direction,
            actual_seen=actual_seen,range_ready=range_ready,route_safe=route_safe,
            body_free=not self.blocked(),free_gap_ms=self.free_gap,callback_epoch=self.life.epoch,
            hit_recovery_complete=hit_recovery_complete)
        if aid:self.attack_generation[aid]=self.body_generation
        return aid

    def kick_contact(self,token,actor,*,authorised=False,actual_body_hit=True):
        # Caller must already have committed a legal skill/control kick. The full
        # 12-skill input/cost/shared cooldown chain is explicitly outside R12.
        if not self.node(token) or not authorised or self.blocked() or not actual_body_hit:return False
        e=self.entity(actor)
        if not e or not e.present or not e.alive or e.room!=self.position:return False
        if actor=='original':
            result=self.deep.damage(self.deep.token(self._t('kick')),15,actual_hit=True)
        else:
            module=self._module(actor)
            result=module.damage(module.token(self._t('kick')),actor,15,source='avatar',actual=True)
        if result is None or result is False:return False
        self.combat.interrupt(actor,actual_body_hit=True,callback_epoch=self.life.epoch)
        if actor=='doublehead':
            self.combat.register_damage(self._t('retaliate'),source='avatar',actual=True,amount=15,survived=e.alive,callback_epoch=self.life.epoch)
            if e.alive and self.combat.revenge_armed:e.target='avatar'
        if actor=='nurse':self.support.interrupt_bandage('nurse_attacked')
        self._sync();return True

    def speak(self,token,actor,*,actual_heard=False,safe=True):
        if not self.node(token) or not safe or self.blocked() or self.chased:return None
        if actor=='original':
            text=self.deep.dialogue(self.deep.token(self._t('speech')),'original',safe=True,actual_heard=actual_heard)
        else:
            module=self._module(actor)
            text=module.friend_dialogue(module.token(self._t('speech')),actor)
        if text:self.paused=True;self._sync()
        return text

    def adopt_control(self,token,*,cast_id,remaining_ms,authorised=False):
        """Adapter for an actual already-paid control result, not a free cast."""
        if (not self.node(token) or not authorised or self.blocked() or
            not 0<remaining_ms<=6000 or 'control' not in self.life.economy.skills or self.control_remaining):return False
        if not self.awareness.start_control(cast_id):return False
        self.control_remaining=remaining_ms;self.life.economy.control=True
        self.life.economy.skills['control'].active=True;return True

    def _end_control(self):
        if self.control_remaining or self.life.economy.control or self.awareness.control is not None:
            self.control_remaining=0;self.life.economy.control=False;self.awareness.end_control()
            skill=self.life.economy.skills.get('control')
            if skill:skill.active=False;skill.remaining=20000

    def _snapshot_exit(self):
        self.exit_snapshot=deepcopy(dict(people=self.people,middle=self.middle,deep=self.deep,
            support=self.support,combat=self.combat,environment=self.environment,
            position=self.position,attempt=self.life.attempts[5],epoch=self.life.epoch))
        self.life.s5_snapshot=self.exit_snapshot

    def frame(self,token,*,contacts=(),pulse_contacts=(),complete_bandage=False,
              cross_to_street=False,hp_damage=0,sp_damage=0):
        if not self.node(token):return 'ignored'
        crossing=cross_to_street and self.position=='brainstem' and not self.blocked()
        old_blocked=self.blocked();proposed=None
        if complete_bandage and self.support.complete_bandage(self._t('finish_bandage'),callback_epoch=self.life.epoch):proposed=self.support.effects[-1]
        new=[]
        for contact in contacts:
            c=dict(contact);aid=c.pop('attack_id');target=c.pop('target','avatar')
            attack=self.combat.attacks.get(aid)
            if not attack:continue
            actor=self.entity(attack['actor']);other=self.entity(target)
            target_room=self.position if target=='avatar' else getattr(other,'room',None)
            if actor.room!=target_room:continue
            can_hold=(not self.blocked() and self.holder is None and self.free_gap>=800 and self.attack_generation.get(aid)==self.body_generation)
            effect=self.combat.contact(self._t('contact'),aid,target,can_hold=can_hold if target=='avatar' else True,callback_epoch=self.life.epoch,**c)
            if effect and effect['id'] not in self.applied:self.applied.add(effect['id']);new.append(effect)
        pulses=[]
        for contact in pulse_contacts:
            c=dict(contact);entity=c.pop('entity')
            accepted=self.environment.contact(entity,token=self._t('pulse'),callback_epoch=self.life.epoch,**c)
            effect=self.environment.effects[-1] if accepted else None
            if effect and effect['id'] not in self.applied:self.applied.add(effect['id']);pulses.append(effect)
        avatar=[e for e in new if e['target']=='avatar']
        npc=[e for e in new if e['target']!='avatar']
        # Inputs in this frame are actual completed contacts. Group NPC impacts
        # against pre-frame alive status so callback order cannot erase mutual hits.
        for module in (self.people,self.middle):
            hits=[]
            for e in npc:
                if e['target'] not in module.entities:continue
                source=e['actor']
                # Cross-roster/bed impacts already passed combat/room checks above.
                if source not in module.entities:source='verified_external_impact'
                elif source=='assistant' and not self.entity(source).alive:source='moving_bed'
                hits.append(dict(actor=e['target'],amount=e['hp'],source=source,actual=True,event_id=str(e['id'])))
            if hits:module.apply_hits(module.token(self._t('npc_batch')),hits)
        original_damage=sum(e['hp'] for e in npc if e['target']=='original')+sum(e['hp'] for e in pulses if e['entity']=='original')
        if original_damage:self.deep.damage(self.deep.token(self._t('original_damage')),original_damage,actual_hit=True)
        avpulse=[e for e in pulses if e['entity']=='avatar']
        damage_hp=hp_damage+sum(e['hp'] for e in avatar)+sum(e['hp'] for e in avpulse)
        damage_sp=sp_damage+sum(e['sp'] for e in avatar)
        events=[('hp_damage',damage_hp),('sp_damage',damage_sp)]
        if proposed:events.append(('heal_hp',proposed['hp_heal']))
        if crossing:events.append(('exit',True))
        result=self.life.frame(token,events)
        if proposed:self.support.resolve_bandage(proposed['id'],applied=result in {'alive','exit'},survived=result in {'alive','exit'})
        elif damage_hp or damage_sp:self.support.interrupt_bandage('avatar_attacked')
        if damage_hp or damage_sp:self.wounds.append((self.life.epoch,token,damage_hp,damage_sp))
        for e in pulses:
            if not e['interrupt']:continue
            actors=([a['actor'] for a in self.combat.attacks.values()
                     if a['phase']=='held' and a['hold_target']=='avatar']
                    if e['entity']=='avatar' else ['original'])
            for actor in actors:self.combat.interrupt(actor,actual_body_hit=True,callback_epoch=self.life.epoch)
            if e['entity']=='avatar':self._release()
        if result=='death':
            self._end_control();self.awareness.transition('death');self._release();self.hit_stop=0;self._sync();return result
        if damage_hp or damage_sp:
            if not self.hit_stop:self.hit_stop=250
        holds=[e for e in avatar if e['hold_ms'] and self.combat.current(e['actor']) and self.combat.current(e['actor'])['phase']=='held']
        if holds and self.holder is None:
            self.holder=holds[0]['actor'];self.hold_remaining=holds[0]['hold_ms'];self.body_generation+=1;self.free_gap=0
        if not old_blocked and self.blocked():self.free_gap=0
        if result=='exit':
            self._end_control();self.awareness.transition('level');self._snapshot_exit()
            self.life.finish_exit();self.position='Street';self._release();self.hit_stop=0
            self.street_registration=dict(level=6,attempt=self.life.attempts[6],registered_once=True,enabled=True)
            self._sync();return 'street'
        self._sync();return result

    def tick(self,token,ms):
        if ms<0:raise ValueError('negative time')
        if not self.node(token):return False
        remaining=ms
        while remaining:
            durations=[x for x in (self.hold_remaining,self.hit_stop,self.life.stun,self.control_remaining) if x>0]
            step=min([remaining]+durations);was_blocked=self.blocked()
            self.life.tick(step);self.people.tick(step);self.middle.tick(step)
            self.combat.tick(step);self.support.tick(step);self.environment.tick(step);self.deep.tick(step)
            self.hit_stop=max(0,self.hit_stop-step);self.hold_remaining=max(0,self.hold_remaining-step)
            if self.control_remaining:
                self.control_remaining=max(0,self.control_remaining-step)
                if not self.control_remaining:self._end_control()
            if self.holder and self.hold_remaining==0:self._release()
            if not was_blocked:self.free_gap=min(800,self.free_gap+step)
            remaining-=step;self._sync()
        return True

    def revive(self):
        if self.life.progress!=5:return False # Street return snapshot implemented in its later group.
        if not super().revive():return False
        self.awareness.new_attempt();self.control_remaining=0;return True
