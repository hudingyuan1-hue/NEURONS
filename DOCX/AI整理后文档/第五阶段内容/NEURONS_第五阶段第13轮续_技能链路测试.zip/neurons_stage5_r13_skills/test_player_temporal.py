"""Concrete follow-up risks: overlapping clocks, host pause and physical stops."""
import pytest
from test_player_session import configured,cast,street,host_target,enemy_hp


def test_formal_dialogue_blocks_cast_even_if_skill_menu_was_open():
    s=street();s.open_menu('cast');s.set_host_pause(True)
    before=s.life.economy.n
    assert s.submit('skin',direction='left') is None
    assert s.life.economy.n==before
    s.start_close();s.finish_close(actual_finished=True)
    assert s.paused and s.host.paused
    s.set_host_pause(False)
    assert not s.paused and not s.host.paused


def test_host_pause_does_not_consume_control_or_regeneration():
    s=street();s.life.economy.n=5;cast(s,'control');s.tick(1234)
    s.set_host_pause(True);s.tick(9000)
    assert s.book.control_remaining==4766 and s.life.economy.n==0
    s.set_host_pause(False);s.tick(8766)
    assert not s.book.control_active and s.life.economy.n==1


def test_feedback_cannot_interrupt_incomplete_body_motion():
    s=configured(True);cast(s,'skin')
    assert s.play_feedback('skin',safe=True) is None
    s.tick(250);assert s.play_feedback('skin',safe=True)


def test_external_hit_stops_old_kick_even_if_body_recovers_in_active_window():
    s=street();_,out=cast(s,'knee');s.tick(150)
    before=enemy_hp(s,'n01')
    s.life.frame((s.life.epoch,'real_hit'),[('hp_damage',1)])
    s.tick(0)
    assert s.kick_contact(out['attack_id'],'n01',distance_m=.5) is None
    assert enemy_hp(s,'n01')==before


def test_external_hit_during_control_cancels_attack_not_ownership():
    s=street();cast(s,'control');cmd=s.command('kick',distance=.5);s.tick(150)
    s.life.frame((s.life.epoch,'hit'),[('hp_damage',1)])
    s.tick(0)
    assert s.book.control_remaining==5850
    assert s.kick_contact(cmd['attack_id'],'n01',distance_m=.5) is None


def test_kick_ordinary_enemy_has_exact_stun_and_paused_clock():
    s=street();s.host.observe(s.host.token('seen'),'n02')
    _,out=cast(s,'knee');s.tick(150)
    hit=s.kick_contact(out['attack_id'],'n02',distance_m=.5,ordinary_enemy=True)
    assert hit['stun_ms']==800 and hit['knockback_max_m']==.8
    assert s.start_enemy_attack('n02') is None
    s.set_pause(True);s.tick(5000);s.set_pause(False)
    s.tick(799);assert s.start_enemy_attack('n02') is None
    s.tick(1);assert s.start_enemy_attack('n02')


@pytest.mark.parametrize('battle',[False,True])
def test_heat_speed_and_exact_expiration(battle):
    s=configured(battle);cast(s,'thermal')
    assert s.movement_multiplier()==(1.25 if battle else .75)
    s.tick(2999);assert s.movement_multiplier()==(1.25 if battle else .75)
    s.tick(1);assert s.movement_multiplier()==1


def test_street_buff_multiplies_heat_once():
    s=street();s.host.people.boost_layers=3 # source-defined max state fixture
    assert s.host.people.speed_multiplier==1.15
    cast(s,'thermal')
    assert s.movement_multiplier()==pytest.approx(1.4375)


def test_cold_zone_and_heat_cancel_by_multiplication():
    s,_=host_target('deep')
    s.host.position='hypothalamus' # valid room-state fixture; not a route test
    s.host._sync()
    assert s.host.environment.set_cold('avatar',True,callback_epoch=s.life.epoch)
    cast(s,'thermal')
    assert s.movement_multiplier()==1


def test_zero_sp_battle_does_not_reduce_normal_movement_after_stupor():
    s=configured(True);s.life.frame((s.life.epoch,'zero'),[('sp_damage',100)])
    assert s.movement_multiplier()==0
    s.tick(1000);assert s.movement_multiplier()==1


def test_fear_point_timer_freezes_in_dialogue_and_clears_on_restart():
    s=configured();s.start_search(1)
    cast(s,'fear',only_current_point=True,current_point=1)
    s.tick(1000);s.set_pause(True);s.tick(9000);s.set_pause(False)
    assert s.start_search(1) is None
    assert s.actual_restart('rest')
    assert s.start_search(1)


def test_exploration_startle_waits_for_actual_motion_not_invented_timer():
    s=configured();s.start_search(1);rec,out=cast(s,'startle')
    assert out['motion_duration_external']
    assert s.start_search(2) is None
    s.tick(5000) # no source-defined exploration duration can auto-complete it
    assert s.start_search(2) is None
    assert not s.finish_motion(rec['id'],actual_finished=False)
    assert s.finish_motion(rec['id'],actual_finished=True)
    assert s.start_search(2)


@pytest.mark.parametrize('kind,ending',[('street','E2'),('hidden','E1')])
def test_actual_ending_tears_down_control_and_blocks_every_new_input(kind,ending):
    s,_=host_target(kind);cast(s,'control');cmd=s.command('move')
    if kind=='street':
        s.host.position='exit' # exit-position fixture, prior round verifies route
        result=s.host.frame(s.host.token('exit'),actual_body_exit=True)
    else:result=s.host.frame(s.host.token('exit'),actual_exit_crossing=True)
    assert result==ending
    assert s.command('move') is None and not s.control_action(cmd['id'])
    assert not s.book.control_active and s.awareness.control is None
    assert s.life.phase==s.life.economy.phase=='ended'
    before=s.life.economy.n
    assert s.submit('happy') is None
    assert not s.tick(99999) and s.life.economy.n==before


@pytest.mark.parametrize('kind',['hospital','s3','s4'])
def test_unintegrated_exploration_host_cannot_silently_create_second_search_ledger(kind):
    from player_session import PlayerSession
    from hospital_session import HospitalSession
    from s3_session import S3Session
    from s4_session import S4Session
    host={'hospital':HospitalSession,'s3':S3Session,'s4':S4Session}[kind]()
    with pytest.raises(ValueError,match='search/handoff integration'):
        PlayerSession(host=host)
