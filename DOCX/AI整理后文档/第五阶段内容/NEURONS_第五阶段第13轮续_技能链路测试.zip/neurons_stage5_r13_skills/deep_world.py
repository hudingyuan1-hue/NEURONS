"""S5F3 topology, sole original personality and evidence/perception model.

Source S1:P419-473; S3:P1513-1576; S4:P216/P242-247.
Actual visibility, sound range, path clearance and collision are engine inputs.
This model supplies no geometric proof, attack timing, damage to avatar or rewards.
"""
from collections import deque
from copy import deepcopy
from dataclasses import dataclass, field

ROOMS = ('hippocampus', 'thalamus', 'cerebellum', 'hypothalamus',
         'basal', 'amygdala', 'brainstem')
EDGES = {frozenset(('thalamus', room)) for room in ROOMS if room != 'thalamus'} | {
    frozenset(('amygdala', 'cerebellum')),
    frozenset(('basal', 'hypothalamus'))}
AVATAR_EDGES = EDGES | {frozenset(('exit', 'hippocampus'))}
IDENTITY = 'cross_level_patient'


@dataclass(frozen=True)
class Token:
    attempt: int
    event_id: str
    epoch: int = 0


@dataclass
class Original:
    identity: str = IDENTITY
    hp: int = 80
    present: bool = False
    alive: bool = True
    room: str = 'thalamus'
    position: str = 'core_side'
    sees_avatar: bool = False
    last_seen: tuple | None = None
    investigation: tuple | None = None
    mode: str = 'idle'
    cooldown_ms: int = 0

    @property
    def target(self):
        return 'avatar' if self.sees_avatar and self.mode == 'chase' else None


@dataclass
class DeepWorld:
    attempt: int = 1
    epoch: int = 0
    avatar_room: str = 'hippocampus'
    paused: bool = False
    dead: bool = False
    loading: bool = False
    active: bool = True
    original: Original = field(default_factory=Original)
    prior_seen: set = field(default_factory=set)
    prior_details: set = field(default_factory=set)
    history: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    witnessed: bool = False
    rack_moving: bool = False
    rack_generation: int = 0
    sounds: list = field(default_factory=list)
    observed: set = field(default_factory=set)
    consent_records: dict = field(default_factory=dict)
    dialogues: set = field(default_factory=set)
    time_ms: int = 0
    amygdala_side: str = 'alarm'
    avatar_hp: int = 100
    avatar_sp: int = 100
    resources: tuple = (0, 0)
    forced_choice: str | None = None
    original_items: set = field(default_factory=set)

    def token(self, event_id):
        return Token(self.attempt, str(event_id), self.epoch)

    def _ok(self, token):
        return (isinstance(token, Token) and token.attempt == self.attempt
                and token.epoch == self.epoch and self.active and not self.paused
                and not self.dead and not self.loading)

    def _fresh(self, token, operation):
        return self._ok(token) and (operation, token.event_id) not in self.seen

    def _mark(self, token, operation):
        self.seen.add((operation, token.event_id))

    def sync_context(self, *, attempt=None, epoch=None, paused=None, dead=None,
                     loading=None, active=None, avatar_room=None):
        if attempt is not None and attempt != self.attempt:
            if attempt < self.attempt:
                return False
            self.attempt = attempt
            self.original = Original()
            self.seen.clear()
            self.witnessed = False
            self.rack_moving = False
            self.rack_generation = 0
            self.sounds.clear()
            self.dialogues.clear()
            self.time_ms = 0
            self.amygdala_side = 'alarm'
        if epoch is not None:
            self.epoch = epoch
        for key, value in (('paused', paused), ('dead', dead), ('loading', loading),
                           ('active', active)):
            if value is not None:
                setattr(self, key, value)
        if avatar_room is not None and avatar_room != self.avatar_room:
            self.avatar_room = avatar_room
            self._lost()
        if self.dead or not self.active:
            self.original.sees_avatar = False
            self.original.mode = 'idle'
        return True

    def enter_layer(self, token, *, actual_entry=True, entry_free=True):
        if (not self._fresh(token, 'enter') or not actual_entry or not entry_free
                or self.avatar_room not in ROOMS or self.original.present
                or not self.original.alive):
            return False
        self.original.present = True
        self._mark(token, 'enter')
        return True

    def avatar_move(self, token, dest, *, actual_step=True, passable=True):
        if (not self._fresh(token, 'avatar_move') or not actual_step or not passable
                or frozenset((self.avatar_room, dest)) not in AVATAR_EDGES):
            return False
        self.avatar_room = dest
        self._lost()
        self._mark(token, 'avatar_move')
        return True

    def _live_original(self):
        return self.original.present and self.original.alive

    def observe(self, token, *, actual_seen, position='last_visible_point'):
        if (not self._fresh(token, 'observe') or not self._live_original()
                or not actual_seen or self.avatar_room != self.original.room
                or self.avatar_room not in ROOMS):
            return False
        self.original.sees_avatar = True
        self.original.last_seen = (self.avatar_room, position)
        self.original.investigation = None
        self.original.mode = 'chase'
        self._mark(token, 'observe')
        return True

    def _lost(self):
        e = self.original
        e.sees_avatar = False
        if e.alive and e.present and e.mode == 'chase':
            e.investigation = e.last_seen
            e.mode = 'inspect' if e.last_seen else 'idle'

    def lose_sight(self, token, *, actually_occluded=True):
        if (not self._fresh(token, 'lose') or not actually_occluded
                or not self._live_original()):
            return False
        self._lost()
        self._mark(token, 'lose')
        return True

    def witness_original(self, token, *, actual_seen):
        if (not self._fresh(token, 'witness') or not self._live_original()
                or not actual_seen or self.avatar_room != self.original.room):
            return False
        self.witnessed = True
        self._mark(token, 'witness')
        return True

    def next_step(self):
        e = self.original
        goal = e.last_seen if e.sees_avatar else e.investigation
        if not self._live_original() or not goal or goal[0] not in ROOMS:
            return None
        if goal[0] == e.room:
            return e.room
        queue = deque([(e.room, [])])
        visited = {e.room}
        while queue:
            room, path = queue.popleft()
            for dest in ROOMS:
                if dest in visited or frozenset((room, dest)) not in EDGES:
                    continue
                new = path + [dest]
                if dest == goal[0]:
                    return new[0]
                visited.add(dest)
                queue.append((dest, new))
        return None

    def move_original(self, token, dest, *, actual_step=True, passable=True,
                      position='doorway', pursuing=False):
        e = self.original
        if (not self._fresh(token, 'move') or not self._live_original()
                or not actual_step or not passable or dest not in ROOMS
                or frozenset((e.room, dest)) not in EDGES
                or (pursuing and dest != self.next_step())):
            return False
        e.room = dest
        e.position = position
        e.sees_avatar = False
        if e.mode == 'chase':
            e.mode = 'inspect'
            e.investigation = e.last_seen
        self._mark(token, 'move')
        return True

    def reposition(self, token, position, *, actual_step=True, passable=True):
        if (not self._fresh(token, 'reposition') or not self._live_original()
                or not actual_step or not passable):
            return False
        self.original.position = position
        self._mark(token, 'reposition')
        return True

    def finish_inspection(self, token, *, actually_at_target, completed):
        e = self.original
        if (not self._fresh(token, 'inspect_done') or not self._live_original()
                or e.sees_avatar or e.mode != 'inspect'
                or not actually_at_target or not completed):
            return False
        e.mode = 'idle'
        e.investigation = None
        self._mark(token, 'inspect_done')
        return True

    def rack_collision(self, token, *, actual_collision, actor='avatar',
                       dry_mouth=False):
        actor_room = self.avatar_room if actor == 'avatar' else (
            self.original.room if actor == 'original' and self._live_original() else None)
        if (not self._fresh(token, 'rack') or not actual_collision
                or actor_room != 'hippocampus' or self.rack_moving):
            return None
        self.rack_moving = True
        self.rack_generation += 1
        sound = {'id': (self.attempt, self.epoch, 'rack', self.rack_generation),
                 'room': 'hippocampus', 'position': 'clothes_rack',
                 'kind': 'object_collision'}
        self.sounds.append(sound)
        self._mark(token, 'rack')
        return deepcopy(sound)

    def settle_rack(self, token, *, actually_settled):
        if (not self._fresh(token, 'settle') or not actually_settled
                or not self.rack_moving):
            return False
        self.rack_moving = False
        self._mark(token, 'settle')
        return True

    def hear(self, token, sound, *, actually_audible, in_range):
        if (not self._fresh(token, 'hear') or not self._live_original()
                or self.original.sees_avatar or not actually_audible or not in_range
                or sound not in self.sounds or sound.get('kind') != 'object_collision'
                or sound['id'][:2] != (self.attempt, self.epoch)
                or ('sound', sound['id']) in self.seen):
            return False
        self.original.investigation = (sound['room'], sound['position'])
        self.original.mode = 'inspect'
        self.seen.add(('sound', sound['id']))
        self._mark(token, 'hear')
        return True

    def damage(self, token, amount, *, actual_hit=True):
        if (not self._fresh(token, 'damage') or not self._live_original()
                or not actual_hit or amount <= 0):
            return False
        self.original.hp = max(0, self.original.hp - amount)
        if not self.original.hp:
            self.original.alive = False
            self.original.mode = 'dead'
            self.original.sees_avatar = False
            self.original.investigation = None
        self._mark(token, 'damage')
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative time')
        if self.paused or self.dead or self.loading or not self.active:
            return False
        self.time_ms += ms
        self.original.cooldown_ms = max(0, self.original.cooldown_ms - ms)
        return True

    def observe_garment(self, token, garment, detail, *, actual_read):
        if (not self._fresh(token, 'garment') or not actual_read
                or self.avatar_room != 'hippocampus'
                or garment not in ('white_coat', 'blood_gown')):
            return None
        evidence = (garment, detail)
        self.observed.add(evidence)
        self._mark(token, 'garment')
        return {'recognized': evidence in self.prior_details, 'evidence': evidence,
                'pickup': False}

    def observe_consent_pair(self, token, original, stamped, *, actual_read):
        if (not self._fresh(token, 'consent') or not actual_read
                or self.avatar_room != 'basal'
                or not original.get('number') or not original.get('time')
                or (original.get('number'), original.get('time')) !=
                   (stamped.get('number'), stamped.get('time'))
                or original.get('choice') not in ('accept', 'refuse')
                or stamped.get('choice') != 'accept'):
            return False
        key = (original['number'], original['time'])
        evidence = (original['choice'], stamped['choice'])
        self.consent_records[key] = evidence
        self._mark(token, 'consent')
        return True

    def consent_comparison(self):
        return {value[0] for value in self.consent_records.values()} == {'accept', 'refuse'}

    def observe_record(self, token, record_kind, *, actual_read,
                       same_number=False, versions_differ=False):
        expected = {'number_versions': 'thalamus', 'training': 'cerebellum',
                    'monitor': 'hypothalamus', 'both_room_records': 'amygdala',
                    'life_and_injury': 'brainstem', 'garment_revision': 'hippocampus'}
        if (not self._fresh(token, 'record') or not actual_read
                or self.avatar_room != expected.get(record_kind)
                or (record_kind == 'number_versions' and not (same_number and versions_differ))
                or (record_kind == 'garment_revision' and not any(
                    evidence[0] in ('white_coat', 'blood_gown') for evidence in self.observed))):
            return False
        self.observed.add(('record', record_kind))
        self._mark(token, 'record')
        return True

    def move_amygdala_side(self, token, side, *, via_internal_passage, actual_step):
        if (not self._fresh(token, 'side') or self.avatar_room != 'amygdala'
                or side not in ('alarm', 'calm') or not via_internal_passage
                or not actual_step or side == self.amygdala_side):
            return False
        self.amygdala_side = side
        self._mark(token, 'side')
        return True

    def dialogue(self, token, kind, *, safe, actual_heard=False):
        if (not self._fresh(token, 'dialogue') or not safe or kind in self.dialogues):
            return None
        if kind == 'original':
            if (not actual_heard or not self._live_original()
                    or self.original.room != self.avatar_room or self.original.mode != 'idle'):
                return None
            lines = ['号码……还在。']
            if self.witnessed and IDENTITY in self.prior_seen:
                lines.append('是他。')
        elif kind == 'consent':
            if self.avatar_room != 'basal' or not self.consent_comparison():
                return None
            lines = ['写了‘拒绝’，最后还是‘同意’。']
        else:
            lines_by_record = {
                'garment_revision': ('hippocampus', '痕迹还在，记录却改了。'),
                'number_versions': ('thalamus', '编号没变，写法变了。'),
                'training': ('cerebellum', '做了多少次，记得很清楚。伤在哪儿，没有这一栏。'),
                'monitor': ('hypothalamus', '身体的数值都在，我说过什么呢？'),
                'both_room_records': ('amygdala', '换了一间房，还是没有让我说话的地方。'),
                'life_and_injury': ('brainstem', '还活着，就可以不写受过什么伤？')}
            if kind not in lines_by_record:
                return None
            room, text = lines_by_record[kind]
            if self.avatar_room != room or ('record', kind) not in self.observed:
                return None
            lines = [text]
        self.dialogues.add(kind)
        self._mark(token, 'dialogue')
        return tuple(lines)

    def snapshot(self):
        return deepcopy(self)

