"""Paid S1 father rescue bridge; S3:P191-196 and S4:P248-264.

The unmodified historical Family model owns event state. Its legacy skill()
entry point is deliberately not called: it would charge/cast a second time.
Actual reaction, contact, dodge/escape and door crossing are host facts.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from family import Family
from player_skills import PlayerSkills, CATALOG
from skill_effects import SkillEffects

RESCUE_WINDOW = frozenset(('approach', 'windup', 'turn', 'carry', 'stunned'))
RESCUE_SKILLS = frozenset(('knee', 'startle', 'withdraw', 'fear', 'happy', 'control'))


@dataclass
class FamilySkillBridge:
    family: Family = field(default_factory=Family)
    effects: SkillEffects = field(default_factory=SkillEffects)
    paused: bool = False
    loading: bool = False
    menu: str | None = None
    fourth_wall_restricted: bool = False
    serial: int = 0
    seen_nodes: set = field(default_factory=set)
    settled_reactions: set = field(default_factory=set)
    completed_control_interrupts: set = field(default_factory=set)
    action_results: dict = field(default_factory=dict)
    proposals: dict = field(default_factory=dict)

    def __post_init__(self):
        self.book = PlayerSkills(self.family.life.economy)
        self._life_epoch = self.family.life.epoch
        self._life_phase = self.family.life.phase
        self._sync()

    def _sync(self):
        f = self.family
        if f.life.epoch != self._life_epoch or (f.life.phase == 'dead' and self._life_phase != 'dead'):
            self.book.end_context('death' if f.life.phase == 'dead' else 'level')
            self.effects.clear_transients()
            self._life_epoch = f.life.epoch
        self._life_phase = f.life.phase
        rescue = f.alive_home() and f.father in RESCUE_WINDOW | {'thought'}
        # This set is a source-specific exception, not an arbitrary authorisation.
        names = tuple(CATALOG) if rescue and f.father == 'thought' else RESCUE_SKILLS if rescue else ()
        self.book.sync_context(mode='explore', paused=self.paused, menu=self.menu,
            loading=self.loading, alive=f.life.phase == 'alive',
            transitioning=f.life.phase == 'transition', body_blocked=bool(f.grabbed or f.life.stun),
            fourth_wall_restricted=self.fourth_wall_restricted,
            rescue_allowed=rescue, rescue_skills=names,
            attack_in_progress=self.effects.body_busy(),
            attack_has_hit=bool(self.effects.current_attack and self.effects.current_attack['hit_targets']),
            can_cancel_attack=self.effects.may_cancel_attack('skin'))
        self.effects.paused = self.paused or self.loading
        self.effects.dead = not f.alive_home()

    def token(self, label='family_skill'):
        self.serial += 1
        return (self.family.life.epoch, label, self.serial)

    def submit(self, name, *, token=None):
        self._sync()
        f = self.family
        if not f.alive_home():
            return None
        if name not in ('fear', 'happy') and f.life.stun:
            return None
        if name == 'control' and f.grabbed or name == 'withdraw' and f.grabbed:
            return None
        return self.book.submit(token if token is not None else self.token(), name)

    def _fresh_node(self, node):
        return (self.family.alive_home() and not self.paused and not self.loading
                and node[0] == self.family.life.epoch and node not in self.seen_nodes)

    def _settle(self, node, *, hp_damage=0, sp_damage=0, heal_sp=0,
                rescue=None, pressure_due=False, actual_exit=False):
        """Single host node: damage before recovery; rescue before pressure."""
        if min(hp_damage, sp_damage, heal_sp) < 0:
            raise ValueError('damage and recovery must be nonnegative')
        self.seen_nodes.add(node)
        f = self.family
        verdict = f.verdict([('hp_damage', hp_damage), ('sp_damage', sp_damage), ('heal_sp', heal_sp)])
        if verdict == 'death':
            self._sync()
            return dict(status='death', rescue=False, exit=False)
        if rescue == 'awake':
            f.father = 'saved'
            f.father_remaining = 0
            f.blood_gate = f.grabbed = False
            f.rescue_exit = True
        elif rescue == 'thought':
            f.father = 'gone'
            f.father_remaining = 0
            f.cat = 'exited'
            f.blood_gate = f.grabbed = False
        elif rescue == 'knee':
            f.father = 'stunned'
            f.father_remaining = 2000
            f.grabbed = False
        elif rescue in ('startle', 'withdraw'):
            f.father = 'approach'
            f.father_remaining = 2000
            f.grabbed = False
        # The actual rescue is already settled. A high rescue stops pressure;
        # a mid rescue merely gains time and does not end the father event.
        if pressure_due and f.father in RESCUE_WINDOW | {'thought'}:
            f.verdict([('sp_damage', 1)])
        exit_result = f.cross_door() if actual_exit else False
        self._sync()
        return dict(status='alive', rescue=rescue or False, exit=exit_result)

    def react(self, cast_id, *, node=None, actual=True, hp_damage=0,
              pressure_due=False, actual_exit=False, collapse_locked=False,
              thought_interrupted=False):
        self._sync()
        node = node or self.token('reaction')
        cast = self.book.casts.get(cast_id)
        if (not self._fresh_node(node) or not cast or cast['epoch'] != self.book.epoch
                or cast['status'] not in ('committed', 'resisted') or cast_id in self.settled_reactions):
            return None
        f = self.family
        self.settled_reactions.add(cast_id)
        if collapse_locked or f.father == 'collapse' or f.mother == 'collapse':
            self.seen_nodes.add(node)
            self.book.interrupt(cast_id)
            f.collapse()
            self._sync()
            return dict(status='collapse', rescue=False, exit=False)
        if cast['resisted']:
            # No neural action and no dedicated rescue reward. Damage/pressure
            # at the actual host node still follows its own event rules.
            return self._settle(node, hp_damage=hp_damage, pressure_due=pressure_due, actual_exit=actual_exit)
        name = cast['name']
        if not actual:
            self.book.interrupt(cast_id)
            return self._settle(node, hp_damage=hp_damage, pressure_due=pressure_due, actual_exit=actual_exit)
        exception = f.father in RESCUE_WINDOW and name in ('knee', 'startle')
        body_available = not f.life.stun and (not f.grabbed or exception)
        if name not in ('fear', 'happy') and not body_available:
            self.book.interrupt(cast_id)
            return None
        proposal = self.effects.begin(cast, actual_reaction=True, body_available=body_available)
        if proposal is None:
            self.book.interrupt(cast_id)
            return None
        reacted = self.book.react(cast_id, duration_ms=proposal['duration_ms'], body_reacted=name != 'control')
        if not reacted:
            raise AssertionError('actual family effect lost paid ledger')
        self.proposals[cast_id] = deepcopy(proposal)
        if proposal['cancel_search']:
            for token, (actor, _) in list(f.search.pending.items()):
                if actor == 'avatar':
                    f.settle(token, complete=False)
        rescue = ('thought' if f.father == 'thought' and thought_interrupted and name != 'control' else
                  'awake' if f.father in RESCUE_WINDOW and name in ('fear', 'happy') else None)
        result = self._settle(node, hp_damage=hp_damage, sp_damage=proposal['sp_damage'],
            heal_sp=proposal['sp_heal'], rescue=rescue, pressure_due=pressure_due, actual_exit=actual_exit)
        result.update(cast_id=cast_id, proposal=proposal)
        return result

    def control_body(self, cast_id, *, node=None, actual=True, kind='move',
                     thought_interrupted=False, hp_damage=0, pressure_due=False):
        """Confirm actual movement/interaction; ownership alone cannot expel."""
        self._sync()
        node = node or self.token('control_body')
        f = self.family
        cast = self.book.casts.get(cast_id)
        if (not actual or not self._fresh_node(node) or kind not in ('move', 'interact')
                or self.book.control_id != cast_id or not self.book.control_active
                or f.grabbed or f.life.stun or cast_id in self.completed_control_interrupts
                or not cast or cast['epoch'] != self.book.epoch):
            return None
        if not cast['reaction']:
            if not self.book.confirm_control_body(cast_id, actual=True):
                return None
        rescue = 'thought' if f.father == 'thought' and thought_interrupted else None
        result = self._settle(node, hp_damage=hp_damage, rescue=rescue, pressure_due=pressure_due)
        if rescue:
            self.completed_control_interrupts.add(cast_id)
        result['cast_id'] = cast_id
        return result

    def resolve_action(self, cast_id, *, node=None, actual_hit=False, roll=None,
                       actual_dodge=False, actual_escape=False,
                       hp_damage=0, pressure_due=False):
        """Actual S1 contact/escape callback; no generic 15HP father damage.

        A knee uses the existing 150ms active interval. The original S1 source
        supplies no distance/HP target, so caller verifies actual father contact.
        Startle's S1 displacement duration remains an external physical fact.
        """
        self._sync()
        node = node or self.token('rescue_result')
        cast = self.book.casts.get(cast_id)
        if (not self._fresh_node(node) or not cast or cast['epoch'] != self.book.epoch
                or cast['status'] != 'reacted' or cast_id in self.action_results
                or self.family.father not in RESCUE_WINDOW):
            return None
        f = self.family
        name = cast['name']
        rescue = None
        heal = 0
        if name == 'knee':
            attack = self.effects.kicks.get(('player_kick', cast_id))
            if not attack or attack['phase'] != 'active' or attack['cancelled']:
                return None
            if actual_hit:
                if not isinstance(roll, int) or isinstance(roll, bool) or not 0 <= roll < 100:
                    raise ValueError('actual knee hit requires a 0..99 probability roll')
                attack['hit_targets'].add('father')
                if roll < 70:
                    rescue, heal = 'knee', 10
        elif name == 'startle':
            if actual_dodge or (f.grabbed and actual_escape):
                rescue, heal = 'startle', 5
        elif name == 'withdraw':
            if not f.grabbed and actual_dodge:
                rescue = 'withdraw'
        else:
            return None
        self.action_results[cast_id] = dict(actual_hit=actual_hit, roll=roll,
            actual_dodge=actual_dodge, actual_escape=actual_escape)
        result = self._settle(node, hp_damage=hp_damage, heal_sp=heal,
                              rescue=rescue, pressure_due=pressure_due)
        result['cast_id'] = cast_id
        return result

    def tick(self, ms):
        if not isinstance(ms, int) or ms < 0:
            raise ValueError('integer game milliseconds required')
        self._sync()
        if self.paused or self.loading or not self.family.alive_home():
            return False
        remaining = ms
        while remaining:
            limits = [t for t in list(self.effects.remaining_by_name.values()) +
                      [self.book.control_remaining, self.family.life.stun] if t > 0]
            step = min([remaining] + limits)
            # Family.tick stores exact Fraction timers even for integer game ms.
            # Convert only integral values; never round an actual time boundary.
            if int(step) != step:
                raise ValueError('sub-millisecond legacy timer requires host time conversion')
            step = int(step)
            active_control = self.book.control_active
            self.family.tick(step)
            self.book.tick(step, advance_economy=False)
            self.effects.tick(step)
            if active_control and not self.book.control_active:
                self.effects.end_control()
            remaining -= step
            self._sync()
        return True

    def cross_door(self, *, actual=True):
        self._sync()
        if not actual or self.paused or self.loading:
            return False
        result = self.family.cross_door()
        self._sync()
        return result
