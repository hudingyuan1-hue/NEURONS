"""S5 deep-room environment; physical contacts are supplied by the engine.

Source: S3:P1546-1576; S4:T14R5, P241-247. This module emits damage
proposals and never mutates avatar HP, handles death, or authorizes an exit.
"""
from dataclasses import dataclass, field
from math import isfinite

ENTITIES = ('avatar', 'original')


@dataclass
class Environment:
    attempt: int = 1
    epoch: int = 0
    room: str = 'hippocampus'
    cold_room: str = 'hypothalamus'
    pulse_room: str = 'brainstem'
    paused: bool = False
    dead: bool = False
    loading: bool = False
    active: bool = True
    clock: int = 0
    entity_rooms: dict = field(default_factory=dict)
    entity_alive: dict = field(default_factory=dict)
    cold: set = field(default_factory=set)
    heat_remaining: int = 0
    effects: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    hit_entities: set = field(default_factory=set)

    def __post_init__(self):
        if not self.entity_rooms:
            self.entity_rooms = {name: self.room for name in ENTITIES}
        if not self.entity_alive:
            self.entity_alive = {name: True for name in ENTITIES}
        self.warnings.append((self.attempt, 0, 0))

    @property
    def running(self):
        return self.active and not (self.paused or self.loading or self.dead)

    @property
    def cycle(self):
        return self.clock // 6000

    @property
    def phase(self):
        offset = self.clock % 6000
        return 'warning' if offset < 1500 else 'active' if offset < 1800 else 'gap'

    def sync_context(self, *, attempt, epoch, paused=False, dead=False,
                     loading=False, active=True, room=None,
                     entity_rooms=None, entity_alive=None):
        if attempt != self.attempt:
            self.attempt = attempt
            self.clock = 0
            self.cold.clear()
            self.heat_remaining = 0
            self.seen.clear()
            self.hit_entities.clear()
            self.effects.clear()
            self.warnings = [(attempt, 0, 0)]
        self.epoch = epoch
        self.paused, self.dead = paused, dead
        self.loading, self.active = loading, active
        if room is not None:
            self.room = room
            self.entity_rooms['avatar'] = room
        if entity_rooms is not None:
            self.entity_rooms = dict(entity_rooms)
            if room is not None:
                self.entity_rooms['avatar'] = room
        if entity_alive is not None:
            self.entity_alive = dict(entity_alive)
        self.cold.intersection_update(
            e for e in ENTITIES
            if self.entity_rooms.get(e) == self.cold_room and self.entity_alive.get(e, False)
        )
        if self.dead or not self.active:
            self.cold.clear()

    def _valid(self, entity, token=None, callback_epoch=None):
        return (self.running and entity in ENTITIES and self.entity_alive.get(entity, False)
                and (callback_epoch is None or callback_epoch == self.epoch)
                and (token is None or (isinstance(token, tuple) and len(token) == 2
                     and token[0] == self.attempt and token not in self.seen)))

    def set_cold(self, entity, actual_inside, token=None, callback_epoch=None):
        if not self._valid(entity, token, callback_epoch):
            return False
        if actual_inside and self.entity_rooms.get(entity) != self.cold_room:
            return False
        if token is not None:
            self.seen.add(token)
        if actual_inside:
            self.cold.add(entity)
        else:
            self.cold.discard(entity)
        return True

    def set_heat(self, entity='avatar', duration_ms=3000, *, actual_effect,
                 token=None, callback_epoch=None):
        if (entity != 'avatar' or not actual_effect
                or not isinstance(duration_ms, int) or not 0 < duration_ms <= 3000
                or not self._valid(entity, token, callback_epoch)):
            return False
        if token is not None:
            self.seen.add(token)
        self.heat_remaining = duration_ms
        return True

    def speed_multiplier(self, entity):
        if entity not in ENTITIES:
            raise ValueError('unknown entity')
        cold = 0.8 if entity in self.cold else 1.0
        heat = 1.25 if entity == 'avatar' and self.heat_remaining > 0 else 1.0
        return cold * heat

    def tick(self, ms):
        if not isinstance(ms, int) or ms < 0:
            raise ValueError('nonnegative integer game milliseconds required')
        if not self.running:
            return
        before = self.cycle
        self.clock += ms
        self.heat_remaining = max(0, self.heat_remaining-ms)
        for cycle in range(before+1, self.cycle+1):
            self.warnings.append((self.attempt, cycle, cycle*6000))

    def contact(self, entity, *, actual_contact,
                affected_segment=True, actual_displacement_m=1.0,
                obstructed_limit_m=1.0, token=None, callback_epoch=None,
                callback_cycle=None):
        if (not self._valid(entity, token, callback_epoch) or self.phase != 'active'
                or not actual_contact or not affected_segment
                or self.entity_rooms.get(entity) != self.pulse_room
                or (callback_cycle is not None and callback_cycle != self.cycle)):
            return False
        target = (self.attempt, self.cycle, entity)
        if target in self.hit_entities:
            return False
        if (not isinstance(actual_displacement_m, (int,float))
                or not isinstance(obstructed_limit_m, (int,float))
                or not isfinite(actual_displacement_m) or not isfinite(obstructed_limit_m)
                or actual_displacement_m < 0 or obstructed_limit_m < 0):
            return False
        if token is not None:
            self.seen.add(token)
        self.hit_entities.add(target)
        displacement = min(1.0, actual_displacement_m, obstructed_limit_m)
        self.effects.append({'id': ('pulse',)+target, 'entity': entity,
                             'cycle': self.cycle, 'hp': 20, 'sp': 0,
                             'knockback_m': displacement,
                             'interrupt': displacement > 0})
        return True
