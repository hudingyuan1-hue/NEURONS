"""S5 F2/F3 combat contracts; caller supplies actual physics/vision facts.
Sources: S3:P1411-1435,P1461-1468,P1495-1525; S4:T18,P213-219.
Four methods copy the inherited implementation with a local spec table;
no inherited module or global is mutated. Other behavior stays inherited.
"""
from dataclasses import dataclass, field
from copy import deepcopy
from combat_flow import CombatFlow, SPECS, BUSY

DEEP_SPECS = deepcopy(SPECS)
DEEP_SPECS.update({
    'doublehead': dict(hp=15, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=False, reach=1.2),
    'twitch': dict(hp=20, sp=0, windup=1200, active=600, recovery=800, cooldown=2000, grab=False, max_move=3.0),
    'reverse': dict(hp=20, sp=0, windup=1200, active=600, recovery=800, cooldown=2000, grab=False, max_move=1.8),
    'face': dict(hp=15, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=False, reach=1.2),
    'original': dict(hp=10, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=True, reach=1.2),
})

@dataclass
class DeepCombatFlow(CombatFlow):
    revenge_armed: bool = False
    knee_history: object = None

    def sync_context(self, **kwargs):
        previous = self.attempt, self.epoch
        if not super().sync_context(**kwargs):
            return False
        if previous != (self.attempt, self.epoch) or self.dead or not self.active or not self._alive('doublehead'):
            self.revenge_armed = False
        return True

    def register_damage(self, token, actor='doublehead', *, source='avatar', actual=True,
                        amount=0, survived=True, callback_epoch=None):
        # Authorization comes from already resolved damage, not an attack press.
        if not self._valid(token, callback_epoch) or actor != 'doublehead':
            return False
        if not (source == 'avatar' and actual and amount > 0 and survived and self._alive(actor)):
            return False
        self.seen.add(token)
        # Further hits remain real damage outside this module, never another order.
        if (self.current(actor) is None or self.current(actor)['phase'] == 'cooldown') and not self.revenge_armed:
            self.revenge_armed = True
            self.facts.append(('retaliation_armed', token))
        return True

    def abandon_retaliation(self, *, actual_lost, checked_last_seen, callback_epoch=None):
        if (self.paused or self.dead or not self.active or
                (callback_epoch is not None and callback_epoch != self.epoch) or
                not actual_lost or not checked_last_seen):
            return False
        a = self.current('doublehead')
        # An ongoing legal physical attack must finish; only pursuit is canceled.
        if a and a['phase'] in {'windup', 'active', 'held'}:
            return False
        self.revenge_armed = False
        self.facts.append(('retaliation_abandoned', self.clock))
        return True

    def register_knee(self, token, *, actual_effective, pose=None, callback_epoch=None):
        if not self._valid(token, callback_epoch) or not actual_effective:
            return False
        self.seen.add(token)
        self.knee_history = deepcopy(pose if pose is not None else 'effective_knee')
        return True

    def aim_twitch(self, token, attack_id, direction, *, second_heel=False, callback_epoch=None):
        if not self._valid(token, callback_epoch):
            return False
        a = self.attacks.get(attack_id)
        if (not a or a['id'][:2] != (self.epoch, self.attempt) or a['actor'] != 'twitch' or
                a['phase'] != 'windup' or a['direction_locked']):
            return False
        self.seen.add(token)
        a['direction'] = deepcopy(direction)
        if second_heel:
            a['direction_locked'] = True
        return True

    def _phase(self, a, phase, reason=None):
        super()._phase(a, phase, reason)
        if phase == 'active':
            a['direction_locked'] = True
        if a['actor'] == 'doublehead' and phase == 'cooldown':
            self.revenge_armed = False

    def start(self, token, actor, target='avatar', direction='forward', *, actual_seen=True,
              range_ready=True, route_safe=True, body_free=True, free_gap_ms=800,
              callback_epoch=None, hit_recovery_complete=True):
        if not self._valid(token, callback_epoch) or actor not in DEEP_SPECS:
            return None
        if actor == 'doublehead' and (target != 'avatar' or not self.revenge_armed or not hit_recovery_complete):
            return None
        if not (self._alive(actor) and self._alive(target) and actual_seen and range_ready and route_safe):
            return None
        if self.current(actor) is not None:
            return None
        if target == 'avatar':
            if self.slots >= 2 or (self.last_avatar_start is not None and self.clock - self.last_avatar_start < 800):
                return None
            if DEEP_SPECS[actor]['grab'] and (not body_free or free_gap_ms < 800):
                return None
        self.seen.add(token)
        self.serial += 1
        aid = (self.epoch, self.attempt, self.serial)
        a = dict(id=aid, actor=actor, target=target, direction=deepcopy(direction),
                 phase='windup', elapsed=0, started=self.clock, hit_targets=set(),
                 hold_target=None, hold_granted=False, room=self.actors[actor].get('room'))
        a['direction_locked'] = actor != 'twitch'
        a['knee_pose'] = deepcopy(self.knee_history) if actor == 'twitch' else None
        self.attacks[aid] = a
        if target == 'avatar':
            self.last_avatar_start = self.clock
        self.facts.append(('start', aid, actor, target, deepcopy(direction)))
        return aid


    def contact(self, token, attack_id, target='avatar', *, actual_contact=True,
                obstructed=False, grip_closed=False, can_hold=True, callback_epoch=None):
        if not self._valid(token, callback_epoch) or not actual_contact or obstructed:
            return None
        a = self.attacks.get(attack_id)
        if not a or a['id'][:2] != (self.epoch, self.attempt) or a['phase'] != 'active' or not self._alive(target):
            return None
        if not self._alive(a['actor']) and a['actor'] != 'assistant':
            return None
        spec = DEEP_SPECS[a['actor']]
        first = target not in a['hit_targets']
        grant = bool(spec['grab'] and grip_closed and can_hold and not a['hold_granted'])
        if grant and target == 'avatar':
            grant = not any(b['phase'] == 'held' and b['hold_target'] == 'avatar' for b in self.attacks.values())
        if not first and not grant:
            return None
        self.seen.add(token)
        out = self._effect(a, target, spec['hp'] if first else 0, spec['sp'] if first else 0, 1200 if grant else 0)
        a['hit_targets'].add(target)
        if grant:
            a['hold_granted'], a['hold_target'] = True, target
            self._phase(a, 'held')
        return out


    def stop_motion(self, attack_id, *, actual_obstacle=True, callback_epoch=None):
        if not self.active or self.dead or self.paused or not actual_obstacle or (callback_epoch is not None and callback_epoch != self.epoch):
            return False
        a = self.attacks.get(attack_id)
        if not a or a['id'][:2] != (self.epoch, self.attempt) or a['actor'] not in {'cat', 'assistant', 'twitch', 'reverse'} or a['phase'] != 'active':
            return False
        self._phase(a, 'recovery', 'physical_stop')
        return True


    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if self.paused or self.dead or not self.active:
            return False
        self.clock += ms
        for a in self.attacks.values():
            rest = ms
            spec = DEEP_SPECS[a['actor']]
            while rest > 0 and a['phase'] in BUSY:
                phase = a['phase']
                duration = 1200 if phase == 'held' else spec[phase]
                step = min(rest, duration - a['elapsed'])
                a['elapsed'] += step
                rest -= step
                if a['elapsed'] >= duration:
                    nxt = {'windup': 'active', 'active': 'recovery', 'held': 'recovery',
                           'recovery': 'cooldown', 'cooldown': 'finished'}[phase]
                    self._phase(a, nxt, 'timeout')
        return True

