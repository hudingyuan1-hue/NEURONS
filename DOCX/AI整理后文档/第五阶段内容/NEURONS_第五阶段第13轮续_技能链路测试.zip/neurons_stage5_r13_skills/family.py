"""S1 event model. Actions denote actual completion/contact, not GUI clicks.

Story/dialogue is not generated here. Read source maps for precedence and scope.
Collision, actual walking distance and animation completion are external inputs.
"""
from dataclasses import dataclass, field
from fractions import Fraction
from rules import Life, Economy, Search, Skill

def mother_branch(sp, cat, dog, father=False):
    if father: return 'collapse'
    if sp<100: return 'porridge'
    if cat: return 'cat_chocolate'
    if dog: return 'door_gift'
    return 'leave'

def father_branch(cat, dog, mother=False):
    if mother: return 'collapse'
    if cat==dog: return 'force'
    return 'cat' if cat else 'dog'

@dataclass
class ParentDraws:
    k: int = 1
    checked_nodes: set = field(default_factory=set)
    selected: set = field(default_factory=set)
    queue: list = field(default_factory=list)
    extra_used: bool = False

    def normal(self, settled, mother_roll, father_roll, first='mother', event_active=False, paused=False):
        if paused or event_active or settled not in (2,4,6,8) or settled in self.checked_nodes:
            return []
        self.checked_nodes.add(settled)
        step=min(self.k-1,4)
        rolls={'mother':mother_roll,'father':father_roll}
        limits={'mother':12+2*step,'father':8+2*step}
        chosen=[p for p in (first, 'father' if first=='mother' else 'mother')
                if p not in self.selected and rolls[p]<limits[p]]
        self.selected.update(chosen); self.queue.extend(chosen)
        return chosen

    def extra(self, present, other_roll, legal_node=True, paused=False):
        other='father' if present=='mother' else 'mother'
        if paused or not legal_node or self.extra_used or other in self.selected:
            return False
        self.extra_used=True
        if other_roll < 8+2*min(self.k-1,4):
            self.selected.add(other); self.queue.append(other)
            return True
        return False


@dataclass
class Family:
    dog: bool = False
    cat: str = 'absent'  # occupying, fighting, carried, exited, absent
    cat_point: int = 1
    cat_rounds: int = 0
    cat_hits: int = 0
    cat_jumps: int = 0
    life: Life = field(default_factory=Life)
    search: Search = field(default_factory=Search)
    mother: str = 'absent'
    father: str = 'absent'
    selected_mother: str = ''
    selected_father: str = ''
    appeared: set = field(default_factory=set)
    blood_gate: bool = False
    rescue_exit: bool = False
    grabbed: bool = False
    father_remaining: object = 0
    pressure_ms: object = 0
    serial: int = 0
    item_serial: int = 0
    gift_floor: dict = field(default_factory=dict)
    gift_kind: object = None
    gifted: bool = False
    rest_committed: bool = False
    unlock_s2: bool = False
    history: list = field(default_factory=list)

    def __post_init__(self):
        if self.dog and self.cat=='occupying': self.cat='fighting'

    def alive_home(self):
        return self.life.phase=='alive' and self.life.place=='S1'

    def event_busy(self):
        return self.mother not in ('absent','gone') or self.father not in ('absent','gone','saved')

    def verdict(self, events):
        self.serial+=1
        result=self.life.frame((self.life.epoch,self.serial),events)
        if result=='death':
            self.search.pending.clear()
            self.grabbed=False
        return result

    def start_search(self, point, dog_point=None):
        if not self.alive_home() or self.event_busy() or self.life.stun: return None
        token=self.search.start(point)
        if token and dog_point is not None and self.dog and self.cat!='fighting':
            if not (self.cat=='occupying' and dog_point==self.cat_point):
                self.search.start(dog_point,'dog')
        return token

    def settle(self, token, complete=True):
        if not self.alive_home() or token not in self.search.pending: return False
        actor,point=self.search.pending[token]
        blocked=actor=='avatar' and self.cat=='occupying' and point==self.cat_point
        old_income=self.search.income
        self.search.settle(token,'complete' if complete and not blocked else 'cancel')
        if self.search.income>old_income:
            self.life.economy.credit(('search',self.search.attempt,point),1)
        if actor=='avatar' and self.cat=='occupying':
            self.cat_rounds+=1
            if self.cat_rounds==3: self.cat='exited'; self.cat_jumps+=1
        return True

    def complete_dog_delivery(self):
        if not self.alive_home() or self.grabbed: return False
        return self.search.deliver()

    def appear(self, parent):
        # Actual entry into the event space, including doorway; queue is not entry.
        if not self.alive_home() or parent in self.appeared: return False
        self.appeared.add(parent)
        other=self.father if parent=='mother' else self.mother
        if other not in ('absent','gone','saved'):
            self.collapse(); return 'collapse'
        if parent=='mother':
            branch=mother_branch(self.life.sp,self.cat in ('occupying','fighting'),self.dog)
            self.selected_mother=branch
            self.mother='gone' if branch=='leave' else branch
        else:
            branch=father_branch(self.cat in ('occupying','fighting'),self.dog)
            self.selected_father=branch
            self.father={'force':'approach','cat':'cat_pickup','dog':'kill_dog'}[branch]
            if branch=='force':
                self.blood_gate=True; self.father_remaining=2000
        self.history.append(('appear',parent,branch))
        return branch

    def collapse(self):
        self.mother=self.father='collapse'
        self.verdict([('collapse',True)])
        self.father_remaining=0

    def remove_cat(self, cause):
        if self.cat not in ('occupying','fighting'): return False
        self.cat='carried' if cause=='father' else 'exited'
        if cause!='father': self.cat_jumps+=1
        return True

    def complete_cat_pickup(self):
        if not self.alive_home() or self.father!='cat_pickup': return False
        self.remove_cat('father')
        self.father='thought' if self.life.sp>=60 else 'approach'
        self.father_remaining=0 if self.father=='thought' else 2000
        self.blood_gate=True
        return True

    def complete_cat_evict(self):
        if not self.alive_home() or self.mother!='cat_chocolate': return False
        self.remove_cat('mother')
        self.mother='chocolate'
        return True

    def complete_kill_dog(self):
        if not self.alive_home() or self.father!='kill_dog': return False
        self.dog=False; self.search.dog_leave()
        self.life.economy.awaken('dog_killed_by_father')
        self.father='gone'
        return True

    def complete_gift(self, roll=0):
        if not self.alive_home() or self.gifted: return False
        if self.mother not in ('porridge','chocolate','door_gift'): return False
        self.gifted=True
        if self.mother=='door_gift':
            kinds=('candy',) if roll<60 else ('chocolate',) if roll<90 else ('candy','chocolate')
            self.gift_kind=kinds
            for item in kinds: self.gift_floor[self._item_id()]=item
            self.mother='gone'
        else:
            item='porridge' if self.mother=='porridge' else 'chocolate'
            self.life.food[self._item_id()]=item
            self.gift_kind=(item,)
            self.mother='bed'
        return True

    def _item_id(self):
        self.item_serial+=1
        return (self.life.epoch,self.item_serial)

    def pickup_gift(self, item):
        if not self.alive_home() or item not in self.gift_floor: return False
        self.life.food[item]=self.gift_floor.pop(item)
        return True

    def complete_eating(self, item, interrupted=False):
        if not self.alive_home() or self.life.stun or self.grabbed or interrupted: return False
        if item not in self.life.food: return False
        self.verdict([('food',item)])
        return True

    def complete_mother_rest(self, interrupted=False):
        if not self.alive_home() or self.mother!='bed' or interrupted or self.rest_committed: return False
        self.rest_committed=True
        assert self.life.rest()
        self.search.restart(self.search.key_point)
        self.unlock_s2=True
        self.life.economy.credit(('unlock',2),3,2)
        self._new_attempt()
        return True

    def skill(self, name, external=True, hit=False, dodge=False, roll=0, actual=True):
        if not self.alive_home(): return 'invalid'
        # Actual reaction is supplied separately from a valid paid submission.
        physical=name not in ('fear','joy')
        if name=='withdraw' and self.grabbed: return 'invalid'
        valid=not (physical and self.life.stun) and not (name=='control' and self.grabbed)
        if self.grabbed and name not in ('startle','fear','joy','knee'): valid=False
        target=next(((t,p) for t,(a,p) in self.search.pending.items() if a=='avatar'),None)
        father_before=self.father
        result=self.life.economy.cast(name,valid=valid,body_reacts=actual)
        if result!='reacted': return result
        # Cat reaction reads pre-cancel target; retirement at the same boundary
        # must not erase an already established startle reaction.
        cat_startles=external and target and self.cat=='occupying' and target[1]==self.cat_point
        if cat_startles:
            self.cat_hits+=1; self.cat='exited'; self.cat_jumps+=1
            self.verdict([('hp_damage',10),('sp_damage',10)])
            if not self.alive_home(): return result
        if target and (cat_startles or name in ('skin','gut','withdraw','knee','startle','fear','control')):
            self.settle(target[0],complete=False)
        if name=='fear': self.verdict([('sp_damage',15)])
        if name=='joy': self.verdict([('heal_sp',20)])
        if father_before=='thought':
            self.father='gone'; self.cat='exited'
            self.blood_gate=False; self.grabbed=False
            return result
        if self.father in ('approach','windup','turn','carry','stunned'):
            if name in ('fear','joy'):
                self.father='saved'; self.blood_gate=False; self.grabbed=False
                self.rescue_exit=True; self.father_remaining=0
            elif name=='knee' and hit and roll<70:
                self.verdict([('heal_sp',10)])
                self.father='stunned'; self.father_remaining=2000; self.grabbed=False
            elif name=='startle' and (self.grabbed or dodge):
                self.verdict([('heal_sp',5)])
                self.grabbed=False; self.father='approach'; self.father_remaining=2000
            elif name=='withdraw' and dodge:
                self.father='approach'; self.father_remaining=2000
        return result

    def tick(self, real_ms, paused=False, scale=1):
        remaining=Fraction(real_ms)*Fraction(str(scale))
        if paused or not self.alive_home(): return
        while remaining>0:
            pressure=self.father in ('thought','approach','windup','turn','carry','stunned')
            step=min(remaining,1000-self.pressure_ms) if pressure else remaining
            if self.father_remaining>0: step=min(step,self.father_remaining)
            self.life.tick(step)
            if pressure: self.pressure_ms+=step
            if self.father_remaining>0: self.father_remaining-=step
            remaining-=step
            if pressure and self.pressure_ms>=1000:
                self.pressure_ms-=1000
                self.verdict([('sp_damage',1)])
                if self.father=='thought' and self.life.sp<60:
                    self.father='approach'; self.father_remaining=2000
            if self.father_remaining==0:
                transitions={'approach':('windup',1000),'windup':('turn',2000), 'turn':('carry',0),'stunned':('approach',2000)}
                if self.father in transitions:
                    old=self.father
                    self.father,self.father_remaining=transitions[old]
                    if old=='windup': self.grabbed=True

    def cross_door(self):
        if not self.alive_home() or self.life.stun: return False
        if self.blood_gate:
            if self.father!='carry': return False
            self.life.enter_hidden(); self.grabbed=False
            self.father='gone'; self.search.pending.clear()
            return 'hiddenStreet'
        if self.grabbed or not (self.rescue_exit or self.unlock_s2 or self.search.key_owner=='avatar'):
            return False
        self.verdict([('exit',True)])
        self.life.finish_exit()
        self.search.pending.clear()
        return 'S2'

    def revive(self):
        if not self.life.revive(): return False
        self.life.place='S1'
        self.search.restart(self.search.key_point)
        self._new_attempt()
        return True

    def _new_attempt(self):
        # Per-attempt participants await a new opening draw; history/inventory stay.
        self.mother=self.father='absent'
        self.dog=False; self.cat='absent'
        self.cat_rounds=self.cat_hits=self.cat_jumps=0
        self.appeared.clear()
        self.blood_gate=self.rescue_exit=self.grabbed=False
        self.father_remaining=self.pressure_ms=0
        self.gifted=self.rest_committed=False
        self.gift_floor.clear()
        self.gift_kind=None
