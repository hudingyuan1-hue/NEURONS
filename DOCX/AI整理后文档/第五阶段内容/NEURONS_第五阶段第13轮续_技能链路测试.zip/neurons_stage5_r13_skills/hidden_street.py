"""R13 independent S1 hidden Street rule adapter; not the S6 Street.

S3:P312-337; S4:T18R7/P211-219/P239/P241/T24R9; S2:T15/P82.
Actual sight, movement, collision, carry and exit facts are caller callbacks.
A legal completed kick is an explicitly authorised external effect: this does
not implement the twelve-skill input/cost/control/shared-cooldown pipeline.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from combat_flow import CombatFlow, BUSY
from rules import Life

HUNTER_SPEC = dict(hp=15, sp=0, windup=1000, active=500, recovery=800,
                   cooldown=1500, grab=False, max_move=1.8)


@dataclass
class HunterCombatFlow(CombatFlow):
    """Local spec implementation: never add hunter to inherited global SPECS."""

    def _phase(self, attack, phase, reason=None):
        super()._phase(attack, phase, reason)
        if phase == 'active':
            attack['direction_locked'] = True

    def start(self, token, actor='hunter', target='avatar', direction=(1, 0), *,
              actual_seen=False, range_ready=False, route_safe=False,
              callback_epoch=None):
        if not self._valid(token, callback_epoch) or actor != 'hunter' or target != 'avatar':
            return None
        if not (self._alive(actor) and self._alive(target) and actual_seen and range_ready and route_safe):
            return None
        if self.current(actor) or self.slots >= 2:
            return None
        if self.last_avatar_start is not None and self.clock - self.last_avatar_start < 800:
            return None
        self.seen.add(token)
        self.serial += 1
        aid = (self.epoch, self.attempt, self.serial)
        self.attacks[aid] = dict(id=aid, actor=actor, target=target,
            direction=deepcopy(direction), direction_locked=False,
            phase='windup', elapsed=0, started=self.clock, hit_targets=set(),
            hold_target=None, hold_granted=False, room='hiddenStreet', moved=0.0)
        self.last_avatar_start = self.clock
        self.facts.append(('start', aid, actor, target, deepcopy(direction)))
        return aid

    def aim(self, token, attack_id, direction, *, actual_aim=False, lock=False, callback_epoch=None):
        attack = self.attacks.get(attack_id)
        if not self._valid(token, callback_epoch) or not actual_aim or not attack:
            return False
        if attack['id'][:2] != (self.epoch, self.attempt) or attack['phase'] != 'windup' or attack['direction_locked']:
            return False
        self.seen.add(token)
        attack['direction'] = deepcopy(direction)
        attack['direction_locked'] = bool(lock)
        return True

    def contact(self, token, attack_id, target='avatar', *, actual_contact=False,
                obstructed=False, hit_region='attack_arm', grip_closed=False,
                callback_epoch=None):
        if not self._valid(token, callback_epoch) or not actual_contact or obstructed:
            return None
        attack = self.attacks.get(attack_id)
        if not attack or attack['id'][:2] != (self.epoch, self.attempt) or attack['phase'] != 'active':
            return None
        if target != 'avatar' or hit_region not in {'attack_arm', 'lunging_body'}:
            return None
        if not self._alive('hunter') or not self._alive(target) or target in attack['hit_targets']:
            return None
        self.seen.add(token)
        effect = self._effect(attack, target, HUNTER_SPEC['hp'], HUNTER_SPEC['sp'], 0)
        attack['hit_targets'].add(target)
        return effect

    def advance(self, token, attack_id, *, actual_distance=0.0, actual_obstacle=False, callback_epoch=None):
        if actual_distance < 0:
            raise ValueError('negative distance')
        attack = self.attacks.get(attack_id)
        if not self._valid(token, callback_epoch) or not attack or attack['phase'] != 'active':
            return False
        if attack['id'][:2] != (self.epoch, self.attempt):
            return False
        if attack['moved'] + actual_distance > HUNTER_SPEC['max_move'] + 1e-9:
            return False  # impossible movement proof is rejected, never teleported
        self.seen.add(token)
        attack['moved'] += actual_distance
        if actual_obstacle or attack['moved'] >= HUNTER_SPEC['max_move']:
            self._phase(attack, 'recovery', 'physical_stop')
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if self.paused or self.dead or not self.active:
            return False
        self.clock += ms
        for attack in self.attacks.values():
            remaining = ms
            while remaining > 0 and attack['phase'] in BUSY:
                phase = attack['phase']
                duration = HUNTER_SPEC[phase]
                step = min(remaining, duration - attack['elapsed'])
                attack['elapsed'] += step
                remaining -= step
                if attack['elapsed'] >= duration:
                    self._phase(attack, {'windup': 'active', 'active': 'recovery',
                        'recovery': 'cooldown', 'cooldown': 'finished'}[phase], 'timeout')
        return True


@dataclass
class HiddenStreet:
    life: Life = field(default_factory=Life)
    memory: dict = field(default_factory=dict)
    combat: HunterCombatFlow = field(default_factory=HunterCombatFlow)
    hunter_hp: int = 60
    hunter_present: bool = False
    entered: bool = False
    paused: bool = False
    loading: bool = False
    position: object = 'entry'
    sees_avatar: bool = False
    last_seen: object = None
    pursuit: str = 'patrol'
    patrol_position: object = None
    father_holding: bool = False
    father_sp_drain_active: bool = False
    hit_stop: int = 0
    seen: set = field(default_factory=set)
    kick_hits: set = field(default_factory=set)
    wounds: list = field(default_factory=list)
    events: list = field(default_factory=list)
    serial: int = 0

    def __post_init__(self):
        if self.life.progress != 1:
            raise ValueError('hidden Street belongs to S1 only')
        self.combat.attempt = self.life.attempts[1]
        self.combat.epoch = self.life.epoch
        self._sync()

    def token(self, identity):
        return (self.life.epoch, identity)

    def _valid(self, token):
        return (isinstance(token, tuple) and len(token) == 2 and
                token[0] == self.life.epoch and token not in self.seen)

    def active(self):
        return (self.entered and self.life.progress == 1 and self.life.place == 'hiddenStreet'
                and self.life.phase == 'alive' and not self.paused and not self.loading)

    def _node(self, token):
        self._sync()
        if not self.active() or not self._valid(token):
            return False
        self.seen.add(token)
        return True

    def _t(self, label):
        self.serial += 1
        return (self.life.attempts[1], (label, self.serial))

    def _sync(self):
        in_hidden = self.entered and self.life.place == 'hiddenStreet' and self.life.progress == 1
        self.combat.sync_context(attempt=self.life.attempts[1], epoch=self.life.epoch,
            paused=self.paused or self.loading, dead=self.life.phase != 'alive', active=in_hidden,
            actors={'hunter': {'alive': self.hunter_present and self.hunter_hp > 0, 'room': 'hiddenStreet'}})

    def _end_control(self):
        skill = self.life.economy.skills.get('control')
        if self.life.economy.control or skill and skill.active:
            self.life.economy.control = False
            if skill:
                skill.active = False
                skill.remaining = 20000

    def enter(self, token, *, actual_father_carry=False, actual_crossing=False, entry_free=False):
        if (self.entered or self.life.progress != 1 or self.life.place == 'hiddenStreet'
                or self.life.phase != 'alive' or self.paused or self.loading or not self._valid(token)
                or not actual_father_carry or not actual_crossing or not entry_free):
            return False
        self.seen.add(token)
        self._end_control()
        self.life.enter_hidden()
        self.entered = self.hunter_present = True
        self.father_holding = self.father_sp_drain_active = False
        self.events.append(('actual_father_carry_entry', self.life.epoch))
        self._sync()
        return True

    def decision(self, *, visible_danger=False):
        if self.life.phase != 'alive':
            return self.life.phase
        if not self.entered or self.life.place != 'hiddenStreet':
            return 's1'
        if self.paused or self.loading:
            return 'paused'
        if self.hit_stop or self.life.stun:
            return 'wait_effect'
        return 'evade' if visible_danger else 'escape'

    def move(self, token, position, *, actual_move=False, passable=False):
        if not self._node(token) or self.hit_stop or self.life.stun or not actual_move or not passable:
            return False
        self.position = deepcopy(position)
        return True  # movement alone never supplies hunter vision or entry rewards

    def observe(self, token, position, *, actual_visible=False):
        if not self._node(token) or not self.hunter_present or not actual_visible:
            return False
        self.sees_avatar = True
        self.last_seen = deepcopy(position)
        self.pursuit = 'pursue'
        return True

    def lose_sight(self, token, *, actually_occluded=False):
        if not self._node(token) or not actually_occluded or not self.sees_avatar:
            return False
        self.sees_avatar = False
        self.pursuit = 'last_seen'
        return True

    def check_last_seen(self, token, position, *, actual_arrival=False, actual_check=False):
        if (not self._node(token) or self.sees_avatar or self.pursuit != 'last_seen'
                or position != self.last_seen or not actual_arrival or not actual_check):
            return False
        self.pursuit = 'return_patrol'
        return True

    def patrol_arrival(self, token, position, *, actual_arrival=False, reachable=False, blocks_exit=True):
        if (not self._node(token) or self.pursuit != 'return_patrol' or not actual_arrival
                or not reachable or blocks_exit):
            return False
        self.patrol_position = deepcopy(position)
        self.pursuit = 'patrol'
        return True

    def start_attack(self, token, *, direction=(1, 0), actual_seen=False, range_ready=False, route_safe=False):
        if not self._node(token) or not self.sees_avatar:
            return None
        return self.combat.start(self._t('start'), direction=direction,
            actual_seen=actual_seen, range_ready=range_ready, route_safe=route_safe,
            callback_epoch=self.life.epoch)

    def aim_attack(self, token, attack_id, direction, *, actual_aim=False, lock=False):
        if not self._node(token):
            return False
        return self.combat.aim(self._t('aim'), attack_id, direction,
            actual_aim=actual_aim, lock=lock, callback_epoch=self.life.epoch)

    def advance_attack(self, token, attack_id, *, actual_distance=0.0, actual_obstacle=False):
        if not self._node(token):
            return False
        return self.combat.advance(self._t('advance'), attack_id,
            actual_distance=actual_distance, actual_obstacle=actual_obstacle, callback_epoch=self.life.epoch)

    def kick_contact(self, token, kick_id, *, authorised=False, actual_body_hit=False):
        if (not self._node(token) or not authorised or not actual_body_hit or not self.hunter_present
                or not isinstance(kick_id, tuple) or len(kick_id) != 2
                or kick_id[0] != self.life.epoch or kick_id in self.kick_hits):
            return False
        self.kick_hits.add(kick_id)
        self.hunter_hp = max(0, self.hunter_hp - 15)
        self.events.append(('actual_kick', kick_id, 15))
        self.combat.interrupt('hunter', actual_body_hit=True, callback_epoch=self.life.epoch)
        if not self.hunter_hp:
            self.hunter_present = self.sees_avatar = False
            self.pursuit = 'retired'
        self._sync()
        return True

    def frame(self, token, *, contacts=(), actual_exit_crossing=False):
        if not self._node(token):
            return 'ignored'
        effects = []
        for contact in contacts:
            callback = dict(contact)
            attack_id = callback.pop('attack_id')
            effect = self.combat.contact(self._t('contact'), attack_id,
                callback_epoch=self.life.epoch, **callback)
            if effect:
                effects.append(effect)
        hp = sum(effect['hp'] for effect in effects)
        sp = sum(effect['sp'] for effect in effects)
        events = [('hp_damage', hp), ('sp_damage', sp)]
        if actual_exit_crossing:
            events.append(('exit', True))
        outcome = self.life.frame(token, events)
        if hp or sp:
            self.wounds.append((token, hp, sp))
            if not self.hit_stop:
                self.hit_stop = 250
        if outcome in {'death', 'exit'}:
            self._end_control()
            self.hit_stop = 0
            self.sees_avatar = False
            self.pursuit = 'stopped'
            if outcome == 'exit':
                outcome = self.life.finish_exit()
            self.events.append(('outcome', outcome))
        self._sync()
        return outcome

    def set_pause(self, *, paused=False, loading=False):
        self.paused, self.loading = paused, loading
        self.life.economy.paused = paused or loading
        self._sync()

    def tick(self, token, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if not self._node(token):
            return False
        self.life.tick(ms)
        self.combat.tick(ms)
        self.hit_stop = max(0, self.hit_stop - ms)
        return True

    def revive(self):
        if self.life.place != 'hiddenStreet' or self.life.progress != 1 or self.life.phase != 'dead':
            return False
        result = self.life.revive()
        self.hit_stop = 0
        self.hunter_present = self.sees_avatar = False
        self.pursuit = 'stopped'
        self._sync()
        return result

    def save_load(self):
        """Exact deepcopy contract only; no filesystem/engine serialization claim."""
        return deepcopy(self)
