"""Street friendly/neutral actions and existing local props.

Authority: S3:P1580-1591,1613-1668,1735-1741,1764-1772,1783-1824,
1900-1905; S4:P156-165,230-238. Actor health and geometry belong to host.
This model records verified actions and proposes healing; it never mutates Life,
spawns inventory, invents evidence, clears history, or grants passage.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from math import dist, isfinite


ROUTE_ACTORS = frozenset({'n08', 'n09', 'n10', 'n20'})
EVIDENCE_FIELDS = {
    'n04': {'paper_number', 'wrist_number'},
    'n06': {'front_number', 'back_number'},
    'n09': {'photo_visible'},
    'n10': {'wrist_number'},
    'n11': {'cancelled_number'},
    'n20': {'transfer_batch'},
    'n24': {'statement_paper', 'broken_recording_wire'},
    'n28': {'box_number'},
    'n31': {'carried_paper'},
    'n43': {'paper_content'},
}
PASSIVE_ACTORS = frozenset({'n04', 'n06', 'n07', 'n08', 'n09', 'n10',
                            'n11', 'n20', 'n24', 'n26', 'n27', 'n28', 'n29', 'n30'})


def _point(value):
    try:
        return (len(value) in (2, 3) and all(isfinite(float(x)) for x in value))
    except (TypeError, ValueError):
        return False


@dataclass
class StreetSupport:
    attempt: int = 1
    epoch: int = 0
    hp: int = 100
    avatar_room: str = 'plaza'
    actors: dict = field(default_factory=dict)
    paused: bool = False
    dead: bool = False
    active: bool = True
    chased: bool = False
    body_blocked: bool = False
    known_connections: dict = field(default_factory=dict)
    progress_ms: int = 0
    phase: str = 'idle'
    used: bool = False
    material_started: bool = False
    material_count: int = 0
    bandaged: bool = False
    pending_id: object = None
    contact_room: object = None
    serial: int = 0
    effects: list = field(default_factory=list)
    settlements: list = field(default_factory=list)
    facts: list = field(default_factory=list)
    evidence: dict = field(default_factory=dict)
    history: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    suggestions: dict = field(default_factory=dict)
    tears: dict = field(default_factory=lambda: {
        a: {'progress': 0.0, 'phase': 'idle', 'fragment_created': False}
        for a in ('n24', 'n31')})
    props: dict = field(default_factory=dict)
    junk_completed: set = field(default_factory=set)
    box: dict = field(default_factory=lambda: {'state': 'held', 'holder': 'n30',
                                             'position': None, 'room': None})
    pending_paper: object = None
    reactions: dict = field(default_factory=dict)
    feedback_seen: set = field(default_factory=set)

    def _present(self, actor):
        a = self.actors.get(actor, {})
        return (a.get('alive', False) and a.get('present', False)
                and a.get('room') == self.avatar_room)

    def _live(self):
        return self.active and not self.dead and self.hp > 0 and not self.paused

    def _available(self, actor):
        return self._live() and self._present(actor)

    def _token(self, token, callback_epoch=None):
        try:
            hash(token)
        except TypeError:
            return False
        return (isinstance(token, tuple) and len(token) == 2
                and token[0] == self.attempt
                and (callback_epoch is None or callback_epoch == self.epoch)
                and (self.epoch, token) not in self.seen)

    def _mark(self, token):
        self.seen.add((self.epoch, token))

    def _fact(self, event, *values):
        record = (event, self.attempt, self.epoch, *deepcopy(values))
        self.facts.append(record)
        self.history.append(record)

    def _eligible(self):
        return (self._available('n07') and self.hp < 100 and not self.chased
                and not self.body_blocked
                and not self.actors['n07'].get('threatened', False))

    def sync_context(self, *, attempt, epoch, paused=False, dead=False,
                     active=True, hp=100, avatar_room=None, room=None,
                     actors=None, actorsdict=None, chased=False,
                     body_blocked=False, bodyblocked=None, known_connections=None):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        new_attempt = attempt != self.attempt
        old_hp, old_room, old_epoch = self.hp, self.avatar_room, self.epoch
        old_nurse = self.actors.get('n07', {})
        if new_attempt:
            self.interrupt_bandage('new_attempt')
            self.progress_ms, self.phase = 0, 'idle'
            self.used = self.material_started = self.bandaged = False
            self.material_count = 0
            self.pending_id = self.contact_room = None
            self.seen.clear()
            self.suggestions.clear()
            self.tears = {a: {'progress': 0.0, 'phase': 'idle', 'fragment_created': False}
                          for a in ('n24', 'n31')}
            self.props.clear()
            self.junk_completed.clear()
            self.box = {'state': 'held', 'holder': 'n30', 'position': None, 'room': None}
            self.pending_paper = None
            self.reactions.clear()
            self.feedback_seen.clear()
        self.attempt, self.epoch = attempt, epoch
        self.paused, self.dead, self.active = bool(paused), bool(dead), bool(active)
        self.hp = max(0, min(100, hp))
        self.avatar_room = avatar_room if avatar_room is not None else (
            room if room is not None else self.avatar_room)
        self.actors = deepcopy(actors if actors is not None else (actorsdict or {}))
        self.chased = bool(chased)
        self.body_blocked = bool(body_blocked if bodyblocked is None else bodyblocked)
        if known_connections is not None:
            self.known_connections = {k: set(v) for k, v in known_connections.items()}
        nurse = self.actors.get('n07', {})
        nurse_harmed = (not new_attempt and 'hp' in old_nurse and 'hp' in nurse
                        and nurse['hp'] < old_nurse['hp'])
        disrupted = (dead or self.hp <= 0 or not active or chased or self.body_blocked
                     or not self._present('n07') or nurse.get('threatened', False)
                     or nurse_harmed or old_room != self.avatar_room or old_epoch != epoch
                     or (not new_attempt and self.hp < old_hp))
        if disrupted:
            self.interrupt_bandage('context_change')
        for actor, tear in self.tears.items():
            if (not active or dead or self.hp <= 0 or not self._present(actor)
                    or old_room != self.avatar_room or old_epoch != epoch
                    or (actor == 'n24' and chased)):
                self.interrupt_tear(actor)
        if (not active or dead or not self._present('n43')
                or old_room != self.avatar_room or old_epoch != epoch):
            self.pending_paper = None
        return True

    def start_bandage(self, token, *, actual_contact=True, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._eligible()
                or not actual_contact or self.used or self.pending_id is not None
                or self.phase in {'bandaging', 'ready', 'completed'}):
            return False
        self._mark(token)
        if not self.material_started:
            self.material_started = True
            self.material_count += 1
        self.contact_room = self.avatar_room
        self.phase = 'ready' if self.progress_ms >= 3000 else 'bandaging'
        self._fact('bandage_contact')
        return True

    def interrupt_bandage(self, reason='actual_interrupt'):
        if self.phase not in {'bandaging', 'ready', 'awaiting_resolution'}:
            return False
        self.pending_id = self.contact_room = None
        self.phase = 'interrupted'
        self._fact('bandage_interrupted', reason, self.progress_ms)
        return True

    def tick(self, ms):
        if not isfinite(ms) or ms < 0:
            raise ValueError('elapsed time must be finite and nonnegative')
        if self.paused:
            return
        if self.phase == 'bandaging' and self._eligible():
            self.progress_ms = min(3000, self.progress_ms + ms)
            if self.progress_ms == 3000:
                self.phase = 'ready'

    def complete_bandage(self, token, *, actual_completed=True, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._eligible()
                or self.phase != 'ready' or not actual_completed or self.used
                or self.progress_ms != 3000 or self.contact_room != self.avatar_room):
            return False
        self._mark(token)
        self.serial += 1
        self.pending_id = ('s6_bandage', self.epoch, self.attempt, self.serial)
        self.effects.append({'id': self.pending_id, 'kind': 'bandage',
                             'hp_heal': 20, 'sp_heal': 0,
                             'attempt': self.attempt, 'epoch': self.epoch})
        self.phase = 'awaiting_resolution'
        return True

    def resolve_bandage(self, effect_id, *, applied, survived):
        if self.pending_id != effect_id or self.phase != 'awaiting_resolution':
            return False
        ok = bool(applied and survived and self.active and not self.dead and self.hp > 0)
        self.settlements.append({'id': effect_id, 'applied': ok})
        self.pending_id = None
        if ok:
            self.used = self.bandaged = True
            self.phase = 'completed'
            self._fact('bandage_completed')
        else:
            self.phase = 'interrupted'
            self.contact_room = None
        return ok

    def suggest_route(self, token, actor, destination, *, actual_visible,
                      actual_reachable, existing=True, original_entry=None,
                      actual_yielded=True, callback_epoch=None):
        if (actor not in ROUTE_ACTORS or not self._token(token, callback_epoch)
                or not self._available(actor) or not actual_visible
                or not actual_reachable or not existing or not actual_yielded
                or destination not in self.known_connections.get(self.avatar_room, set())
                or (actor in {'n08', 'n09', 'n10'} and destination != original_entry)):
            return False
        self._mark(token)
        self.suggestions[actor] = (self.avatar_room, destination)
        self._fact('existing_route_indicated', actor, self.avatar_room, destination)
        return True

    def observe_evidence(self, token, actor, part, value, *, actual_visible,
                         actual_complete=True, corresponding_records=(), callback_epoch=None):
        if (part not in EVIDENCE_FIELDS.get(actor, set())
                or not self._token(token, callback_epoch) or not self._available(actor)
                or not actual_visible or not actual_complete
                or (actor == 'n11' and self.chased)):
            return False
        self._mark(token)
        current = self.evidence.setdefault(actor, {})
        current[part] = deepcopy(value)
        if actor == 'n04' and {'paper_number', 'wrist_number'} <= current.keys():
            current['number_mismatch'] = current['paper_number'] != current['wrist_number']
        if actor == 'n06':
            current['both_seen'] = {'front_number', 'back_number'} <= current.keys()
        if actor == 'n11':
            current['living_cancelled_number_seen'] = True
        if actor == 'n28' and value in corresponding_records:
            current['matched_existing_batch'] = deepcopy(value)
        self._fact('evidence_observed', actor, part, value)
        return True

    def start_tear(self, token, actor, *, actual_contact, callback_epoch=None):
        if (actor not in self.tears or not self._token(token, callback_epoch)
                or not self._available(actor) or not actual_contact
                or self.tears[actor]['phase'] in {'tearing', 'completed'}
                or (actor == 'n24' and self.chased)):
            return False
        self._mark(token)
        self.tears[actor]['phase'] = 'tearing'
        self._fact('tear_started', actor)
        return True

    def advance_tear(self, token, actor, progress, *, actual_torn, callback_epoch=None):
        if (actor not in self.tears or not self._token(token, callback_epoch)
                or not self._available(actor) or not actual_torn
                or not isfinite(progress) or progress <= 0
                or self.tears[actor]['phase'] != 'tearing'
                or (actor == 'n24' and self.chased)):
            return False
        self._mark(token)
        tear = self.tears[actor]
        tear['progress'] = min(1.0, tear['progress'] + progress)
        if tear['progress'] == 1:
            tear['phase'], tear['fragment_created'] = 'completed', True
        self._fact('paper_torn', actor, tear['progress'])
        return True

    def interrupt_tear(self, actor):
        if actor not in self.tears or self.tears[actor]['phase'] != 'tearing':
            return False
        self.tears[actor]['phase'] = 'interrupted'
        self._fact('tear_interrupted', actor, self.tears[actor]['progress'])
        return True

    def indicate_danger(self, token, direction, *, actual_seen, target_still_visible,
                        callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._available('n24')
                or not actual_seen or not target_still_visible):
            return False
        self._mark(token)
        self.interrupt_tear('n24')
        self._fact('observed_danger_direction', 'n24', direction)
        return True

    def dog_intercepts(self, token, actual_hit_order, *, actual_geometry=True,
                       callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._available('n26')
                or not actual_geometry or not actual_hit_order
                or actual_hit_order[0] != 'n26'):
            return False
        self._mark(token)
        self._fact('dog_intercepts', tuple(actual_hit_order))
        return True

    def record_prop(self, token, prop_id, *, kind, room, position, holder=None,
                    actual_existing, callback_epoch=None):
        """Register a host-observed existing prop once; never creates an item."""
        if (not self._token(token, callback_epoch) or not self._live()
                or not actual_existing or prop_id in self.props or not _point(position)
                or room != self.avatar_room
                or kind not in {'maintenance_junk', 'tag', 'stain', 'numbered_paper'}):
            return False
        self._mark(token)
        self.props[prop_id] = {'kind': kind, 'room': room, 'position': tuple(position),
                               'holder': holder, 'state': 'present'}
        self._fact('existing_prop_registered', prop_id, kind)
        return True

    def push_junk(self, token, prop_id, position, *, actual_motion, path_clear,
                  original_route_free, completed=False, callback_epoch=None):
        prop = self.props.get(prop_id, {})
        if (not self._token(token, callback_epoch) or not self._available('n27')
                or prop.get('kind') != 'maintenance_junk'
                or prop.get('room') != self.avatar_room or prop.get('holder') is not None
                or prop_id in self.junk_completed or not actual_motion or not path_clear
                or not original_route_free or not _point(position)
                or len(position) != len(prop['position'])):
            return False
        self._mark(token)
        prop['position'] = tuple(position)
        if completed:
            self.junk_completed.add(prop_id)
        self._fact('maintenance_junk_moved', prop_id, tuple(position), bool(completed))
        return True

    def cleaner_clean(self, token, prop_id, *, actual_contact, completed,
                      callback_epoch=None):
        prop = self.props.get(prop_id, {})
        if (not self._token(token, callback_epoch) or not self._available('n29')
                or not actual_contact or not completed
                or prop.get('kind') not in {'tag', 'stain'}
                or prop.get('room') != self.avatar_room or prop.get('holder') is not None
                or prop.get('state') != 'present'):
            return False
        self._mark(token)
        if prop['kind'] == 'tag':
            prop['state'], prop['holder'] = 'collected', 'n29_waste_bag'
        else:
            prop['state'] = 'cleaned'
        self._fact('local_prop_cleaned', prop_id, prop['kind'])
        return True

    def throw_box(self, token, origin, landing, *, actual_released,
                  nearby_searching_enemy, landing_clear, original_route_free,
                  callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._available('n30')
                or self.box['state'] != 'held' or not actual_released
                or not nearby_searching_enemy or not landing_clear or not original_route_free
                or not _point(origin) or not _point(landing) or len(origin) != len(landing)
                or dist(origin, landing) > 4):
            return False
        self._mark(token)
        self.box.update(state='airborne', holder=None, room=self.avatar_room,
                        origin=tuple(origin), intended_landing=tuple(landing))
        self._fact('box_released', tuple(origin), tuple(landing))
        return True

    def land_box(self, token, position, *, actual_landed, listeners=(), callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._live()
                or self.box['state'] != 'airborne' or not actual_landed
                or not _point(position) or len(position) != len(self.box['origin'])
                or dist(self.box['origin'], position) > 4):
            return False
        self._mark(token)
        self.box.update(state='landed', position=tuple(position))
        checked = []
        for listener in listeners:
            if (listener.get('actual_heard') and listener.get('lost_visual')
                    and listener.get('hostile', True)
                    and 0 <= listener.get('distance', float('inf')) <= 6):
                checked.append(listener['id'])
        self.effects.append({'kind': 'box_noise', 'attempt': self.attempt,
                             'epoch': self.epoch, 'position': tuple(position),
                             'room': self.box['room'], 'radius': 6,
                             'checks': tuple(dict.fromkeys(checked)),
                             'cancel_attacks': False, 'hp_damage': 0, 'sp_damage': 0})
        self._fact('box_landed_noise', tuple(position), tuple(dict.fromkeys(checked)))
        return True

    def start_collect_paper(self, token, prop_id, *, actual_reachable,
                            attacking=False, callback_epoch=None):
        prop = self.props.get(prop_id, {})
        if (not self._token(token, callback_epoch) or not self._available('n43')
                or attacking or not actual_reachable or self.pending_paper is not None
                or prop.get('kind') != 'numbered_paper' or prop.get('holder') is not None
                or prop.get('state') != 'present' or prop.get('room') != self.avatar_room):
            return False
        self._mark(token)
        self.pending_paper = prop_id
        return True

    def collect_paper(self, token, *, actual_collected, attacking=False, callback_epoch=None):
        prop = self.props.get(self.pending_paper, {})
        if (not self._token(token, callback_epoch) or not self._available('n43')
                or attacking or not actual_collected or prop.get('holder') is not None
                or prop.get('state') != 'present' or prop.get('room') != self.avatar_room):
            return False
        self._mark(token)
        prop_id = self.pending_paper
        prop['holder'], prop['state'] = 'n43_folder', 'collected'
        self.pending_paper = None
        self._fact('actual_ground_paper_collected', prop_id)
        return True

    def react_to_attack(self, token, actor, *, actual_hit, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._available(actor)
                or not actual_hit or actor not in PASSIVE_ACTORS | {'n31', 'n43'}):
            return False
        self._mark(token)
        if actor == 'n07':
            self.interrupt_bandage('nurse_attacked')
        if actor in self.tears:
            self.interrupt_tear(actor)
        if actor == 'n43':
            self.pending_paper = None
        # n31/n43 combat responses are owned by the combat model.
        if actor in PASSIVE_ACTORS:
            self.reactions[actor] = 'evade'
        self._fact('support_action_interrupted', actor)
        return True

    def safe_feedback(self, token, actor, event, *, actual_event, callback_epoch=None):
        key = (actor, event)
        if (not self._token(token, callback_epoch) or not self._available(actor)
                or self.chased or not actual_event or key in self.feedback_seen):
            return False
        self._mark(token)
        self.feedback_seen.add(key)
        self._fact('safe_feedback_available', actor, event)
        return True
