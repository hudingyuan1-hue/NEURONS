"""Paid player input -> actual effect -> actual world contact -> cognition.

Rules: S2:P26-36/P43-92; S4:P18-39/P166-176. This models commands and verified
callbacks, not Unity GUI, navigation, rendering, or the S6 death-return save path.
"""
from copy import deepcopy
from dataclasses import dataclass,field
from rules import Life,Search
from awareness import Awareness
from player_skills import PlayerSkills
from skill_effects import SkillEffects


@dataclass
class PlayerSession:
    host: object=None
    life: Life=field(default_factory=Life)
    awareness: Awareness=field(default_factory=Awareness)
    effects: SkillEffects=field(default_factory=SkillEffects)
    search: Search|None=None
    menu: str|None=None
    closing: bool=False
    external_pause: bool=False
    loading: bool=False
    extra_body_blocked: bool=False
    serial: int=0
    current_search: object=None
    search_progress: float=0
    search_base_ms: int=4000
    feedback: dict=field(default_factory=dict)
    commands: dict=field(default_factory=dict)
    results: list=field(default_factory=list)
    applied: set=field(default_factory=set)
    perceived_targets: list=field(default_factory=list)
    current_context: tuple=('S1','idle','none')
    deferred_points: dict=field(default_factory=dict)
    host_pause: bool=False
    host_loading: bool=False
    enemy_stops: dict=field(default_factory=dict)
    pending_motion: object=None

    def __post_init__(self):
        if self.host is not None:
            self.life=self.host.life
            if hasattr(self.host,'awareness'):self.awareness=self.host.awareness
            if not self.battle:
                raise ValueError('S2-S4 host search/handoff integration is not implemented; use its own authoritative host')
        self.book=PlayerSkills(self.life.economy)
        self._observed_life=self._life_marker()
        self._last_host_pause=False;self._last_host_loading=False
        self._last_hp=self.life.hp;self._was_body_blocked=False
        if self.search is None and not self.battle:self.search=Search(level=self.life.progress)
        self._sync()

    @property
    def battle(self):return self.life.progress>=5 or self.life.place=='hiddenStreet'

    @property
    def paused(self):return (self.external_pause or self.menu is not None or self.closing
                            or self.loading or self.host_pause or self.host_loading)

    def _life_marker(self):
        return (self.life.epoch,self.life.phase,self.life.progress,self.life.place=='hiddenStreet')

    def token(self,label='input'):
        self.serial+=1
        return (self.life.epoch,label,self.serial)

    def physical_blocked(self):
        return bool(self.extra_body_blocked or self.life.stun or
                    (self.host is not None and (self.host.blocked() if hasattr(self.host,'blocked')
                      else getattr(self.host,'hit_stop',0))))

    def _sync(self):
        marker=self._life_marker()
        previous=self._observed_life
        changed=(marker[0]!=previous[0] or marker[2:]!=previous[2:] or
                 marker[1]!=previous[1] and marker[1] in {'dead','transition','ended'})
        self._observed_life=marker
        if changed:
            self._end_boundary('death' if self.life.phase=='dead' else 'level')
            if self.search is not None and self.search.level!=self.life.progress and not self.battle:
                self.search=Search(level=self.life.progress)
        if self.host is not None:
            if self.host.paused!=self._last_host_pause:self.host_pause=self.host.paused
            if self.host.loading!=self._last_host_loading:self.host_loading=self.host.loading
            self.host.paused=self._last_host_pause=self.paused
            self.host.loading=self._last_host_loading=self.loading or self.host_loading
            self.host._sync()
        blocked=self.physical_blocked()
        if self.life.hp<self._last_hp or blocked and not self._was_body_blocked:
            self.effects.interrupt_kick(actual=True)
            self.pending_motion=None
        self._last_hp=self.life.hp;self._was_body_blocked=blocked
        attack=self.effects.current_attack
        self.book.sync_context(mode='battle' if self.battle else 'explore',
            paused=self.paused,menu='cast' if self.menu=='cast' and not self.closing else self.menu,
            loading=self.loading or self.host_loading,alive=self.life.phase=='alive',
            transitioning=self.life.phase=='transition',body_blocked=self.physical_blocked(),
            attack_in_progress=self.effects.body_busy() or self.pending_motion is not None,
            attack_has_hit=bool(attack and attack['hit_targets']),
            can_cancel_attack=bool(attack and self.effects.may_cancel_attack('skin')),
            fourth_wall_restricted=self.awareness.restriction)
        self.life.economy.phase=self.life.phase
        self.effects.paused=self.paused
        self.effects.dead=self.life.phase!='alive'
        self.awareness.paused=self.paused
        self.awareness.alive=self.life.phase=='alive'
        self.awareness.mode='battle' if self.battle else 'explore'

    def open_menu(self,kind):
        if kind not in {'cast','upgrade'} or self.life.phase!='alive' or self.loading:return False
        self.menu=kind;self.closing=False;self._sync();return True

    def start_close(self):
        if self.menu is None:return False
        self.closing=True;self._sync();return True

    def finish_close(self,*,actual_finished):
        if not self.closing or not actual_finished:return False
        self.menu=None;self.closing=False;self._sync();return True

    def set_pause(self,value=False,*,loading=False):
        self.external_pause=bool(value);self.loading=bool(loading);self._sync()

    def set_host_pause(self,value=False,*,loading=False):
        """Actual dialogue/loading callbacks own independent pause reasons.

        Use this hook if a dialogue opens during a menu: a shared Boolean cannot
        communicate two simultaneous reasons. Direct host changes are adopted
        when observable; this hook disambiguates an already-paused overlap.
        """
        self.host_pause=bool(value);self.host_loading=bool(loading)
        self._sync()

    def submit(self,name,*,token=None,direction=None,valid_target=True,**facts):
        self._sync()
        if self.closing or self.host_pause or self.host_loading or self.external_pause:return None
        perceived=any(t.get('actual_perceived') and t.get('alive',True)
                      and t.get('threat',True) for t in self.perceived_targets)
        return self.book.submit(token or self.token(),name,direction=direction,
            valid_target=valid_target,threat_perceived=perceived,**facts)

    def react(self,cast_id,*,actual=True,perceived=True,against_intent=False,
              action_id=None,context=None,hp_damage=0,**facts):
        self._sync()
        cast=self.book.casts.get(cast_id)
        if not cast or cast['epoch']!=self.book.epoch or self.paused or self.life.phase!='alive':return None
        conscious=not self.life.stun
        if cast['status']=='resisted':
            if not actual:return None
            if cast_id in self.applied:return None
            self.applied.add(cast_id)
            self.awareness.observe(cast_id,cast['skill'],context or self.current_context,
                perceived=perceived,reaction=False,resisted=True,conscious=conscious,
                action_id=action_id,changes_intent=False)
            self.feedback[cast['skill']]=dict(cast_id=cast_id,resisted=True,actual=False)
            return dict(cast_id=cast_id,resisted=True)
        if cast['status']!='committed':return None
        if not actual:
            return self.book.interrupt(cast_id)
        if self.physical_blocked() and cast['skill'] not in {'fear','happy'}:
            return self.book.interrupt(cast_id)
        proposal=self.effects.begin(cast,actual_reaction=True,
            perceived_targets=self.perceived_targets,body_available=not self.physical_blocked(),**facts)
        if not proposal:return self.book.interrupt(cast_id)
        if proposal.get('motion_duration_external'):self.pending_motion=cast_id
        if proposal.get('stop_active_offense'):
            self.effects.interrupt_kick(actual=True)
        if proposal.get('defer_current_point_ms'):
            self.deferred_points[proposal['deferred_point']]=proposal['defer_current_point_ms']
        control=cast['skill']=='control'
        reacted=self.book.react(cast_id,actual=True,duration_ms=proposal['duration_ms'],body_reacted=not control)
        if not reacted:raise AssertionError('accepted effect lost its committed ledger')
        self.applied.add(cast_id)
        if proposal['cancel_search'] and self.current_search is not None:
            self.search.settle(self.current_search,'cancel');self.current_search=None;self.search_progress=0
        if control:self.awareness.start_control(cast_id)
        outcome=self.life.frame((self.life.epoch,('effect',cast_id)),
            [('hp_damage',hp_damage),('sp_damage',proposal['sp_damage']),('heal_sp',proposal['sp_heal'])])
        if outcome=='death':
            self._end_boundary('death');self._sync();return proposal
        if not control:
            self.awareness.observe(cast_id,cast['skill'],context or self.current_context,
                perceived=perceived,reaction=True,conscious=conscious,
                action_id=action_id,changes_intent=against_intent)
        if cast['skill']=='knee' and hasattr(self.host,'combat') and hasattr(self.host.combat,'register_knee'):
            self.host.combat.register_knee(self.host._t('paid_knee'),actual_effective=True,
                pose=facts.get('pose','effective_knee'),callback_epoch=self.life.epoch)
        self.feedback[cast['skill']]=dict(cast_id=cast_id,resisted=False,actual=True,
            control_has_action=False if control else None,proposal=deepcopy(proposal))
        self.results.append(proposal);self._sync();return proposal

    def start_search(self,point,*,base_ms=None):
        self._sync()
        if self.paused or self.physical_blocked() or self.effects.body_busy() or self.pending_motion is not None or self.battle or self.current_search is not None:return None
        if self.life.phase!='alive' or self.deferred_points.get(point,0)>0:return None
        token=self.search.start(point)
        if token:
            self.current_search=token;self.search_progress=0
            self.search_base_ms=base_ms or {1:4000,2:5000,3:6000,4:7000}[self.life.progress]
            self.current_context=(self.life.place,'search',point)
        return token

    def finish_motion(self,cast_id,*,actual_finished):
        self._sync()
        if not actual_finished or self.paused or self.life.phase!='alive' or self.pending_motion!=cast_id:return False
        self.pending_motion=None;return True

    def complete_search(self,*,actual_finished=True):
        if (not actual_finished or self.paused or self.life.phase!='alive'
                or self.current_search is None or self.search_progress<self.search_base_ms):return False
        token=self.current_search
        actor,point=self.search.pending[token]
        if not self.search.settle(token,'complete'):return False
        self.life.economy.credit(('search',self.life.progress,self.life.attempts[self.life.progress],point),1)
        self.current_search=None;return True

    def _finish_control(self,was_active):
        if was_active and not self.book.control_active:
            self.awareness.end_control();self.effects.end_control()
            self.commands={k:v for k,v in self.commands.items() if v.get('kind')=='kick'}

    def end_control(self):
        was=self.book.control_active
        result=self.book.end_control();self._finish_control(was);self._sync();return result

    def command(self,kind,*,token=None,**facts):
        self._sync()
        result=self.book.control_command(token or self.token(),kind,**facts)
        if not result:return None
        self.commands[result['id']]=result
        if kind=='kick':
            attack=self.effects.start_kick(result['id'],source='control',mode='battle')
            if not attack:raise AssertionError('paid command failed body preconditions')
            result['attack_id']=attack['id']
        return result

    def right_target(self,*,distance,valid_target=True,**facts):
        turn=self.command('turn',valid_target=valid_target)
        if not turn:return None
        kick=self.command('kick',distance=distance,valid_target=valid_target,**facts) if distance<=1 else None
        return dict(turn=turn,kick=kick,auto_pursue=False)

    def control_action(self,action_id,*,actual=True,against_intent=True,context=None,permitted=True):
        self._sync();command=self.commands.get(action_id)
        if (not command or command['kind'] not in {'move','interact'} or not self.book.control_active
                or self.paused or self.physical_blocked() or not actual or not permitted):return False
        if command.get('completed'):return False
        command['completed']=True
        self.book.confirm_control_body(command['cast_id'],actual=True)
        self.awareness.control_action(command['cast_id'],action_id,context or self.current_context,
            actual=True,against_intent=against_intent,kind=command['kind'])
        if 'control' in self.feedback:self.feedback['control']['control_has_action']=True
        return True

    def kick_contact(self,attack_id,target,*,token=None,**facts):
        self._sync()
        if self.host is None or self.paused or self.physical_blocked() or self.life.phase!='alive':return None
        target_entity=None
        if hasattr(self.host,'entity'):target_entity=self.host.entity(target)
        elif hasattr(self.host,'people'):target_entity=self.host.people.entities.get(target)
        hidden=hasattr(self.host,'hunter_hp')
        alive=self.host.hunter_hp>0 and target=='hunter' if hidden else bool(target_entity and target_entity.alive and target_entity.present)
        same_room=hidden or bool(target_entity and target_entity.room==self.host.position)
        if not alive or not same_room:return None
        effect=self.effects.kick_contact(token or self.token(),attack_id,target,target_alive=True,**facts)
        if not effect:return None
        if effect.get('stun_ms'):
            self.enemy_stops[target]=effect['stun_ms']
        if hidden:
            self.host.hunter_hp=max(0,self.host.hunter_hp-effect['hp_damage'])
            if self.host.hunter_hp==0:self.host.hunter_present=False
            self.host.combat.interrupt('hunter',actual_body_hit=True,callback_epoch=self.life.epoch)
        elif target=='original' and hasattr(self.host,'deep'):
            self.host.deep.damage(self.host.deep.token(self.token('player_hit')),effect['hp_damage'],actual_hit=True)
            self.host.combat.interrupt(target,actual_body_hit=True,callback_epoch=self.life.epoch)
        else:
            module=self.host._module(target) if hasattr(self.host,'_module') else self.host.people
            event=module.damage(module.token(self.token('player_hit')),target,effect['hp_damage'],source='avatar',actual=True)
            if not event:raise AssertionError('actual paid kick was not accepted by world')
            self.host.combat.interrupt(target,actual_body_hit=True,callback_epoch=self.life.epoch)
            if target in {'n35','doublehead'}:
                self.host.combat.register_damage(self.host._t('paid_counter'),amount=15,survived=target_entity.alive,callback_epoch=self.life.epoch)
            if hasattr(self.host,'special'):self.host.special.interrupt(target)
        self._sync();return effect

    def start_enemy_attack(self,actor,**facts):
        """Canonical host attack entrance after paid ordinary-enemy hit stops."""
        self._sync()
        if not self.host or self.paused or self.life.phase!='alive' or self.enemy_stops.get(actor,0):return None
        token=(self.life.epoch,self.token('enemy_start'))
        if hasattr(self.host,'hunter_hp'):
            return self.host.start_attack(token,**facts) if actor=='hunter' else None
        return self.host.start_attack(token,actor,**facts)

    def movement_multiplier(self):
        """Multiplier only; actual routes, collision and displacement are external."""
        self._sync()
        if self.paused or self.life.phase!='alive' or self.physical_blocked():return 0
        multiplier=1
        if self.host is not None and hasattr(self.host,'people') and hasattr(self.host.people,'speed_multiplier'):
            multiplier*=self.host.people.speed_multiplier
        if self.host is not None and hasattr(self.host,'environment'):
            multiplier*=.8 if 'avatar' in self.host.environment.cold else 1
        if self.effects.remaining('thermal'):multiplier*=1.25 if self.battle else .75
        return multiplier

    def _end_boundary(self,kind):
        self.book.end_context(kind)
        self.effects.clear_transients();self.commands.clear()
        self.awareness.transition('death' if kind=='death' else 'level')
        self.feedback.clear()
        self.deferred_points.clear()
        self.enemy_stops.clear()
        self.pending_motion=None
        if self.current_search is not None:
            self.search.settle(self.current_search,'cancel');self.current_search=None

    def boundary(self,kind):
        if kind in {'room','floor','street_segment'}:
            self.book.end_context(kind);self.awareness.transition(kind);return True
        self._end_boundary(kind);self._sync();return True

    def actual_restart(self,kind):
        if self.host is not None:return False # actual S5/S6 save-return remains group E
        if kind=='rest':
            if self.life.phase!='alive' or self.life.progress>3 or self.life.place=='hiddenStreet':return False
            self._end_boundary('rest');ok=self.life.rest()
        elif kind=='death':
            if self.life.phase!='dead':return False
            self._end_boundary('death');ok=self.life.revive()
        else:return False
        if ok:
            self._observed_life=self._life_marker()
            self.search.restart(self.search.key_point);self.awareness.new_attempt();self._sync()
        return ok

    def tick(self,ms):
        if not isinstance(ms,int) or ms<0:raise ValueError('nonnegative integer time required')
        self._sync()
        if self.paused or self.life.phase!='alive':return False
        remaining=ms
        while remaining:
            active=list(self.effects.remaining_by_name.values())
            limits=[t for t in active+[self.book.control_remaining,self.life.stun] if t>0]
            step=min([remaining]+limits)
            if self.current_search is not None and not self.physical_blocked() and not self.effects.body_busy():
                rate=.75 if self.effects.remaining('thermal') else 1
                if self.life.sp<20:rate*=.8
                self.search_progress=min(self.search_base_ms,self.search_progress+step*rate)
            was_control=self.book.control_active
            if self.host is None:self.life.tick(step)
            else:
                token=(self.life.epoch,self.token('host_tick'))
                self.host.tick(token,step)
            self.book.tick(step,advance_economy=False);self.effects.tick(step)
            self.deferred_points={p:max(0,t-step) for p,t in self.deferred_points.items() if t>step}
            self.enemy_stops={actor:t-step for actor,t in self.enemy_stops.items() if t>step}
            self._finish_control(was_control)
            remaining-=step;self._sync()
        return True

    def play_feedback(self,skill,*,safe=True):
        self._sync()
        if self.life.phase!='alive' or self.paused or not safe or self.physical_blocked() or self.effects.body_busy() or self.pending_motion is not None:return None
        item=self.feedback.get(skill)
        if not item or skill=='control' and not item.get('control_has_action'):return None
        self.feedback.pop(skill);self.external_pause=True;self._sync();return item
