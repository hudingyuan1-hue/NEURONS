"""Stage-six Street identities and actual-contact life state (R13).

Sources: S3:P1580-1942; S4:P210-247/P292-296. This is a Python design
model, not Unity. Collision, timing, path clearance and visibility are supplied
by the caller. No roster lottery, simultaneous-presence limit or new dialogue.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from math import isfinite

ROOMS = ('plaza', 'side', 'narrow', 'street', 'maintenance', 'node', 'exit')
# The two boundary mouths belong to the preceding segment in this abstraction.
EDGES = {frozenset(pair) for pair in (
    ('plaza', 'side'), ('plaza', 'narrow'), ('narrow', 'street'),
    ('street', 'maintenance'), ('street', 'node'), ('node', 'exit'))}

# ordinal, display name, home, alignment, canonical earlier identity.
_ROWS = (
    (1, '父亲', 'plaza', 'hostile', 'S1_father'),
    (2, '普通护工', 'plaza', 'hostile', 'S3_ordinary_orderly'),
    (3, '转运工', 'plaza', 'hostile', 'S2_transfer_worker'),
    (4, '登记护士', 'plaza', 'neutral', 'S3_registration_nurse'),
    (5, '护士长', 'plaza', 'hostile', 'S3_head_nurse'),
    (6, '背身人', 'plaza', 'neutral', 'S4_back_person'),
    (7, '小护士', 'side', 'friendly', 'S2_junior_nurse'),
    (8, '角落病友', 'side', 'friendly', 'S3_corner_patient'),
    (9, '轮椅患者', 'side', 'friendly', 'S2_wheelchair_patient'),
    (10, '被转运患者', 'side', 'friendly', 'S3_transferred_patient'),
    (11, '术后病友', 'side', 'friendly', 'S3_postoperative_patient'),
    (12, '黑猫', 'narrow', 'hostile', 'S1_cat'),
    (13, '抽动人格', 'narrow', 'hostile', 'S4_twitch'),
    (14, '检查助手', 'narrow', 'hostile', 'S3_check_assistant'),
    (15, '隔离护工', 'narrow', 'hostile', 'S3_isolation_orderly'),
    (16, '肢体错位者', 'narrow', 'hostile', 'S4_dislocated_person'),
    (17, '反身人格', 'street', 'hostile', 'S4_reverse'),
    (18, '档案员', 'street', 'hostile', 'S2_archivist'),
    (19, '双面人格', 'street', 'neutral', 'S4_doubleface'),
    (20, '导诊护士', 'street', 'neutral', 'S2_triage_nurse'),
    (21, '药师', 'street', 'hostile', 'S2_pharmacist'),
    (22, '给药护士／病区护士', 'street', 'hostile', 'S3_medication_nurse'),
    (23, '转运工', 'street', 'hostile', 'S3_transfer_worker'),
    (24, '发言病友', 'street', 'friendly', 'S3_speaking_patient'),
    (25, '作业督导', 'street', 'hostile', 'S3_work_supervisor'),
    (26, '大黄', 'maintenance', 'friendly', 'S1_dog'),
    (27, '空面人格', 'maintenance', 'friendly', 'S4_blank'),
    (28, '治疗药师', 'maintenance', 'neutral', 'S3_treatment_pharmacist'),
    (29, '保洁员', 'maintenance', 'neutral', 'S3_cleaner'),
    (30, '劳动病友', 'maintenance', 'friendly', 'S3_labor_patient'),
    (31, '缝口人', 'maintenance', 'hostile', 'S4_sewn_mouth_person'),
    (32, '母亲', 'node', 'hostile', 'S1_mother'),
    (33, '检查医生', 'node', 'hostile', 'S2_check_doctor'),
    (34, '检查助手', 'node', 'hostile', 'S2_check_assistant'),
    (35, '双头人格', 'node', 'neutral', 'S4_doublehead'),
    (36, '精神科医生', 'node', 'hostile', 'S3_psychiatrist'),
    (37, '保安', 'node', 'hostile', 'S3_security_guard'),
    (38, '治疗主任', 'node', 'hostile', 'S3_treatment_director'),
    (39, '蒙眼人', 'node', 'neutral', 'S4_blindfold_person'),
    (40, '贴面人格', 'exit', 'hostile', 'S4_face'),
    (41, '本身人格', 'exit', 'hostile', 'cross_level_patient'),
    (42, '保安', 'exit', 'hostile', 'S2_security_guard'),
    (43, '档案员', 'exit', 'hostile', 'S3_archivist'),
    (44, '告密病友', 'exit', 'neutral', 'S3_informer_patient'),
    (45, '复述者', 'exit', 'neutral', 'S4_repeater'),
)
ROSTER = {f'n{row[0]:02d}': row for row in _ROWS}
ATTACKERS = frozenset(f'n{n:02d}' for n in (
    1, 2, 3, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 25,
    31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43))
NO_HP_ATTACKERS = frozenset(('n15', 'n21', 'n22'))
MEDICAL_IDS = frozenset(f'n{n:02d}' for n in (
    2, 4, 5, 7, 14, 15, 20, 21, 22, 28, 33, 34, 36, 38))
ELIGIBLE_FRIENDS = frozenset(f'n{n:02d}' for n in (8, 9, 10, 11, 24, 26, 30))


@dataclass(frozen=True)
class Token:
    attempt: int
    event_id: str
    epoch: int = 0


@dataclass
class Entity:
    actor: str
    ordinal: int
    name: str
    home: str
    alignment: str
    max_hp: int
    identity: str
    hp: int = 0
    alive: bool = True
    present: bool = False
    activated: bool = False
    room: str | None = None
    target: str | None = None
    sees_avatar: bool = False
    last_seen: tuple | None = None
    counter_active: bool = False
    history: list = field(default_factory=list)

    def __post_init__(self):
        self.hp = self.max_hp

    @property
    def medical(self):
        return self.actor in MEDICAL_IDS


@dataclass
class StreetPeople:
    attempt: int = 1
    epoch: int = 0
    paused: bool = False
    dead: bool = False
    active: bool = False
    room: str = 'plaza'
    entities: dict = field(default_factory=dict)
    done: set = field(default_factory=set)
    history: list = field(default_factory=list)
    identity_history: dict = field(default_factory=dict)
    qualified_deaths: set = field(default_factory=set)
    boost_layers: int = 0

    def __post_init__(self):
        if self.attempt < 1:
            raise ValueError('attempt must be positive')
        if not self.entities:
            self._build_entities()

    def _build_entities(self):
        self.entities = {}
        for actor, (ordinal, name, home, side, identity) in ROSTER.items():
            hp = (80 if ordinal in (1, 32, 41) else 30 if ordinal == 12
                  else 60 if side == 'hostile' or ordinal in (26, 35) else 40)
            self.entities[actor] = Entity(actor, ordinal, name, home, side, hp,
                                         identity, history=deepcopy(
                                             self.identity_history.get(identity, [])))

    @property
    def avatar_room(self):
        return self.room

    @property
    def speed_multiplier(self):
        return 1 + .05 * self.boost_layers

    @property
    def street_boost(self):
        return self.boost_layers * 5

    def token(self, event_id):
        return Token(self.attempt, str(event_id), self.epoch)

    def _ok(self, token):
        return (isinstance(token, Token) and token.attempt == self.attempt
                and token.epoch == self.epoch and self.active
                and not self.paused and not self.dead)

    def _fresh(self, token, operation, actor=''):
        return self._ok(token) and (operation, actor, token.event_id) not in self.done

    def _mark(self, token, operation, actor=''):
        self.done.add((operation, actor, token.event_id))

    def sync_context(self, *, attempt=None, epoch=None, paused=None, dead=None,
                     active=None, room=None, avatar_room=None):
        """Caller registers a real attempt; activation remains a separate contact.

        Epoch invalidates stale world callbacks without refreshing state. Attempt
        increment is reserved for actual revival; ordinary crossings keep it.
        """
        if attempt is not None and attempt < self.attempt:
            return False
        if epoch is not None and epoch < self.epoch:
            return False
        chosen_room = room if room is not None else avatar_room
        if chosen_room is not None and chosen_room not in ROOMS:
            return False
        if attempt is not None and attempt != self.attempt:
            for e in self.entities.values():
                self.identity_history[e.identity] = deepcopy(e.history)
            self.attempt = attempt
            self._build_entities()
            self.done.clear()
            self.qualified_deaths.clear()
            self.boost_layers = 0
            self.active = False
        if epoch is not None:
            self.epoch = epoch
        if paused is not None:
            self.paused = paused
        if dead is not None:
            self.dead = dead
        if active is not None:
            self.active = active
        if self.dead or not self.active:
            self.boost_layers = 0
        if chosen_room is not None and chosen_room != self.room:
            self.room = chosen_room
            for entity in self.entities.values():
                entity.sees_avatar = False
        return True

    def activate(self, token, room, *, entry_free=True):
        """Activate registered bodies upon actual safe entry; never respawn."""
        if (room not in ROOMS or room != self.room or not entry_free
                or not self._fresh(token, 'activate', room)):
            return ()
        arriving = [e for e in self.entities.values()
                    if e.home == room and e.alive and not e.activated]
        for e in arriving:
            e.present, e.activated, e.room = True, True, room
        if arriving:
            self._mark(token, 'activate', room)
        return tuple(e.actor for e in arriving)

    enter_pending = activate

    def move(self, token, actor, dest, *, passable=True, route=None):
        if actor not in self.entities or not self._fresh(token, 'move', actor):
            return False
        e = self.entities[actor]
        path = (e.room, dest) if route is None else tuple(route)
        if (not e.alive or not e.present or not passable or len(path) < 2
                or path[0] != e.room or path[-1] != dest
                or any(frozenset((a, b)) not in EDGES for a, b in zip(path, path[1:]))):
            return False
        e.room, e.sees_avatar = dest, False
        self._mark(token, 'move', actor)
        return True

    def observe(self, token, actor, avatar_pos, *, actual_visible=True):
        if actor not in self.entities or not self._fresh(token, 'observe', actor):
            return False
        e = self.entities[actor]
        if not e.alive or not e.present or e.room != self.room or not actual_visible:
            e.sees_avatar = False
            return False
        e.sees_avatar, e.last_seen = True, (self.room, deepcopy(avatar_pos))
        if e.alignment == 'hostile':
            other = self.entities.get(e.target)
            if other is None or not other.alive or not other.present:
                e.target = 'avatar'
        self._mark(token, 'observe', actor)
        return True

    def lose_sight(self, actor):
        if actor in self.entities:
            self.entities[actor].sees_avatar = False

    def meet_parents(self, token, *, mutual_visible=True):
        if not self._fresh(token, 'parents') or not mutual_visible:
            return False
        father, mother = self.entities['n01'], self.entities['n32']
        if (not all(e.alive and e.present for e in (father, mother))
                or father.room != mother.room):
            return False
        father.target, mother.target = 'n32', 'n01'
        self._mark(token, 'parents')
        self.history.append({'kind': 'parents_met', 'attempt': self.attempt,
                             'epoch': self.epoch, 'event': token.event_id})
        return True

    def finish_counter(self, token):
        if not self._fresh(token, 'counter_end', 'n35'):
            return False
        e = self.entities['n35']
        if not e.counter_active:
            return False
        e.counter_active, e.target = False, None
        self._mark(token, 'counter_end', 'n35')
        return True

    def _bed_contact_proof(self, actor, amount, source, moving_bed,
                           attack_valid, combat_effect):
        """Validate caller's actual combat contact proof, never a fresh corpse attack.

        Only the combat system can confirm that the bed is still physically
        moving. The effect must be its matching current-attempt contact result.
        """
        if (source not in ('n23', 'n34') or moving_bed is not True
                or attack_valid is not True or not isinstance(combat_effect, dict)):
            return None
        aid = combat_effect.get('attack_id')
        if (not isinstance(aid, tuple) or len(aid) != 3
                or aid[:2] != (self.epoch, self.attempt)
                or not isinstance(aid[2], int) or aid[2] < 1
                or combat_effect.get('actor') != source
                or combat_effect.get('target') != actor
                or combat_effect.get('hp') != amount or amount != 20
                or combat_effect.get('id') != ('combat', aid, actor, 'hit')):
            return None
        return str(combat_effect['id'])

    def _valid_hit(self, token, actor, amount, source, actual, attack_valid,
                   moving_bed=False, combat_effect=None):
        if (actor not in self.entities or not self._fresh(token, 'damage', actor)
                or not actual or isinstance(amount, bool)
                or not isinstance(amount, (int, float)) or not isfinite(amount)
                or amount < 0):
            return False
        target = self.entities[actor]
        if not target.alive or not target.present:
            return False
        if source in ('avatar', 'player'):
            return target.room == self.room
        if source in (None, 'environment'):
            return True
        attacker = self.entities.get(source)
        proof = self._bed_contact_proof(actor, amount, source, moving_bed,
                                        attack_valid, combat_effect)
        if proof is not None and ('bed_contact', actor, proof) in self.done:
            return False
        source_available = bool(attacker and (
            (attacker.alive and attacker.present)
            or (not attacker.alive and attacker.activated and proof is not None)))
        return bool(attacker and source in ATTACKERS and source_available
                    and attacker.room == target.room
                    and (source not in NO_HP_ATTACKERS or amount == 0)
                    and (source != 'n35' or attacker.counter_active or attack_valid))

    def damage(self, token, actor, amount, *, source=None, actual=True,
               avatar_alive=True, attack_valid=False, witnessed=False,
               moving_bed=False, combat_effect=None):
        if not self._valid_hit(token, actor, amount, source, actual, attack_valid,
                               moving_bed, combat_effect):
            return None
        proof = self._bed_contact_proof(actor, amount, source, moving_bed,
                                        attack_valid, combat_effect)
        return self._apply_hit(token, actor, amount, source, avatar_alive, witnessed, proof)

    def apply_hits(self, token, hits, *, avatar_alive=True):
        """Validate one actual-contact frame before committing any actor deaths.

        Each hit uses actor/amount/source/actual and optional event_id,
        attack_valid, witnessed, moving_bed and combat_effect. A dead n23/n34
        source requires moving_bed=True plus attack_valid=True and its matching
        actual combat contact effect; other dead attackers remain invalid.
        attack_valid may confirm a real already
        launched n35 counter from the attack system. Unknown attribution never
        becomes an invented attacker. Supply avatar_alive=False when the same
        batch kills the avatar: history commits, boost does not.
        """
        if not self._ok(token):
            return []
        valid = []
        for hit in hits:
            impact = Token(token.attempt, str(hit.get('event_id', token.event_id)), token.epoch)
            actor, amount = hit['actor'], hit['amount']
            source = hit.get('source')
            if self._valid_hit(impact, actor, amount, source,
                               hit.get('actual', True), hit.get('attack_valid', False),
                               hit.get('moving_bed', False), hit.get('combat_effect')):
                proof = self._bed_contact_proof(actor, amount, source,
                    hit.get('moving_bed', False), hit.get('attack_valid', False),
                    hit.get('combat_effect'))
                valid.append((impact, actor, amount, source, hit.get('witnessed', False), proof))
        results = []
        for impact, actor, amount, source, witnessed, proof in valid:
            if (self._fresh(impact, 'damage', actor) and self.entities[actor].alive
                    and (proof is None or ('bed_contact', actor, proof) not in self.done)):
                results.append(self._apply_hit(impact, actor, amount, source,
                                              avatar_alive, witnessed, proof))
        return results

    def _apply_hit(self, token, actor, amount, source, avatar_alive, witnessed, bed_proof=None):
        e = self.entities[actor]
        before = e.hp
        shattered = actor == 'n26' and source == 'n01'
        e.hp = 0 if shattered else max(0, e.hp - amount)
        killed = e.hp == 0
        qualified = killed and actor in ELIGIBLE_FRIENDS and source in ATTACKERS
        gained = 0
        if killed:
            e.alive, e.present, e.target, e.counter_active = False, False, None, False
            for other in self.entities.values():
                if other.target == actor:
                    other.target = None
        elif actor == 'n35' and source in ('avatar', 'player'):
            e.counter_active, e.target = True, 'avatar'
        if qualified and e.identity not in self.qualified_deaths:
            self.qualified_deaths.add(e.identity)
            if avatar_alive and self.boost_layers < 3:
                self.boost_layers += 1
                gained = 1
        if not avatar_alive:
            self.boost_layers = 0
        event = {'kind': 'damage', 'attempt': self.attempt, 'epoch': self.epoch,
                 'event': token.event_id, 'actor': actor, 'identity': e.identity,
                 'source': source, 'source_identity': self.entities[source].identity
                 if source in self.entities else source,
                 'hp_loss': before - e.hp, 'killed': killed, 'shattered': shattered,
                 'qualified_death': qualified, 'boost_gained': gained,
                 'boost_layers': self.boost_layers, 'witnessed': bool(witnessed),
                 'resources': (0, 0), 'awakening': 0, 'resistance': 0}
        e.history.append(deepcopy(event))
        self.history.append(event)
        self._mark(token, 'damage', actor)
        if bed_proof is not None:
            self.done.add(('bed_contact', actor, bed_proof))
        return event

    def retire(self, token, actor):
        """Ordinary departure is neither death nor a boost; no reentry lottery."""
        if actor not in self.entities or not self._fresh(token, 'retire', actor):
            return False
        e = self.entities[actor]
        if not e.present:
            return False
        e.present, e.target, e.sees_avatar = False, None, False
        self._mark(token, 'retire', actor)
        return True

    def snapshot(self):
        return deepcopy(self)

    @classmethod
    def restore(cls, snapshot):
        if not isinstance(snapshot, cls):
            raise TypeError('StreetPeople snapshot required')
        return deepcopy(snapshot)
