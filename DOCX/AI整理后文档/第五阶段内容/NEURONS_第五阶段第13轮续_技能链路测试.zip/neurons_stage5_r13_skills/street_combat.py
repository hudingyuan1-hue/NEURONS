"""Street attack contracts, S3:P1588-1904; S4:T18,T19,P211-229.

Physics, visible discovery and dose ledgers are caller-resolved facts. Numeric
identity keys keep the two assistants, archivists, guards and transporters apart.
No inherited spec dictionary is modified.
"""
from copy import deepcopy
from dataclasses import dataclass
from combat_flow import BUSY
from deep_combat import DeepCombatFlow, DEEP_SPECS

INHERITED_NAMES = {
    'n01': 'father', 'n02': 'orderly', 'n12': 'cat', 'n13': 'twitch',
    'n17': 'reverse', 'n18': 'archivist', 'n32': 'mother', 'n33': 'doctor',
    'n34': 'assistant', 'n35': 'doublehead', 'n40': 'face', 'n41': 'original',
}
STREET_SPECS = {actor: deepcopy(DEEP_SPECS[name]) for actor, name in INHERITED_NAMES.items()}

def _ordinary(hp, sp=0, *, grab=False, closed_required=False, **extras):
    return dict(hp=hp, sp=sp, windup=800, active=300, recovery=600,
                cooldown=1500, grab=grab, closed_required=closed_required,
                reach=1.2, **extras)

STREET_SPECS.update({
    'n03': _ordinary(15),
    'n14': _ordinary(10, 10, grab=True, closed_required=True),
    'n15': _ordinary(0, 15, grab=True, closed_required=True),
    'n16': _ordinary(10, grab=True, closed_required=True),
    'n21': dict(hp=0, sp=10, windup=1000, active=300, recovery=600,
                cooldown=3000, grab=False, reach=2.0),
    'n22': _ordinary(0, grab=True, closed_required=True),
    'n23': dict(hp=20, sp=0, windup=1200, active=600, recovery=800,
                cooldown=2000, grab=False, max_move=1.0,
                max_displacement=1.0, displacement_kind='knockback'),
    'n25': _ordinary(10, grab=True, closed_required=True),
    'n31': _ordinary(10, grab=True, closed_required=True),
    'n36': _ordinary(10, grab=True, closed_required=True,
                      max_displacement=1.0, displacement_kind='drag'),
    'n37': dict(hp=20, sp=0, windup=1200, active=600, recovery=800,
                cooldown=2000, grab=False, max_move=3.0,
                max_displacement=1.0, displacement_kind='knockback'),
    'n38': _ordinary(10, 10, grab=True, closed_required=True),
    'n42': _ordinary(10, 10, grab=True, closed_required=True,
                      max_displacement=1.0, displacement_kind='push_inward'),
    'n43': _ordinary(15),
})
CLOSED_REQUIRED = frozenset(actor for actor, spec in STREET_SPECS.items() if spec.get('closed_required'))
BEDS = frozenset({'n23', 'n34'})
MOVING = frozenset({'n12', 'n13', 'n17', 'n23', 'n34', 'n37'})

@dataclass
class StreetCombatFlow(DeepCombatFlow):
    avatar_free_since: int | None = None
    _transition_clock: int | None = None

    def _release(self, a, reason):
        if a['hold_target'] == 'avatar':
            self.avatar_free_since = self.clock if self._transition_clock is None else self._transition_clock
        super()._release(a, reason)

    def _phase(self, a, phase, reason=None):
        super()._phase(a, phase, reason)
        if phase == 'active':
            a['direction_locked'] = True
        if a['actor'] == 'n35' and phase == 'cooldown':
            self.revenge_armed = False

    def sync_context(self, *, attempt, epoch, paused=False, dead=False, active=True, actors=None):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        changed = (attempt, epoch) != (self.attempt, self.epoch)
        if changed or dead or not active:
            for a in self.attacks.values():
                if a['phase'] in BUSY:
                    self._phase(a, 'finished', 'new_context' if changed else 'inactive')
            self.last_avatar_start = None
            self.avatar_free_since = None
            self.revenge_armed = False
        if attempt != self.attempt:
            self.seen.clear()
        self.attempt, self.epoch = attempt, epoch
        self.paused, self.dead, self.active = paused, dead, active
        if actors is not None:
            self.actors = deepcopy(actors)
        if not self._alive('n35'):
            self.revenge_armed = False
        for a in self.attacks.values():
            if a['phase'] in {'windup', 'active', 'held'}:
                launched_bed = a['actor'] in BEDS and a['phase'] == 'active'
                if (not self._alive(a['actor']) or not self._alive(a['target'])) and not launched_bed:
                    self._phase(a, 'recovery', 'actor_or_target_left')
        return True

    def _hold_ready(self, target):
        if any(a['phase'] == 'held' and a['hold_target'] == target for a in self.attacks.values()):
            return False
        return target != 'avatar' or self.avatar_free_since is None or self.clock - self.avatar_free_since >= 800

    def start(self, token, actor, target='avatar', direction='forward', *, actual_seen=True,
              range_ready=True, route_safe=True, body_free=True, free_gap_ms=800,
              callback_epoch=None, hit_recovery_complete=True, cup_ready=False,
              paper_ready=False):
        if not self._valid(token, callback_epoch) or actor not in STREET_SPECS:
            return None
        if actor in {'n21', 'n22'} and not cup_ready:
            return None
        if actor == 'n31' and not paper_ready:
            return None
        if actor == 'n35' and (target != 'avatar' or not self.revenge_armed or not hit_recovery_complete):
            return None
        if not (self._alive(actor) and self._alive(target) and actual_seen and range_ready and route_safe):
            return None
        if self.current(actor) is not None:
            return None
        spec = STREET_SPECS[actor]
        if target == 'avatar':
            if self.slots >= 2 or (self.last_avatar_start is not None and self.clock - self.last_avatar_start < 800):
                return None
            if spec['grab'] and (not body_free or free_gap_ms < 800 or not self._hold_ready(target)):
                return None
        self.seen.add(token)
        self.serial += 1
        aid = (self.epoch, self.attempt, self.serial)
        a = dict(id=aid, actor=actor, target=target, direction=deepcopy(direction),
                 phase='windup', elapsed=0, started=self.clock, hit_targets=set(),
                 hold_target=None, hold_granted=False, room=self.actors[actor].get('room'),
                 direction_locked=actor != 'n13',
                 knee_pose=deepcopy(self.knee_history) if actor == 'n13' else None,
                 swallowed=False)
        self.attacks[aid] = a
        if target == 'avatar':
            self.last_avatar_start = self.clock
        if actor == 'n35':
            self.revenge_armed = False
        self.facts.append(('start', aid, actor, target, deepcopy(direction)))
        return aid

    def contact(self, token, attack_id, target='avatar', *, actual_contact=True,
                obstructed=False, grip_closed=False, can_hold=True, callback_epoch=None,
                dose_released=False):
        if not self._valid(token, callback_epoch) or not actual_contact or obstructed:
            return None
        a = self.attacks.get(attack_id)
        if not a or a['id'][:2] != (self.epoch, self.attempt) or a['phase'] != 'active' or not self._alive(target):
            return None
        if not self._alive(a['actor']) and a['actor'] not in BEDS:
            return None
        spec = STREET_SPECS[a['actor']]
        if a['actor'] == 'n21' and not dose_released:
            return None
        first = target not in a['hit_targets']
        grant = bool(spec['grab'] and grip_closed and can_hold and not a['hold_granted'] and self._hold_ready(target))
        if spec.get('closed_required') and not grant:
            return None
        if not first and not grant:
            return None
        self.seen.add(token)
        out = self._effect(a, target, spec['hp'] if first else 0, spec['sp'] if first else 0, 1200 if grant else 0)
        for key in ('max_displacement', 'displacement_kind'):
            if key in spec:
                out[key] = spec[key]
        a['hit_targets'].add(target)
        if grant:
            a['hold_granted'], a['hold_target'] = True, target
            self._phase(a, 'held')
        return out

    def real_swallow(self, token, attack_id, *, actual_swallow=False,
                     dose_authorized=False, callback_epoch=None):
        """Commit a matching, externally authorized swallow; head contact is not dosing."""
        if not self._valid(token, callback_epoch) or not actual_swallow or not dose_authorized:
            return None
        a = self.attacks.get(attack_id)
        if (not a or a['id'][:2] != (self.epoch, self.attempt) or a['actor'] != 'n22'
                or a['phase'] != 'held' or a['swallowed'] or not self._alive('n22')
                or not self._alive(a['hold_target'])):
            return None
        self.seen.add(token)
        out = self._effect(a, a['hold_target'], 0, 20, 0)
        out['id'] = ('combat', a['id'], a['hold_target'], 'swallow')
        out['stop_ms'] = 1500
        a['swallowed'] = True
        self._phase(a, 'recovery', 'actual_swallow')
        return out

    def register_damage(self, token, actor='n35', *, source='avatar', actual=True,
                        amount=0, survived=True, callback_epoch=None):
        if not self._valid(token, callback_epoch) or actor != 'n35':
            return False
        if not (source == 'avatar' and actual and amount > 0 and survived and self._alive(actor)):
            return False
        self.seen.add(token)
        current = self.current(actor)
        if (current is None or current['phase'] == 'cooldown') and not self.revenge_armed:
            self.revenge_armed = True
            self.facts.append(('retaliation_armed', token))
        return True

    def abandon_retaliation(self, *, actual_lost, checked_last_seen, callback_epoch=None):
        if (self.paused or self.dead or not self.active or
                (callback_epoch is not None and callback_epoch != self.epoch) or
                not actual_lost or not checked_last_seen):
            return False
        a = self.current('n35')
        if a and a['phase'] in {'windup', 'active', 'held'}:
            return False
        self.revenge_armed = False
        self.facts.append(('retaliation_abandoned', self.clock))
        return True

    def aim_twitch(self, token, attack_id, direction, *, second_heel=False, callback_epoch=None):
        if not self._valid(token, callback_epoch):
            return False
        a = self.attacks.get(attack_id)
        if (not a or a['id'][:2] != (self.epoch, self.attempt) or a['actor'] != 'n13' or
                a['phase'] != 'windup' or a['direction_locked']):
            return False
        self.seen.add(token)
        a['direction'] = deepcopy(direction)
        if second_heel:
            a['direction_locked'] = True
        return True

    def interrupt(self, actor, *, actual_body_hit=True, callback_epoch=None):
        if not self.active or self.dead or self.paused or not actual_body_hit or (callback_epoch is not None and callback_epoch != self.epoch):
            return False
        a = self.current(actor)
        if not a or a['phase'] not in {'windup', 'active', 'held'}:
            return False
        if actor in BEDS and a['phase'] == 'active':
            a['operator_interrupted'] = True
            self.facts.append(('operator_hit_bed_continues', a['id']))
            return True
        self._phase(a, 'recovery', 'actual_interrupt')
        return True

    def stop_motion(self, attack_id, *, actual_obstacle=True, callback_epoch=None):
        if not self.active or self.dead or self.paused or not actual_obstacle or (callback_epoch is not None and callback_epoch != self.epoch):
            return False
        a = self.attacks.get(attack_id)
        if not a or a['id'][:2] != (self.epoch, self.attempt) or a['actor'] not in MOVING or a['phase'] != 'active':
            return False
        self._phase(a, 'recovery', 'physical_stop')
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if self.paused or self.dead or not self.active:
            return False
        begin = self.clock
        self.clock += ms
        for a in self.attacks.values():
            rest = ms
            spec = STREET_SPECS[a['actor']]
            while rest > 0 and a['phase'] in BUSY:
                phase = a['phase']
                duration = 1200 if phase == 'held' else spec[phase]
                step = min(rest, duration - a['elapsed'])
                a['elapsed'] += step
                rest -= step
                if a['elapsed'] >= duration:
                    nxt = {'windup': 'active', 'active': 'recovery', 'held': 'recovery',
                           'recovery': 'cooldown', 'cooldown': 'finished'}[phase]
                    self._transition_clock = begin + ms - rest
                    self._phase(a, nxt, 'timeout')
                    self._transition_clock = None
        return True
