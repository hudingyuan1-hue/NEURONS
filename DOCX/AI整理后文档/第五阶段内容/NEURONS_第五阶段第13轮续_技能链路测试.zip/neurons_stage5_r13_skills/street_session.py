"""R13 Street host integration. Source-backed Python rules, not engine physics.

S3:P1580-1962; S4:T16/T18-T21/P210-247/P292-297. Actual geometry, sight,
contact, skill authorization and body crossing are external verified callbacks.
No roster lottery, extra key, kill requirement, original dialogue rewrite or
S5 return serialization is introduced here.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from rules import Life
from awareness import Awareness
from street_people import StreetPeople, ROOMS, EDGES
from street_combat import StreetCombatFlow, STREET_SPECS, BEDS
from street_support import StreetSupport
from street_special import StreetSpecial

CONNECTIONS = {r:{next(iter(e-{r})) for e in EDGES if r in e} for r in ROOMS}


@dataclass
class StreetSession:
    life: Life = field(default_factory=lambda:Life(progress=6,place='S6'))
    awareness: Awareness = field(default_factory=Awareness)
    people: StreetPeople = field(default_factory=StreetPeople)
    combat: StreetCombatFlow = field(default_factory=StreetCombatFlow)
    support: StreetSupport = field(default_factory=StreetSupport)
    special: StreetSpecial = field(default_factory=StreetSpecial)
    position: str = 'plaza'
    paused: bool = False
    loading: bool = False
    chased: bool = False
    serial: int = 0
    seen: set = field(default_factory=set)
    applied: set = field(default_factory=set)
    holder: str|None = None
    hold_remaining: int = 0
    hit_stop: int = 0
    drug_stop: int = 0
    free_gap: int = 800
    body_generation: int = 0
    attack_generation: dict = field(default_factory=dict)
    released_doses: dict = field(default_factory=dict)
    control_remaining: int = 0
    heat_remaining: int = 0
    wounds: list = field(default_factory=list)
    ending: str|None = None
    ending_record: dict|None = None
    source_snapshot: dict|None = None
    actual_history: dict = field(default_factory=dict)
    actor_positions: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.life.progress != 6 or self.life.place != 'S6':
            raise ValueError('actual Street entry required')
        self.life.economy.battle = True
        self._sync()
        self._visit(self.position)

    @classmethod
    def from_s5(cls, source):
        if (source.life.progress != 6 or source.life.place != 'S6'
                or source.life.phase != 'alive' or not source.exit_snapshot):
            raise ValueError('S5 actual exit snapshot required')
        history = {}
        for actor,e in source.entity_map().items():
            module=source.deep if actor=='original' else source._module(actor)
            history[e.identity]=deepcopy([event for event in module.history
                                          if event.get('actor')==actor])
        return cls(life=deepcopy(source.life),awareness=deepcopy(source.awareness),
                   people=StreetPeople(identity_history=history),
                   combat=StreetCombatFlow(knee_history=deepcopy(source.combat.knee_history)),
                   source_snapshot=deepcopy(source.exit_snapshot),
                   wounds=deepcopy(source.wounds))

    def token(self,label='event'):
        self.serial += 1
        return self.life.epoch, (label,self.serial)

    def _t(self,label):
        self.serial += 1
        return self.life.attempts[6], (label,self.serial)

    def node(self,token):
        if (self.paused or self.loading or self.life.phase != 'alive'
                or self.life.progress != 6 or self.life.place != 'S6'
                or token[0] != self.life.epoch or token in self.seen):
            return False
        self.seen.add(token)
        return True

    def _visit(self,room):
        self.life.economy.credit(('explore',6,room),1)

    def blocked(self):
        return bool(self.holder or self.hold_remaining or self.hit_stop
                    or self.drug_stop or self.life.stun)

    @property
    def speed_multiplier(self):
        return self.people.speed_multiplier*(1.25 if self.heat_remaining else 1)

    def _actors(self):
        return {a:dict(alive=e.alive,present=e.present,room=e.room,hp=e.hp,
                       alignment=e.alignment,hostile=e.alignment=='hostile',
                       medical=e.medical,sees_avatar=e.sees_avatar,target=e.target,
                       last_seen=deepcopy(e.last_seen),position=self.actor_positions.get(a))
                for a,e in self.people.entities.items()}

    def _release(self):
        if self.holder or self.hold_remaining:
            self.holder = None
            self.hold_remaining = 0
            self.free_gap = 0

    def _sync(self):
        active = self.life.progress==6 and self.life.place=='S6' and self.life.phase=='alive'
        args = dict(attempt=self.life.attempts[6],epoch=self.life.epoch,
                    paused=self.paused or self.loading,dead=not active,active=active)
        self.people.sync_context(**args,room=self.position)
        actors = self._actors()
        self.combat.sync_context(**args,actors={a:{**s,'alive':s['alive'] and s['present']}
                                               for a,s in actors.items()})
        current = self.combat.current(self.holder) if self.holder else None
        if self.holder and (not current or current['phase']!='held'
                            or current['hold_target']!='avatar'):
            self._release()
        counter = self.people.entities['n35']
        counter_attack = self.combat.current('n35')
        if not self.combat.revenge_armed and (not counter_attack or counter_attack['phase']=='cooldown'):
            counter.counter_active, counter.target = False,None
        self.support.sync_context(**args,actors=actors,hp=self.life.hp,
            avatar_room=self.position,chased=self.chased,body_blocked=self.blocked(),
            known_connections=CONNECTIONS)
        self.special.sync_context(**args,actors=actors,avatar_room=self.position,
                                  actual_history=self.actual_history)
        self.awareness.mode='battle'
        self.awareness.paused=self.paused or self.loading
        self.awareness.alive=active
        self.life.economy.paused=self.paused or self.loading

    def set_pause(self,paused=False,*,loading=False):
        self.paused,self.loading=bool(paused),bool(loading)
        self._sync()

    def enter_pending(self,token,*,entry_free=True):
        if not self.node(token):return ()
        out=self.people.activate(self.people.token(self._t('entry')),self.position,entry_free=entry_free)
        self._sync();return out

    def move(self,token,dest,*,actual=True,passable=True):
        if (not self.node(token) or self.blocked() or not actual or not passable
                or dest not in CONNECTIONS[self.position]):return False
        self.position=dest
        self._visit(dest)
        self._sync();return True

    def actor_move(self,token,actor,dest,*,actual=True,passable=True,bed_passable=True):
        if not self.node(token) or not actual or actor in BEDS and not bed_passable:return False
        ok=self.people.move(self.people.token(self._t('actor_step')),actor,dest,passable=passable)
        if ok:self.combat.move_actor(actor,dest,actual_move=True,callback_epoch=self.life.epoch)
        self._sync();return ok

    def observe(self,token,actor,*,actual_visible=True,avatar_pos=(0,0),observer_pos=None):
        if not self.node(token):return False
        if observer_pos is not None and self.special.blocks_vision(observer_pos,avatar_pos):actual_visible=False
        result=self.people.observe(self.people.token(self._t('observe')),actor,avatar_pos,actual_visible=actual_visible)
        if result and actor=='n35' and self.combat.revenge_armed:
            self.people.entities[actor].counter_active=True
            self.people.entities[actor].target='avatar'
        self._sync();return result

    def meet_parents(self,token,*,mutual_visible=True):
        if not self.node(token):return False
        ok=self.people.meet_parents(self.people.token(self._t('parents')),mutual_visible=mutual_visible)
        self._sync();return ok

    def start_attack(self,token,actor,*,target=None,direction=(1,0),actual_seen=True,
                     range_ready=True,route_safe=True,hit_recovery_complete=True):
        if not self.node(token) or actor not in STREET_SPECS:return None
        e=self.people.entities[actor]
        target=target or e.target
        if not e.alive or not e.present or not target:return None
        if target=='avatar':
            if e.room!=self.position or not e.sees_avatar:return None
        else:
            other=self.people.entities.get(target)
            if not other or not other.alive or not other.present or e.room!=other.room:return None
        aid=self.combat.start(self._t('attack'),actor,target,direction,
            actual_seen=actual_seen,range_ready=range_ready,route_safe=route_safe,
            body_free=not self.blocked(),free_gap_ms=self.free_gap,
            callback_epoch=self.life.epoch,hit_recovery_complete=hit_recovery_complete,
            cup_ready=self.special.can_pour(actor),
            paper_ready=self.support.tears['n31']['progress']==1)
        if aid:self.attack_generation[aid]=self.body_generation
        return aid

    def release_dose(self,token,aid,dose_id,*,actual_released=True,oral_spilled=False):
        if not self.node(token):return False
        a=self.combat.attacks.get(aid)
        if (not a or a['actor'] not in {'n21','n22'}
                or a['phase']!=('held' if a['actor']=='n22' else 'active')):return False
        ok=self.special.release_dose(self._t('pour'),a['actor'],aid,dose_id,
            actual_released=actual_released,oral_spilled=oral_spilled,callback_epoch=self.life.epoch)
        if ok:self.released_doses[aid]=dose_id
        return ok

    def _swallow(self,aid,dose_id,actual):
        a=self.combat.attacks.get(aid)
        if (not actual or not a or a['actor']!='n22' or a['phase']!='held'
                or a['swallowed'] or a['hold_target']!='avatar'
                or self.holder!='n22'):return None
        auth=self.special.authorize_swallow(self._t('swallow_auth'),aid,dose_id,
            actual_swallowed=True,callback_epoch=self.life.epoch)
        if not auth:return None
        return self.combat.real_swallow(self._t('swallow_commit'),aid,
            actual_swallow=True,dose_authorized=True,callback_epoch=self.life.epoch)

    def kick_contact(self,token,actor,*,authorised=False,actual_body_hit=True):
        if not self.node(token) or not authorised or self.blocked() or not actual_body_hit:return False
        e=self.people.entities.get(actor)
        if not e or not e.alive or not e.present or e.room!=self.position:return False
        event=self.people.damage(self.people.token(self._t('kick')),actor,15,source='avatar',actual=True,witnessed=True)
        if not event:return False
        self.combat.interrupt(actor,actual_body_hit=True,callback_epoch=self.life.epoch)
        self.support.react_to_attack(self._t('support_hit'),actor,actual_hit=True,callback_epoch=self.life.epoch)
        self.special.interrupt(actor,actual_position=self.actor_positions.get(actor))
        if actor=='n35':
            self.combat.register_damage(self._t('counter'),amount=15,survived=e.alive,callback_epoch=self.life.epoch)
        self._sync();return True

    def record_knee_effect(self,token,*,authorised=False,actual_effective=False,pose=None):
        # Actual effective neural intervention; a missed enemy can still be an
        # effective bodily knee reaction. Control kicks are not this callback.
        if not self.node(token) or not authorised or not actual_effective:return False
        return self.combat.register_knee(self._t('knee_history'),actual_effective=True,
                                        pose=pose,callback_epoch=self.life.epoch)

    def receive_report(self,token,actor,recipient,**facts):
        if not self.node(token):return None
        hint=self.special.receive_report(self._t('report'),actor,recipient,callback_epoch=self.life.epoch,**facts)
        if hint:
            e=self.people.entities[recipient]
            if not e.sees_avatar:
                e.last_seen=(self.people.entities[actor].room,deepcopy(hint['position']))
        self._sync();return hint

    def start_bandage(self,token,*,actual_contact=True):
        if not self.node(token):return False
        return self.support.start_bandage(self._t('bandage'),actual_contact=actual_contact,callback_epoch=self.life.epoch)

    def adopt_control(self,token,*,cast_id,remaining_ms,authorised=False):
        # An already-paid valid result from the skill system, not a free cast.
        if (not self.node(token) or not authorised or self.blocked()
                or not 0<remaining_ms<=6000 or 'control' not in self.life.economy.skills
                or self.control_remaining):return False
        if not self.awareness.start_control(cast_id):return False
        self.control_remaining=remaining_ms;self.life.economy.control=True
        self.life.economy.skills['control'].active=True;return True

    def _end_control(self):
        if self.control_remaining or self.life.economy.control or self.awareness.control is not None:
            self.control_remaining=0;self.life.economy.control=False
            self.awareness.end_control()
            skill=self.life.economy.skills.get('control')
            if skill:skill.active=False;skill.remaining=20000

    def frame(self,token,*,contacts=(),swallows=(),complete_bandage=False,
              actual_body_exit=False,hp_damage=0,sp_damage=0,heal_sp=0):
        if not self.node(token):return 'ignored'
        crossing=bool(actual_body_exit and self.position=='exit')
        old_blocked=self.blocked()
        proposed=None
        if complete_bandage and self.support.complete_bandage(self._t('bandage_complete'),callback_epoch=self.life.epoch):
            proposed=self.support.effects[-1]
        effects=[]
        for contact in contacts:
            c=dict(contact);aid=c.pop('attack_id');target=c.pop('target','avatar')
            witnessed=bool(c.pop('witnessed',False))
            a=self.combat.attacks.get(aid)
            if not a:continue
            actor=self.people.entities[a['actor']]
            other=self.people.entities.get(target)
            room=self.position if target=='avatar' else getattr(other,'room',None)
            # A travelling bed uses its last verified actual room; actor movement
            # updates that room. No remote source is inferred from an effect name.
            source_room=a['room'] if a['actor'] in BEDS else actor.room
            if source_room!=room:continue
            # The 800ms requirement gates a NEW grab start. Its own contact
            # damage/hitstop must not cancel subsequent actual finger closure.
            # A intervening holder invalidates old acquisition generations.
            can_hold=(self.holder is None and not self.life.stun and not self.drug_stop
                      and self.attack_generation.get(aid)==self.body_generation)
            e=self.combat.contact(self._t('contact'),aid,target,
                can_hold=can_hold if target=='avatar' else True,callback_epoch=self.life.epoch,
                dose_released=aid in self.released_doses,**c)
            if e and e['id'] not in self.applied:
                e['witnessed']=witnessed
                self.applied.add(e['id']);effects.append(e)
        for aid,dose_id,actual in swallows:
            e=self._swallow(aid,dose_id,actual)
            if e and e['id'] not in self.applied:self.applied.add(e['id']);effects.append(e)
        avatar=[e for e in effects if e['target']=='avatar']
        npc=[e for e in effects if e['target']!='avatar']
        hp_loss=hp_damage+sum(e['hp'] for e in avatar)
        sp_loss=sp_damage+sum(e['sp'] for e in avatar)
        events=[('hp_damage',hp_loss),('sp_damage',sp_loss),('heal_sp',heal_sp)]
        if proposed:events.append(('heal_hp',proposed['hp_heal']))
        if crossing:events.append(('exit',True))
        result=self.life.frame(token,events)
        hits=[dict(actor=e['target'],amount=e['hp'],source=e['actor'],actual=True,
            event_id=str(e['id']),attack_valid=True,witnessed=e.get('witnessed',False),
            moving_bed=e['actor'] in BEDS,combat_effect=e) for e in npc]
        # NPC contacts are validated against the same pre-frame bodies. An avatar
        # lethal verdict suppresses the speed reward but not the real death record.
        if hits:self.people.apply_hits(self.people.token(self._t('npc_batch')),hits,avatar_alive=result!='death')
        for e in npc:
            if e['hp'] or e['sp']:
                self.support.react_to_attack(self._t('npc_interrupted'),e['target'],actual_hit=True,callback_epoch=self.life.epoch)
                self.special.interrupt(e['target'],actual_position=self.actor_positions.get(e['target']))
        if proposed:self.support.resolve_bandage(proposed['id'],applied=result in {'alive','exit'},survived=result in {'alive','exit'})
        elif hp_loss or sp_loss:self.support.interrupt_bandage('avatar_attacked')
        if hp_loss or sp_loss:self.wounds.append((self.life.epoch,token,hp_loss,sp_loss))
        if result=='death':
            self._end_control();self.awareness.transition('death');self._release()
            self.hit_stop=self.drug_stop=self.heat_remaining=0;self._sync();return 'death'
        if hp_loss or sp_loss:
            if not self.hit_stop:self.hit_stop=250
        for e in avatar:
            if e.get('stop_ms'):self.drug_stop=max(self.drug_stop,e['stop_ms'])
        holds=[e for e in avatar if e['hold_ms'] and self.combat.current(e['actor'])
               and self.combat.current(e['actor'])['phase']=='held']
        if holds and self.holder is None:
            self.holder=holds[0]['actor'];self.hold_remaining=holds[0]['hold_ms']
            self.body_generation+=1;self.free_gap=0
        if not old_blocked and self.blocked():self.free_gap=0
        if result=='exit':
            self._end_control();self.awareness.transition('level')
            self.ending_record=dict(hp=self.life.hp,sp=self.life.sp,wounds=deepcopy(self.wounds),
                npc_history=deepcopy(self.people.history),evidence=deepcopy(self.support.evidence),
                source_snapshot=deepcopy(self.source_snapshot),identified=self.awareness.stage>=3)
            self.ending=self.life.finish_exit()
            self._release();self.hit_stop=self.drug_stop=self.heat_remaining=0
            self._sync();return self.ending
        self._sync();return result

    def tick(self,token,ms):
        if ms<0:raise ValueError('negative time')
        if not self.node(token):return False
        remaining=ms
        while remaining:
            timers=[t for t in (self.hold_remaining,self.hit_stop,self.drug_stop,self.life.stun,
                                self.control_remaining,self.heat_remaining) if t>0]
            step=min([remaining]+timers);blocked=self.blocked()
            self.life.tick(step);self.combat.tick(step);self.support.tick(step);self.special.tick(step)
            for attr in ('hold_remaining','hit_stop','drug_stop','heat_remaining'):
                setattr(self,attr,max(0,getattr(self,attr)-step))
            if self.control_remaining:
                self.control_remaining=max(0,self.control_remaining-step)
                if not self.control_remaining:self._end_control()
            if self.holder and self.hold_remaining==0:self._release()
            if not blocked:self.free_gap=min(800,self.free_gap+step)
            remaining-=step;self._sync()
        return True
