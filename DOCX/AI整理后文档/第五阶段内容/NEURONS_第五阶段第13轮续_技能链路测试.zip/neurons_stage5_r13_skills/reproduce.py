"""Reproduce this continuation only; never overwrite retained initial evidence."""
import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
env=os.environ.copy()
env['RUN_REPORT']=str(root/'results'/'reproduced.json')
files=['test_player_skills.py','test_skill_effects.py','test_player_session.py',
       'test_player_temporal.py','test_family_skill_bridge.py']
command=[sys.executable,'-m','pytest',*files,'-q','--hypothesis-seed=2026101314',
         '--hypothesis-show-statistics']
result=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True)
(root/'results'/'reproduced.log').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stdout,end='')
print(result.stderr,end='',file=sys.stderr)
raise SystemExit(result.returncode)
