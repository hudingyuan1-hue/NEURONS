"""Street special observations and medication ledger; host owns actors/effects.

S3:P1620-1624,P1729-1734,P1743-1755,P1865-1869,P1908-1920;
S4:T16R4-R5,T21R2/R4/R5,P193-194,P228,P238,P297.
Only trusted actual-world callbacks establish sight, hearing, release or swallow.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from math import hypot, isfinite


INITIAL_DOSES = {'n21': 2, 'n22': 1}
CONTROL_SKILLS = {'control', 'complete_control', '完全掌控'}


def _point(value):
    try:
        p = tuple(float(x) for x in value)
        return p if len(p) >= 2 and all(isfinite(x) for x in p) else None
    except (TypeError, ValueError):
        return None


def _crosses(a, b, c, d):
    """Symmetric intersection of actual top-down sight and cloth segments."""
    def side(p, q, r):
        return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    def on(p, q, r):
        return (min(p[0], q[0])-1e-9 <= r[0] <= max(p[0], q[0])+1e-9
                and min(p[1], q[1])-1e-9 <= r[1] <= max(p[1], q[1])+1e-9)
    s = side(a, b, c), side(a, b, d), side(c, d, a), side(c, d, b)
    if s[0]*s[1] < 0 and s[2]*s[3] < 0:
        return True
    return any(abs(v) <= 1e-9 and on(p, q, r) for v, p, q, r in
               ((s[0], a, b, c), (s[1], a, b, d),
                (s[2], c, d, a), (s[3], c, d, b)))


@dataclass
class StreetSpecial:
    attempt: int = 1
    epoch: int = 0
    actors: dict = field(default_factory=dict)
    avatar_room: str = 'plaza'
    paused: bool = False
    dead: bool = False
    active: bool = True
    clock_ms: int = 0
    seen: set = field(default_factory=set)
    reports: dict = field(default_factory=dict)
    report_last_start: dict = field(default_factory=dict)
    hints: list = field(default_factory=list)
    doses: dict = field(default_factory=lambda: dict(INITIAL_DOSES))
    releases: dict = field(default_factory=dict)
    swallowed: set = field(default_factory=set)
    swallow_proposals: list = field(default_factory=list)
    face_casts: set = field(default_factory=set)
    face_phase: str = 'idle'
    face_cast: object = None
    actual_history: dict = field(default_factory=dict)
    cloth_phase: str = 'idle'
    cloth_started: object = None
    cloth_cooldown_until: int = 0
    cloth_position: object = None
    cloth_segments: tuple = ()
    dropped_cloth: list = field(default_factory=list)
    mimic_seen: set = field(default_factory=set)
    mimic_last_start: object = None
    mimic_phase: str = 'idle'
    mimic_action: object = None
    mimic_records: list = field(default_factory=list)
    facts: list = field(default_factory=list)

    def _live(self):
        return self.active and not self.dead and not self.paused

    def _present(self, actor):
        s = self.actors.get(actor, {})
        return bool(s.get('alive', False) and s.get('present', False))

    def _token(self, token, callback_epoch=None):
        try:
            return (isinstance(token, tuple) and len(token) == 2
                    and token[0] == self.attempt
                    and (callback_epoch is None or callback_epoch == self.epoch)
                    and (self.epoch, token) not in self.seen)
        except TypeError:
            return False

    def _mark(self, token):
        self.seen.add((self.epoch, token))

    def sync_context(self, *, attempt, epoch, actors=None, avatar_room='plaza',
                     paused=False, dead=False, active=True, actual_history=None):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        new_attempt = attempt != self.attempt
        if new_attempt:
            history = deepcopy(self.actual_history)
            fresh = StreetSpecial(attempt=attempt, epoch=epoch,
                                  actual_history=history)
            self.__dict__.update(fresh.__dict__)
        elif epoch != self.epoch:
            # Old callbacks cannot complete pending observations in a new epoch.
            for actor in ('n05', 'n44', 'n19', 'n39', 'n45', 'n22'):
                self.interrupt(actor, 'epoch_change')
        self.attempt, self.epoch = attempt, epoch
        self.paused, self.dead, self.active = bool(paused), bool(dead), bool(active)
        self.avatar_room = avatar_room
        if actors is not None:
            self.actors = deepcopy(actors)
        if actual_history is not None:
            self.actual_history = deepcopy(actual_history)
        if dead or not active:
            for actor in ('n05', 'n44', 'n19', 'n39', 'n45', 'n22'):
                self.interrupt(actor, 'inactive')
        else:
            for actor in ('n05', 'n44', 'n19', 'n39', 'n45', 'n22'):
                if not self._present(actor):
                    self.interrupt(actor, 'actor_absent',
                                   actual_position=self.actors.get(actor, {}).get('position'))
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if not self._live():
            return
        self.clock_ms += ms
        for report in self.reports.values():
            if report['phase'] == 'indicating' and self.clock_ms-report['started'] >= 1000:
                report['phase'] = 'ready'
        if self.cloth_phase in {'deploying', 'holding', 'retracting'}:
            elapsed = self.clock_ms-self.cloth_started
            if elapsed < 500:
                self.cloth_phase = 'deploying'
            elif elapsed < 3500:
                self.cloth_phase = 'holding'
            elif elapsed < 4000:
                self.cloth_phase = 'retracting'
            else:
                self.cloth_phase = 'cooldown'
                self.cloth_segments = ()
                self.cloth_cooldown_until = self.cloth_started+10000
        if self.cloth_phase == 'cooldown' and self.clock_ms >= self.cloth_cooldown_until:
            self.cloth_phase = 'idle'

    def start_report(self, token, actor, seen_position, *, actual_saw_avatar,
                     seen_direction=None, callback_epoch=None):
        p = _point(seen_position)
        previous = self.report_last_start.get(actor)
        if (actor not in {'n05', 'n44'} or not self._token(token, callback_epoch)
                or not self._live() or not self._present(actor)
                or not actual_saw_avatar or p is None
                or (previous is not None and self.clock_ms-previous < 8000)
                or self.reports.get(actor, {}).get('phase') in {'indicating', 'ready'}):
            return False
        self._mark(token)
        self.report_last_start[actor] = self.clock_ms
        self.reports[actor] = {'started': self.clock_ms, 'phase': 'indicating',
                               'position': p, 'direction': deepcopy(seen_direction),
                               'recipients': set(), 'epoch': self.epoch,
                               'attempt': self.attempt}
        return True

    def receive_report(self, token, actor, recipient, *, actual_seen_point,
                       actual_heard_board=False, distance_m=None, callback_epoch=None):
        report = self.reports.get(actor)
        receiver = self.actors.get(recipient, {})
        hostile = receiver.get('hostile', False) or receiver.get('alignment') == 'hostile'
        try:
            in_range = distance_m is not None and 0 <= distance_m <= 6
        except TypeError:
            in_range = False
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present(actor) or not self._present(recipient)
                or not hostile or not receiver.get('medical', False)
                or not report or report['phase'] != 'ready'
                or recipient in report['recipients'] or not in_range
                or not actual_seen_point or (actor == 'n05' and not actual_heard_board)):
            return None
        self._mark(token)
        report['recipients'].add(recipient)
        hint = {'kind': 'inspect', 'actor': actor, 'recipient': recipient,
                'position': report['position'], 'direction': deepcopy(report['direction']),
                'attempt': self.attempt, 'epoch': self.epoch,
                'cancel_started_attack': False, 'spawn': False}
        self.hints.append(hint)
        return deepcopy(hint)

    def finish_report(self, token, actor, *, actual_completed, callback_epoch=None):
        report = self.reports.get(actor)
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present(actor) or not actual_completed
                or not report or report['phase'] != 'ready'):
            return False
        self._mark(token)
        report['phase'] = 'completed'
        return True

    def can_pour(self, actor):
        return self._live() and self._present(actor) and self.doses.get(actor, 0) > 0

    def release_dose(self, token, actor, attack_id, dose_id, *, actual_released,
                     oral_spilled=False, callback_epoch=None):
        try:
            key = (self.attempt, dose_id)
            duplicate = key in self.releases or any(
                r['actor'] == actor and r['attack_id'] == attack_id
                for r in self.releases.values())
        except TypeError:
            return False
        if (not self._token(token, callback_epoch) or not self.can_pour(actor)
                or not actual_released or duplicate or attack_id is None or dose_id is None):
            return False
        self._mark(token)
        self.doses[actor] -= 1
        self.releases[key] = {'actor': actor, 'attack_id': attack_id,
                              'dose_id': dose_id, 'epoch': self.epoch,
                              'spilled': bool(oral_spilled), 'cancelled': False}
        return True

    def authorize_swallow(self, token, attack_id, dose_id, *, actual_swallowed,
                          callback_epoch=None):
        try:
            key = (self.attempt, dose_id)
            release = self.releases.get(key)
        except TypeError:
            return None
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n22') or not actual_swallowed or not release
                or release['actor'] != 'n22' or release['attack_id'] != attack_id
                or release['epoch'] != self.epoch or release['spilled']
                or release['cancelled'] or key in self.swallowed):
            return None
        self._mark(token)
        self.swallowed.add(key)
        proposal = {'kind': 'swallow_authorization', 'actor': 'n22',
                    'attack_id': attack_id, 'dose_id': dose_id,
                    'hp_damage': 0, 'sp_damage': 20, 'stop_ms': 1500,
                    'attempt': self.attempt, 'epoch': self.epoch}
        self.swallow_proposals.append(proposal)
        return deepcopy(proposal)

    def observe_intervention(self, token, cast_id, *, skill, effective,
                             actual_seen, actual_visible_body_reaction,
                             actual_control_moved=False, resisted=False,
                             menu_preview=False, callback_epoch=None):
        try:
            known = cast_id in self.face_casts
        except TypeError:
            return False
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n19') or cast_id is None or known
                or not effective or not actual_seen or not actual_visible_body_reaction
                or resisted or menu_preview
                or (skill in CONTROL_SKILLS and not actual_control_moved)):
            return False
        self._mark(token)
        self.face_casts.add(cast_id)
        if self.face_phase == 'facing':
            self.facts.append(('face_holds_gaze', cast_id))
        elif self.face_phase != 'turning':
            self.face_phase, self.face_cast = 'turning', cast_id
        # Observations while already turning are not queued.
        return True

    def complete_face_turn(self, token, *, actual_completed, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n19') or self.face_phase != 'turning'
                or not actual_completed):
            return False
        self._mark(token)
        self.face_phase = 'facing'
        self.facts.append(('face_turn_completed', self.face_cast))
        return True

    def real_faces(self):
        return {'front': deepcopy(self.actual_history.get('current_appearance')),
                'rear_wounds': deepcopy(self.actual_history.get('real_old_wounds', []))}

    def start_cloth(self, token, actual_position, *, actual_heard_footsteps,
                    callback_epoch=None):
        position = _point(actual_position)
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n39') or not actual_heard_footsteps
                or position is None or self.cloth_phase != 'idle'
                or self.clock_ms < self.cloth_cooldown_until):
            return False
        self._mark(token)
        self.cloth_phase, self.cloth_started = 'deploying', self.clock_ms
        self.cloth_position, self.cloth_segments = position, ()
        return True

    def update_cloth_geometry(self, token, segments, *, actual_position,
                              actual_geometry, callback_epoch=None):
        position = _point(actual_position)
        normalized = []
        try:
            for a, b in segments:
                a, b = _point(a), _point(b)
                if a is None or b is None:
                    return False
                normalized.append((a, b))
        except (TypeError, ValueError):
            return False
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n39') or not actual_geometry or position is None
                or self.cloth_phase not in {'deploying', 'holding', 'retracting'}):
            return False
        self._mark(token)
        self.cloth_position, self.cloth_segments = position, tuple(normalized)
        return True

    def blocks_vision(self, observer_position, target_position, *, actual_sight_plane=True):
        # Geometry is solely a sight query: never a collision wall, shield or hit veto.
        a, b = _point(observer_position), _point(target_position)
        if not actual_sight_plane or a is None or b is None:
            return False
        return any(_crosses(a, b, c, d) for c, d in self.cloth_segments)

    def observe_action(self, token, action_id, action, *, actual_seen,
                       actual_clear=True, menu_input=False, future_prediction=False,
                       callback_epoch=None):
        try:
            known = action_id in self.mimic_seen
        except TypeError:
            return False
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n45') or not actual_seen or not actual_clear
                or menu_input or future_prediction or action_id is None or known):
            return False
        self._mark(token)
        self.mimic_seen.add(action_id)
        if (self.mimic_phase in {'imitating', 'writing'}
                or (self.mimic_last_start is not None
                    and self.clock_ms-self.mimic_last_start < 3000)):
            return False
        self.mimic_last_start = self.clock_ms
        self.mimic_phase, self.mimic_action = 'imitating', (action_id, deepcopy(action))
        return True

    def complete_mimic(self, token, *, actual_mimicked, actual_written,
                       callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('n45')
                or self.mimic_phase not in {'imitating', 'writing'}
                or not actual_mimicked):
            return False
        self._mark(token)
        if not actual_written:
            self.mimic_phase = 'writing'
            return False
        self.mimic_records.append({'action_id': self.mimic_action[0],
                                   'action': deepcopy(self.mimic_action[1]),
                                   'annotation': '自主行为',
                                   'damage': 0, 'displacement': 0,
                                   'attempt': self.attempt, 'epoch': self.epoch})
        self.mimic_phase = 'completed'
        return True

    def interrupt(self, actor, reason='actual_interrupt', *, actual_position=None):
        changed = False
        if actor in {'n05', 'n44'}:
            report = self.reports.get(actor)
            if report and report['phase'] in {'indicating', 'ready'}:
                report['phase'] = 'interrupted'
                changed = True
        elif actor == 'n19' and self.face_phase == 'turning':
            self.face_phase, self.face_cast = 'interrupted', None
            changed = True
        elif actor == 'n45' and self.mimic_phase in {'imitating', 'writing'}:
            self.mimic_phase, self.mimic_action = 'interrupted', None
            changed = True
        elif actor == 'n39' and self.cloth_phase in {'deploying', 'holding', 'retracting'}:
            # Released material remains an actual object at the last real position.
            position = _point(actual_position) or self.cloth_position
            self.dropped_cloth.append({'position': position,
                                       'last_held_segments': deepcopy(self.cloth_segments),
                                       'reason': reason, 'collision_wall': False,
                                       'invulnerability': False})
            self.cloth_segments = ()
            self.cloth_phase = 'cooldown'
            self.cloth_cooldown_until = self.clock_ms+6000
            changed = True
        elif actor == 'n22':
            for key, release in self.releases.items():
                if release['actor'] == 'n22' and key not in self.swallowed and not release['cancelled']:
                    release['cancelled'] = True
                    changed = True
        if changed:
            self.facts.append(('interrupted', actor, reason))
        return changed
