"""S5F2 identities and observable noncombat actions.

S3:P1411-1516, S4:T20, S4 appearance rules. Actual contact, visibility,
animation callbacks and cart progress are caller-supplied physical facts;
this model does not prove Unity geometry, animation or perception.
"""
from dataclasses import dataclass, field
from copy import deepcopy
from rules import Spawn
from s5_people import People5, Entity, Token, EDGES as F1_EDGES

ROOMS = ('bridge', 'rhythm', 'index', 'fork', 'identity', 'exit')
EDGES = F1_EDGES | {frozenset(e) for e in (
    ('bridge', 'index'), ('index', 'fork'), ('fork', 'exit'),
    ('bridge', 'rhythm'), ('rhythm', 'identity'), ('identity', 'exit'),
    ('fork', 'bridge'))}
ROSTER = {
    'doublehead': ('bridge', 'neutral', 60, 'S4_doublehead'),
    'twitch': ('rhythm', 'hostile', 60, 'S4_twitch'),
    'blank': ('index', 'friendly', 40, 'S4_blank'),
    'reverse': ('fork', 'hostile', 60, 'S4_reverse'),
    'doubleface': ('identity', 'neutral', 40, 'S4_doubleface'),
    'face': ('exit', 'hostile', 60, 'S4_face'),
}
TEXT = {
    'blank': '𩇬䵉䶴䂙䨻䵊䴓㱎㔿𩉻䶺䴔䶳！',
    'doubleface': '䶹䶱䴕䲈䶼䴡䵿䶳䴴䵳䶸䴵！',
}


@dataclass
class Personalities(People5):
    avatar_room: str = 'bridge'
    prior_knowledge: set = field(default_factory=set)
    current_forms: tuple = ()
    wound_history: tuple = ()
    cart_progress: float = 0.0
    cart_phase: str = 'idle'
    cart_blocked: bool = False
    turn_cast: str | None = None
    turn_phase: str = 'idle'
    back_to_camera: bool = False
    witnessed_casts: set = field(default_factory=set)
    dialogue_pending: set = field(default_factory=set)

    def __post_init__(self):
        assert self.attempt >= 1
        if not self.entities:
            self.entities = {actor: Entity(actor, home, side, hp, identity,
                                Spawn('s5', self.attempt))
                             for actor, (home, side, hp, identity) in ROSTER.items()}

    @property
    def base_path_open(self):
        """Design invariant, not a Unity pathfinding result."""
        return True

    def sync_context(self, **kwargs):
        next_attempt = kwargs.get('attempt', self.attempt)
        reset = next_attempt is not None and next_attempt > self.attempt
        ok = super().sync_context(**kwargs)
        if ok and reset:
            self.cart_progress = 0.0
            self.cart_phase = 'idle'
            self.cart_blocked = False
            self.turn_cast = None
            self.turn_phase = 'idle'
            self.back_to_camera = False
            self.witnessed_casts.clear()
            self.dialogue_pending.clear()
        return ok

    def enter_pending(self, token, room, *, entry_free=True):
        if (not self._fresh(token, 'batch', room) or room != self.avatar_room
                or not entry_free or room not in ROOMS
                or self.time_ms - self.batch_at.get(room, -10000) < 10000):
            return ()
        batch = [e for e in self.entities.values()
                 if e.home == room and e.spawn.state == 'pending']
        if not batch:
            return ()
        for entity in batch:
            entity.spawn.enter()
            entity.present = True
            entity.room = room
        self.batch_at[room] = self.time_ms
        self._mark(token, 'batch', room)
        return tuple(e.actor for e in batch)

    def move(self, token, actor, dest, *, passable=True, bed_passable=True):
        if actor not in self.entities or not self._fresh(token, 'move', actor):
            return False
        entity = self.entities[actor]
        if (not entity.alive or not entity.present or not passable
                or frozenset((entity.room, dest)) not in EDGES):
            return False
        entity.room = dest
        entity.sees_avatar = False
        if actor == 'blank' and dest != 'index' and self.cart_phase != 'yield':
            self.cart_phase = 'interrupted'
        self._mark(token, 'move', actor)
        return True

    def _usable(self, actor, *, co_present=True):
        entity = self.entities[actor]
        return (entity.alive and entity.present
                and (not co_present or entity.room == self.avatar_room))

    def start_cart(self, token, *, actual_approach=False, parking_clear=False):
        if (not self._fresh(token, 'cart_start') or not actual_approach
                or not parking_clear or not self._usable('blank')
                or self.entities['blank'].room != 'index'
                or self.cart_progress >= 1.0
                or self.cart_phase not in ('idle', 'interrupted')):
            return False
        self.cart_phase = 'inspect'
        self.cart_blocked = False
        self._mark(token, 'cart_start')
        self.dialogue_pending.add('blank')
        return True

    def cart_step(self, token, stage, *, actual=False, blocked=False, progress=None):
        """Progress is actual normalized position along the authored push path.

        No fixed push speed or duration is invented. A body/obstacle stops push;
        animation completion alone never moves the cart.
        """
        if (not self._fresh(token, 'cart_step') or not actual
                or not self._usable('blank', co_present=False)
                or self.entities['blank'].room != 'index'):
            return False
        transitions = {'inspect': 'approach', 'approach': 'grip',
                       'grip': 'push', 'park': 'yield'}
        if stage == 'push':
            if self.cart_phase != 'push':
                return False
            if blocked:
                self.cart_blocked = True
            elif progress is None or not self.cart_progress <= progress <= 1.0:
                return False
            else:
                self.cart_blocked = False
                self.cart_progress = float(progress)
                if progress == 1.0:
                    self.cart_phase = 'park'
        elif stage in transitions and self.cart_phase == stage:
            self.cart_phase = transitions[stage]
        else:
            return False
        self._mark(token, 'cart_step')
        return True

    def witness_intervention(self, token, cast_id, *, effective=False,
                             visible_reaction=False, witnessed=False,
                             same_room=True, wall_blocked=False, kind='skill',
                             control_action=False):
        if (not self._fresh(token, 'witness_intervention')
                or str(cast_id) in self.witnessed_casts
                or not self._usable('doubleface') or not effective
                or not visible_reaction or not witnessed or not same_room
                or wall_blocked or kind not in ('skill', 'control')
                or (kind == 'control' and not control_action)):
            return False
        self.witnessed_casts.add(str(cast_id))
        self.turn_cast = str(cast_id)
        self.turn_phase = 'gaze' if self.back_to_camera else 'turning'
        self.dialogue_pending.add('doubleface')
        self._mark(token, 'witness_intervention')
        return True

    def finish_turn(self, token, *, actual_back_to_camera=False):
        if (not self._fresh(token, 'turn_complete')
                or not self._usable('doubleface', co_present=False)
                or self.turn_phase != 'turning' or not actual_back_to_camera):
            return False
        self.back_to_camera = True
        self.turn_phase = 'gaze'
        self._mark(token, 'turn_complete')
        return True

    def _apply_hit(self, token, actor, amount, source):
        result = super()._apply_hit(token, actor, amount, source)
        if result['hp_loss']:
            if actor == 'blank' and self.cart_phase != 'yield':
                self.cart_phase = 'interrupted'
                self.cart_blocked = False
            if actor == 'doubleface':
                self.turn_phase = 'interrupted'
                self.turn_cast = None
        return result

    def retire(self, token, actor):
        ok = super().retire(token, actor)
        if ok:
            if actor == 'blank' and self.cart_phase != 'yield':
                self.cart_phase = 'interrupted'
            if actor == 'doubleface':
                self.turn_phase = 'interrupted'
                self.turn_cast = None
        return ok

    def friend_dialogue(self, token, actor):
        if (actor not in TEXT or actor not in self.dialogue_pending
                or not self._fresh(token, 'speech', actor)
                or self.chased or not self._usable(actor)
                or self.entities[actor].spoken):
            return None
        self.entities[actor].spoken = True
        self.dialogue_pending.discard(actor)
        self._mark(token, 'speech', actor)
        return TEXT[actor]

    def appearance(self, actor):
        """Return only actual established history; never infer avatar stitches."""
        if actor not in self.entities:
            return None
        return {'identity': self.entities[actor].identity,
                'known_forms': deepcopy(self.current_forms),
                'actual_wounds': deepcopy(self.wound_history)}
