"""R13 player skill ledger, bound to the host's existing Economy.

Sources: S2 P43-92/T8-15; S4 P7-46/P166-176. Milliseconds are game
milliseconds. This layer commits payments and resistance, not damage, geometry,
search cancellation, awareness or animation. The host supplies actual reactions.
"""
from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from rules import Skill


@dataclass(frozen=True)
class SkillSpec:
    tier: str
    cost: int
    unlock_cost: int
    power: int
    cooldown: int
    prerequisites: tuple = ()
    any_prerequisite: bool = False


CATALOG = MappingProxyType({
    "skin": SkillSpec("low", 1, 0, 1, 2000),
    "gut": SkillSpec("low", 1, 1, 1, 2000, ("skin",)),
    "pores": SkillSpec("low", 1, 1, 1, 2000, ("skin",)),
    "thermal": SkillSpec("low", 1, 1, 1, 2000, ("skin",)),
    "tinnitus": SkillSpec("low", 1, 1, 1, 2000, ("skin",)),
    "dry": SkillSpec("low", 1, 1, 1, 2000, ("skin",)),
    "knee": SkillSpec("mid", 2, 2, 2, 4000, ("gut",)),
    "withdraw": SkillSpec("mid", 2, 2, 2, 4000, ("skin",)),
    "startle": SkillSpec("mid", 2, 2, 2, 4000, ("thermal",)),
    "fear": SkillSpec("high", 3, 3, 3, 8000, ("tinnitus", "startle")),
    "happy": SkillSpec("high", 3, 3, 3, 8000, ("pores", "withdraw")),
    "control": SkillSpec("control", 5, 5, 4, 20000, ("fear", "happy"), True),
})


class PlayerSkills:
    """One ledger per host Economy; callback identities are opaque hashable IDs.

    submit is permitted in an ordinary paused selection menu. react and control
    commands require resumed gameplay. Preview never mutates state. Growth menu
    operations are legal while paused, but not during loading, death or transition.
    """
    _MENTAL = frozenset(("fear", "happy"))
    _DEFENSIVE = frozenset(("skin", "withdraw", "startle"))
    _ROOMS = frozenset(("room", "floor", "street_segment"))
    _BOUNDARIES = frozenset(("level", "death", "rest", "restart", "street_enter", "street_exit", "hidden_street_enter", "hidden_street_exit"))

    def __init__(self, economy):
        self.economy = economy
        self.context = {
            "mode": "battle" if economy.battle else "explore", "menu": None,
            "paused": economy.paused, "loading": False,
            "alive": economy.phase == "alive", "transitioning": False,
            "body_blocked": False, "can_cancel_attack": True,
            "attack_in_progress": False, "attack_has_hit": False,
            "fourth_wall_restricted": False, "rescue_skills": (),
            "rescue_allowed": False,
        }
        self.epoch = 0
        self._sequence = 0
        self._casts = {}
        self._tokens = {}
        self._menu_tokens = set()
        self._pending = {}
        self._effect_remaining = {}
        self._command_tokens = {}
        self.control_id = None
        self.control_remaining = 0
        self._shared_attack_remaining = 0
        self.last_reason = None

    @property
    def casts(self):
        return deepcopy(self._casts)

    @property
    def shared_attack_remaining(self):
        knee = self.economy.skills.get("knee")
        return max(self._shared_attack_remaining, knee.remaining if knee else 0)

    @property
    def control_active(self):
        return self.control_id is not None and self.control_remaining > 0

    def sync_context(self, **facts):
        if facts.get("mode") == "exploration":
            facts["mode"] = "explore"
        if "mode" in facts and facts["mode"] not in ("explore", "battle"):
            raise ValueError("mode must be explore or battle")
        self.context.update(facts)
        self.economy.battle = self.context["mode"] == "battle"
        self.economy.paused = bool(self.context["paused"] or self.context["loading"])
        if not self.context["alive"]:
            self.economy.phase = "dead"
        elif self.context["transitioning"]:
            self.economy.phase = "transition"
        else:
            self.economy.phase = "alive"
        return deepcopy(self.context)

    def _available(self):
        return (self.context["alive"] and self.economy.phase == "alive"
                and not self.context["loading"] and not self.context["transitioning"])

    def _reject(self, reason):
        self.last_reason = reason
        return None

    def _menu_once(self, kind, token):
        if token is None:
            return True
        key = (self.epoch, kind, token)
        if key in self._menu_tokens:
            return False
        return True

    def _menu_record(self, kind, token):
        if token is not None:
            self._menu_tokens.add((self.epoch, kind, token))

    def unlock(self, name, token=None):
        spec = CATALOG.get(name)
        if (not self._available() or not spec or name in self.economy.skills
                or not self._menu_once("unlock", token)):
            return False
        owned = [p in self.economy.skills for p in spec.prerequisites]
        if (spec.prerequisites and not (any(owned) if spec.any_prerequisite else all(owned))):
            return False
        if self.economy.c < spec.unlock_cost:
            return False
        self.economy.c -= spec.unlock_cost
        self.economy.skills[name] = Skill(spec.cost, spec.power, spec.cooldown)
        self._menu_record("unlock", token)
        return True

    def upgrade(self, name="skin", token=None):
        if (not self._available() or name not in CATALOG or name not in self.economy.skills
                or self.economy.c < 1 or not self._menu_once("upgrade", token)):
            return False
        self.economy.c -= 1
        self.economy.skills[name].power += 1
        self._menu_record("upgrade", token)
        return True

    def reconnect(self, token=None):
        if not self._available() or not self._menu_once("reconnect", token):
            return False
        if not self.economy.reconnect():
            return False
        self._menu_record("reconnect", token)
        return True

    def convert(self, token=None):
        if not self._available() or not self._menu_once("convert", token):
            return False
        if not self.economy.convert():
            return False
        self._menu_record("convert", token)
        return True

    def preview(self, name):
        spec = CATALOG.get(name)
        if not spec:
            return None
        s = self.economy.skills.get(name)
        return {"name": name, "spec": spec, "unlocked": s is not None,
                "power": s.power if s else spec.power,
                "required_upgrades": max(0, s.resistance + self.economy.global_r + 1 - s.power) if s else None,
                "remaining": s.remaining if s else 0,
                "model_only": True}

    def _rescue(self, name, facts):
        # A host-designated event window exempts only that existing skill. It
        # never grants ownership, payment, damage or actual physical escape.
        names = facts.get("rescue_skills", self.context.get("rescue_skills", ()))
        allowed = facts.get("rescue_allowed", self.context.get("rescue_allowed", False))
        return bool(allowed and name in names)

    def submit(self, token, name, *, direction=None, valid_target=True,
               cancelled=False, **facts):
        key = (self.epoch, token)
        if key in self._tokens:
            return self._reject("duplicate")
        s = self.economy.skills.get(name)
        if name not in CATALOG or s is None:
            return self._reject("locked")
        if not self._available():
            return self._reject("unavailable")
        if self.context["paused"] and self.context.get("menu") != "cast":
            return self._reject("paused")
        if cancelled or not valid_target or facts.get("valid", True) is False:
            return self._reject("invalid_target")
        if self.control_active or "control" in self._pending:
            return self._reject("control_active")
        if name in self._pending or s.active:
            return self._reject("effect_active")
        if s.remaining or (name == "knee" and self.shared_attack_remaining):
            return self._reject("cooldown")
        if self.economy.n < s.cost:
            return self._reject("balance")
        rescue = self._rescue(name, facts)
        if self.context["fourth_wall_restricted"] and not rescue:
            return self._reject("fourth_wall")
        if self.context["body_blocked"] and name not in self._MENTAL and not rescue:
            return self._reject("body_blocked")
        busy = self.context.get("attack_in_progress", False)
        if busy and name not in self._MENTAL:
            cancellable = (name in self._DEFENSIVE and self.context["can_cancel_attack"]
                           and not self.context.get("attack_has_hit", False))
            if not cancellable and not rescue:
                return self._reject("attack_busy")
        if self.context["mode"] == "battle" and name == "skin" and direction is None:
            return self._reject("direction")
        if (self.context["mode"] == "battle" and name == "pores"
                and not facts.get("threat_perceived", facts.get("perceived_threat", False))):
            return self._reject("unperceived_threat")
        self._sequence += 1
        cast_id = (self.epoch, self._sequence)
        resisted = s.power <= s.resistance + self.economy.global_r
        self.economy.n -= s.cost
        if name != "control" or resisted:
            s.remaining = s.cooldown
        if name == "knee":
            self._shared_attack_remaining = 4000
        record = {
            "id": cast_id, "cast_id": cast_id, "token": token,
            "name": name, "skill": name, "mode": self.context["mode"],
            "epoch": self.epoch, "context": deepcopy(self.context),
            "direction": deepcopy(direction), "facts": deepcopy(facts),
            "power": s.power, "resistance": s.resistance,
            "global_resistance": self.economy.global_r,
            "effective_resistance": s.resistance + self.economy.global_r,
            "cost": s.cost, "cooldown": s.cooldown, "resisted": resisted,
            "status": "resisted" if resisted else "committed",
            "reaction_counted": False, "reaction": False,
        }
        self._casts[cast_id] = record
        self._tokens[key] = cast_id
        if not resisted:
            self._pending[name] = cast_id
        self.last_reason = None
        return deepcopy(record)

    def react(self, cast_id, *, actual=True, actual_reaction=None, body_reacted=True, duration_ms=None, **facts):
        if actual_reaction is not None:
            actual = actual_reaction
        record = self._casts.get(cast_id)
        if (not record or record["epoch"] != self.epoch or record["status"] != "committed"
                or not self._available() or self.context["paused"]):
            return None
        if duration_ms is not None and duration_ms < 0:
            raise ValueError("duration_ms must be nonnegative")
        name = record["name"]
        if self._pending.get(name) != cast_id:
            return None
        if not actual or (name == "control" and self.context["body_blocked"]):
            return self.interrupt(cast_id)
        # A reaction is an observed host event, not another resistance check.
        self._pending.pop(name)
        s = self.economy.skills[name]
        record.update(status="reacted", reaction=bool(body_reacted), reaction_facts=deepcopy(facts))
        if body_reacted and not s.pending:
            s.successes += 1
            record["reaction_counted"] = True
            if s.successes == 3:
                s.successes = 0
                s.pending = True
        if name == "control":
            self.control_id = cast_id
            self.control_remaining = 6000
            self.economy.control = True
            s.active = True
        elif duration_ms != 0 and name != "happy":
            s.active = True
            self._effect_remaining[cast_id] = duration_ms
        return deepcopy(record)

    def confirm_control_body(self, cast_id, *, actual=True):
        """Host confirms one actual movement/interaction, not a requested command."""
        record = self._casts.get(cast_id)
        if (not actual or not self._available() or self.context["paused"]
                or self.context["body_blocked"] or self.control_id != cast_id
                or not record or record["reaction"]):
            return None
        record["reaction"] = True
        s = self.economy.skills["control"]
        if not s.pending:
            record["reaction_counted"] = True
            s.successes += 1
            if s.successes == 3:
                s.successes = 0
                s.pending = True
        return deepcopy(record)

    def interrupt(self, cast_id):
        record = self._casts.get(cast_id)
        if not record or record["epoch"] != self.epoch or record["status"] != "committed":
            return None
        self._pending.pop(record["name"], None)
        record["status"] = "interrupted"
        if record["name"] == "control":
            self.economy.skills["control"].remaining = 20000
        return deepcopy(record)

    abort = interrupt

    def finish_effect(self, cast_id):
        record = self._casts.get(cast_id)
        if not record or record["epoch"] != self.epoch or record["status"] != "reacted":
            return False
        if record["name"] == "control":
            return self.end_control() if self.control_id == cast_id else False
        if cast_id not in self._effect_remaining:
            return False
        self._effect_remaining.pop(cast_id)
        self.economy.skills[record["name"]].active = False
        return True

    def end_control(self):
        if not self.control_active:
            return False
        self.control_id = None
        self.control_remaining = 0
        self.economy.control = False
        s = self.economy.skills["control"]
        s.active = False
        s.remaining = 20000
        # Already started action IDs remain valid; commands are never queued.
        return True

    def control_command(self, token, kind, *, valid_target=True, reachable=True,
                        permitted=True, distance=None, facing_valid=True, **facts):
        key = (self.epoch, token)
        if key in self._command_tokens:
            return self._reject("duplicate")
        if (not self._available() or self.context["paused"] or not self.control_active):
            return self._reject("control_inactive")
        if kind not in {"move", "turn", "interact", "kick"}:
            return self._reject("command")
        if self.context["body_blocked"]:
            return self._reject("body_blocked")
        if not valid_target or not reachable or not permitted:
            return self._reject("invalid_target")
        if self.context.get("attack_in_progress", False):
            return self._reject("attack_busy")
        if kind == "kick":
            if self.context["mode"] != "battle" or "knee" not in self.economy.skills:
                return self._reject("kick_locked")
            if self.shared_attack_remaining or self.economy.skills["knee"].active:
                return self._reject("cooldown")
            if distance is None or not 0 <= distance <= 1 or not facing_valid:
                return self._reject("range_or_facing")
            self._shared_attack_remaining = 4000
            self.economy.skills["knee"].remaining = 4000
        self._sequence += 1
        command = {"id": (self.epoch, "action", self._sequence),
                   "action_id": (self.epoch, "action", self._sequence),
                   "cast_id": self.control_id, "kind": kind,
                   "name": "knee" if kind == "kick" else kind,
                   "mode": self.context["mode"], "status": "started",
                   "distance": distance, "facts": deepcopy(facts), "cost": 0}
        self._command_tokens[key] = command
        self.last_reason = None
        return deepcopy(command)

    command = control_command

    def tick(self, ms, advance_economy=True):
        if not isinstance(ms, int) or ms < 0:
            raise ValueError("ms must be a nonnegative integer")
        if not self._available() or self.context["paused"]:
            return
        # Split at ownership expiry so natural regeneration resumes only after
        # the exact 6000ms endpoint. Host-driven ticks must use the same split.
        remaining = ms
        while remaining:
            step = min(remaining, self.control_remaining) if self.control_active else remaining
            if advance_economy:
                self.economy.tick(step)
            self._shared_attack_remaining = max(0, self._shared_attack_remaining - step)
            for cast_id, duration in list(self._effect_remaining.items()):
                if duration is not None:
                    self._effect_remaining[cast_id] = max(0, duration - step)
                    if self._effect_remaining[cast_id] == 0:
                        self.finish_effect(cast_id)
            if self.control_active:
                self.control_remaining -= step
                if self.control_remaining == 0:
                    # end_control requires active; preserve the exact endpoint.
                    self.control_remaining = 1
                    self.end_control()
            remaining -= step

    def end_context(self, kind):
        if kind in self._ROOMS:
            return False
        if kind not in self._BOUNDARIES:
            raise ValueError(kind)
        for cast_id in list(self._pending.values()):
            self.interrupt(cast_id)
        self.end_control()
        for cast_id in list(self._effect_remaining):
            self.finish_effect(cast_id)
        self.epoch += 1
        if kind == "death":
            self.sync_context(alive=False)
        return True

    def snapshot(self):
        return {"n": self.economy.n, "c": self.economy.c, "fraction": self.economy.fraction,
                "epoch": self.epoch, "context": deepcopy(self.context),
                "control_remaining": self.control_remaining,
                "shared_attack_remaining": self.shared_attack_remaining,
                "skills": {n: deepcopy(vars(s)) for n, s in self.economy.skills.items()},
                "pending": deepcopy(self._pending), "casts": deepcopy(self._casts)}
