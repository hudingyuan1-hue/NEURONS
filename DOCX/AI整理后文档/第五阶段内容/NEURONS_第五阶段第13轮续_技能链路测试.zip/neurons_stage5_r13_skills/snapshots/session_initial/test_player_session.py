"""R13 continuation: paid inputs composed with actual actions/world results.

Balances below are explicitly test fixtures, not claimed campaign incomes.
Geometry remains externally confirmed; no Unity callback is fabricated as real.
"""
from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from player_session import PlayerSession
from player_skills import CATALOG
from rules import Life
from street_session import StreetSession
from s5_deep_session import S5DeepSession
from hidden_street import HiddenStreet


def configured(battle=False,host=None):
    session=PlayerSession(host=host,life=Life(progress=5 if battle else 1,place='S5_atrium' if battle else 'S1'))
    session.life.economy.c=22
    session.life.economy.n=100
    for name in CATALOG:
        if name!='skin':assert session.book.unlock(name)
    assert session.life.economy.c==0
    session.perceived_targets=[dict(id='wall_hidden',actual_perceived=False,distance_m=.1),
                              dict(id='near',actual_perceived=True,distance_m=.7),
                              dict(id='far',actual_perceived=True,distance_m=2)]
    return session


def cast(s,name,**facts):
    record=s.submit(name,direction='left')
    assert record, (name,s.book.last_reason)
    effect=s.react(record['id'],**facts)
    assert effect, (name,record)
    return record,effect


def street():
    host=StreetSession()
    host.enter_pending(host.token('actual_entry'))
    return configured(host=host)


def host_target(kind):
    if kind=='street':return street(),'n01'
    if kind=='deep':
        host=S5DeepSession()
        assert host.spawn_check((host.life.epoch,'spawn'),'father',0,first=True)
        host.enter_pending((host.life.epoch,'entry'))
        return configured(host=host),'father'
    host=HiddenStreet()
    assert host.enter(host.token('entry'),actual_father_carry=True,actual_crossing=True,entry_free=True)
    return configured(host=host),'hunter'


def enemy_hp(s,target):
    if target=='hunter':return s.host.hunter_hp
    if hasattr(s.host,'entity'):return s.host.entity(target).hp
    return s.host.people.entities[target].hp


def test_menu_commit_close_animation_and_actual_effect_are_separate():
    s=configured();s.start_search(1);s.tick(900)
    assert s.open_menu('cast')
    before=s.life.economy.n
    rec=s.submit('skin')
    assert rec and s.life.economy.n==before-1
    assert s.current_search and not s.react(rec['id'])
    s.tick(9000)
    assert s.search_progress==900 and s.life.economy.skills['skin'].remaining==2000
    s.start_close()
    assert s.submit('happy') is None
    assert not s.finish_close(actual_finished=False)
    assert s.react(rec['id']) is None
    assert s.finish_close(actual_finished=True)
    assert s.react(rec['id'])['cancel_search']
    assert s.current_search is None and s.search.income==0
    assert s.life.economy.skills['skin'].successes==1
    assert len(s.awareness.evidence)==1
    assert not s.react(rec['id'])


def test_upgrade_after_commit_does_not_rejudge_resisted_cast():
    s=configured();sk=s.life.economy.skills['skin'];sk.resistance=1
    s.open_menu('cast');rec=s.submit('skin');assert rec['resisted']
    s.life.economy.c=1;assert s.book.upgrade('skin')
    s.start_close();s.finish_close(actual_finished=True)
    assert s.react(rec['id'])['resisted']
    assert sk.power==2 and sk.successes==0 and not s.effects.effects
    assert len(s.awareness.evidence)==1


@pytest.mark.parametrize('reason',['pause','loading','death','closing'])
def test_unavailable_input_never_spends_or_executes(reason):
    s=configured(True)
    if reason=='pause':s.set_pause(True)
    elif reason=='loading':s.set_pause(loading=True)
    elif reason=='death':s.life.frame((s.life.epoch,'fatal'),[('hp_damage',100)])
    else:s.open_menu('cast');s.start_close()
    before=s.life.economy.n
    assert s.submit('skin',direction='left') is None
    assert s.life.economy.n==before and not s.effects.effects


@pytest.mark.parametrize('name',['skin','gut','knee','withdraw','startle','fear','control'])
def test_exploration_cancellation_has_no_completion_reward(name):
    s=configured();s.start_search(1);s.tick(3999);before=s.life.economy.n
    cast(s,name)
    assert s.current_search is None and not s.complete_search()
    assert s.life.economy.n==before-CATALOG[name].cost
    assert s.search.used==1 and s.search.income==0 and 1 not in s.search.complete


@pytest.mark.parametrize('name,elapsed',[('pores',4000),('tinnitus',5000),('thermal',4750)])
def test_search_progress_resumes_and_pays_once(name,elapsed):
    s=configured();s.start_search(1);before=s.life.economy.n
    cast(s,name);s.tick(elapsed-1)
    assert not s.complete_search()
    s.tick(1);assert s.complete_search()
    assert s.life.economy.n==before-CATALOG[name].cost+1
    assert not s.complete_search() and s.search.income==1


def test_fear_defers_only_point_without_completing_it():
    s=configured();s.start_search(1)
    rec,out=cast(s,'fear',only_current_point=True,current_point=1)
    assert out['defer_current_point_ms']==6000
    assert s.start_search(1) is None
    s.tick(5999);assert s.start_search(1) is None
    s.tick(1);assert s.start_search(1)
    assert s.search.income==0


def test_happy_does_not_clear_drug_stop_or_heal_life():
    s=street();s.host.drug_stop=2000;s.life.hp=30;s.life.sp=40
    cast(s,'happy')
    assert (s.life.hp,s.life.sp,s.host.drug_stop)==(30,60,2000)
    assert s.command('move') is None
    assert s.submit('control') is None


def test_fear_zero_sp_stupor_consumes_escape_duration():
    s=configured(True);s.life.sp=15
    cast(s,'fear')
    assert s.life.sp==0 and s.life.stun==1000
    assert s.effects.remaining('fear')==3000
    s.tick(1000)
    assert s.life.stun==0 and s.effects.remaining('fear')==2000


def test_fear_stops_existing_unhit_proactive_kick():
    s=street();_,kick=cast(s,'knee');cast(s,'fear')
    s.tick(150)
    hp=enemy_hp(s,'n01')
    assert s.kick_contact(kick['attack_id'],'n01',distance_m=.5) is None
    assert enemy_hp(s,'n01')==hp


def test_three_real_reactions_adapt_only_on_actual_restart():
    s=configured();sk=s.life.economy.skills['skin']
    for i in range(3):
        cast(s,'skin');s.tick(2000)
    assert sk.pending and sk.resistance==0
    s.boundary('room');assert sk.pending and sk.resistance==0
    assert s.actual_restart('rest')
    assert not sk.pending and sk.resistance==1
    rec=s.submit('skin');assert rec['resisted'];s.react(rec['id'])
    assert sk.successes==0


def test_interrupted_commit_spends_but_creates_no_evidence_or_adaptation():
    s=configured();before=s.life.economy.n
    rec=s.submit('skin');s.extra_body_blocked=True
    result=s.react(rec['id'])
    assert result['status']=='interrupted'
    assert s.life.economy.n==before-1 and not s.awareness.evidence
    assert s.life.economy.skills['skin'].successes==0
    assert s.life.economy.skills['skin'].remaining==2000


def test_pending_cast_cannot_reappear_after_actual_boundary():
    s=configured();rec=s.submit('happy');s.boundary('level')
    s.life.sp=10
    assert s.react(rec['id']) is None and s.life.sp==10


def test_control_activation_no_evidence_actual_movement_identifies_once():
    s=configured(True);s.awareness.stage=2
    rec,_=cast(s,'control')
    assert not s.awareness.evidence and s.life.economy.skills['control'].successes==0
    assert s.play_feedback('control') is None
    cmd=s.command('move');assert cmd and not s.awareness.evidence
    assert not s.control_action(cmd['id'],actual=False)
    assert s.control_action(cmd['id'],actual=True)
    assert s.awareness.stage==3 and len(s.awareness.evidence)==1
    assert s.life.economy.skills['control'].successes==1
    assert not s.control_action(cmd['id'])
    nxt=s.command('move');assert s.control_action(nxt['id'])
    assert len(s.awareness.evidence)==1 and s.life.economy.skills['control'].successes==1


def test_control_clock_pause_restriction_and_exact_regen():
    s=configured(True);s.life.economy.n=5
    cast(s,'control');s.tick(1000)
    s.open_menu('upgrade');s.tick(90000)
    assert s.book.control_remaining==5000 and s.life.economy.n==0
    s.start_close();s.finish_close(actual_finished=True)
    s.life.frame((s.life.epoch,'mental_hit'),[('sp_damage',100)])
    assert s.command('move') is None
    s.tick(1000)
    assert s.book.control_remaining==4000 and s.command('move')
    s.tick(7999)
    assert not s.book.control_active and s.life.economy.n==0
    assert s.life.economy.skills['control'].remaining==16001
    s.tick(1);assert s.life.economy.n==1


@pytest.mark.parametrize('boundary',['room','floor','street_segment'])
def test_ordinary_boundary_preserves_control_and_command(boundary):
    s=configured(True);cast(s,'control');s.tick(500)
    cmd=s.command('move');s.boundary(boundary)
    assert s.book.control_remaining==5500 and s.control_action(cmd['id'])


def test_control_far_target_turn_only_no_attack_charge_or_autopursuit():
    s=street();cast(s,'control');before=s.life.economy.n
    result=s.right_target(distance=1.01)
    assert result['turn'] and result['kick'] is None and not result['auto_pursue']
    assert s.life.economy.n==before and not s.book.shared_attack_remaining
    assert s.life.economy.skills['knee'].successes==0


@pytest.mark.parametrize('kind',['street','deep','hidden'])
def test_paid_knee_actual_world_hit_exactly_once(kind):
    s,target=host_target(kind);before=enemy_hp(s,target)
    rec,attack=cast(s,'knee')
    assert s.kick_contact(attack['attack_id'],target,distance_m=.5) is None
    s.tick(150)
    assert s.kick_contact(attack['attack_id'],target,distance_m=.5)['hp_damage']==15
    assert enemy_hp(s,target)==before-15
    assert s.kick_contact(attack['attack_id'],target,distance_m=.5) is None
    assert s.life.economy.skills['knee'].successes==1


def test_control_neural_share_four_seconds_but_not_extra_cost_or_adaptation():
    s=street();cast(s,'knee');s.tick(650);cast(s,'control')
    before=s.life.economy.n
    assert s.command('kick',distance=.5) is None
    s.tick(3349);assert s.command('kick',distance=.5) is None
    s.tick(1);cmd=s.command('kick',distance=.5);assert cmd
    assert s.life.economy.n==before and s.life.economy.skills['knee'].successes==1
    s.end_control();s.tick(650)
    assert s.submit('knee') is None
    s.tick(3350);assert s.submit('knee')


def test_started_kick_finishes_after_control_expiry_without_replay():
    s=street();cast(s,'control');s.tick(5900)
    cmd=s.command('kick',distance=.5);hp=enemy_hp(s,'n01')
    s.tick(150)
    assert not s.book.control_active
    assert s.kick_contact(cmd['attack_id'],'n01',distance_m=.5)
    assert enemy_hp(s,'n01')==hp-15
    assert s.command('kick',distance=.5) is None


def test_defensive_cancel_only_before_hit_and_damage_never_rolled_back():
    s=street();_,kick=cast(s,'knee');cast(s,'skin');s.tick(150)
    assert s.kick_contact(kick['attack_id'],'n01',distance_m=.5) is None
    s.tick(3850);_,kick=cast(s,'knee');s.tick(150)
    assert s.kick_contact(kick['attack_id'],'n01',distance_m=.5)
    hp=enemy_hp(s,'n01')
    assert s.submit('skin',direction='left') is None
    assert enemy_hp(s,'n01')==hp


def test_missing_perception_not_a_free_target_sensor():
    s=configured(True);s.perceived_targets=[dict(id='behind_wall',distance_m=.1,actual_perceived=False)]
    before=s.life.economy.n
    assert s.submit('pores') is None and s.life.economy.n==before
    s.perceived_targets.append(dict(id='seen',distance_m=2,actual_perceived=True))
    assert cast(s,'pores')[1]['turn_target']=='seen'


def test_committed_direction_reaches_movement_effect():
    s=configured(True);rec=s.submit('skin',direction='right')
    assert s.react(rec['id'])['movement_request']['direction']=='right'


def test_death_stops_pending_feedback_control_and_old_commands():
    s=street();cast(s,'control');cmd=s.command('move')
    s.life.frame((s.life.epoch,'fatal'),[('hp_damage',100)])
    s.tick(0)
    assert not s.book.control_active and s.awareness.control is None
    assert not s.control_action(cmd['id']) and s.play_feedback('control') is None
    assert not s.commands and not s.feedback


def test_outcome_feedback_waits_for_safe_gap_and_pauses_once():
    s=configured(True);cast(s,'skin')
    assert s.play_feedback('skin',safe=False) is None
    s.tick(250);assert s.play_feedback('skin',safe=True)
    assert s.paused and s.play_feedback('skin') is None


def test_host_owns_dialogue_pause_until_actual_close():
    s=street();s.host.paused=True
    before=s.life.economy.n
    assert s.submit('skin',direction='left') is None
    assert s.host.paused and s.life.economy.n==before


def test_no_actual_resisted_sensation_means_no_awareness_evidence():
    s=configured();s.life.economy.skills['skin'].resistance=1
    rec=s.submit('skin');s.react(rec['id'],actual=False,perceived=True)
    assert s.awareness.stage==0 and not s.awareness.evidence


def test_actual_life_level_change_invalidates_pending_old_cast_without_manual_boundary():
    s=configured();rec=s.submit('happy')
    assert s.life.frame((s.life.epoch,'exit'),[('exit',True)])=='exit'
    s.life.finish_exit();s.life.sp=10
    assert s.react(rec['id']) is None and s.life.sp==10


def test_host_death_revive_invalidates_control_before_next_input():
    s,target=host_target('deep');cast(s,'control')
    s.host.frame((s.life.epoch,'fatal'),hp_damage=100)
    assert s.host.revive()
    assert s.command('move') is None and not s.book.control_active
    assert not s.life.economy.control and s.awareness.control is None


class IntegratedPlayerMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.s=configured(True);self.pending=[]

    @rule(name=st.sampled_from(tuple(CATALOG)))
    def submit(self,name):
        before=self.s.life.economy.n
        rec=self.s.submit(name,direction='left')
        assert self.s.life.economy.n==before-(CATALOG[name].cost if rec else 0)
        if rec:self.pending.append(rec['id'])

    @rule(index=st.integers(0,100),actual=st.booleans(),perceived=st.booleans())
    def react(self,index,actual,perceived):
        if self.pending:
            identity=self.pending[index%len(self.pending)]
            self.s.react(identity,actual=actual,perceived=perceived)

    @rule(ms=st.sampled_from([0,1,149,150,300,650,1000,2000,4000,6000,9999]))
    def tick(self,ms):
        before=self.s.book.snapshot()
        paused=self.s.paused
        self.s.tick(ms)
        if paused:assert self.s.book.snapshot()==before

    @rule(kind=st.sampled_from(['cast','upgrade','close','resume','pause']))
    def menu(self,kind):
        if kind in {'cast','upgrade'}:self.s.open_menu(kind)
        elif kind=='close':self.s.start_close()
        elif kind=='resume':
            if self.s.closing:self.s.finish_close(actual_finished=True)
            self.s.set_pause(False)
        else:self.s.set_pause(True)

    @rule(kind=st.sampled_from(['move','turn','interact','kick']),actual=st.booleans())
    def command(self,kind,actual):
        before=self.s.life.economy.n
        cmd=self.s.command(kind,distance=.5)
        assert self.s.life.economy.n==before
        if cmd:self.s.control_action(cmd['id'],actual=actual)

    @rule(blocked=st.booleans())
    def body(self,blocked):self.s.extra_body_blocked=blocked;self.s._sync()

    @rule()
    def end_control(self):self.s.end_control()

    @rule(kind=st.sampled_from(['room','floor','street_segment']))
    def ordinary_boundary(self,kind):self.s.boundary(kind)

    @invariant()
    def conservation_and_evidence(self):
        s=self.s
        assert s.life.economy.n>=0 and 0<=s.life.hp<=100 and 0<=s.life.sp<=100
        assert s.life.economy.control==s.book.control_active
        assert (s.awareness.control is not None)==s.book.control_active
        assert len(s.awareness.evidence)<=len(s.book.casts)
        for sk in s.life.economy.skills.values():
            assert sk.remaining>=0 and 0<=sk.successes<3
        for key,ev in s.awareness.evidence.items():
            rec=s.book.casts[key]
            assert rec['resisted'] or rec['reaction']


TestIntegratedPlayer=IntegratedPlayerMachine.TestCase
TestIntegratedPlayer.settings=settings(max_examples=240,stateful_step_count=80,deadline=None)
