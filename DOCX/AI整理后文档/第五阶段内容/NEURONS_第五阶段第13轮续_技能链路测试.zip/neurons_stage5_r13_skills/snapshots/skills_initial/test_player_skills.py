"""R13 ledger contract tests. Fixed seed: 2026101314; 240 x 70 operations."""
from collections import Counter
from copy import deepcopy
import pytest
from hypothesis import given, settings, seed, strategies as st
from rules import Economy
from player_skills import CATALOG, PlayerSkills


def full(n=200, c=22, battle=False):
    economy = Economy(n=n, c=c, battle=battle)
    engine = PlayerSkills(economy=economy)
    for name in CATALOG:
        if name != "skin":
            assert engine.unlock(name)
    return economy, engine


def cast(engine, token, name="skin", **facts):
    return engine.submit(token, name, direction="left", threat_perceived=True, **facts)


def activate(engine, token="control", body_reacted=True):
    result = cast(engine, token, "control")
    assert result and not result["resisted"]
    return engine.react(result["cast_id"], body_reacted=body_reacted)


def test_tree_exact_costs_and_existing_economy_identity():
    economy, engine = full(c=22)
    assert engine.economy is economy
    assert economy.c == 0
    assert len(CATALOG) == 12
    assert Counter(s.tier for s in CATALOG.values()) == {"low": 6, "mid": 3, "high": 2, "control": 1}
    for name, spec in CATALOG.items():
        tier_values = {"low": (1, 1, 2000), "mid": (2, 2, 4000), "high": (3, 3, 8000), "control": (5, 4, 20000)}
        assert (spec.cost, spec.power, spec.cooldown) == tier_values[spec.tier]
        assert vars(economy.skills[name])["power"] == spec.power


@pytest.mark.parametrize("route,cost", [(["pores", "withdraw", "happy", "control"], 11), (["thermal", "tinnitus", "startle", "fear", "control"], 12), (["pores", "withdraw", "happy", "control", "gut", "knee"], 14)])
def test_control_alternative_prerequisite_routes(route, cost):
    economy = Economy(c=cost)
    engine = PlayerSkills(economy)
    assert not engine.unlock("control")
    for skill in route:
        assert engine.unlock(skill)
    assert economy.c == 0
    assert not engine.unlock("control")


@pytest.mark.parametrize("name", ["gut", "pores", "thermal", "tinnitus", "dry", "withdraw", "knee", "startle", "fear", "happy", "control"])
def test_unlock_payment_and_preconditions(name):
    economy = Economy(c=0)
    engine = PlayerSkills(economy)
    before = engine.snapshot()
    assert not engine.unlock(name)
    assert engine.snapshot() == before


def test_ordinary_paused_growth_and_cast_menu_are_distinct():
    economy = Economy(n=20, c=5)
    engine = PlayerSkills(economy)
    engine.sync_context(paused=True, menu="upgrade")
    assert engine.unlock("gut")
    assert engine.upgrade("gut")
    assert cast(engine, "pause", "skin") is None
    engine.sync_context(menu="cast")
    committed = cast(engine, "menu", "skin")
    assert committed and economy.n == 19
    assert engine.react(committed["id"]) is None
    engine.tick(5000)
    assert economy.skills["skin"].remaining == 2000
    engine.sync_context(paused=False, menu=None)
    assert engine.react(committed["id"], duration_ms=500)


@pytest.mark.parametrize("fact", [dict(alive=False), dict(loading=True), dict(transitioning=True)])
def test_unavailable_blocks_all_menu_spending(fact):
    economy = Economy(n=20, c=3)
    engine = PlayerSkills(economy)
    engine.sync_context(**fact)
    before = engine.snapshot()
    assert not engine.unlock("gut")
    assert not engine.upgrade()
    assert not engine.convert()
    assert not engine.reconnect()
    assert cast(engine, "unavailable") is None
    assert engine.snapshot() == before


def test_snapshot_power_and_resistance_fixed_at_submission():
    economy = Economy(n=10, c=3)
    engine = PlayerSkills(economy)
    result = cast(engine, "one")
    result["power"] = 999
    result["context"]["alive"] = False
    assert engine.upgrade()
    economy.global_r = 99
    reaction = engine.react(result["id"], duration_ms=0)
    assert reaction["power"] == 1 and reaction["effective_resistance"] == 0
    assert reaction["reaction"] and economy.skills["skin"].successes == 1
    assert engine.casts[result["id"]]["context"]["alive"]


def test_resistance_equality_charges_cooldown_without_adaptation():
    economy = Economy(n=5)
    engine = PlayerSkills(economy)
    economy.skills["skin"].resistance = 1
    result = cast(engine, "resisted")
    assert result["status"] == "resisted" and economy.n == 4
    assert economy.skills["skin"].remaining == 2000
    assert engine.react(result["id"]) is None
    assert economy.skills["skin"].successes == 0


def test_duplicate_pending_and_active_never_refresh_or_charge():
    economy, engine = full(battle=True)
    result = cast(engine, "one", "dry")
    assert cast(engine, "one", "dry") is None
    engine.tick(2000)
    assert cast(engine, "two", "dry") is None
    assert engine.react(result["id"], duration_ms=6000)
    engine.tick(5999)
    before = engine.snapshot()
    assert cast(engine, "three", "dry") is None
    assert engine.snapshot() == before
    engine.tick(1)
    assert cast(engine, "three", "dry")


def test_adaptation_at_actual_reaction_once_and_capped_until_actual_restart():
    economy = Economy(n=100)
    engine = PlayerSkills(economy)
    skill = economy.skills["skin"]
    for index in range(6):
        result = cast(engine, index)
        assert skill.successes == index if index < 3 else skill.successes == 0
        assert engine.react(result["id"], duration_ms=0)
        assert engine.react(result["id"], duration_ms=0) is None
        engine.tick(2000)
    assert skill.successes == 0 and skill.pending and skill.resistance == 0
    engine.end_context("room")
    assert skill.pending and skill.resistance == 0
    engine.end_context("level")
    assert skill.pending and skill.resistance == 0
    engine.end_context("rest")
    economy.restart(death=False)
    assert skill.resistance == 1 and not skill.pending and skill.successes == 0


def test_partial_adaptation_survives_death_and_cooldown_survives_revival():
    economy = Economy(n=10)
    engine = PlayerSkills(economy)
    result = cast(engine, "a")
    engine.react(result["id"], duration_ms=0)
    engine.tick(700)
    engine.end_context("death")
    assert economy.skills["skin"].remaining == 1300
    engine.tick(50000)
    assert economy.skills["skin"].remaining == 1300
    economy.restart()
    engine.sync_context(alive=True)
    assert economy.skills["skin"].successes == 1
    assert economy.skills["skin"].remaining == 1300


def test_interruption_no_refund_no_reaction_and_stale_callbacks():
    economy = Economy(n=10)
    engine = PlayerSkills(economy)
    result = cast(engine, "a")
    assert engine.interrupt(result["id"])
    assert economy.n == 9
    assert engine.react(result["id"]) is None
    engine.tick(2000)
    result = cast(engine, "b")
    engine.end_context("level")
    assert engine.react(result["id"]) is None
    assert economy.n == 8 and economy.skills["skin"].successes == 0


@pytest.mark.parametrize("name", ["skin", "gut", "pores", "thermal", "tinnitus", "dry", "knee", "withdraw", "startle", "control"])
def test_body_blocked_movement_is_invalid_and_cannot_be_granted_by_boolean(name):
    economy, engine = full(battle=True)
    engine.sync_context(body_blocked=True)
    before = engine.snapshot()
    assert cast(engine, "blocked", name, authorised=True) is None
    assert engine.snapshot() == before


def test_mental_effects_do_not_clear_grab_and_zero_sp_is_not_a_gate():
    economy, engine = full(battle=True)
    engine.sync_context(body_blocked=True, sp=0)
    assert cast(engine, "happy", "happy")
    assert engine.context["body_blocked"]
    engine.sync_context(body_blocked=False, sp=0)
    assert activate(engine)


def test_rescue_is_explicit_designated_skill_and_pays_exact_cost():
    economy = Economy(n=2, c=2)
    engine = PlayerSkills(economy)
    engine.sync_context(fourth_wall_restricted=True, body_blocked=True,
                        rescue_allowed=True, rescue_skills=("withdraw",))
    assert cast(engine, "locked", "withdraw") is None
    assert engine.unlock("withdraw")
    assert cast(engine, "wrong", "skin") is None
    result = cast(engine, "rescue", "withdraw")
    assert result and economy.n == 0
    assert engine.context["body_blocked"]
    assert not engine.economy.control


def test_control_reacted_activation_timers_and_post_end_regeneration():
    economy, engine = full(n=5, battle=True)
    economy.fraction = 3000
    result = cast(engine, "c", "control")
    assert engine.control_remaining == 0 and economy.n == 0
    assert economy.skills["control"].remaining == 0
    assert engine.react(result["id"], body_reacted=False)
    assert engine.control_remaining == 6000 and economy.control
    assert economy.skills["control"].successes == 0
    engine.tick(10000)
    assert engine.control_remaining == 0 and not economy.control
    assert economy.skills["control"].remaining == 16000
    assert economy.n == 1 and economy.fraction == 3000


def test_control_actual_body_count_is_once_and_never_on_click():
    economy, engine = full(battle=True)
    result = activate(engine, body_reacted=False)
    assert engine.control_command("move", "move")
    assert economy.skills["control"].successes == 0
    assert engine.confirm_control_body(result["id"], actual=False) is None
    assert engine.confirm_control_body(result["id"])
    assert engine.confirm_control_body(result["id"]) is None
    assert economy.skills["control"].successes == 1


def test_control_resisted_interrupted_and_early_end_all_start_twenty_seconds():
    economy, engine = full(n=50)
    economy.skills["control"].resistance = 4
    resisted = cast(engine, "r", "control")
    assert resisted["resisted"] and economy.skills["control"].remaining == 20000
    assert engine.control_remaining == 0
    engine.tick(20000)
    economy.skills["control"].resistance = 0
    pending = cast(engine, "i", "control")
    assert engine.interrupt(pending["id"])
    assert economy.skills["control"].remaining == 20000
    engine.tick(20000)
    activate(engine, "actual")
    engine.tick(1000)
    assert engine.end_control()
    assert not engine.end_control()
    assert economy.skills["control"].remaining == 20000
    assert economy.n == 35


def test_control_cannot_activate_after_new_body_block():
    economy, engine = full()
    pending = cast(engine, "pending", "control")
    engine.sync_context(body_blocked=True)
    assert engine.react(pending["id"])["status"] == "interrupted"
    assert not engine.control_active and economy.skills["control"].remaining == 20000


@pytest.mark.parametrize("boundary", ["room", "floor", "street_segment", "level", "death", "rest", "street_enter", "street_exit"])
def test_control_boundary_and_loading_preservation(boundary):
    economy, engine = full()
    result = activate(engine)
    engine.tick(1000)
    engine.sync_context(loading=True)
    engine.tick(30000)
    assert engine.control_remaining == 5000
    engine.sync_context(loading=False)
    changed = engine.end_context(boundary)
    if boundary in {"room", "floor", "street_segment"}:
        assert not changed and engine.control_remaining == 5000 and engine.epoch == 0
    else:
        assert changed and engine.control_remaining == 0 and engine.epoch == 1
        assert economy.skills["control"].remaining == 20000
    assert engine.react(result["id"]) is None


def test_control_blocks_other_neural_and_upgrade_does_not_refresh():
    economy, engine = full(c=23)
    activate(engine)
    engine.tick(1001)
    engine.sync_context(paused=True, menu="upgrade")
    assert engine.upgrade("control")
    assert engine.control_remaining == 4999
    engine.tick(10000)
    assert engine.control_remaining == 4999
    engine.sync_context(paused=False, menu=None)
    assert cast(engine, "blocked", "skin") is None


def test_shared_knee_control_kick_cooldown_without_cost_or_adaptation():
    economy, engine = full(battle=True)
    knee = cast(engine, "knee", "knee")
    assert engine.react(knee["id"], duration_ms=650)
    activate(engine)
    before_n = economy.n
    assert engine.control_command("too_soon", "kick", distance=1) is None
    engine.tick(4000)
    economy.skills["knee"].resistance = 999
    attack = engine.control_command("kick", "kick", distance=1)
    assert attack and attack["status"] == "started"
    assert economy.n == before_n and economy.skills["knee"].successes == 1
    assert engine.shared_attack_remaining == 4000
    assert engine.end_control()
    assert attack["status"] == "started"
    assert cast(engine, "too_soon_neural", "knee") is None
    engine.tick(4000)
    assert cast(engine, "new_neural", "knee")["resisted"]


@pytest.mark.parametrize("facts", [dict(distance=None), dict(distance=1.0001), dict(distance=-1), dict(distance=1, facing_valid=False), dict(distance=1, valid_target=False), dict(distance=1, reachable=False), dict(distance=1, permitted=False)])
def test_invalid_control_kicks_have_no_queue_or_payment(facts):
    economy, engine = full(battle=True)
    activate(engine)
    before = engine.snapshot()
    assert engine.control_command("invalid", "kick", **facts) is None
    assert engine.snapshot() == before
    assert engine.control_command("invalid", "kick", distance=1)


def test_no_free_knee_from_control_and_no_exploration_attack():
    economy = Economy(n=30, c=11)
    engine = PlayerSkills(economy)
    for name in ("pores", "withdraw", "happy", "control"):
        assert engine.unlock(name)
    activate(engine)
    engine.sync_context(mode="battle")
    assert engine.control_command("no_knee", "kick", distance=0.5) is None
    assert "knee" not in economy.skills
    economy2, engine2 = full()
    activate(engine2)
    assert engine2.control_command("explore", "kick", distance=0.5) is None


def test_reconnect_all_blocked_exact_balance_and_menu_allowed():
    economy = Economy(n=5, c=0, battle=True)
    engine = PlayerSkills(economy)
    economy.skills["skin"].resistance = 2
    economy.global_r = 2
    engine.sync_context(paused=True, menu="upgrade", body_blocked=True)
    assert engine.reconnect("one")
    assert economy.n == 0 and economy.skills["skin"].power == 5
    assert economy.skills["skin"].successes == 0 and engine.context["body_blocked"]
    assert not engine.reconnect("one")


@pytest.mark.parametrize("n,c,resistance,battle", [(4,0,4,True),(10,0,4,True),(5,1,4,True),(5,0,0,True),(5,0,4,False)])
def test_reconnect_rejection_boundaries(n,c,resistance,battle):
    economy = Economy(n=n,c=c,battle=battle)
    engine = PlayerSkills(economy)
    economy.skills["skin"].resistance = resistance
    before = engine.snapshot()
    assert not engine.reconnect()
    assert engine.snapshot() == before


def test_preview_is_entirely_inert_and_public_ledger_is_copied():
    economy, engine = full()
    before = engine.snapshot()
    for name in CATALOG:
        assert engine.preview(name)["model_only"]
    assert engine.snapshot() == before
    result = cast(engine, "one")
    copied = engine.casts
    copied[result["id"]]["power"] = 500
    assert engine.casts[result["id"]]["power"] == 1


def test_attack_cancel_windows_do_not_queue_or_undo_hit():
    economy, engine = full(battle=True)
    engine.sync_context(attack_in_progress=True, can_cancel_attack=False)
    assert cast(engine, "no", "skin") is None
    engine.sync_context(can_cancel_attack=True, attack_has_hit=True)
    assert cast(engine, "hit", "skin") is None
    engine.sync_context(attack_has_hit=False)
    assert cast(engine, "yes", "skin")
    assert cast(engine, "not_defense", "gut") is None


# Independent accounting/state oracle: it does not call Economy.cast or reuse
# PlayerSkills guards. Seventy operations exercise pending commits, snapshots,
# reaction timing, stale epochs, menus, partial growth and exact cooldowns.
OPS = st.lists(st.tuples(st.sampled_from(("cast", "react", "interrupt", "tick", "upgrade", "pause", "body", "room", "restart", "preview", "resistance")), st.integers(0, 8)), min_size=70, max_size=70)

@seed(2026101314)
@settings(max_examples=240, deadline=None, database=None)
@given(OPS)
def test_randomized_seventy_step_skin_ledger_oracle(ops):
    economy = Economy(n=500, c=500)
    engine = PlayerSkills(economy)
    ref = dict(n=500,c=500,power=1,resistance=0,successes=0,pending_growth=False,
               cooldown=0,paused=False,body=False,epoch=0,pending=None)
    last = None
    used_tokens = set()
    for index, (op, arg) in enumerate(ops):
        if op == "cast":
            token = arg
            valid = arg != 8
            expected = (valid and not ref["paused"] and not ref["body"] and not ref["cooldown"]
                        and ref["pending"] is None and (ref["epoch"],token) not in used_tokens)
            result = cast(engine, token, valid_target=valid)
            assert bool(result) == expected
            if expected:
                ref["n"] -= 1
                ref["cooldown"] = 2000
                used_tokens.add((ref["epoch"],token))
                last = result["id"]
                assert result["power"] == ref["power"]
                resisted = ref["power"] <= ref["resistance"]
                assert result["resisted"] == resisted
                if not resisted:
                    ref["pending"] = last
        elif op == "react":
            expected = last is not None and ref["pending"] == last and not ref["paused"]
            result = engine.react(last, duration_ms=0)
            assert bool(result) == expected
            if expected:
                ref["pending"] = None
                if not ref["pending_growth"]:
                    ref["successes"] += 1
                    if ref["successes"] == 3:
                        ref["successes"] = 0
                        ref["pending_growth"] = True
        elif op == "interrupt":
            expected = last is not None and ref["pending"] == last
            assert bool(engine.interrupt(last)) == expected
            if expected:
                ref["pending"] = None
        elif op == "tick":
            elapsed = arg*501
            engine.tick(elapsed)
            if not ref["paused"]:
                ref["cooldown"] = max(0,ref["cooldown"]-elapsed)
        elif op == "upgrade":
            assert engine.upgrade()
            ref["c"] -= 1
            ref["power"] += 1
        elif op == "pause":
            ref["paused"] = bool(arg%2)
            engine.sync_context(paused=ref["paused"],menu=None)
        elif op == "body":
            ref["body"] = bool(arg%2)
            engine.sync_context(body_blocked=ref["body"])
        elif op == "room":
            assert not engine.end_context("room")
        elif op == "restart":
            engine.end_context("rest")
            economy.restart(death=False)
            ref["epoch"] += 1
            ref["pending"] = None
            ref["resistance"] += int(ref["pending_growth"])
            ref["pending_growth"] = False
        elif op == "preview":
            before = engine.snapshot()
            engine.preview("skin")
            assert engine.snapshot() == before
        elif op == "resistance":
            # Explicit host fixture for different inherited resistance profiles.
            economy.skills["skin"].resistance = ref["resistance"] = arg
        skill = economy.skills["skin"]
        assert (economy.n,economy.c,skill.power,skill.resistance,skill.successes,skill.pending,skill.remaining,engine.epoch) == (ref["n"],ref["c"],ref["power"],ref["resistance"],ref["successes"],ref["pending_growth"],ref["cooldown"],ref["epoch"])
        assert economy.n >= 0 and economy.c >= 0
        assert skill.successes in {0,1,2}
