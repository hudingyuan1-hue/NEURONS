"""R13 effects layer: actual mechanics and stateful temporal invariants."""
from copy import deepcopy

import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, invariant, rule

from skill_effects import DURATIONS, SKILLS, SkillEffects


def cast(name, number=1, mode='battle', **extra):
    return dict(id=(1, number), skill=name, mode=mode, power=2,
                effective_resistance=0, result='committed', **extra)


def targets():
    return [dict(id='through_wall', actual_perceived=False, distance_m=.1),
            dict(id='near', actual_perceived=True, distance_m=.7),
            dict(id='far', actual_perceived=True, distance_m=2),
            dict(id='dead', actual_perceived=True, distance_m=.2, alive=False)]


@pytest.mark.parametrize('name', SKILLS)
def test_exploration_twelve_skills_actual_effects(name):
    engine = SkillEffects()
    out = engine.begin(cast(name, mode='exploration'), pending_handoff=True,
                       handoff_id='medicine', current_point='cabinet', only_current_point=True)
    assert out and out['actual_reaction']
    assert out['cancel_search'] == (name in {'skin', 'gut', 'knee', 'withdraw', 'startle', 'fear', 'control'})
    assert out['sp_damage'] == (15 if name == 'fear' else 0)
    assert out['sp_heal'] == (20 if name == 'happy' else 0)
    expected = 6000 if name == 'fear' else DURATIONS['exploration'][name]
    assert out['duration_ms'] == expected
    assert engine.remaining(name) == expected
    assert not out['invulnerable'] and not out['clear_grip']
    if name == 'gut':
        assert out['interrupt_rest_persuasion']
    if name == 'pores':
        assert out['visible_anomaly'] and out['search_continues']
    if name == 'thermal':
        assert out['move_multiplier'] == out['search_multiplier'] == .75
        assert out['preserve_search_progress']
    if name == 'tinnitus':
        assert out['pause_action_ms'] == 1000 and out['resume_original_action']
        assert not out['external_sound']
    if name == 'dry':
        assert out['handoff_delay_ms'] == 2000 and out['handoff_id'] == 'medicine'
        assert not out['revoke_acquired']
    if name == 'fear':
        assert out['defer_current_point_ms'] == 6000
        assert out['deferred_point'] == 'cabinet' and not out['search_point_completed']


@pytest.mark.parametrize('name', SKILLS)
def test_battle_twelve_skills_actual_effects(name):
    engine = SkillEffects()
    out = engine.begin(cast(name), perceived_targets=targets(), direction='left')
    assert out and out['duration_ms'] == DURATIONS['battle'][name]
    assert out['sp_damage'] == (15 if name == 'fear' else 0)
    assert out['sp_heal'] == (20 if name == 'happy' else 0)
    assert out['cancel_search'] == (name == 'control')
    assert not out['invulnerable'] and not out['enemy_attack_cancelled']
    if name == 'skin':
        assert out['movement_request'] == dict(max_distance_m=.8, duration_ms=250,
                                               direction='left', obey_obstacles=True)
    if name == 'gut':
        assert out['pose_request'] == dict(enter_ms=200, hold_ms=800, exit_ms=200,
                                          collision_from_actual_pose=True,
                                          avoids_low_ground_full_body=False)
    if name == 'pores':
        assert out['turn_target'] == 'near' and out['turn_ms'] == 250
        assert out['perception_range_increase'] == 0
    if name == 'thermal':
        assert out['move_multiplier'] == 1.25
    if name == 'tinnitus':
        assert out['pause_action_ms'] == 300 and out['rejudge_route']
        assert not out['clear_enemy_tracking']
    if name == 'dry':
        assert out['suppress_character_vocal']
        assert out['footstep_sound'] and out['collision_sound']
        assert out['requires_listener_hearing']
    if name == 'withdraw':
        assert out['prevent_unclosed_hand_grip_only']
        assert out['collision_from_actual_arm'] and not out['avoids_full_body']
    if name == 'startle':
        assert out['movement_request']['max_distance_m'] == 1.4
        assert out['movement_request']['direction'] == 'backward'
    if name == 'fear':
        assert out['avoid_target'] == 'near' and not out['find_exit']
        assert out['remaining_runs_during_stupor']
    if name == 'happy':
        assert out['hp_heal'] == 0 and out['search_continues']
        assert not out['clear_grip'] and not out['clear_drug_pause']


def test_book_explore_mode_alias_is_supported():
    out = SkillEffects().begin(cast('skin', mode='explore'))
    assert out['mode'] == 'exploration' and out['cancel_search']


def test_perception_is_actual_and_not_global_entity_scan():
    engine = SkillEffects()
    assert engine.begin(cast('pores'), perceived_targets=[dict(id='hidden', distance_m=.2)]) is None
    assert not engine.pose_history
    out = engine.begin(cast('fear', 2), perceived_targets=[dict(id='hidden', distance_m=.2)])
    assert out['avoid_target'] is None and out['sp_damage'] == 15


def test_dry_cannot_revoke_acquired_handoff_and_fear_tries_other_points():
    for context in ({}, {'pending_handoff': False},
                    {'pending_handoff': True, 'handoff_acquired': True}):
        out = SkillEffects().begin(cast('dry', mode='exploration'), **context)
        assert out['handoff_delay_ms'] == 0 and not out['revoke_acquired']
    out = SkillEffects().begin(cast('fear', mode='exploration'), current_point='desk')
    assert out['prefer_other_points'] and out['defer_current_point_ms'] == 0


def test_exactly_once_frozen_snapshot_and_no_refresh_after_upgrade():
    engine = SkillEffects()
    original = cast('thermal')
    out = engine.begin(original)
    original['power'] = 200
    out['snapshot']['power'] = 300
    engine.tick(550)
    before = deepcopy(engine.__dict__)
    assert engine.begin(original) is None
    assert engine.begin(cast('thermal', 2, power_override=100)) is None
    assert engine.__dict__ == before
    assert engine.remaining('thermal') == 2450
    assert engine.effects[0]['snapshot']['power'] == 2
    engine.tick(2450)
    assert engine.begin(original) is None
    assert engine.begin(cast('thermal', 2))['duration_ms'] == 3000
    assert len(engine.pose_history) == 2


@pytest.mark.parametrize('reason', ['resisted', 'not_actual', 'paused', 'dead', 'body_unavailable'])
def test_failure_does_not_emit_actual_reaction_or_effect(reason):
    engine = SkillEffects(paused=reason == 'paused', dead=reason == 'dead')
    snapshot = cast('skin')
    if reason == 'resisted':
        snapshot['result'] = 'resisted'
    assert engine.begin(snapshot, actual_reaction=reason != 'not_actual',
                        body_available=reason != 'body_unavailable') is None
    assert not engine.active and not engine.effects and not engine.seen_casts


def test_pause_freezes_effects_and_motion_then_resumes_exactly():
    engine = SkillEffects()
    engine.begin(cast('thermal'))
    kick = engine.start_kick(('control', 1))
    engine.tick(100)
    engine.paused = True
    before = deepcopy(engine.__dict__)
    assert engine.tick(9000) is False
    assert engine.__dict__ == before
    assert engine.kick_contact(1, kick['id'], 'enemy') is None
    engine.paused = False
    engine.tick(50)
    assert engine.remaining('thermal') == 2850
    assert engine.current_attack['phase'] == 'active'


@pytest.mark.parametrize('source', ['neural', 'control'])
def test_kick_windup_active_recovery_and_contact_once(source):
    engine = SkillEffects()
    kick = engine.start_kick(('entry', source), source=source)
    assert engine.current_attack['phase'] == 'windup'
    assert engine.kick_contact(1, kick['id'], 'enemy', distance_m=.6) is None
    engine.tick(149)
    assert engine.kick_contact(2, kick['id'], 'enemy', distance_m=.6) is None
    engine.tick(1)
    out = engine.kick_contact(3, kick['id'], 'enemy', distance_m=1, ordinary_enemy=True)
    assert out['hp_damage'] == 15 and out['knockback_max_m'] == .8 and out['stun_ms'] == 800
    assert out['displacement_requires_actual_geometry']
    assert engine.kick_contact(4, kick['id'], 'enemy', distance_m=.5) is None
    assert engine.kick_contact(3, kick['id'], 'other', distance_m=.5) is None
    engine.tick(149)
    assert engine.kick_contact(5, kick['id'], 'other', distance_m=.5)['hp_damage'] == 15
    engine.tick(1)
    assert engine.current_attack['phase'] == 'recovery'
    assert engine.kick_contact(6, kick['id'], 'third', distance_m=.5) is None
    assert engine.start_kick(('entry', 2)) is None
    assert not engine.can_execute('skin')
    engine.tick(349)
    assert engine.body_busy()
    engine.tick(1)
    assert not engine.body_busy() and engine.current_attack is None
    assert engine.start_kick(('entry', source), source=source) is None


@pytest.mark.parametrize('invalid', [dict(actual_contact=False), dict(distance_m=1.01),
    dict(distance_m=-.01), dict(distance_m=float('nan')), dict(front=False),
    dict(actual_body_contact=False), dict(obstructed=True), dict(target_alive=False),
    dict(contact_kind='bedframe')])
def test_contact_requires_front_range_actual_unobstructed_living_body(invalid):
    engine = SkillEffects()
    kick = engine.start_kick(('c', 1))
    engine.tick(150)
    assert engine.kick_contact(('hit', 1), kick['id'], 'operator', **invalid) is None
    assert not engine.kicks[kick['id']]['hit_targets']
    assert not engine.seen_contacts
    assert engine.kick_contact(('hit', 1), kick['id'], 'operator')['hp_damage'] == 15


@pytest.mark.parametrize('defense', ['skin', 'withdraw', 'startle'])
def test_valid_defensive_action_cancels_unhit_attack_and_prevents_future_contact(defense):
    engine = SkillEffects()
    knee = engine.begin(cast('knee'))
    engine.tick(100)
    assert engine.may_cancel_attack(defense)
    assert engine.begin(cast(defense, 2), defensive_action_valid=False) is None
    defense_out = engine.begin(cast(defense, 2), defensive_action_valid=True)
    assert defense_out
    assert engine.kicks[knee['attack_id']]['phase'] == 'cancelled'
    engine.tick(50)
    assert engine.kick_contact(('contact', 1), knee['attack_id'], 'enemy') is None


def test_past_damage_survives_interrupt_and_defense_not_valid_after_hit():
    engine = SkillEffects()
    knee = engine.begin(cast('knee'))
    engine.tick(150)
    hit = engine.kick_contact(1, knee['attack_id'], 'enemy')
    assert not engine.may_cancel_attack('skin')
    assert engine.begin(cast('skin', 2)) is None
    assert engine.interrupt_kick(knee['attack_id'], actual=True)
    assert engine.effects[-1] == hit
    assert 'enemy' in engine.kicks[knee['attack_id']]['hit_targets']
    assert engine.kick_contact(2, knee['attack_id'], 'other') is None


def test_control_end_keeps_started_attack_neural_history_is_not_control_evidence():
    engine = SkillEffects()
    engine.begin(cast('control'))
    kick = engine.start_kick(('command', 1), source='control')
    assert engine.end_control()
    engine.tick(150)
    assert engine.kick_contact(1, kick['id'], 'enemy')['hp_damage'] == 15
    assert engine.pose_history == [dict(id=('skill_effect', (1, 1)), skill='control',
        mode='battle', clock=0, actual_neural_reaction=True, actual_control_action=False)]
    assert engine.start_kick(('command', 2), source='control', mode='exploration') is None


def test_fear_stupor_time_not_refilled_and_happy_does_not_remove_other_limits():
    engine = SkillEffects()
    fear = engine.begin(cast('fear'), body_available=False, perceived_targets=targets())
    assert fear['sp_damage'] == 15
    engine.tick(1000)  # Host's one-second stupor: timer continues.
    assert engine.remaining('fear') == 2000
    happy = engine.begin(cast('happy', 2), body_available=False)
    assert happy['sp_heal'] == 20
    assert not happy['clear_grip'] and not happy['clear_drug_pause']
    assert engine.remaining('fear') == 2000


def test_real_stage_clear_preserves_emitted_damage_and_prevents_stale_contacts():
    engine = SkillEffects()
    knee = engine.begin(cast('knee'))
    engine.tick(150)
    engine.kick_contact(1, knee['attack_id'], 'enemy')
    previous = deepcopy(engine.effects)
    engine.clear_transients()
    assert not engine.active and not engine.body_busy()
    assert engine.effects == previous
    assert engine.kick_contact(2, knee['attack_id'], 'other') is None


class EffectStateMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.engine = SkillEffects()
        self.serial = 0
        self.expected_timers = {}
        self.clock = 0
        self.hit_pairs = set()

    def next_id(self):
        self.serial += 1
        return ('random', self.serial)

    @rule(name=st.sampled_from(SKILLS), exploration=st.booleans(), actual=st.booleans(),
          only=st.booleans(), handoff=st.booleans())
    def activate(self, name, exploration, actual, only, handoff):
        mode = 'exploration' if exploration else 'battle'
        snapshot = dict(id=self.next_id(), skill=name, mode=mode, power=1, result='committed')
        old_remaining = self.engine.remaining(name)
        previous_attack = deepcopy(self.engine.current_attack)
        out = self.engine.begin(snapshot, actual_reaction=actual,
            perceived_targets=targets(), pending_handoff=handoff, only_current_point=only)
        if out:
            expected = DURATIONS[mode][name]
            if name == 'fear' and exploration and only:
                expected = 6000
            if name == 'dry' and exploration and not handoff:
                expected = 0
            assert out['duration_ms'] == expected
            assert actual and not self.engine.paused and old_remaining == 0
            if previous_attack and name in ('skin', 'withdraw', 'startle'):
                self.expected_timers.pop('knee', None)
            if expected:
                self.expected_timers[name] = expected
            assert self.engine.begin(snapshot) is None
        else:
            assert self.engine.remaining(name) == old_remaining

    @rule(ms=st.integers(min_value=0, max_value=7000))
    def advance(self, ms):
        old = deepcopy(self.engine.__dict__)
        self.engine.tick(ms)
        if self.engine.paused:
            assert self.engine.__dict__ == old
        else:
            self.clock += ms
            self.expected_timers = {name: remaining - ms for name, remaining in self.expected_timers.items()
                                    if remaining > ms}

    @rule()
    def toggle_pause(self):
        self.engine.paused = not self.engine.paused

    @rule()
    def start_control_kick(self):
        self.engine.start_kick(self.next_id(), source='control')

    @rule(target=st.sampled_from(['person', 'operator', 'friend']), contact=st.booleans(),
          front=st.booleans(), distance=st.sampled_from([0, .7, 1, 1.01]), bed=st.booleans())
    def contact(self, target, contact, front, distance, bed):
        if not self.engine.kicks:
            return
        attack = next(reversed(self.engine.kicks.values()))
        valid_phase = attack['phase'] == 'active'
        pair = (attack['id'], target)
        out = self.engine.kick_contact(self.next_id(), attack['id'], target,
            actual_contact=contact, front=front, distance_m=distance,
            contact_kind='bedframe' if bed else 'body')
        expected = (not self.engine.paused and valid_phase and contact and front
                    and distance <= 1 and not bed and pair not in self.hit_pairs)
        assert bool(out) == expected
        if out:
            assert out['hp_damage'] == 15
            self.hit_pairs.add(pair)

    @rule(actual=st.booleans(), defensive=st.booleans())
    def interrupt(self, actual, defensive):
        attack = self.engine.current_attack
        if attack is None:
            return
        aid = attack['cast_id']
        if self.engine.interrupt_kick(actual=actual, defensive=defensive):
            if self.engine.active.get('knee', {}).get('cast_id') != aid:
                self.expected_timers.pop('knee', None)

    @rule()
    def end_control(self):
        self.engine.end_control()
        self.expected_timers.pop('control', None)

    @invariant()
    def all_effects_and_contacts_exactly_once(self):
        assert self.engine.clock == self.clock
        assert self.engine.remaining_by_name == self.expected_timers
        ids = [entry['id'] for entry in self.engine.effects]
        assert len(ids) == len(set(ids))
        assert all(0 < value <= 6000 for value in self.engine.remaining_by_name.values())
        hits = [entry for entry in self.engine.effects if 'attack_id' in entry and 'target' in entry]
        assert sum(entry['hp_damage'] for entry in hits) == 15 * len(self.hit_pairs)
        assert all(not entry['actual_control_action'] for entry in self.engine.pose_history)


TestEffectStateMachine = EffectStateMachine.TestCase
TestEffectStateMachine.settings = settings(max_examples=200, stateful_step_count=70,
                                           deadline=None, database=None)
