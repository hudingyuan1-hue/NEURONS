"""Focused S1 father/new paid-skill seam; no rerun of the historical chapter."""
from pathlib import Path
from hashlib import sha256
import pytest
from family import Family
from family_skill_bridge import FamilySkillBridge


ROUTES = {
    'knee': ('gut', 'knee'), 'startle': ('thermal', 'startle'),
    'withdraw': ('withdraw',),
    'fear': ('thermal', 'tinnitus', 'startle', 'fear'),
    'happy': ('pores', 'withdraw', 'happy'),
    'control': ('pores', 'withdraw', 'happy', 'control'),
}


def setup(name, *, grabbed=False, sp=40, n=50, c=22):
    f = Family()
    f.life.economy.n, f.life.economy.c = n, c
    f.life.sp = sp
    assert f.appear('father') == 'force'
    if grabbed:
        f.father, f.father_remaining, f.grabbed = 'turn', 2000, True
    b = FamilySkillBridge(family=f)
    for skill in ROUTES.get(name, ()):
        assert b.book.unlock(skill)
    return f, b


def react(b, name, **facts):
    cast = b.submit(name)
    assert cast and not cast['resisted']
    result = b.react(cast['id'], **facts)
    assert result
    return cast, result


def test_preserved_family_is_exact_latest_r3_bytes():
    assert sha256(Path('family.py').read_bytes()).hexdigest() == 'e15b98be0c1899ba5480262af01b9e4ea4fd5b83bfa8a58fd0a7435eafb4c772'


@pytest.mark.parametrize('roll,success', [(0,True),(69,True),(70,False),(99,False)])
def test_knee_paid_then_actual_active_contact_then_seventy_percent(roll, success):
    f, b = setup('knee', grabbed=True)
    before = f.life.economy.n
    cast, _ = react(b, 'knee')
    assert f.life.economy.n == before - 2
    assert f.life.sp == 40 and f.grabbed
    assert f.life.economy.skills['knee'].successes == 1
    assert b.resolve_action(cast['id'], actual_hit=True, roll=roll) is None
    b.tick(150)
    result = b.resolve_action(cast['id'], actual_hit=True, roll=roll)
    assert bool(result['rescue']) == success
    assert f.life.sp == 40 + (10 if success else 0)
    assert f.grabbed is not success
    assert f.father == ('stunned' if success else 'turn')
    assert f.father_remaining == (2000 if success else 1850)
    assert f.blood_gate and not f.rescue_exit
    assert b.resolve_action(cast['id'], actual_hit=True, roll=0) is None
    assert f.life.economy.n == before - 2


def test_knee_actual_miss_counts_one_reaction_but_no_rescue_or_heal():
    f, b = setup('knee', grabbed=True)
    cast, _ = react(b, 'knee')
    b.tick(150)
    result = b.resolve_action(cast['id'], actual_hit=False)
    assert not result['rescue'] and f.grabbed and f.life.sp == 40
    assert f.life.economy.skills['knee'].successes == 1
    assert b.resolve_action(cast['id'], actual_hit=True, roll=0) is None


@pytest.mark.parametrize('elapsed,accepted', [(149,False),(150,True),(299,True),(300,False)])
def test_s1_knee_uses_actual_active_interval_without_generic_fifteen_hp(elapsed, accepted):
    f, b = setup('knee')
    cast, _ = react(b, 'knee')
    b.tick(elapsed)
    result = b.resolve_action(cast['id'], actual_hit=True, roll=0)
    assert bool(result) == accepted
    assert f.life.hp == 100
    assert not hasattr(f, 'father_hp')
    assert all(e.get('hp_damage', 0) == 0 for e in b.effects.effects)


@pytest.mark.parametrize('name', ['knee','startle','fear','happy'])
def test_resisted_rescue_pays_but_has_no_body_reaction_or_recovery(name):
    f, b = setup(name, grabbed=True)
    s = f.life.economy.skills[name]
    s.resistance = s.power
    before = (f.life.economy.n, f.life.sp)
    cast = b.submit(name)
    assert cast['resisted']
    assert b.react(cast['id'])
    assert f.life.economy.n == before[0] - s.cost
    assert f.life.sp == before[1] and f.grabbed and f.blood_gate
    assert s.remaining == s.cooldown and s.successes == 0
    assert b.resolve_action(cast['id'], actual_hit=True, roll=0, actual_escape=True) is None
    assert b.react(cast['id']) is None
    assert not b.effects.effects


@pytest.mark.parametrize('name', ['knee','startle','fear','happy','control'])
def test_rescue_hint_never_unlocks_free_or_bypasses_balance(name):
    f = Family(); f.appear('father')
    b = FamilySkillBridge(family=f)
    original = (f.life.economy.n, f.life.economy.c)
    assert b.submit(name) is None
    assert (f.life.economy.n, f.life.economy.c) == original
    f2, b2 = setup(name, n=0)
    assert b2.submit(name) is None
    assert f2.life.economy.n == 0


@pytest.mark.parametrize('grabbed,dodge,escape,success', [(False,True,False,True),(False,False,False,False),(True,False,True,True),(True,False,False,False)])
def test_startle_requires_actual_dodge_or_actual_dedicated_escape(grabbed,dodge,escape,success):
    f, b = setup('startle', grabbed=grabbed)
    cast, _ = react(b, 'startle')
    assert f.life.sp == 40 and f.grabbed == grabbed
    result = b.resolve_action(cast['id'], actual_dodge=dodge, actual_escape=escape)
    assert bool(result['rescue']) == success
    assert f.life.sp == 40 + (5 if success else 0)
    assert f.grabbed == (grabbed and not success)
    assert f.blood_gate
    assert b.resolve_action(cast['id'], actual_dodge=True, actual_escape=True) is None
    assert f.life.economy.skills['startle'].successes == 1


def test_startle_exception_does_not_exist_outside_father_rescue_window():
    f, b = setup('startle', grabbed=True)
    f.father = 'gone'
    assert b.submit('startle') is None
    assert f.grabbed and f.life.sp == 40


def test_withdraw_only_before_grab_and_never_heals():
    f, b = setup('withdraw')
    cast, _ = react(b, 'withdraw')
    result = b.resolve_action(cast['id'], actual_dodge=True)
    assert result['rescue'] == 'withdraw' and f.life.sp == 40
    f2, b2 = setup('withdraw', grabbed=True)
    assert b2.submit('withdraw') is None
    assert f2.grabbed


@pytest.mark.parametrize('name,expected_sp', [('fear',25),('happy',60)])
def test_high_rescue_actual_effect_clears_father_only_and_keeps_own_sp(name, expected_sp):
    f, b = setup(name, grabbed=True)
    cast = b.submit(name)
    assert f.grabbed and f.blood_gate and f.life.sp == 40
    result = b.react(cast['id'], pressure_due=True)
    assert result['rescue'] == 'awake'
    assert f.life.sp == expected_sp
    assert not f.grabbed and not f.blood_gate and f.father == 'saved'
    assert f.rescue_exit
    assert b.cross_door() == 'S2' and f.life.progress == 2
    assert b.react(cast['id']) is None


def test_fear_zero_sp_has_one_stupor_then_rescue_exit_not_bed():
    f, b = setup('fear', grabbed=True, sp=10)
    cast, _ = react(b, 'fear')
    assert f.life.sp == 0 and f.life.stun == 1000 and f.rescue_exit
    assert not b.cross_door()
    b.tick(999)
    assert not b.cross_door()
    b.tick(1)
    assert b.cross_door() == 'S2'


@pytest.mark.parametrize('name', ['fear','happy'])
def test_lethal_damage_wins_same_actual_rescue_node_over_heal_and_exit(name):
    f, b = setup(name, grabbed=True, sp=40)
    f.life.hp = 5
    cast = b.submit(name)
    result = b.react(cast['id'], hp_damage=5, pressure_due=True, actual_exit=True)
    assert result['status'] == 'death'
    assert f.life.phase == 'dead' and f.life.progress == 1 and f.life.hp == 0
    assert f.life.sp == (25 if name == 'fear' else 40) and not f.rescue_exit
    assert not b.cross_door()
    assert not b.book.control_active


def test_actual_collapse_locks_before_paid_happy_can_rescue_or_recover():
    f, b = setup('happy', grabbed=True)
    cast = b.submit('happy')
    before = f.life.economy.n
    result = b.react(cast['id'], collapse_locked=True, actual_exit=True)
    assert result['status'] == 'collapse'
    assert f.life.hp == f.life.sp == 0 and f.life.phase == 'dead'
    assert f.life.economy.pending_g == {'parent_collapse'}
    assert f.life.economy.skills['happy'].successes == 0
    assert f.life.economy.n == before and not f.rescue_exit
    assert b.react(cast['id'], collapse_locked=True) is None


def test_middle_recovery_precedes_same_node_pressure_without_false_zero_stupor():
    f, b = setup('startle', grabbed=True, sp=1)
    cast, _ = react(b, 'startle')
    result = b.resolve_action(cast['id'], actual_escape=True, pressure_due=True)
    assert result['rescue'] == 'startle'
    assert f.life.sp == 5 and f.life.stun == 0 and not f.life.emptied
    assert f.blood_gate and not f.rescue_exit


def test_only_designated_rescue_escapes_fourth_wall_limit_and_still_pays():
    f, b = setup('startle', grabbed=True)
    b.fourth_wall_restricted = True
    assert b.submit('skin') is None
    before = f.life.economy.n
    cast, _ = react(b, 'startle')
    assert f.life.economy.n == before - 2
    assert f.grabbed
    assert b.resolve_action(cast['id'], actual_escape=True)['rescue'] == 'startle'


def test_control_never_unlocks_grab_or_blood_gate_and_key_does_not_override():
    f, b = setup('control')
    f.search.key_owner = 'avatar'
    cast, _ = react(b, 'control')
    assert b.book.control_active and f.blood_gate and not f.rescue_exit
    assert not b.cross_door()
    b.tick(3000)
    assert f.grabbed and b.book.control_remaining == 3000
    assert not b.book.control_command('move', 'move')
    b.tick(2000)
    assert f.father == 'carry'
    assert b.cross_door() == 'hiddenStreet'
    assert f.life.place == 'hiddenStreet' and f.life.progress == 1
    assert not b.book.control_active and f.life.economy.skills['control'].remaining == 20000
    assert b.react(cast['id']) is None


def test_grabbed_control_rejected_without_charge_even_in_rescue_window():
    f, b = setup('control', grabbed=True)
    before = f.life.economy.n
    assert b.submit('control') is None
    assert f.life.economy.n == before and f.grabbed and f.blood_gate


def test_paid_submission_is_not_completed_rescue_and_pause_freezes_all_clocks():
    f, b = setup('happy', grabbed=True)
    b.paused, b.menu = True, 'cast'
    cast = b.submit('happy')
    assert cast and f.grabbed and f.life.sp == 40
    assert b.react(cast['id']) is None
    before = (f.father_remaining, f.life.economy.skills['happy'].remaining, f.pressure_ms)
    b.tick(10000)
    assert (f.father_remaining, f.life.economy.skills['happy'].remaining, f.pressure_ms) == before
    b.paused, b.menu = False, None
    assert b.react(cast['id'])['rescue'] == 'awake'


def test_cancelled_reaction_keeps_payment_without_rescue_or_adaptation():
    f, b = setup('happy', grabbed=True)
    before = f.life.economy.n
    cast = b.submit('happy')
    assert b.react(cast['id'], actual=False)
    assert f.life.economy.n == before - 3 and f.grabbed and f.life.sp == 40
    assert f.life.economy.skills['happy'].successes == 0
    assert b.react(cast['id']) is None


def test_thought_branch_keeps_any_actual_skill_rule_without_free_normal_exit():
    f = Family(cat='occupying'); f.life.sp=100
    assert f.appear('father') == 'cat'
    assert f.complete_cat_pickup() and f.father == 'thought'
    b = FamilySkillBridge(family=f)
    cast, result = react(b, 'skin')
    assert result['rescue'] == 'thought'
    assert f.father == 'gone' and f.cat == 'exited' and not f.blood_gate
    assert not f.rescue_exit and not b.cross_door()


def thought_bridge(name):
    f = Family(cat='occupying')
    f.life.economy.n, f.life.economy.c = 50, 22
    assert f.appear('father') == 'cat'
    assert f.complete_cat_pickup() and f.father == 'thought'
    b = FamilySkillBridge(family=f)
    for skill in ROUTES.get(name, ()):
        assert b.book.unlock(skill)
    return f, b


def test_thought_review_any_unlocked_node_gets_designated_window_exception():
    f, b = thought_bridge('skin')
    b.fourth_wall_restricted = True
    before = f.life.economy.n
    cast = b.submit('skin')
    assert cast is not None
    assert f.life.economy.n == before - 1
    assert f.father == 'thought' and f.blood_gate


def test_thought_review_reaction_alone_does_not_assert_actual_interruption():
    f, b = thought_bridge('skin')
    cast = b.submit('skin')
    assert b.react(cast['id'])
    assert f.father == 'thought' and f.blood_gate


def test_thought_review_control_activation_waits_for_actual_body_interrupt():
    f, b = thought_bridge('control')
    cast = b.submit('control')
    assert b.react(cast['id'])
    assert f.father == 'thought' and f.blood_gate
    assert b.book.control_remaining == 6000
    assert f.life.economy.skills['control'].successes == 0
    assert b.control_body(cast['id'], actual=False, thought_interrupted=True) is None
    assert f.father == 'thought' and f.blood_gate
    result = b.control_body(cast['id'], actual=True, thought_interrupted=True)
    assert result['rescue'] == 'thought'
    assert f.father == 'gone' and not f.blood_gate and not f.rescue_exit
    assert f.life.economy.skills['control'].successes == 1
    assert b.control_body(cast['id'], actual=True, thought_interrupted=True) is None
