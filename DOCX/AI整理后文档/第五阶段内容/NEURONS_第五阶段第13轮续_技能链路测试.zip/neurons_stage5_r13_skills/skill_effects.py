"""NEURONS S2:P61-82 / S4:P166-176: verified skill reactions and proposals.

This module does not spend resources, decide neural resistance, move an entity,
find threats, change host health, or resolve collision geometry. The caller owns
those operations and must supply actual perception/contact/body-state inputs.
Times are integer gameplay milliseconds. All durations use committed snapshots;
upgrading a ledger cannot change an already running effect.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from math import isfinite

SKILLS = ('skin', 'gut', 'pores', 'thermal', 'tinnitus', 'dry', 'knee',
          'withdraw', 'startle', 'fear', 'happy', 'control')
# Timed gameplay effects, not universal animation lengths. Zero for fear/happy
# means immediate SP/selection consequences; exploration startle has no supplied
# numeric movement duration and is explicitly delegated to actual host movement.
DURATIONS = {
    'exploration': dict(skin=500, gut=1200, pores=3000, thermal=3000,
                        tinnitus=1000, dry=2000, knee=650, withdraw=300,
                        startle=0, fear=0, happy=0, control=6000),
    'battle': dict(skin=250, gut=1200, pores=250, thermal=3000,
                   tinnitus=300, dry=6000, knee=650, withdraw=300,
                   startle=350, fear=3000, happy=0, control=6000),
}
DEFENSIVE = frozenset(('skin', 'withdraw', 'startle'))
BODY_ACTIONS = frozenset(('skin', 'gut', 'pores', 'tinnitus', 'knee', 'withdraw', 'startle'))


def _cast_key(cast):
    return cast.get('id', cast.get('cast_id'))


def _nearest_perceived(targets):
    """Only current, explicitly perceived, live threats supplied by the host."""
    candidates = []
    for index, target in enumerate(targets):
        if not isinstance(target, dict):
            continue
        distance = target.get('distance_m', target.get('distance'))
        if (target.get('actual_perceived') is True and target.get('alive', True)
                and target.get('threat', True) and target.get('id') is not None
                and isinstance(distance, (int, float)) and isfinite(distance)
                and distance >= 0):
            candidates.append((distance, index, target['id']))
    return min(candidates)[2] if candidates else None


@dataclass
class SkillEffects:
    paused: bool = False
    dead: bool = False
    clock: int = 0
    active: dict = field(default_factory=dict)
    effects: list = field(default_factory=list)
    seen_casts: set = field(default_factory=set)
    kicks: dict = field(default_factory=dict)
    seen_contacts: set = field(default_factory=set)
    pose_history: list = field(default_factory=list)
    serial: int = 0

    @property
    def remaining_by_name(self):
        return {name: entry['remaining_ms'] for name, entry in self.active.items()}

    def remaining(self, name):
        return self.active.get(name, {}).get('remaining_ms', 0)

    @property
    def current_attack(self):
        return next((attack for attack in reversed(list(self.kicks.values()))
                     if attack['phase'] in ('windup', 'active', 'recovery')), None)

    def may_cancel_attack(self, skill):
        attack = self.current_attack
        return bool(skill in DEFENSIVE and attack
                    and attack['phase'] in ('windup', 'active')
                    and not attack['hit_targets'])

    def body_busy(self):
        if self.current_attack is not None:
            return True
        return any(entry.get('body_busy', False) for entry in self.active.values())

    def can_execute(self, skill, *, body_available=True):
        if self.paused or self.dead or skill not in SKILLS or self.remaining(skill):
            return False
        if skill in ('fear', 'happy', 'dry', 'thermal'):
            return True
        if not body_available:
            return False
        if self.current_attack is not None:
            return self.may_cancel_attack(skill)
        return not self.body_busy()

    def begin(self, cast, actual_reaction=True, context=None, **inputs):
        """Activate one actual successful committed reaction, returning a proposal.

        Supported context: perceived_targets (each with actual_perceived=True,
        id and distance_m), pending_handoff, handoff_id, handoff_acquired,
        only_current_point, current_point, direction, body_available and
        defensive_action_valid. Perception is supplied afresh at activation.
        ``actual_reaction`` confirms the neural reaction, not a collision dodge,
        completed displacement, or an automatically successful control action.
        """
        context = dict(context or {})
        context.update(inputs)
        name = cast.get('skill', cast.get('name'))
        mode = cast.get('mode', 'exploration')
        if mode == 'combat':
            mode = 'battle'
        elif mode == 'explore':
            mode = 'exploration'
        cast_id = _cast_key(cast)
        result = cast.get('result', cast.get('status', 'committed'))
        if (cast_id is None or name not in SKILLS or mode not in DURATIONS
                or self.paused or self.dead or not actual_reaction
                or cast.get('resisted', False) or result in ('resisted', 'rejected', 'cancelled')
                or cast_id in self.seen_casts or self.remaining(name)):
            return None
        if name in BODY_ACTIONS or name == 'control':
            if not context.get('body_available', True):
                return None
            attack = self.current_attack
            if attack is not None:
                if not (self.may_cancel_attack(name) and context.get('defensive_action_valid', True)):
                    return None
                self.interrupt_kick(attack['id'], actual=True, defensive=True)
            elif self.body_busy():
                return None
        target = _nearest_perceived(context.get('perceived_targets', ()))
        # Without a perceived threat there is no battle turn target. Fear still
        # changes the character's mental state; it does not invent a target.
        if name == 'pores' and mode == 'battle' and target is None:
            return None
        duration = DURATIONS[mode][name]
        if name == 'fear' and mode == 'exploration' and context.get('only_current_point', False):
            duration = 6000
        if name == 'dry' and mode == 'exploration':
            if not context.get('pending_handoff', False) or context.get('handoff_acquired', False):
                # The reaction can occur, but there is no pending transaction
                # to delay and no acquired item can be revoked.
                duration = 0
        out = dict(id=('skill_effect', cast_id), cast_id=cast_id, skill=name,
                   mode=mode, hp_damage=0, sp_damage=0, sp_heal=0,
                   cancel_search=False, duration_ms=duration,
                   actual_reaction=True, invulnerable=False, clear_grip=False,
                   clear_drug_pause=False, enemy_attack_cancelled=False,
                   snapshot=deepcopy(cast))
        if mode == 'exploration':
            out['cancel_search'] = name in ('skin', 'gut', 'knee', 'withdraw', 'startle', 'fear', 'control')
            if name == 'gut':
                out['interrupt_rest_persuasion'] = True
            elif name == 'pores':
                out.update(visible_anomaly=True, search_continues=True)
            elif name == 'thermal':
                out.update(move_multiplier=.75, search_multiplier=.75,
                           preserve_search_progress=True, search_continues=True)
            elif name == 'tinnitus':
                out.update(pause_action_ms=1000, resume_original_action=True,
                           external_sound=False, preserve_search_progress=True)
            elif name == 'dry':
                out.update(handoff_delay_ms=duration,
                           handoff_id=context.get('handoff_id') if duration else None,
                           revoke_acquired=False)
            elif name == 'fear':
                out.update(sp_damage=15, prefer_other_points=True,
                           deferred_point=context.get('current_point'),
                           defer_current_point_ms=duration,
                           search_point_completed=False)
        else:
            if name == 'skin':
                out['movement_request'] = dict(max_distance_m=.8, duration_ms=250,
                                               direction=deepcopy(context.get('direction', cast.get('direction'))),
                                               obey_obstacles=True)
            elif name == 'gut':
                out['pose_request'] = dict(enter_ms=200, hold_ms=800, exit_ms=200,
                                          collision_from_actual_pose=True,
                                          avoids_low_ground_full_body=False)
            elif name == 'pores':
                out.update(turn_target=target, turn_ms=250, stop_unrelated_action=True,
                           perception_range_increase=0)
            elif name == 'thermal':
                out.update(move_multiplier=1.25)
            elif name == 'tinnitus':
                out.update(pause_action_ms=300, rejudge_route=True,
                           clear_enemy_tracking=False, external_sound=False)
            elif name == 'dry':
                out.update(suppress_character_vocal=True, footstep_sound=True,
                           collision_sound=True, requires_listener_hearing=True)
            elif name == 'fear':
                out.update(sp_damage=15, stop_active_offense=True,
                           avoid_target=target, find_exit=False,
                           remaining_runs_during_stupor=True)
        if name == 'happy':
            out.update(sp_heal=20, clear_emotional_hesitation=True,
                       search_continues=True, hp_heal=0)
        elif name == 'withdraw':
            out.update(withdraw_arm_ms=300, prevent_unclosed_hand_grip_only=True,
                       collision_from_actual_arm=True, clear_grip=False,
                       avoids_full_body=False)
        elif name == 'startle':
            if mode == 'battle':
                out['movement_request'] = dict(max_distance_m=1.4, duration_ms=350,
                                               direction='backward', obey_obstacles=True)
            else:
                # S4:T14R10 supplies exploration cancellation/backward motion,
                # but only the battle column gives 1.4 m / 350 ms. Zero in the
                # scheduler means no locally specified timer, not instant motion.
                out.update(motion_duration_external=True,
                           movement_request=dict(direction='backward',
                               obey_obstacles=True, actual_movement_external=True))
        elif name == 'control':
            out.update(stop_autonomous_movement=True, cancel_search=True,
                       control_ownership_external=True, input_duration_ms=6000,
                       actual_control_action=False)
        elif name == 'knee':
            attack = self.start_kick(cast_id, source='neural', mode=mode)
            if attack is None:
                return None
            out['attack_id'] = attack['id']
        self.seen_casts.add(cast_id)
        body_busy = (name in BODY_ACTIONS and name != 'knee'
                     and not (name == 'pores' and mode == 'exploration'))
        if duration:
            self.active[name] = dict(id=out['id'], cast_id=cast_id,
                                     remaining_ms=duration, total_ms=duration,
                                     mode=mode, body_busy=body_busy)
        self.effects.append(deepcopy(out))
        self.pose_history.append(dict(id=out['id'], skill=name, mode=mode,
                                      clock=self.clock, actual_neural_reaction=True,
                                      actual_control_action=False))
        return deepcopy(out)

    def start_kick(self, cast_id, source='control', mode='battle', *, body_available=True):
        """Start an already ledger-approved attack; cooldown belongs to the ledger."""
        if (self.paused or self.dead or not body_available or self.body_busy()
                or source not in ('neural', 'control') or mode not in DURATIONS
                or (source == 'control' and mode != 'battle')):
            return None
        attack_id = ('player_kick', cast_id)
        if attack_id in self.kicks:
            return None
        attack = dict(id=attack_id, cast_id=cast_id, source=source, mode=mode,
                      phase='windup', elapsed_ms=0, total_elapsed_ms=0,
                      started_ms=self.clock, hit_targets=set(), cancelled=False)
        self.kicks[attack_id] = attack
        return deepcopy(attack)

    def kick_contact(self, token, attack_id, target, *, actual_contact=True,
                     distance_m=0, front=True, actual_body_contact=True,
                     obstructed=False, target_alive=True, ordinary_enemy=False,
                     contact_kind='body'):
        """Return contact proposal only in the actual 150 ms active interval.

        Callers verify the front body line, distance, obstruction, and actual
        target identity. A bed frame cannot stand in for its operator. Geometry
        and target-specific knockback remain external to this motion timeline.
        """
        attack = self.kicks.get(attack_id)
        if (self.paused or self.dead or token in self.seen_contacts or not attack
                or attack['phase'] != 'active' or attack['cancelled']
                or target in attack['hit_targets'] or target is None
                or not actual_contact or not actual_body_contact or not front
                or obstructed or not target_alive or contact_kind != 'body'
                or not isinstance(distance_m, (int, float))
                or not isfinite(distance_m) or not 0 <= distance_m <= 1):
            return None
        self.seen_contacts.add(token)
        attack['hit_targets'].add(target)
        out = dict(id=('kick_hit', attack_id, target), attack_id=attack_id,
                   target=target, hp_damage=15, hp=15, sp_damage=0,
                   source=attack['source'], mode=attack['mode'],
                   actual_body_contact=True,
                   exploration_special=attack['mode'] == 'exploration',
                   knockback_max_m=.8 if ordinary_enemy and attack['mode'] == 'battle' else 0,
                   stun_ms=800 if ordinary_enemy and attack['mode'] == 'battle' else 0,
                   displacement_requires_actual_geometry=True)
        self.effects.append(deepcopy(out))
        return deepcopy(out)

    # Convenient alternate name for hosts whose combat modules call contact().
    contact = kick_contact

    def interrupt_kick(self, attack_id=None, *, actual=True, defensive=False):
        attack = self.kicks.get(attack_id) if attack_id is not None else self.current_attack
        if (self.paused or self.dead or not actual or not attack
                or attack['phase'] not in ('windup', 'active', 'recovery')):
            return False
        if defensive and (attack['phase'] not in ('windup', 'active') or attack['hit_targets']):
            return False
        attack.update(phase='cancelled', cancelled=True, elapsed_ms=0)
        # Remove the neural reaction's body timer so the real replacement action
        # can run; past contact records and already emitted damage stay intact.
        entry = self.active.get('knee')
        if entry and entry['cast_id'] == attack['cast_id']:
            del self.active['knee']
        return True

    def finish_effect(self, name):
        return self.active.pop(name, None) is not None

    def end_control(self):
        """Ending input ownership does not cancel an attack already started."""
        return self.finish_effect('control')

    def clear_transients(self):
        """Host calls on a real stage end/death/restart, never an ordinary door."""
        self.active.clear()
        for attack in self.kicks.values():
            if attack['phase'] in ('windup', 'active', 'recovery'):
                attack.update(phase='cancelled', cancelled=True, elapsed_ms=0)

    def tick(self, ms):
        if not isinstance(ms, int) or ms < 0:
            raise ValueError('elapsed time must be a nonnegative integer in milliseconds')
        if self.paused or self.dead:
            return False
        self.clock += ms
        for name, entry in list(self.active.items()):
            entry['remaining_ms'] = max(0, entry['remaining_ms'] - ms)
            if not entry['remaining_ms']:
                del self.active[name]
        for attack in self.kicks.values():
            rest = ms
            while rest and attack['phase'] in ('windup', 'active', 'recovery'):
                phase = attack['phase']
                duration = {'windup': 150, 'active': 150, 'recovery': 350}[phase]
                step = min(rest, duration - attack['elapsed_ms'])
                attack['elapsed_ms'] += step
                attack['total_elapsed_ms'] += step
                rest -= step
                if attack['elapsed_ms'] == duration:
                    attack['phase'] = {'windup': 'active', 'active': 'recovery',
                                       'recovery': 'finished'}[phase]
                    attack['elapsed_ms'] = 0
        return True
