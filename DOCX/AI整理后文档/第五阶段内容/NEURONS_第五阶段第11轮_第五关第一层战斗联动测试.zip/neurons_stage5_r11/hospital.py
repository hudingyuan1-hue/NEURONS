"""S2 hospital rules only. Integer game milliseconds; geometry supplied by caller.

No dialogue changes; no Unity implementation or route simulation is implied.
Sources: S3:T7,T9,T13-T15/P528-578; S4:T13R5,T15R3-4,T16R2/P189-192/P207.
"""
from dataclasses import dataclass, field


@dataclass
class Hospital:
    hp: int = 100
    sp: int = 100
    paused: bool = False
    dead: bool = False
    episode: int = 1
    # Prescription can be supplied independently of completed sampling.
    prescription: str | None = None
    cup: str = 'none'
    cup_id: str | None = None
    medicine_closed: bool = False
    cup_progress: int = 0
    drug_stop: int = 0
    empty_stop: int = 0
    empty_armed: bool = True
    drug_history: bool = False
    false_label_known: bool = False
    false_label: bool = False
    refusal_witnessed: bool = False
    medication_count: int = 0
    exam: str = 'idle'
    exam_closed: bool = False
    needle_count: int = 0
    hold_ms: int = 0
    sample_ms: int = 0
    sample_valid: bool = False
    sample_interrupted: bool = False
    holder: str | None = None
    report: str = 'none'
    guard_present: bool = False
    guard_busy: bool = False
    guard: str = 'idle'
    guard_closed: bool = False
    guard_ms: int = 0
    guard_damage_count: int = 0
    nurse_present: bool = True
    nurse_alive: bool = True
    bandaging: bool = False
    bandage_ms: int = 0
    healed: bool = False
    healing_count: int = 0
    events: list = field(default_factory=list)

    def active(self):
        return not self.dead and not self.paused

    def _damage(self, hp=0, sp=0):
        if not self.active():
            return False
        old_sp = self.sp
        self.hp = max(0, self.hp-hp)
        self.sp = max(0, self.sp-sp)
        if self.hp == 0:
            self.dead = True
            self.holder = None
            self.bandaging = False
            self.events.append('death')
        elif old_sp > 0 and self.sp == 0 and self.empty_armed:
            self.empty_stop = 1000
            self.empty_armed = False
        return True

    def give_prescription(self, ident='patient', actual=True):
        if not self.active() or not actual:
            return False
        self.prescription = ident
        return True

    def prepare(self, actual_handover=True, match=True, departing=False):
        # Same/new orders cannot reopen this actual attempt's closed episode.
        if not (self.active() and actual_handover and match and self.prescription
                and not self.medicine_closed and self.cup == 'none' and not departing):
            return False
        self.cup, self.cup_id = 'prepared', self.prescription
        return True

    def take_cup(self, actual=True):
        if not (self.active() and actual and self.cup in ('prepared', 'interrupted')):
            return False
        if self.drug_history or self.false_label_known:
            return self.refuse()
        self.cup = 'held'
        return True

    def raise_cup(self):
        if not self.active() or self.cup != 'held':
            return False
        self.cup, self.cup_progress = 'raising', 0
        return True

    def interrupt_cup(self):
        if not self.active() or self.cup not in ('held', 'raising'):
            return False
        self.cup, self.cup_progress = 'interrupted', 0
        return True

    def refuse(self, nurse_witness=False):
        if not self.active() or self.medicine_closed or self.cup == 'none':
            return False
        self.cup, self.medicine_closed = 'refused', True
        self.refusal_witnessed = bool(nurse_witness and self.nurse_present and self.nurse_alive and not self.bandaging)
        self.events.append('refused')
        return True

    def swallow(self, actual=True):
        if not (self.active() and actual and self.cup == 'raising'
                and self.cup_progress >= 1000 and not self.medicine_closed):
            return False
        self.cup, self.medicine_closed, self.drug_history = 'consumed', True, True
        self.medication_count += 1
        self._damage(sp=15)
        self.drug_stop = 1000
        self.events.append('swallowed')
        return True

    def complete_false_label(self, witnessed_complete=False):
        if not (self.active() and self.nurse_present and self.nurse_alive
                and not self.bandaging and self.refusal_witnessed and not self.false_label):
            return False
        self.false_label = True
        self.false_label_known |= witnessed_complete
        self.events.append('false_label')
        return True

    def restore_sp(self, amount):
        if not self.active():
            return False
        self.sp = min(100, self.sp+amount)
        if self.sp >= 20:
            self.empty_armed = True
        return True

    def begin_exam(self, departing=False, dangerous=False):
        if not self.active() or self.exam_closed or departing or self.exam != 'idle':
            return False
        self.exam = 'refused' if dangerous or self.needle_count else 'offered'
        return True

    def grip_exam(self, actual=True):
        if not (self.active() and actual and self.exam in ('offered', 'refused') and self.holder is None):
            return False
        self.exam, self.holder = 'held', 'doctor'
        self.bandaging = False
        self.hold_ms = 0
        return True

    def insert_needle(self, actual=True):
        if not (self.active() and actual and self.exam == 'held' and self.holder == 'doctor'):
            return False
        self.exam, self.sample_ms = 'sampling', 0
        self.needle_count += 1
        self._damage(hp=5)
        self.events.append('needle')
        return True

    def end_exam(self):
        if not self.active() or self.exam_closed or self.exam == 'idle':
            return False
        self.sample_interrupted |= self.exam == 'sampling' and not self.sample_valid
        self.exam, self.exam_closed = 'ended', True
        if self.holder == 'doctor':
            self.holder = None
        return True

    def withdraw(self):
        # A valid dodge ends this encounter only before actual grip.
        if not self.active():
            return False
        if self.holder is not None:
            return False
        if self.exam in ('offered', 'refused') and not self.exam_closed:
            return self.end_exam()
        if self.guard == 'approach':
            self.guard, self.guard_closed = 'ended', True
            return True
        return False

    def doctor_hit_releases(self, actual=True):
        if not actual or self.holder != 'doctor':
            return False
        return self.end_exam()

    def file_report(self, seen=True, warned=True, continued=True):
        if not (self.active() and seen and warned and continued and self.report == 'none'):
            return False
        self.report = 'desk'
        return True

    def receive_report(self, actual=True):
        if not (self.active() and actual and self.report == 'desk'
                and self.guard_present and not self.guard_busy and not self.guard_closed):
            return False
        self.report, self.guard = 'received', 'received'
        return True

    def approach_guard(self, target_found=True):
        if not self.active() or self.guard != 'received':
            return False
        if not target_found:
            self.guard, self.guard_closed = 'ended', True
            return False
        self.guard = 'approach'
        return True

    def grip_guard(self, actual=True):
        if not (self.active() and self.guard == 'approach' and not self.guard_closed and self.holder is None):
            return False
        if not actual:
            self.guard, self.guard_closed = 'ended', True
            return False
        self.guard, self.holder, self.guard_ms = 'dragging', 'guard', 0
        self.bandaging = False
        self.guard_damage_count += 1
        self._damage(hp=5, sp=10)
        return True

    def release_guard(self):
        if not self.active() or self.guard != 'dragging':
            return False
        self.guard, self.guard_closed = 'ended', True
        if self.holder == 'guard':
            self.holder = None
        return True

    def start_bandage(self, contact=True, cooperating=True, sleeping=False):
        if not (self.active() and self.nurse_alive and self.nurse_present and contact
                and cooperating and not sleeping and self.hp < 100 and not self.healed
                and self.holder is None):
            return False
        self.bandaging = True
        return True

    def interrupt_bandage(self, nurse_dies=False):
        if not self.active():
            return False
        self.bandaging = False
        if nurse_dies:
            self.nurse_alive = False
        return True

    def tick(self, ms, damage=0, contact=True, route=True):
        assert ms >= 0 and damage >= 0
        if not self.active():
            return
        # Same-node damage resolves before a potential completed treatment.
        if damage:
            self._damage(hp=damage)
            self.bandaging = False
        if self.dead:
            return
        self.drug_stop = max(0, self.drug_stop-ms)
        self.empty_stop = max(0, self.empty_stop-ms)
        if self.cup == 'raising':
            self.cup_progress += ms
        if self.holder == 'doctor':
            remain = max(0, 4000-self.hold_ms)
            elapsed = min(ms, remain)
            self.hold_ms += elapsed
            if self.exam == 'sampling':
                self.sample_ms += elapsed
                if self.sample_ms >= 2000:
                    self.sample_valid = True
                    self.events.append('sample')
                    self.end_exam()
            if self.holder == 'doctor' and self.hold_ms >= 4000:
                self.end_exam()
        if self.holder == 'guard':
            self.guard_ms += ms
            if not route or self.guard_ms >= 6000:
                self.release_guard()
        if self.bandaging:
            if not contact or not self.nurse_alive or not self.nurse_present:
                self.bandaging = False
            else:
                self.bandage_ms += ms
                if self.bandage_ms >= 3000:
                    self.hp = min(100, self.hp+10)
                    self.healed, self.bandaging = True, False
                    self.healing_count += 1
                    self.events.append('healed')

    def route_decision(self, key=False, exhausted=False):
        if self.dead:
            return 'dead'
        if self.holder is not None or self.drug_stop or self.empty_stop:
            return 'wait_effect'
        if key:
            return 'exit'
        return 'bed' if self.sp < 50 or exhausted else 'search'

    def new_attempt(self):
        # Called only by caller's real rest/revival commit, not room re-entry.
        nxt = Hospital(episode=self.episode+1, drug_history=self.drug_history,
                       false_label_known=self.false_label_known)
        self.__dict__.update(nxt.__dict__)
