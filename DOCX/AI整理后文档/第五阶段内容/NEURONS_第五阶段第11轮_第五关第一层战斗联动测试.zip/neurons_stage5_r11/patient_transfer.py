"""S3:F2 actual push-bed transport. S3:P824-843/T26, P974; S4:P181-186.
No pathfinding or automatic transport: contact, visibility and arrival are inputs.
"""
from copy import deepcopy

ROUTE=('double','corridor','quiet')
PATIENT='s3_transfer_patient'

class PatientTransfer:
    def __init__(self,attempt=1):
        self.attempt=attempt;self.paused=self.dead=False;self.tokens=set()
        self.spawned=False;self.patient_id=PATIENT;self.order_id=None
        self.order_subject=self.band_subject=self.bed_subject=PATIENT
        self.signed=False;self.order_taken=False;self.verified=False
        self.positions={'patient':None,'bed':None,'porter':None};self.avatar_room=None
        self.brake_on=True;self.hand_out=False;self.interrupted=False
        self.delivered=False;self.band_owner='patient';self.band_room=None
        self.facts=[];self.knowledge=set();self.read_ids={};self.history=[]
        self.hp_effect=self.sp_effect=self.resource_effect=0

    def node(self,token,actual=True):
        if not actual or self.paused or self.dead or token[0]!=self.attempt or token in self.tokens:return False
        self.tokens.add(token);return True

    def fact(self,kind,**extra):
        self.facts.append({'attempt':self.attempt,'kind':kind,'patient':self.patient_id,
                           'room':self.positions['patient'],**extra})

    def spawn(self,token,order_id,subject=PATIENT,band_subject=PATIENT,bed_subject=PATIENT,signed=True,actual=True):
        if not self.node(token,actual) or self.spawned or not signed or subject!=PATIENT or band_subject!=subject or bed_subject!=subject:return False
        self.spawned=True;self.order_id=order_id;self.signed=True
        self.order_subject=subject;self.band_subject=band_subject;self.bed_subject=bed_subject
        self.positions=dict.fromkeys(('patient','bed','porter'),'double')
        self.history.append(('spawn',self.attempt,order_id))
        # Initial paperwork is not eyewitness knowledge.
        return True

    def take_order(self,token,actual=True):
        if not self.node(token,actual) or not self.spawned or not self.positions['porter'] or self.order_taken:return False
        self.order_taken=True;return True

    def verify(self,token,actual=True):
        if not self.node(token,actual) or not self.order_taken or self.verified:return False
        p=self.positions
        if not p['porter'] or len(set(p.values()))!=1 or self.band_owner!='patient':return False
        if not self.order_subject==self.band_subject==self.bed_subject==self.patient_id:return False
        self.verified=True;self.fact('ids_verified');return True

    def release_brake(self,token,actual=True):
        if not self.node(token,actual) or not self.verified or self.delivered or not self.brake_on:return False
        if self.positions['porter']!=self.positions['bed']:return False
        self.brake_on=False;self.fact('brake_released');return True

    def grab_rail(self,token,actual=True):
        if not self.node(token,actual) or not self.spawned or self.hand_out or self.delivered:return False
        self.hand_out=True;self.fact('hand_grab');return True

    def return_hand(self,token,actual=True):
        if not self.node(token,actual) or not self.hand_out or self.positions['porter']!=self.positions['patient']:return False
        self.hand_out=False;self.fact('hand_return');return True

    def detach_band(self,token,actual=True):
        if not self.node(token,actual) or not self.spawned or self.band_owner!='patient':return False
        self.band_owner='floor';self.band_room=self.positions['patient'];self.fact('band_dropped');return True

    def move(self,token,dest,actual=True,route_clear=True,space=True):
        if not self.node(token,actual) or not self.spawned or not self.verified or self.brake_on or self.hand_out or self.interrupted or self.delivered:return False
        p=self.positions['bed']
        if not route_clear or not space or self.positions['porter']!=p or self.positions['patient']!=p:return False
        if p not in ROUTE[:-1] or dest!=ROUTE[ROUTE.index(p)+1]:return False
        self.positions=dict.fromkeys(('patient','bed','porter'),dest)
        self.fact('transport_step');return True

    def park(self,token,actual=True):
        if not self.node(token,actual) or self.delivered or self.positions['bed']!='quiet' or self.positions['porter']!='quiet' or self.positions['patient']!='quiet':return False
        self.brake_on=True;self.delivered=True;self.fact('delivered');return True

    def interrupt(self,token,actual=True):
        if not self.node(token,actual) or not self.spawned or self.delivered:return False
        self.interrupted=True;return True

    def resume(self,token,actual=True):
        if not self.node(token,actual) or not self.interrupted or self.positions['porter']!=self.positions['bed']:return False
        self.interrupted=False;return True

    def observe(self,token,kind,actual=True,visible=True):
        if not self.node(token,actual) or not visible or self.avatar_room!=self.positions['patient']:return False
        if kind=='alive' and self.hand_out:self.knowledge.add((self.patient_id,'alive'));return True
        if kind=='delivered' and self.delivered:self.knowledge.add((self.patient_id,'delivered'));return True
        return False

    def read(self,token,item,actual=True,visible=True,readable=True):
        if not self.node(token,actual) or not visible or not readable:return False
        if item=='order':
            if not self.signed or self.avatar_room!=self.positions['porter']:return False
            subject=self.order_subject
        elif item=='band':
            loc=self.positions['patient'] if self.band_owner=='patient' else self.positions['porter'] if self.band_owner=='porter' else self.band_room
            if self.band_owner!='avatar' and (loc is None or self.avatar_room!=loc):return False
            subject=self.band_subject
        else:return False
        self.read_ids[item]=subject;self.knowledge.add((subject,'read_'+item));return True

    def pickup(self,token,actor='avatar',actual=True,visible=True,reachable=True):
        if not self.node(token,actual) or not visible or not reachable or self.band_owner not in ('floor','porter') or actor not in ('avatar','porter'):return False
        if self.band_owner=='porter':return False # no invented stealing mechanic
        loc=self.avatar_room if actor=='avatar' else self.positions['porter']
        if loc is None or loc!=self.band_room:return False
        self.band_owner=actor;return True

    def linked(self):return self.read_ids.get('order')==self.patient_id and self.read_ids.get('band')==self.patient_id

    def new_attempt(self,attempt):
        if attempt<=self.attempt:return False
        history=self.history+[('attempt_ended',self.attempt)];facts=self.facts;knowledge=self.knowledge;read_ids=self.read_ids
        owned_band=self.band_owner=='avatar'
        self.__init__(attempt);self.history=history;self.facts=facts;self.knowledge=knowledge;self.read_ids=read_ids
        if owned_band:self.band_owner='avatar' # S2:T3R2: no deletion or second world copy
        return True

    def reload(self):return deepcopy(self)
