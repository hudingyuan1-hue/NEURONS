"""Directed S5 first-floor identities + 225 stateful event sequences."""
from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s5_people import People5, Token, ROOMS, ROSTER, FRIEND_TEXT


def spawn(p, actor):
    home = p.entities[actor].home
    p.sync_context(avatar_room=home)
    assert p.check_spawn(p.token(f'check-{actor}'), actor, 0, first=True)
    p.tick(10000)
    assert actor in p.enter_pending(p.token(f'enter-{actor}'), home)
    return p.entities[actor]


def parents():
    p = People5()
    spawn(p, 'father')
    spawn(p, 'mother')
    p.move(p.token('chase'), 'father', 'decision')
    return p


@pytest.mark.parametrize('actor,hp,side,home', [
    ('dog',60,'friendly','atrium'), ('father',80,'hostile','atrium'),
    ('nurse',40,'friendly','memory'),('archivist',60,'hostile','memory'),
    ('corner',40,'friendly','visual'),('orderly',60,'hostile','visual'),
    ('mother',80,'hostile','decision'),('cat',30,'hostile','decision'),
    ('doctor',60,'hostile','body'),('assistant',60,'hostile','body')])
def test_exact_canonical_identity_and_combat_body(actor,hp,side,home):
    p = People5()
    e = p.entities[actor]
    assert len(p.entities) == 10
    assert (e.hp,e.max_hp,e.alignment,e.home) == (hp,hp,side,home)
    assert not e.present
    assert sum(v.alignment == 'friendly' for v in p.entities.values()) == 3


@pytest.mark.parametrize('attempt,roll,expected', [
    (1,5499,True),(1,5500,False),(2,5999,True),(2,6000,False),
    (5,7499,True),(5,7500,False),(99,7499,True),(99,7500,False)])
def test_first_spawn_probability_boundary(attempt,roll,expected):
    p=People5(attempt=attempt)
    assert p.check_spawn(p.token('initial'), 'father', roll, first=True)
    assert (p.entities['father'].spawn.state == 'pending') is expected


def test_revisit_requires_runtime_twenty_seconds_and_half_probability():
    p=People5()
    p.check_spawn(p.token('1'),'father',9999,first=True)
    p.sync_context(avatar_room='memory')
    p.tick(19999)
    p.sync_context(paused=True)
    p.tick(50000)
    p.sync_context(paused=False)
    p.tick(1)
    p.sync_context(avatar_room='atrium')
    assert p.check_spawn(p.token('2'),'father',2750)
    assert p.entities['father'].spawn.state == 'unseen'
    p.sync_context(avatar_room='body')
    p.tick(20000)
    p.sync_context(avatar_room='atrium')
    assert p.check_spawn(p.token('3'),'father',2749)
    assert p.entities['father'].spawn.state == 'pending'
    assert p.entities['father'].spawn.checks == 3


def test_no_fourth_check_after_three_misses():
    p=People5()
    for i in range(4):
        if i:
            p.sync_context(avatar_room='memory');p.tick(20000)
            p.sync_context(avatar_room='atrium')
        assert p.check_spawn(p.token(str(i)),'father',9999,first=i==0) == (i<3)
    assert p.entities['father'].spawn.checks == 3


def test_invalid_early_revisit_consumes_no_probability_check():
    p=People5()
    p.check_spawn(p.token('one'),'dog',9999,first=True)
    p.sync_context(avatar_room='memory');p.tick(19999)
    p.sync_context(avatar_room='atrium')
    assert not p.check_spawn(p.token('tooearly'),'dog',0)
    assert p.entities['dog'].spawn.checks == 1


@pytest.mark.parametrize('blocking', ['paused','dead','loading'])
def test_nonruntime_does_not_advance_outside_or_batches(blocking):
    p=People5();p.sync_context(avatar_room='body')
    p.sync_context(**{blocking:True})
    p.tick(99999)
    assert p.time_ms == p.entities['dog'].spawn.outside == 0


def test_waiting_entry_does_not_reroll_or_spawn_at_occupied_door():
    p=People5()
    assert p.check_spawn(p.token('roll'),'father',0,first=True)
    assert not p.enter_pending(p.token('blocked'),'atrium',entry_free=False)
    assert not p.entities['father'].present
    assert not p.check_spawn(p.token('again'),'father',9999,first=True)
    assert p.entities['father'].spawn.checks == 1
    assert p.enter_pending(p.token('free'),'atrium') == ('father',)
    assert not p.enter_pending(p.token('again2'),'atrium')


def test_room_batches_ten_seconds_exact_boundary():
    p=People5()
    p.check_spawn(p.token('father'),'father',0,first=True)
    p.enter_pending(p.token('first'),'atrium')
    p.check_spawn(p.token('dog'),'dog',0,first=True)
    p.tick(9999)
    assert not p.enter_pending(p.token('early'),'atrium')
    p.tick(1)
    assert p.enter_pending(p.token('ontime'),'atrium') == ('dog',)


def test_same_batch_can_contain_two_independent_identities():
    p=People5()
    for a in ('dog','father'):
        p.check_spawn(p.token(a),a,0,first=True)
    assert p.enter_pending(p.token('batch'),'atrium') == ('dog','father')


def test_pending_spawn_not_delivered_to_absent_avatar_room():
    p=People5();p.check_spawn(p.token('roll'),'father',0,first=True)
    p.sync_context(avatar_room='memory')
    assert not p.enter_pending(p.token('batch'),'atrium')
    assert not p.entities['father'].present


@pytest.mark.parametrize('origin,destination,expected', [
    ('atrium','body',True),('body','bridge',False),
    ('memory','visual',True),('visual','decision',False),
    ('decision','bridge',True),('bridge','decision',True)])
def test_physical_connections_only(origin,destination,expected):
    p=People5();e=spawn(p,'father');e.room=origin
    assert p.move(p.token('move'),'father',destination) is expected
    assert e.room == (destination if expected else origin)


def test_existing_character_entry_not_subject_to_ten_second_batch_limit():
    p=People5();spawn(p,'father')
    assert p.move(p.token('move'),'father','memory')
    assert p.entities['father'].room == 'memory'
    assert not p.entities['father'].spawn.away


def test_assistant_and_bed_cannot_split_at_narrow_door():
    p=People5();e=spawn(p,'assistant')
    assert not p.move(p.token('tight'),'assistant','atrium',bed_passable=False)
    assert e.room == e.bed_room == 'body'
    assert p.move(p.token('fit'),'assistant','atrium',bed_passable=True)
    assert e.room == e.bed_room == 'atrium'


def test_no_tracking_avatar_through_wall_or_other_room():
    p=People5();e=spawn(p,'father')
    assert p.observe(p.token('saw'),'father',(2,3))
    assert e.last_seen == ('atrium',(2,3))
    p.sync_context(avatar_room='memory')
    assert not p.observe(p.token('unseen'),'father',(8,8))
    assert e.last_seen == ('atrium',(2,3)) and not e.sees_avatar
    p.move(p.token('follow'),'father','memory')
    assert not p.observe(p.token('wall'),'father',(9,9),actual_visible=False)
    assert e.last_seen == ('atrium',(2,3))


def test_last_seen_value_cannot_mutate_through_caller_reference():
    p=People5();e=spawn(p,'father');pos=[2,3]
    p.observe(p.token('seen'),'father',pos);pos[0]=99
    assert e.last_seen == ('atrium',[2,3])


def test_actual_parent_meeting_changes_only_next_target_and_has_no_old_event():
    p=parents()
    assert p.meet_parents(p.token('meeting'))
    assert p.entities['father'].target == 'mother'
    assert p.entities['mother'].target == 'father'
    assert p.resources == (0,0) and p.awakening == p.street_boost == 0
    assert all(e.hp == 80 for a,e in p.entities.items() if a in ('father','mother'))
    assert not p.meet_parents(p.token('meeting'))


@pytest.mark.parametrize('same_room,visible',[(False,True),(True,False)])
def test_simultaneous_existence_is_not_parent_meeting(same_room,visible):
    p=parents()
    if not same_room:p.entities['father'].room='atrium'
    assert not p.meet_parents(p.token('meeting'),mutual_visible=visible)
    assert p.entities['mother'].target is None


def test_parent_target_survives_avatar_observation_then_clears_on_actual_death():
    p=parents();p.meet_parents(p.token('meeting'))
    p.observe(p.token('avatar'),'father',(1,2))
    assert p.entities['father'].target == 'mother'
    p.damage(p.token('hit'),'mother',80,source='father')
    assert p.entities['father'].target is None
    p.observe(p.token('sawagain'),'father',(3,4))
    assert p.entities['father'].target == 'avatar'


def test_actual_hits_once_per_target_keep_no_rewards_and_no_friendly_retaliation():
    p=People5();e=spawn(p,'nurse')
    r=p.damage(p.token('one'),'nurse',10,source='player')
    assert r['hp_loss'] == 10 and e.hp==30 and e.target is None
    assert p.damage(p.token('one'),'nurse',10,source='player') is None
    assert e.hp==30 and p.resources==(0,0)


@pytest.mark.parametrize('actual,father_present,same_room,killed',[
    (False,True,True,False),(True,False,True,False),
    (True,True,False,False),(True,True,True,True)])
def test_dog_only_shatters_on_fathers_actual_hit(actual,father_present,same_room,killed):
    p=People5();e=spawn(p,'dog')
    if father_present:spawn(p,'father')
    if not same_room:p.entities['father'].room='memory'
    p.damage(p.token('hit'),'dog',1,source='father',actual=actual)
    assert (not e.alive) is killed
    assert e.hp == (0 if killed else 60)
    assert p.awakening==p.street_boost==0 and p.resources==(0,0)


def test_ordinary_hit_needs_actual_hp_exhaustion_and_death_is_not_auto_revival():
    p=People5();e=spawn(p,'dog')
    p.damage(p.token('one'),'dog',59,source='player')
    assert e.alive and e.hp==1
    p.damage(p.token('two'),'dog',1,source='player')
    p.sync_context(avatar_room='memory');p.tick(20000)
    p.sync_context(avatar_room='atrium')
    assert not p.check_spawn(p.token('reroll'),'dog',0)
    assert not p.enter_pending(p.token('reenter'),'atrium')
    assert not e.alive and e.spawn.state=='retired'


def test_ordinary_retirement_is_not_death_or_room_revival():
    p=People5();e=spawn(p,'corner')
    assert p.retire(p.token('leave'),'corner')
    assert e.hp==40 and e.alive and not e.present
    assert not p.friend_dialogue(p.token('queued'),'corner')
    assert not p.history


@pytest.mark.parametrize('actor',['dog','nurse','corner'])
def test_friend_original_dialogue_safe_once_and_persists_room_reload(actor):
    p=People5();spawn(p,actor);p.sync_context(chased=True)
    assert p.friend_dialogue(p.token('unsafe'),actor) is None
    p.sync_context(chased=False)
    assert p.friend_dialogue(p.token('safe'),actor) == FRIEND_TEXT[actor]
    p=People5.restore(p.snapshot())
    assert p.friend_dialogue(p.token('duplicate'),actor) is None


def test_new_life_resets_bodies_not_historical_record_or_previous_identity():
    p=People5();spawn(p,'dog');spawn(p,'father')
    p.prior_seen.add('S1_dog');p.s1_dog_died=True
    p.damage(p.token('killed'),'dog',1,source='father')
    assert p.dog_repeated_death_feedback(witnessed=True)
    old=p.token('old')
    p.sync_context(attempt=2,epoch=9,dead=False,avatar_room='atrium')
    assert p.entities['dog'].hp==60 and p.entities['dog'].alive
    assert not p.entities['dog'].present and p.entities['dog'].spawn.k==2
    assert len(p.history)==1 and p.s1_dog_died and 'S1_dog' in p.prior_seen
    assert not p.dog_repeated_death_feedback(witnessed=True)
    assert not p.check_spawn(old,'dog',0,first=True)


def test_dog_death_without_history_cannot_create_again_memory():
    p=People5();spawn(p,'dog');spawn(p,'father')
    p.damage(p.token('kill'),'dog',1,source='father')
    assert not p.dog_repeated_death_feedback(witnessed=True)
    p.s1_dog_died=True
    assert not p.dog_repeated_death_feedback(witnessed=False)


def test_npc_seeing_avatar_cannot_create_avatar_recognition():
    p=People5();spawn(p,'corner');p.prior_seen.add('S3_corner_patient')
    p.observe(p.token('npc_saw_avatar'),'corner',(0,0))
    assert not p.recognizes_previous_identity('corner')


@pytest.mark.parametrize('previous,visible,expected', [
    (False,True,False),(True,False,False),(True,True,True)])
def test_actual_avatar_witness_plus_previous_history_required(previous,visible,expected):
    p=People5();spawn(p,'corner')
    if previous:p.prior_seen.add('S3_corner_patient')
    p.witness_actor(p.token('see'),'corner',actual_visible=visible)
    assert p.recognizes_previous_identity('corner') is expected


def test_simultaneous_parent_impacts_are_not_lost_when_first_parent_dies():
    p=parents();p.meet_parents(p.token('meeting'))
    result=p.apply_hits(p.token('frame'),[
        {'actor':'mother','amount':80,'source':'father'},
        {'actor':'father','amount':80,'source':'mother'}])
    assert len(result)==2 and all(r['killed'] for r in result)
    assert p.entities['father'].hp==p.entities['mother'].hp==0
    assert not p.apply_hits(p.token('frame'),[
        {'actor':'mother','amount':80,'source':'father'},
        {'actor':'father','amount':80,'source':'mother'}])


def test_batch_rejects_already_dead_or_remote_source_before_frame():
    p=parents()
    p.damage(p.token('prior'),'mother',80,source='father')
    assert not p.apply_hits(p.token('frame'),[
        {'actor':'father','amount':80,'source':'mother'}])
    assert p.entities['father'].hp==80


def test_batch_deduplicates_same_attack_but_preserves_distinct_attacks():
    p=People5();spawn(p,'nurse')
    result=p.apply_hits(p.token('frame'),[
        {'actor':'nurse','amount':10,'source':'player','event_id':'attack1'},
        {'actor':'nurse','amount':10,'source':'player','event_id':'attack1'},
        {'actor':'nurse','amount':10,'source':'player','event_id':'attack2'}])
    assert len(result)==2 and p.entities['nurse'].hp==20


def test_room_epoch_change_preserves_body_and_invalidates_stale_callback():
    p=People5(epoch=7);e=spawn(p,'father')
    old=p.token('old')
    p.damage(p.token('scratch'),'father',10,source='player')
    p.sync_context(epoch=8)
    assert e.hp==70 and e.present
    assert p.damage(old,'father',70,source='player') is None
    assert p.damage(p.token('new'),'father',1,source='player')['hp_loss']==1


def test_return_snapshot_does_not_reroll_or_regenerate_bodies():
    p=People5();spawn(p,'father')
    p.damage(p.token('scratch'),'father',20,source='player')
    p.tick(18000)
    loaded=People5.restore(p.snapshot())
    assert loaded==p and loaded is not p
    loaded.sync_context(attempt=1,epoch=4,avatar_room='decision')
    assert loaded.entities['father'].hp==60
    assert loaded.entities['father'].spawn.checks==1
    assert loaded.time_ms==28000


class PeopleMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.p=People5();self.n=0;self.retired=set()

    def tok(self):
        self.n+=1;return self.p.token(str(self.n))

    @rule(room=st.sampled_from(ROOMS+('bridge',)))
    def avatar_move(self,room):
        self.p.sync_context(avatar_room=room)

    @rule(actor=st.sampled_from(tuple(ROSTER)),roll=st.integers(0,9999))
    def roll_spawn(self,actor,roll):
        e=self.p.entities[actor]
        self.p.check_spawn(self.tok(),actor,roll,first=e.spawn.checks==0)
        self.p.enter_pending(self.tok(),self.p.avatar_room)

    @rule(ms=st.sampled_from([0,1,799,1000,9999,10000,19999,20000]))
    def clock(self,ms):
        self.p.tick(ms)

    @rule(actor=st.sampled_from(tuple(ROSTER)),room=st.sampled_from(ROOMS+('bridge',)),
          passable=st.booleans(),bed_passable=st.booleans())
    def npc_move(self,actor,room,passable,bed_passable):
        self.p.move(self.tok(),actor,room,passable=passable,bed_passable=bed_passable)

    @rule(actor=st.sampled_from(tuple(ROSTER)),amount=st.integers(0,100),actual=st.booleans())
    def hit(self,actor,amount,actual):
        self.p.damage(self.tok(),actor,amount,source='player',actual=actual)
        if self.p.entities[actor].spawn.state=='retired':self.retired.add(actor)

    @rule(actor=st.sampled_from(tuple(ROSTER)),visible=st.booleans())
    def observe(self,actor,visible):
        self.p.observe(self.tok(),actor,(self.n,self.n),actual_visible=visible)

    @rule(actor=st.sampled_from(tuple(FRIEND_TEXT)))
    def say(self,actor):
        self.p.friend_dialogue(self.tok(),actor)

    @rule(paused=st.booleans(),chased=st.booleans())
    def flags(self,paused,chased):
        self.p.sync_context(paused=paused,chased=chased)

    @rule()
    def meeting(self):
        self.p.meet_parents(self.tok())

    @rule()
    def reload(self):
        self.p=People5.restore(self.p.snapshot())

    @rule()
    def new_attempt(self):
        self.p.sync_context(attempt=self.p.attempt+1,epoch=self.p.epoch+1,
                            avatar_room='atrium',paused=False,dead=False)
        self.retired.clear()

    @invariant()
    def objective_invariants(self):
        assert len(self.p.entities)==10
        assert self.p.resources==(0,0) and self.p.awakening==self.p.street_boost==0
        for a,e in self.p.entities.items():
            assert 0<=e.hp<=e.max_hp and 0<=e.spawn.checks<=3
            assert not e.present or e.alive
            assert e.alive or e.hp==0
            if a in self.retired:assert not e.present
            if a=='assistant' and e.present:assert e.room==e.bed_room


TestPeopleMachine=PeopleMachine.TestCase
TestPeopleMachine.settings=settings(max_examples=225,stateful_step_count=70,
                                    deadline=None,database=None)
