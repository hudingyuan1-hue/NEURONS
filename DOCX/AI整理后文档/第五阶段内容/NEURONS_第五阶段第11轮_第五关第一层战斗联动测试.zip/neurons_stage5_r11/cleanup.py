"""S3 washroom cleaner: actual physical work, owned relics and acquired knowledge.

Source: S3 P17-34, P950-969/T32; S4 P185-186, P206-207.
Position/visibility/reachability are actual facts supplied by the world adapter.
No life, sanity, search, currency, awakening or key effects are emitted.
"""
from dataclasses import dataclass, field
from copy import deepcopy


@dataclass
class Cleanup:
    attempt: int = 1
    deceased_id: str = 'deceased-wash-01'
    living_ids: frozenset = frozenset({'cross_level_patient', 'corner_patient', 'bed_patient'})
    avatar_location: str | None = 'wash'
    cleaner_location: str | None = 'wash'
    bucket_location: str = 'wash'
    body_location: str = 'wash'
    board_location: str = 'wash'
    body_covered: bool = False
    body_on_board: bool = False
    curtain_closed: bool = False
    interrupted: bool = False
    paused: bool = False
    avatar_blocked: bool = False
    active: bool = True
    items: dict = field(default_factory=lambda: {'band': 'wash', 'meal': 'wash'})
    item_ids: dict = field(default_factory=dict)
    meal_unfolded: bool = False
    traces: dict = field(default_factory=lambda: {'shower': True, 'drain': True, 'floor': True})
    reads: dict = field(default_factory=dict)
    knowledge: set = field(default_factory=set)
    seen: set = field(default_factory=set)
    history: list = field(default_factory=list)

    def __post_init__(self):
        if self.deceased_id in self.living_ids:
            raise ValueError('dead patient must have a separate identity')
        if not self.item_ids:
            self.item_ids = {item: self.deceased_id for item in ('anklet', 'band', 'meal')}
        if set(self.item_ids) != {'anklet', 'band', 'meal'} or any(
                subject != self.deceased_id for subject in self.item_ids.values()):
            raise ValueError('corpse and three identifiers must refer to the same deceased patient')

    def _node(self, token):
        if not self.active or self.paused or token[0] != self.attempt or token in self.seen:
            return False
        self.seen.add(token)
        return True

    def _npc(self, token, room=None):
        return (self._node(token) and not self.interrupted
                and self.cleaner_location is not None
                and (room is None or self.cleaner_location == room))

    def _avatar(self, token):
        return self._node(token) and not self.avatar_blocked and self.avatar_location is not None

    def notice(self, token, *, actual=True, visible=True):
        if not self._npc(token, 'wash') or not actual or not visible or self.avatar_location != 'wash':
            return False
        if self.body_location != 'wash' or self.curtain_closed:
            return False
        self.curtain_closed = True
        self.history.append(('curtain', self.attempt))
        return True

    def cover(self, token, *, actual=True, reachable=True):
        if (not self._npc(token, self.body_location) or not actual or not reachable
                or self.body_covered):
            return False
        self.body_covered = True
        self.history.append(('covered', self.attempt))
        return True

    def load_board(self, token, *, actual=True, reachable=True, space_clear=True):
        if (not self._npc(token, self.body_location) or not actual or not reachable or not space_clear
                or not self.body_covered or self.body_on_board or self.board_location != self.body_location):
            return False
        self.body_on_board = True
        self.history.append(('loaded', self.attempt))
        return True

    def move_body(self, token, dest, *, actual=True, route_clear=True):
        if (not self._npc(token, self.body_location) or not actual or not route_clear
                or not self.body_on_board or self.body_location != 'wash' or dest != 'corridor'):
            return False
        self.body_location = self.board_location = self.cleaner_location = dest
        self.history.append(('body_at', dest, self.attempt))
        return True

    def move_cleaner(self, token, dest, *, actual=True, route_clear=True):
        if (not self._npc(token) or not actual or not route_clear
                or {self.cleaner_location, dest} != {'wash', 'corridor'}):
            return False
        self.cleaner_location = dest
        return True

    def collect(self, token, item, *, actual=True, reachable=True):
        if not self._npc(token) or not actual or not reachable or item not in self.items:
            return False
        if self.items[item] != self.cleaner_location or self.bucket_location != self.cleaner_location:
            return False
        self.items[item] = 'bucket'
        self.history.append(('collected', item, self.attempt))
        return True

    def clean(self, token, region, *, actual=True, reachable=True):
        if (not self._npc(token, 'wash') or not actual or not reachable
                or region not in self.traces or not self.traces[region]):
            return False
        self.traces[region] = False
        self.history.append(('cleaned', region, self.attempt))
        return True

    def _visible_item(self, item, visible):
        if not visible:
            return False
        if item == 'anklet':
            return (self.avatar_location == self.body_location and not self.body_covered
                    and not (self.body_location == 'wash' and self.curtain_closed))
        owner = self.items.get(item)
        if owner == 'avatar':
            return True
        if owner == 'bucket':
            return self.avatar_location == self.bucket_location
        return owner is not None and owner == self.avatar_location

    def observe_body(self, token, *, actual=True, visible=True):
        if (not self._avatar(token) or not actual or not visible
                or self.avatar_location != self.body_location or self.body_covered
                or (self.body_location == 'wash' and self.curtain_closed)):
            return False
        self.knowledge.add('saw_body')
        return True

    def unfold_meal(self, token, *, actual=True, visible=True, reachable=True):
        if (not self._avatar(token) or not actual or not reachable
                or not self._visible_item('meal', visible)):
            return False
        self.meal_unfolded = True
        return True

    def read_item(self, token, item, *, actual=True, visible=True, legible=True, reachable=True):
        if (not self._avatar(token) or not actual or not legible or item not in self.item_ids
                or not self._visible_item(item, visible)):
            return False
        if self.items.get(item) == 'bucket' and not reachable:
            return False
        if item == 'meal' and not self.meal_unfolded:
            return False
        self.reads[item] = self.item_ids[item]
        self.knowledge.add(('read', item, self.item_ids[item]))
        return True

    def take_item(self, token, item, *, actual=True, visible=True, reachable=True):
        if (not self._avatar(token) or not actual or not reachable or item not in self.items
                or self.items[item] == 'avatar' or not self._visible_item(item, visible)):
            return False
        self.items[item] = 'avatar'
        self.history.append(('taken', item, self.attempt))
        return True

    @property
    def matched_identity(self):
        # Matching two legible identifiers does not establish that a meal recipient is alive.
        return self.deceased_id if len(self.reads) >= 2 and set(self.reads.values()) == {self.deceased_id} else None

    def interrupt(self, token, *, actual=True):
        if not self._node(token) or not actual:
            return False
        self.interrupted = True
        return True

    def resume(self, token, *, actual=True):
        if not self._node(token) or not actual or self.cleaner_location is None:
            return False
        self.interrupted = False
        return True

    def depart(self):
        self.active = False

    def new_attempt(self, attempt):
        if attempt <= self.attempt:
            return False
        # Per-attempt physical scene resets; learned facts survive. No resource reward.
        fresh = Cleanup(attempt=attempt, deceased_id=self.deceased_id, living_ids=self.living_ids)
        fresh.reads = deepcopy(self.reads)
        fresh.knowledge = deepcopy(self.knowledge)
        fresh.history = deepcopy(self.history)
        for item, owner in self.items.items():
            if owner == 'avatar':
                fresh.items[item] = 'avatar'
        fresh.meal_unfolded = self.meal_unfolded and fresh.items['meal'] == 'avatar'
        self.__dict__.update(fresh.__dict__)
        return True

    def reload(self):
        return deepcopy(self)
