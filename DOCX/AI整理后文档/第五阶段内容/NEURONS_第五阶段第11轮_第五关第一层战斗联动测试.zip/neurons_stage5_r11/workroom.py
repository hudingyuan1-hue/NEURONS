"""S3F2 work room. Canon: S3 P1014-1054/T33; S4 T15R8.

Actual positions, visibility, hand position and body availability are supplied by
an adapter. Effects are emitted once and applied to the authoritative Life by it.
No key, search reward, inventory confiscation or patient identity inference.
"""
from copy import deepcopy
from dataclasses import dataclass, field


@dataclass
class Workroom:
    attempt: int = 1
    epoch: int = 0
    paper_count: int = 3
    label_count: int = 3
    batch: str = 'fixture-batch-01'
    positions: dict = field(default_factory=lambda: {'avatar': 'work', 'supervisor': 'work', 'worker': 'work'})
    paused: bool = False
    dead: bool = False
    active: bool = True
    avatar_blocked: bool = False
    hand_in_drawer: bool = False
    stage: str = 'idle'
    attempt_used: bool = False
    clamp_remaining_ms: int = 0
    supervisor_interrupted: bool = False
    worker_interrupted: bool = False
    worker_phase: str = 'idle'
    current_box: dict | None = None
    boxes: list = field(default_factory=list)
    avatar_materials: dict = field(default_factory=lambda: {'paper': 0, 'label': 0})
    board_steady: bool = False
    board_back_visible: bool = False
    knowledge: set = field(default_factory=set)
    cold_batches: set = field(default_factory=set)
    effects: list = field(default_factory=list)
    history: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    serial: int = 0

    def __post_init__(self):
        if self.paper_count < 0 or self.label_count < 0:
            raise ValueError('material counts cannot be negative')
        self.initial_paper = self.paper_count
        self.initial_labels = self.label_count

    def _node(self, token):
        if (not self.active or self.paused or self.dead or token[0] != self.attempt
                or token in self.seen):
            return False
        self.seen.add(token)
        return True

    def _actor(self, token, actor):
        return self._node(token) and self.positions.get(actor) == 'work'

    def _supervisor(self, token):
        return (self._actor(token, 'supervisor') and not self.supervisor_interrupted
                and self.positions.get('avatar') == 'work')

    def _avatar(self, token):
        return self._actor(token, 'avatar') and not self.avatar_blocked

    def sync_context(self, *, positions=None, paused=None, dead=None, epoch=None,
                     attempt=None, avatar_blocked=None):
        if attempt is not None and attempt > self.attempt:
            self.new_attempt(attempt, epoch=epoch)
        if epoch is not None and epoch != self.epoch:
            self.abort('epoch_changed')
            self.active = False
            self.epoch = epoch
        if positions is not None:
            self.positions.update(positions)
        if paused is not None:
            self.paused = paused
        if dead is not None:
            self.dead = dead
        if avatar_blocked is not None:
            self.avatar_blocked = avatar_blocked
        if self.dead or self.positions.get('avatar') != 'work' or self.positions.get('supervisor') != 'work':
            self.abort('death' if self.dead else 'left_room')
        if self.positions.get('avatar') != 'work':
            self.hand_in_drawer = False
            self.board_steady = self.board_back_visible = False

    def set_hand(self, token, inside, *, actual=True, drawer='material_unlocked'):
        if not self._avatar(token) or not actual or drawer != 'material_unlocked':
            return False
        if self.stage == 'clamped':
            return False
        self.hand_in_drawer = bool(inside)
        return True

    def notice(self, token, *, visible=True, actual=True, drawer='material_unlocked'):
        if (not self._supervisor(token) or not actual or not visible
                or drawer != 'material_unlocked' or not self.hand_in_drawer
                or self.attempt_used or self.stage != 'idle'):
            return False
        self.stage = 'approaching'
        self.history.append(('noticed', self.attempt))
        return True

    def reach(self, token, *, actual=True, reachable=True):
        if (not self._supervisor(token) or not actual or not reachable
                or self.stage != 'approaching'):
            return False
        self.stage = 'ready'
        return True

    def windup(self, token, *, actual=True, body_available=True):
        if (not self._supervisor(token) or not actual or not body_available
                or self.stage != 'ready' or self.attempt_used):
            return False
        self.stage = 'windup'
        self.attempt_used = True
        self.history.append(('attempted', self.attempt))
        return True

    def close(self, token, *, actual=True, body_available=True, contact=True):
        if (not self._supervisor(token) or not actual or self.stage != 'windup'):
            return False
        if self.hand_in_drawer and contact:
            self.stage = 'clamped' if body_available else 'reopening'
            self.clamp_remaining_ms = 1000
            self.effects.append({'id': (self.attempt, 'work_drawer'), 'hp': 10, 'sp': 0,
                                 'cancel_search': True, 'hold': body_available})
            self.history.append(('clamp_hit', self.attempt))
        else:
            self.stage = 'reopening'
            self.clamp_remaining_ms = 1000
            self.history.append(('clamp_missed', self.attempt))
        return True

    def release(self, token, *, actual=True):
        if (not self._node(token) or not actual or self.stage not in {'clamped', 'reopening'}):
            return False
        self._release('actual_release')
        return True

    def _release(self, reason):
        self.stage = 'finished'
        self.clamp_remaining_ms = 0
        self.hand_in_drawer = False
        self.history.append(('released', reason, self.attempt))

    def tick(self, milliseconds):
        if milliseconds < 0:
            raise ValueError('negative time')
        if self.paused or self.dead or not self.active:
            return
        if self.stage in {'clamped', 'reopening'}:
            self.clamp_remaining_ms = max(0, self.clamp_remaining_ms - milliseconds)
            if self.clamp_remaining_ms == 0:
                self._release('release_cap')

    def abort(self, reason='interrupted'):
        if self.stage in {'clamped', 'reopening'}:
            self._release(reason)
        elif self.stage in {'approaching', 'ready', 'windup'}:
            self.stage = 'finished' if self.attempt_used else 'idle'
            self.history.append(('aborted', reason, self.attempt))

    def interrupt_supervisor(self, token, *, actual=True):
        if not self._node(token) or not actual:
            return False
        self.supervisor_interrupted = True
        self.abort('supervisor_interrupted')
        return True

    def remove_material(self, token, kind, count=1, *, actual=True, reachable=True):
        if (not self._avatar(token) or not actual or not reachable
                or kind not in {'paper', 'label'} or count <= 0):
            return False
        attr = 'paper_count' if kind == 'paper' else 'label_count'
        if getattr(self, attr) < count:
            return False
        setattr(self, attr, getattr(self, attr) - count)
        self.avatar_materials[kind] += count
        self.history.append(('material_removed', kind, count, self.attempt))
        return True

    def labor_action(self, token, action, *, actual=True, table='table2', reachable=True):
        if (not self._actor(token, 'worker') or self.worker_interrupted or not actual
                or not reachable or table != 'table2'):
            return False
        if action == 'take_paper' and self.worker_phase == 'idle' and self.paper_count:
            self.paper_count -= 1
            self.serial += 1
            self.current_box = {'id': (self.attempt, self.serial), 'folded': False,
                                'flat': False, 'label_taken': False, 'batch': None}
            self.worker_phase = 'paper'
        elif action == 'fold' and self.worker_phase == 'paper':
            self.current_box['folded'] = True
            self.worker_phase = 'folded'
        elif action == 'flatten' and self.worker_phase == 'folded':
            self.current_box['flat'] = True
            self.worker_phase = 'flat'
        elif action == 'take_label' and self.worker_phase == 'flat' and self.label_count:
            self.label_count -= 1
            self.current_box['label_taken'] = True
            self.worker_phase = 'label'
        elif action == 'paste' and self.worker_phase == 'label':
            self.current_box['batch'] = self.batch
            self.worker_phase = 'labeled'
        elif action == 'place' and self.worker_phase == 'labeled':
            self.boxes.append(self.current_box)
            self.current_box = None
            self.worker_phase = 'idle'
        else:
            return False
        self.history.append(('labor', action, self.attempt))
        return True

    def interrupt_worker(self, token, *, actual=True):
        if not self._node(token) or not actual:
            return False
        self.worker_interrupted = True
        return True

    def resume_worker(self, token, *, actual=True):
        if not self._actor(token, 'worker') or not actual:
            return False
        self.worker_interrupted = False
        return True

    def steady_board(self, token, *, actual=True, reachable=True):
        if not self._avatar(token) or not actual or not reachable:
            return False
        self.board_steady = True
        return True

    def view_board(self, token, *, back=True, actual=True, visible=True, legible=True):
        if (not self._avatar(token) or not actual or not visible or not legible
                or not back or not self.board_steady):
            return False
        self.board_back_visible = True
        self.knowledge.add(('work_batch', self.batch))
        return True

    def observe_label(self, token, *, item='shelf_label', box_id=None,
                      actual=True, visible=True, legible=True):
        if not self._avatar(token) or not actual or not visible or not legible:
            return False
        if item == 'shelf_label':
            available = self.label_count > 0
        elif item == 'current_box':
            available = bool(self.current_box and self.current_box['batch'] is not None)
        elif item == 'box':
            available = any(box['id'] == box_id and box['batch'] is not None for box in self.boxes)
        else:
            available = False
        if not available:
            return False
        self.knowledge.add(('work_batch', self.batch))
        return True

    def record_cold_label(self, batch, *, actual_read=False):
        # Adapter passes only an already acquired S2 label fact, never a guess.
        if not actual_read or not batch:
            return False
        self.cold_batches.add(batch)
        return True

    def cross_linked(self):
        return (('work_batch', self.batch) in self.knowledge and self.batch in self.cold_batches)

    def new_attempt(self, attempt, *, epoch=None):
        if attempt <= self.attempt:
            return False
        self.abort('new_attempt')
        self.attempt = attempt
        if epoch is not None:
            self.epoch = epoch
        self.stage = 'idle'
        self.attempt_used = False
        self.clamp_remaining_ms = 0
        self.hand_in_drawer = False
        self.supervisor_interrupted = self.worker_interrupted = False
        self.paused = self.dead = self.avatar_blocked = False
        self.active = True
        self.seen.clear()
        self.board_steady = self.board_back_visible = False
        # Real carried materials and the actual unfinished work persist; no free refill.
        return True

    def reload(self):
        return deepcopy(self)
