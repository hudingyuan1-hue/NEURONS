"""S3 F2 isolation: physical rule model, not a Unity implementation.

Source: S3:P811-815,T30,P925-949; S4:T15R9,P181-182,P196-207.
Caller validates real actor positions, shared-body ownership, and reports.
This module independently enforces authority, target/attempt identity, actual
contact, capacity, bounded doors and the distinction between transport/isolation.
"""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Authorization:
    order_id: str
    report_id: str
    target: str
    attempt: int
    source: str


@dataclass
class Isolation:
    attempt: int = 1
    avatar_id: str = 'avatar'
    orders: dict = field(default_factory=dict)
    reports_signed: set = field(default_factory=set)
    consumed: set = field(default_factory=set)
    avatar_attempts: set = field(default_factory=set)
    active: Authorization | None = None
    phase: str = 'idle'
    position: str | None = None
    room_clear: bool = True
    room_space: bool = True
    holding: bool = False
    door: str = 'open'
    timer: int = 0
    transport_ms: int = 0
    elapsed_ms: int = 0
    paused: bool = False
    loading: bool = False
    dead: bool = False
    history: list = field(default_factory=list)
    facts: list = field(default_factory=list)
    outcomes: list = field(default_factory=list)
    hp_effect: int = 0
    sp_effect: int = 0

    @property
    def available(self):
        return not (self.paused or self.loading or self.dead)

    def _record(self, action, **extra):
        self.history.append(dict(action=action, at_ms=self.elapsed_ms,
                                 attempt=self.attempt,
                                 target=self.active.target if self.active else None,
                                 order_id=self.active.order_id if self.active else None,
                                 **extra))

    def sign(self, order_id, report_id, target, *, report_target=None,
             chief_present=False, actual=False, report_received=False,
             target_verified=False, source='report'):
        """Only an actual chief-signed, received, matching report authorizes.

        source='transfer' means a separately signed order after number checking;
        delivering a transfer slip alone never calls/signals this operation.
        """
        if (not self.available or not actual or not chief_present
                or not report_received or not target_verified
                or not order_id or not report_id or not target
                or report_target != target or source not in ('report', 'transfer')
                or order_id in self.orders
                or (self.attempt, report_id) in self.reports_signed):
            return False
        order = Authorization(order_id, report_id, target, self.attempt, source)
        self.orders[order_id] = order
        self.reports_signed.add((self.attempt, report_id))
        self._record('signed', signed_target=target, signed_order=order_id)
        return True

    def take_order(self, order_id, *, actual=False, orderly_present=False,
                   idle=False, previous_holder_released=False):
        order = self.orders.get(order_id)
        if (not self.available or self.active or not order
                or order.attempt != self.attempt or not actual
                or not orderly_present or not idle or not previous_holder_released
                or (self.attempt, order.report_id) in self.consumed
                or (order.target == self.avatar_id and self.attempt in self.avatar_attempts)):
            return False
        self.active = order
        self.consumed.add((self.attempt, order.report_id))
        if order.target == self.avatar_id:
            self.avatar_attempts.add(self.attempt)
        self.phase = 'locating'
        self.position = None
        self.transport_ms = 0
        self._record('taken')
        return True

    def locate(self, location=None, *, actual=False, found=False,
               last_known_checked=False):
        if not self.available or not self.active or self.phase != 'locating' or not actual:
            return False
        if found and location:
            self.position = location
            self.phase = 'located'
            self._record('located', location=location)
            return True
        if not found and last_known_checked:
            self._finish('not_found')
            return True
        return False

    def configure_room(self, *, clear, space):
        """Actual occupancy/capacity input. It is not an NPC teleport operation."""
        self.room_clear, self.room_space = bool(clear), bool(space)
        if self.active and (not clear or not space) and self.door in ('closing', 'closed'):
            self._start_open('room_blocked')

    def approach(self, *, actual=False, visible=False):
        if (not self.available or not self.active or self.phase != 'located'
                or not actual or not visible or not self.room_clear or not self.room_space):
            return False
        self.phase = 'reaching'
        self._record('visible_reach')
        return True

    def grip(self, *, actual=False):
        if not self.available or not self.active or self.phase != 'reaching':
            return False
        if not self.room_clear or not self.room_space:
            self.phase = 'located'
            return False
        if not actual:
            self._finish('miss')
            return True
        self.holding = True
        self.transport_ms = 0
        self.phase = 'held'
        self._record('gripped')
        return True

    def step(self, location, *, actual=False, route_valid=False,
             at_observation=False):
        if (not self.available or not self.active or self.phase != 'held'
                or not actual or not route_valid
                or (at_observation and location != 'quiet')):
            return False
        self.position = location
        self._record('transport_step', location=location)
        if at_observation:
            self.holding = False
            self.phase = 'arrived'
            self._record('arrived_released')
        return True

    def begin_close(self, *, actual=False):
        if (not self.available or not self.active or self.phase != 'arrived'
                or not actual or self.position != 'quiet' or self.holding
                or not self.room_clear or not self.room_space):
            return False
        self.phase = 'closing'
        self.door = 'closing'
        self.timer = 0
        self._record('closing')
        return True

    def close_actual(self, *, actual=False):
        if (not self.available or not self.active or self.phase != 'closing'
                or not actual or not self.room_clear or not self.room_space):
            return False
        self.phase = 'closed'
        self.door = 'closed'
        self.timer = 0
        fact = dict(kind='actually_isolated', attempt=self.attempt,
                    target=self.active.target, report_id=self.active.report_id,
                    order_id=self.active.order_id, at_ms=self.elapsed_ms)
        self.facts.append(fact)
        self._record('actually_closed')
        return True

    def _start_open(self, reason):
        if not self.active:
            return False
        self.holding = False
        if self.door == 'open':
            self._finish(reason)
        elif self.phase != 'opening':
            self.phase = 'opening'
            self.door = 'opening'
            self.timer = 0
            self._record('opening', reason=reason)
        return True

    def open_actual(self, *, actual=False):
        # Death may initiate opening; the door must still complete without revival.
        if self.paused or self.loading or not actual or self.phase != 'opening':
            return False
        self.door = 'open'
        self._record('actually_opened')
        self._finish('released')
        return True

    def abort(self, reason='cancel', *, actual=False):
        if self.paused or self.loading or not actual or not self.active:
            return False
        return self._start_open(reason)

    def orderly_departed(self, *, actual=False, doorway_observer=False):
        if doorway_observer:
            return False
        return self.abort('orderly_departed', actual=actual)

    def target_died(self):
        self.dead = True
        if self.active:
            self._start_open('death')

    def can_leave(self, subject='avatar'):
        return not (self.active and self.active.target == subject
                    and self.position == 'quiet' and self.door in ('closed', 'opening'))

    def can_move_inside(self, subject='avatar'):
        return not (self.active and self.active.target == subject and self.holding)

    def target_moved(self, location, *, actual=False):
        if (not self.available or not self.active or not actual or self.holding
                or (location != self.position and not self.can_leave(self.active.target))):
            return False
        self.position = location
        if self.phase in ('arrived', 'closing') and location != 'quiet':
            self._start_open('left_before_close')
        return True

    def _finish(self, reason):
        if self.active:
            self.outcomes.append(dict(attempt=self.attempt, target=self.active.target,
                                      report_id=self.active.report_id,
                                      order_id=self.active.order_id, reason=reason,
                                      position=self.position, at_ms=self.elapsed_ms))
            self._record('ended', reason=reason)
        self.active = None
        self.phase = 'idle'
        self.holding = False
        self.timer = 0
        self.transport_ms = 0
        self.door = 'open'

    def tick(self, ms, *, paused=None, loading=None):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if paused is not None:
            self.paused = bool(paused)
        if loading is not None:
            self.loading = bool(loading)
        if self.paused or self.loading:
            return
        remaining = ms
        while remaining:
            bound = None
            if self.phase == 'held' and self.active.target == self.avatar_id:
                bound = 6000 - self.transport_ms
            elif self.phase in ('closing', 'opening'):
                bound = 1000 - self.timer
            elif self.phase == 'closed':
                bound = 8000 - self.timer
            dt = min(remaining, bound) if bound is not None else remaining
            self.elapsed_ms += dt
            remaining -= dt
            if self.phase == 'held':
                self.transport_ms += dt
                if self.active.target == self.avatar_id and self.transport_ms >= 6000:
                    self._finish('transport_timeout')
            elif self.phase == 'closing':
                self.timer += dt
                if self.timer >= 1000:
                    # A scheduled physical door action has a <=1s completion cap.
                    self.close_actual(actual=True)
            elif self.phase == 'closed':
                self.timer += dt
                if self.timer >= 8000:
                    self._start_open('expired')
            elif self.phase == 'opening':
                self.timer += dt
                if self.timer >= 1000:
                    self.open_actual(actual=True)

    def new_attempt(self, attempt):
        if attempt <= self.attempt:
            return False
        if self.active:
            self._finish('attempt_ended')
        self.attempt = attempt
        self.position = None
        self.dead = False
        self.phase = 'idle'
        self.door = 'open'
        self.holding = False
        self.timer = self.transport_ms = 0
        return True
