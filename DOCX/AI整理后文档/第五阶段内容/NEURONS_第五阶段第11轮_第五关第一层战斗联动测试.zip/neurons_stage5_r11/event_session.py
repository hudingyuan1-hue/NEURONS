"""R8 physical scene adapter: three S3F2 event chains + R7 report/isolation.
Sources S2:T3; S3:P824-843/P887-917/P950-975; S4:P185-186.
"""
from dataclasses import dataclass,field
from ward_session import WardSession
from group_therapy import GroupTherapy
from patient_transfer import PatientTransfer,PATIENT
from cleanup import Cleanup

THERAPY_ACTIONS={'start_recording','sit_speaker','speak_transfer','say_stop','stop_recording','delete_segment','hand_statement','read_retraction','write_minutes','release_seat','stand_up','sign','read_statement','search_chair','interrupt','replay'}
TRANSFER_ACTIONS={'take_order','verify','release_brake','grab_rail','return_hand','detach_band','move','park','interrupt','resume','observe','read','pickup'}
CLEANUP_ACTIONS={'notice','cover','load_board','move_body','move_cleaner','collect','clean','observe_body','unfold_meal','read_item','take_item','interrupt','resume'}

@dataclass
class EventSession(WardSession):
    group: GroupTherapy=field(default_factory=lambda:GroupTherapy(speaker_id='s3_speaker',transfer_number='speaker-transfer-01'))
    transport: PatientTransfer=field(default_factory=PatientTransfer)
    cleaning: Cleanup=field(default_factory=Cleanup)

    def __post_init__(self):
        self.actors.update(dict.fromkeys(('therapy_director','speaker','porter','cleaner')))
        super().__post_init__()

    def _sync(self):
        super()._sync()
        if not hasattr(self,'group'):return
        self.group.sync_context(attempt=self.life.attempts[3],epoch=self.life.epoch,
            positions={'avatar':self.position,'director':self.actors.get('therapy_director'),
                       'speaker':self.actors.get('speaker')},paused=self.paused or self.loading,
            dead=self.life.phase=='dead')
        self.transport.avatar_room=self.position[1] if self.position[0]==2 else None
        self.transport.paused=self.paused or self.loading
        self.transport.dead=self.life.phase=='dead' or self.life.progress!=3
        self.cleaning.avatar_location=self.position[1] if self.position[0]==2 else None
        p=self.actors.get('cleaner')
        self.cleaning.cleaner_location=p[1] if p and p[0]==2 else None
        self.cleaning.paused=self.paused or self.loading
        self.cleaning.avatar_blocked=self.blocked()
        self.cleaning.active=self.life.phase=='alive' and self.life.progress==3

    def _dialogue_node(self,token):
        self._sync()
        if self.loading or self.life.phase!='alive' or self.life.progress!=3 or token[0]!=self.life.epoch or token in self.seen:return False
        self.seen.add(token);return True

    def group_action(self,token,name,**kw):
        formal=name in ('speak_transfer','say_stop','read_retraction') and kw.get('formal_dialogue',False)
        if not (self._dialogue_node(token) if formal else self.node(token)) or name not in THERAPY_ACTIONS:return False
        if name in ('read_statement','search_chair','replay') or name=='sign' and kw.get('actor')=='avatar':
            if self.blocked():return False
        if name=='speak_transfer' and not self.group.transfer_number:return False
        return getattr(self.group,name)(token,**kw)

    def spawn_transfer(self,token,order_id,actual=True):
        if not self.node(token) or not actual or self.transport.spawned:return False
        if self.actors.get('transferred') is not None or self.actors.get('porter') is not None:return False
        if not self.transport.spawn(self._rt('spawn'),order_id):return False
        self.actors['transferred']=self.actors['porter']=(2,'double')
        self.ward.register_transfer(self._rt('initial_transfer'),order_id,
            patient_id=PATIENT,wrist_id=PATIENT,bed_id=PATIENT)
        self._sync();return True

    def transfer_action(self,token,name,**kw):
        if not self.node(token) or name not in TRANSFER_ACTIONS:return False
        if name in ('read','pickup','observe') and kw.get('actor','avatar')=='avatar' and self.blocked():return False
        for role,key in (('porter','porter'),('transferred','patient')):
            p=self.actors.get(role)
            self.transport.positions[key]=p[1] if p and p[0]==2 else None
        result=getattr(self.transport,name)(self._rt(name),**kw)
        if result and name=='move':
            self.actors['porter']=(2,self.transport.positions['porter'])
            self.actors['transferred']=(2,self.transport.positions['patient'])
        self._sync();return result

    def cleanup_action(self,token,name,**kw):
        if not self.node(token) or name not in CLEANUP_ACTIONS:return False
        result=getattr(self.cleaning,name)(self._rt(name),**kw)
        if result and name in ('move_body','move_cleaner'):
            self.actors['cleaner']=(2,self.cleaning.cleaner_location)
        self._sync();return result

    def isolation_take(self,token,order_id,target,actual=True):
        if target=='transferred' and (not self.transport.delivered or self.transport.positions['patient']!='quiet'):return False
        return super().isolation_take(token,order_id,target,actual)

    def actor_move(self,token,actor,dest,actual=True):
        # Moving a loaded push-bed is performed only by its physical transport action.
        if actor in ('porter','transferred') and self.transport.spawned and not self.transport.delivered:return False
        result=super().actor_move(token,actor,dest,actual)
        if result:self._sync()
        return result

    def damage_or_exit(self,token,hp=0,sp=0,exit_actual=False):
        result=super().damage_or_exit(token,hp,sp,exit_actual)
        self._sync();return result

    def _restart(self):
        super()._restart()
        self.actors.update(dict.fromkeys(('therapy_director','speaker','porter','cleaner')))
        self.transport.new_attempt(self.life.attempts[3]);self.cleaning.new_attempt(self.life.attempts[3]);self._sync()
