"""S3 numbered medicine cup. Source: S3:P679,700-728/T22; S4:T16/P189-192.

No Life/stat ownership: actual swallowing emits one idempotent effect; session
applies it. Spatial contact, free hands and resolved external action precedence
are session facts. Imported institutional labels never become bodily facts.
"""
from dataclasses import dataclass, field
from typing import Hashable


@dataclass(frozen=True)
class Order:
    id: Hashable
    patient_id: str
    source_level: int
    signed: bool
    project: str


@dataclass
class Medication:
    patient_id: str = 'avatar'
    attempt: int = 1
    floor: int = 1
    paused: bool = False
    dead: bool = False
    orders: dict = field(default_factory=dict)
    settled_orders: dict = field(default_factory=dict)
    inherited_labels: dict = field(default_factory=dict)
    cup_id: Hashable | None = None
    cup_order: Hashable | None = None
    cup_state: str = 'none'
    raising_ms: int = 0
    closed: bool = False
    used_cups: set = field(default_factory=set)
    outcomes: dict = field(default_factory=dict)
    records: list = field(default_factory=list)
    effects: list = field(default_factory=list)
    emitted: set = field(default_factory=set)
    record_events: set = field(default_factory=set)

    @property
    def active(self):
        return not self.paused and not self.dead

    def issue_order(self, order_id, patient_id=None, source_level=3,
                    signed=True, project='numbered_cup'):
        """Actual signed prescribing fact, not merely a diagnosis/label."""
        if not self.active or order_id in self.orders:
            return False
        self.orders[order_id] = Order(order_id, patient_id or self.patient_id,
                                      source_level, signed, project)
        return True

    def inherit_order(self, order_id, patient_id=None, source_level=2,
                      signed=True, project='numbered_cup', actual_status='pending',
                      label_status=None):
        if actual_status not in ('pending', 'swallowed', 'refused'):
            raise ValueError('Unknown actual order outcome')
        if not self.issue_order(order_id, patient_id, source_level, signed, project):
            return False
        if actual_status != 'pending':
            self.settled_orders[order_id] = actual_status
        if label_status is not None:
            self.inherited_labels[order_id] = label_status
        return True

    def prepare(self, order_id, cup_id, pharmacist_present=True, matched=True):
        order = self.orders.get(order_id)
        if (not self.active or self.closed or not pharmacist_present or not matched
                or order is None or not order.signed
                or order.patient_id != self.patient_id or order.project != 'numbered_cup'
                or order_id in self.settled_orders or cup_id in self.used_cups
                or self.cup_state in ('ready', 'held', 'raising')):
            return False
        self.cup_id, self.cup_order, self.cup_state = cup_id, order_id, 'ready'
        self.raising_ms = 0
        self.used_cups.add(cup_id)
        return True

    def take(self):
        if not self.active or self.closed or self.cup_state != 'ready':
            return False
        self.cup_state = 'held'
        return True

    def raise_cup(self):
        if not self.active or self.closed or self.cup_state != 'held':
            return False
        self.cup_state = 'raising'
        self.raising_ms = 0
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('Negative time')
        if self.active and self.cup_state == 'raising':
            self.raising_ms += ms

    def interrupt(self):
        if not self.active or self.closed or self.cup_state != 'raising':
            return False
        self.cup_state = 'held'
        self.raising_ms = 0
        return True

    def _finish(self, event_id, outcome, nurse_present, nurse_witnessed):
        if not self.active or self.closed or event_id in self.outcomes:
            return False
        if self.cup_order is None or self.cup_order in self.settled_orders:
            return False
        if outcome == 'swallowed':
            if self.cup_state != 'raising' or self.raising_ms < 1000:
                return False
        elif self.cup_state not in ('ready', 'held', 'raising'):
            return False
        self.cup_state = outcome
        self.closed = True
        self.settled_orders[self.cup_order] = outcome
        self.outcomes[event_id] = {
            'id': event_id, 'attempt': self.attempt, 'floor': self.floor,
            'patient_id': self.patient_id, 'cup_id': self.cup_id,
            'order_id': self.cup_order, 'actual': outcome,
            'nurse_witnessed': bool(nurse_present and nurse_witnessed),
        }
        if outcome == 'swallowed':
            effect_id = ('S3-medication', self.patient_id, self.cup_order)
            if effect_id not in self.emitted:
                self.emitted.add(effect_id)
                self.effects.append({'id': effect_id, 'attempt': self.attempt,
                                     'kind': 'swallowed', 'sp_damage': 20,
                                     'drug_stop_ms': 1500, 'hp_damage': 0,
                                     'order_id': self.cup_order, 'cup_id': self.cup_id})
        return True

    def swallow(self, event_id, nurse_present=False, nurse_witnessed=False):
        return self._finish(event_id, 'swallowed', nurse_present, nurse_witnessed)

    def refuse(self, event_id, nurse_present=False, nurse_witnessed=False):
        return self._finish(event_id, 'refused', nurse_present, nurse_witnessed)

    def nurse_record(self, event_id, outcome_id, claim='taken', completed=True,
                     nurse_present=True):
        outcome = self.outcomes.get(outcome_id)
        if (not self.active or not completed or not nurse_present
                or event_id in self.record_events or outcome is None
                or not outcome['nurse_witnessed'] or claim != 'taken'):
            return False
        # A witnessed refusal remains actual refusal even after false paperwork.
        self.record_events.add(event_id)
        self.records.append({'id': event_id, 'outcome_id': outcome_id,
                             'order_id': outcome['order_id'], 'claim': claim,
                             'actual': outcome['actual'],
                             'false': outcome['actual'] == 'refused'})
        return True

    def move_floor(self, floor):
        if not self.active or floor not in (1, 2):
            return False
        self.floor = floor
        return True

    def new_attempt(self, attempt):
        """Called only after real restart; unresolved cup keeps its identity."""
        if attempt <= self.attempt:
            return False
        self.attempt = attempt
        self.dead = False
        self.closed = False
        self.raising_ms = 0
        if self.cup_state == 'raising':
            self.cup_state = 'held'
        return True

    def drain_effects(self):
        effects, self.effects = self.effects, []
        return effects
