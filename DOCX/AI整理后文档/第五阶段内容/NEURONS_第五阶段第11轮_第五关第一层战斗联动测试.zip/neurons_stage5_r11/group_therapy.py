"""S3:P887-917,T28: actual speech, recordings, papers and knowledge stay distinct.

No HP/SP, forced avatar seating, skills, awakening or door controls are produced.
Positions use (floor, room); only the actual group room permits these actions.
"""
from dataclasses import dataclass, field
from copy import deepcopy

GROUP = (2, 'group')
RETRACTION = '此前所述均不属实'


@dataclass
class GroupTherapy:
    attempt: int = 1
    epoch: int = 0
    speaker_id: str = 'speaker'
    transfer_number: str | None = None
    positions: dict = field(default_factory=lambda: {'avatar': None, 'director': None, 'speaker': None})
    paused: bool = False
    dead: bool = False
    recording: bool = False
    started: bool = False
    original_spoken: bool = False
    stop_requested: bool = False
    stopped: bool = False
    deleted: bool = False
    paper_handed: bool = False
    retraction_spoken: bool = False
    minutes_written: bool = False
    seat_requested: bool = False
    speaker_seated: bool = False
    released: bool = False
    finished: bool = False
    closed: bool = False
    segments: dict = field(default_factory=dict)
    documents: list = field(default_factory=list)
    facts: set = field(default_factory=set)
    knowledge: set = field(default_factory=set)
    seen: set = field(default_factory=set)
    signed: set = field(default_factory=set)
    events: list = field(default_factory=list)

    def _valid(self, token, actual=True, physical=True, roles=(), live_event=True):
        if (not actual or self.dead or token[0] != self.epoch or token in self.seen
                or (physical and self.paused) or (live_event and self.closed)
                or any(self.positions.get(r) != GROUP for r in roles)):
            return False
        return True

    def _commit(self, token, action):
        self.seen.add(token)
        self.events.append((self.attempt, action, token))

    def sync_context(self, *, attempt, epoch, positions, paused=False, dead=False):
        """Call after actual movement/lifecycle. Reset only on a larger attempt.

        Epoch updates invalidate all stale callbacks, including floor exit callbacks.
        A director leaving ends this event, without inventing a device operation.
        """
        if attempt < self.attempt or epoch < self.epoch:
            return False
        if attempt > self.attempt:
            old_facts, old_knowledge, old_documents = self.facts, self.knowledge, self.documents
            fresh = GroupTherapy(attempt, epoch, self.speaker_id, self.transfer_number)
            self.__dict__.update(fresh.__dict__)
            self.facts, self.knowledge, self.documents = old_facts, old_knowledge, old_documents
        elif epoch != self.epoch:
            self.closed = True
            self.seat_requested = False
        old_director = self.positions.get('director')
        self.epoch, self.positions = epoch, dict(positions)
        self.paused, self.dead = paused, dead
        if self.started and old_director == GROUP and self.positions.get('director') != GROUP:
            self.closed = True
            self.seat_requested = False
        if dead:
            self.closed = True
            self.seat_requested = False
        return True

    def start_recording(self, token, *, actual=True):
        if (not self._valid(token, actual, roles=('director', 'speaker'))
                or self.started):
            return False
        self._commit(token, 'start_recording')
        self.started = self.recording = True
        self.seat_requested = True
        return True

    def sit_speaker(self, token, *, actual=True):
        if not self._valid(token, actual, roles=('speaker',)) or not self.seat_requested:
            return False
        self._commit(token, 'sit_speaker')
        self.speaker_seated = True
        return True

    def _hear(self, text, heard_text, origin='original'):
        # Upstream supplies only the segment actually audible to this avatar.
        if (self.positions.get('avatar') == GROUP and heard_text
                and heard_text in text):
            self.knowledge.add((self.attempt, self.speaker_id, 'heard', heard_text))
            self.knowledge.add((self.attempt, self.speaker_id, 'heard_' + origin, heard_text))

    def speak_transfer(self, token, *, actual=True, formal_dialogue=False, heard_text=None):
        if (not self._valid(token, actual, physical=not formal_dialogue, roles=('speaker', 'director'))
                or not self.started or self.original_spoken or not self.transfer_number):
            return False
        self._commit(token, 'speak_transfer')
        text = f'转运编号是{self.transfer_number}，那天——'
        self.original_spoken = True
        self.facts.add((self.attempt, self.speaker_id, 'said', text))
        if self.recording:
            self.segments[(self.attempt, 'original')] = text
        self._hear(text, heard_text)
        return True

    def say_stop(self, token, *, actual=True, formal_dialogue=False):
        if (not self._valid(token, actual, physical=not formal_dialogue, roles=('director',))
                or not self.original_spoken or self.stop_requested):
            return False
        self._commit(token, 'say_stop')
        self.stop_requested = True
        return True

    def stop_recording(self, token, *, actual=True):
        if (not self._valid(token, actual, roles=('director',))
                or not self.stop_requested or not self.recording):
            return False
        self._commit(token, 'stop_recording')
        self.recording, self.stopped = False, True
        return True

    def delete_segment(self, token, *, actual=True, seen_by_avatar=False):
        if (not self._valid(token, actual, roles=('director',))
                or not self.stopped or self.deleted):
            return False
        self._commit(token, 'delete_segment')
        self.segments.pop((self.attempt, 'original'), None)
        self.deleted = True
        self.facts.add((self.attempt, self.speaker_id, 'recording_deleted'))
        if seen_by_avatar and self.positions.get('avatar') == GROUP:
            self.knowledge.add((self.attempt, self.speaker_id, 'deletion_seen'))
        return True

    def hand_statement(self, token, *, actual=True):
        if (not self._valid(token, actual, roles=('director', 'speaker'))
                or not self.deleted or self.paper_handed):
            return False
        self._commit(token, 'hand_statement')
        self.paper_handed = True
        return True

    def read_retraction(self, token, *, actual=True, formal_dialogue=False, heard_text=None):
        if (not self._valid(token, actual, physical=not formal_dialogue, roles=('director', 'speaker'))
                or not self.paper_handed or self.retraction_spoken):
            return False
        self._commit(token, 'read_retraction')
        self.retraction_spoken = True
        self.facts.add((self.attempt, self.speaker_id, 'said', RETRACTION))
        if self.recording:
            self.segments[(self.attempt, 'retraction')] = RETRACTION
        self._hear(RETRACTION, heard_text, origin='retraction')
        return True

    def write_minutes(self, token, *, actual=True, prefilled=False):
        if not self._valid(token, actual, roles=('director',)):
            return False
        if not prefilled and (not self.retraction_spoken or self.minutes_written):
            return False
        kind = 'prefilled' if prefilled else 'actual_statement'
        if any(d[:3] == (self.attempt, self.speaker_id, kind) for d in self.documents):
            return False
        self._commit(token, 'write_minutes')
        self.documents.append((self.attempt, self.speaker_id, kind, RETRACTION))
        if not prefilled:
            self.minutes_written = True
        return True

    def release_seat(self, token, *, actual=True):
        if (not self._valid(token, actual, roles=('director', 'speaker'))
                or not self.minutes_written or self.released):
            return False
        self._commit(token, 'release_seat')
        self.seat_requested, self.released = False, True
        return True

    def stand_up(self, token, *, actual=True):
        if (not self._valid(token, actual, roles=('speaker',))
                or not self.released or self.finished):
            return False
        self._commit(token, 'stand_up')
        self.speaker_seated, self.finished = False, True
        self.closed = True
        return True

    def sign(self, token, *, actor='speaker', actual=True, prefilled=False, proxy=False):
        if actor not in ('avatar', 'speaker') or not self._valid(token, actual, roles=(actor,)):
            return False
        if not self.paper_handed:
            return False
        subject = self.speaker_id if actor == 'speaker' else 'avatar'
        kind = 'prefilled_signature' if prefilled else 'proxy_signature' if proxy else 'actual_signature'
        ident = (self.attempt, subject, kind)
        if ident in self.signed:
            return False
        self._commit(token, 'sign')
        self.signed.add(ident)
        self.documents.append((*ident, 'signature'))
        if kind == 'actual_signature':
            self.facts.add(ident)
        return True

    def read_statement(self, token, *, actual=True, clear=True):
        if not self._valid(token, actual, roles=('avatar',), live_event=False) or not clear or not self.paper_handed:
            return False
        self._commit(token, 'read_statement')
        self.knowledge.add((self.attempt, self.speaker_id, 'paper_read', RETRACTION))
        return True

    def search_chair(self, token, *, actual=True):
        if not self._valid(token, actual, roles=('avatar',), live_event=False):
            return False
        self._commit(token, 'search_chair')
        return True

    def interrupt(self, token, *, actual=True):
        if not self._valid(token, actual, physical=False) or not self.started:
            return False
        self._commit(token, 'interrupt')
        self.closed, self.seat_requested = True, False
        return True

    def replay(self, token, *, actual=True):
        if not self._valid(token, actual, roles=('avatar',), live_event=False):
            return None
        text = self.segments.get((self.attempt, 'original'))
        if text is None:
            return None
        self._commit(token, 'replay')
        self._hear(text, text)
        return text

    def can_question_deletion(self):
        return ((self.attempt, self.speaker_id, 'deletion_seen') in self.knowledge
                and any(k[:3] == (self.attempt, self.speaker_id, 'heard_original') for k in self.knowledge))

    def reload(self):
        return deepcopy(self)
