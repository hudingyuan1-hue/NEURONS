"""S3:P979-1013: corner patient receipts and actual orderly escort.
Rooms/visibility/contact are explicit fixture facts, not simulated Unity perception.
Receipt IDs are personal; equal batches never establish a shared vehicle.
"""
from copy import deepcopy
from dataclasses import dataclass

@dataclass(frozen=True)
class Receipt:
    person: str
    date: str
    trip: str
    batch: str = ''
    erased_name: bool = False
    bed: str = ''

class CornerPatient:
    def __init__(self, attempt=1, receipts=None):
        self.attempt=attempt
        self.receipts=receipts or {
            'corner':Receipt('corner_fixture','date_fixture','trip_fixture','batch_fixture',True,'2'),
            'cross':Receipt('cross_fixture','date_fixture','trip_fixture','batch_fixture',False,'1')}
        if set(self.receipts)!={'corner','cross'}:raise ValueError('Two separate personal receipts required')
        if self.receipts['corner'].person==self.receipts['cross'].person:raise ValueError('Distinct personal IDs required')
        self.owners={'corner':'corner','cross':'cross'}
        self.read_fields={'corner':set(),'cross':set()};self.knowledge=set();self.facts=[];self.history=[]
        self.hp_effect=self.sp_effect=self.resource_effect=0
        self._local_reset()

    def _local_reset(self):
        self.positions=dict.fromkeys(('avatar','corner','cross','orderly'))
        self.medical_near=set();self.orderly_busy=False;self.avatar_blocked=False
        self.paused=self.dead=False;self.tokens=set();self.showing=set()
        self.talking=False;self.talk_completed=False;self.spoken=set()
        self.state='idle';self.completed=False;self.observed=False;self.held=False
        self.elapsed_ms=0;self.escort_witnessed=False

    def node(self,token,actual=True,formal=False):
        if not actual or self.dead or (self.paused and not formal) or token[0]!=self.attempt or token in self.tokens:return False
        self.tokens.add(token);return True

    def fact(self,kind,**kw):
        self.facts.append({'attempt':self.attempt,'kind':kind,'corner_room':self.positions['corner'],**kw})

    def begin_talk(self,token,near=True,actual=True):
        if not self.node(token,actual) or not near or self.avatar_blocked or self.talk_completed or self.completed or self.talking or self.held:return False
        if self.medical_near or self.positions['avatar']!='double' or self.positions['corner']!='double':return False
        self.talking=True;self.fact('talk_started');return True

    def say(self,token,speaker,line_key,heard=True,formal_dialogue=False,actual=True):
        if not self.node(token,actual,formal_dialogue) or not self.talking or self.medical_near or self.held:return False
        if speaker not in ('corner','cross') or self.positions[speaker]!='double' or line_key in self.spoken:return False
        if (speaker,line_key) not in (('cross','same_vehicle'),('corner','remember_number')):return False
        self.spoken.add(line_key);self.fact('said',speaker=speaker,line=line_key)
        if heard and self.positions['avatar']=='double':self.knowledge.add(line_key)
        return True

    def show(self,token,person='corner',actual=True):
        if not self.node(token,actual) or person not in self.receipts or not self.talking or self.medical_near or self.held:return False
        if self.owners[person]!=person or self.positions[person]!='double' or person in self.showing:return False
        self.showing.add(person);self.fact('receipt_shown',person=person);return True

    def _readable(self,person):
        owner=self.owners[person]
        return owner=='avatar' or (person in self.showing and self.positions[person] is not None and self.positions[person]==self.positions['avatar'])

    def read(self,token,person,fields,visible=True,legible=True,actual=True):
        if not self.node(token,actual) or self.avatar_blocked or person not in self.receipts or not visible or not legible or not self._readable(person):return False
        allowed={'person','date','trip','batch','erased_name','bed'}
        if not fields or not set(fields)<=allowed:return False
        self.read_fields[person].update(fields);self.fact('receipt_read',person=person,fields=sorted(fields));return True

    def give(self,token,person='corner',actual=True,reachable=True):
        if not self.node(token,actual) or self.avatar_blocked or self.held or person not in self.receipts or not reachable:return False
        if self.owners[person]!=person or self.positions[person] is None or self.positions[person]!=self.positions['avatar']:return False
        self.owners[person]='avatar';self.showing.discard(person);self.fact('receipt_given',person=person);return True

    def stow(self,token,person='corner',actual=True):
        if not self.node(token,actual) or person not in self.showing:return False
        self.showing.remove(person);self.fact('receipt_stowed',person=person);return True

    @property
    def same_vehicle_verified(self):
        a,b=self.receipts['corner'],self.receipts['cross']
        required={'person','date','trip'}
        return ('same_vehicle' in self.knowledge and required<=self.read_fields['corner'] and required<=self.read_fields['cross']
                and bool(a.date) and bool(a.trip) and a.date==b.date and a.trip==b.trip and a.person!=b.person)

    def complete_talk(self,token,actual=True):
        if not self.node(token,actual) or not self.talking:return False
        self.talking=False;self.talk_completed=True;self.fact('talk_completed');return True

    def medical_arrive(self,token,role,pos='doorway',actual=True):
        if not self.node(token,actual) or pos not in ('doorway','double') or (role=='orderly' and self.held):return False
        self.medical_near.add(role)
        if role=='orderly':self.positions['orderly']=pos
        self.talking=False;self.fact('talk_stopped_medical',role=role)
        # No unperformed stow, no unseen lines, no automatic escort.
        return True

    def medical_leave(self,token,role,actual=True):
        if not self.node(token,actual) or role not in self.medical_near:return False
        self.medical_near.remove(role)
        if role=='orderly' and self.state not in ('held','doorway','corridor'):self.positions['orderly']='corridor'
        return True

    def observe_receipt(self,token,visible=True,actual=True):
        if not self.node(token,actual) or self.orderly_busy or self.completed or self.held or not visible:return False
        if self.positions['orderly'] not in ('doorway','double') or self.positions['corner']!='double' or 'corner' not in self.showing or self.owners['corner']!='corner':return False
        if self.state in ('observed','approaching'):return False
        self.observed=True;self.state='observed';self.fact('receipt_seen_by_orderly');return True

    def approach(self,token,actual=True,route_clear=True):
        if not self.node(token,actual) or self.orderly_busy or self.state!='observed' or not route_clear or self.positions['corner']!='double' or self.positions['orderly'] not in ('double','doorway'):return False
        self.positions['orderly']='double';self.state='approaching';self.talking=False;self.fact('orderly_approached');return True

    def grip(self,token,contact=True,actual=True):
        if not self.node(token,actual) or self.orderly_busy or self.state!='approaching' or self.positions['orderly']!=self.positions['corner']:return False
        if not contact:self.state='missed';self.history.append((self.attempt,'missed'));return True
        self.held=True;self.state='held';self.showing.discard('corner');self.fact('gripped');return True

    def witness_escort(self,token,visible=True,actual=True):
        if not self.node(token,actual) or not visible or not self.held:return False
        if self.positions['avatar']!=self.positions['corner']:return False
        self.escort_witnessed=True;self.knowledge.add('escort_witnessed');return True

    def step(self,token,dest,actual=True,route_clear=True,space=True):
        if not self.node(token,actual) or not self.held or not route_clear or not space:return False
        room=self.positions['corner'];expected={'double':'doorway','doorway':'corridor'}.get(room)
        if dest!=expected or self.positions['orderly']!=room:return False
        self.positions['corner']=self.positions['orderly']=dest;self.state=dest;self.fact('escort_step');return True

    def release(self,token,actual=True):
        if not self.node(token,actual) or not self.held or self.positions['corner']!='corridor' or self.positions['orderly']!='corridor':return False
        self.held=False;self.state='completed';self.completed=True;self.talking=False;self.talk_completed=True
        self.history.append((self.attempt,'completed'));self.fact('escort_completed');return True

    def interrupt(self,token,actual=True,reason='interrupted'):
        if not self.node(token,actual) or self.state not in ('observed','approaching','held','doorway','corridor'):return False
        self.held=False;self.state='interrupted';self.talking=False;self.history.append((self.attempt,reason));self.fact('escort_interrupted');return True

    def tick(self,ms):
        if ms<0:raise ValueError('negative time')
        if self.paused or self.dead:return
        if self.held:self.elapsed_ms+=ms
        # S4:P182: no avatar-only 6 s cap and no timeout teleport for NPC transport.

    def new_attempt(self,attempt):
        if attempt<=self.attempt:return False
        self.attempt=attempt;self._local_reset();return True

    def reload(self):return deepcopy(self)
