"""R11 reproducible runs. Historical reports are never overwritten."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
FILES=['test_combat_flow.py','test_s5_people.py','test_s5_support.py','test_s5_session.py']
BATCHES=[('attacks_initial','combat_flow.py','attacks_initial_combat_flow.py','test_combat_flow.py','attacks_initial_collected_test_combat_flow.py'),
         ('people_initial','s5_people.py','people_initial_s5_people.py','test_s5_people.py','people_initial_test_s5_people.py')]

def rows(name):return json.loads((ROOT/'results'/f'{name}.json').read_text(encoding='utf-8'))['tests']

def run(cwd,nodes,label,stamp,seed):
    report=ROOT/'results'/f'reproduced_{stamp}_{label}.json'
    log=report.with_suffix('.log')
    env=dict(os.environ,RUN_REPORT=str(report))
    cmd=[sys.executable,'-m','pytest',*nodes,'-q',f'--hypothesis-seed={seed}','--hypothesis-show-statistics']
    with log.open('w',encoding='utf-8') as output:
        result=subprocess.run(cmd,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT)
    print(f'{label}: exit={result.returncode}; {log.name}')
    return result.returncode,report

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',nargs='?',default='affected',choices=['affected','current','failures','collection-error'])
    parser.add_argument('--seed',type=int,default=2026101311)
    parser.add_argument('--list',action='store_true')
    args=parser.parse_args();stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    if args.mode in ('affected','current'):
        nodes=FILES if args.mode=='current' else sorted({r['test'] for name in ['attacks_impacted','people_impacted'] for r in rows(name)})
        if args.list:print('\n'.join(nodes));return 0
        return run(ROOT,nodes,args.mode,stamp,args.seed)[0]
    if args.mode=='collection-error':
        batches=[('attacks_collection_error','combat_flow.py','attacks_initial_combat_flow.py','test_combat_flow.py','attacks_initial_test_combat_flow.py')]
    else:batches=BATCHES
    valid=True
    for label,module,old_module,testfile,old_test in batches:
        nodes=[testfile] if args.mode=='collection-error' else [r['test'] for r in rows(label) if r['outcome']=='failed']
        if args.list:print(label+':\n'+'\n'.join(nodes));continue
        with tempfile.TemporaryDirectory(prefix='neurons_r11_') as directory:
            temporary=Path(directory)
            for f in ROOT.glob('*.py'):shutil.copy2(f,temporary/f.name)
            shutil.copy2(ROOT/'revisions'/old_module,temporary/module)
            shutil.copy2(ROOT/'revisions'/old_test,temporary/testfile)
            code,report=run(temporary,nodes,args.mode+'_'+label,stamp,args.seed)
            data=json.loads(report.read_text(encoding='utf-8')) if report.exists() else {}
            if args.mode=='collection-error':
                correct=code==2 and 'InvalidArgument' in report.with_suffix('.log').read_text(encoding='utf-8')
            else:
                correct=code==1 and {r['test']:r['outcome'] for r in data.get('tests',[])}=={n:'failed' for n in nodes}
            if not correct:valid=False;print('Unexpected reproduction result; inspect log.')
    return 0 if valid else 1

if __name__=='__main__':raise SystemExit(main())
