"""S4 F2 documentary events. Evidence fixtures are supplied actual facts, never story creation.
S3:P1168-1181,1201-1215,1261-1277; S4:T17R3/R4/R8.
World operations pause; a formal speech-completion callback may run while text pauses.
"""
from dataclasses import dataclass, field
from copy import deepcopy

@dataclass
class WhiteRecords:
    attempt: int = 1
    epoch: int = 0
    event: dict | None = None
    identity: dict | None = None
    label: dict | None = None
    room: str | None = None
    actors: dict = field(default_factory=dict)
    avatar_able: bool = True
    paused: bool = False
    dead: bool = False
    departed: bool = False
    seen: set = field(default_factory=set)
    effects: list = field(default_factory=list)
    effect_ids: set = field(default_factory=set)
    knowledge: set = field(default_factory=set)
    history: list = field(default_factory=list)
    conversation: bool = False
    spoken: set = field(default_factory=set)
    identity_started: bool = False
    matched: set = field(default_factory=set)
    face_side: str = 'left'
    label_phase: str = 'idle'
    label_used: bool = False
    label_ms: int = 0
    label_removed: bool = False
    label_owner: str = 'index'
    search_cancelled: bool = False

    def __post_init__(self):
        self.event, self.identity, self.label = deepcopy((self.event,self.identity,self.label))

    def sync_context(self, *, attempt, epoch, room, actors, avatar_able=True, paused=False, dead=False):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        if attempt > self.attempt:
            self.attempt = attempt
            self.seen.clear()
            self.conversation = self.identity_started = False
            self.spoken.clear()
            self.matched.clear()
            self.face_side = 'left'
            self.label_phase, self.label_used, self.label_ms = 'idle', False, 0
            self.search_cancelled = False
            self.departed = False
        elif epoch != self.epoch:
            self.departed = True
        if self.label_phase in ('approach','reached','pulling') and (dead or self.departed or actors.get('blankface') != 'index'):
            self.label_phase, self.label_ms = 'interrupted', 0
        self.epoch, self.room, self.actors = epoch, room, dict(actors)
        self.avatar_able, self.paused, self.dead = avatar_able, paused, dead
        if dead or self.departed or self.actors.get('doublehead') != 'bridge':
            self.conversation = False
        return True

    def _valid(self, token, *, actual=True, room=None, actor=None, avatar=True, physical=True):
        if (not actual or self.dead or self.departed or token[0] != self.attempt or token in self.seen
            or (physical and self.paused) or (avatar and (not self.avatar_able or (room and self.room != room)))
            or (actor and self.actors.get(actor) != room)):
            return False
        return True

    def _done(self, token, action):
        self.seen.add(token)
        self.history.append((self.attempt, action, token))

    def _effect(self, kind, ident):
        key = (kind, ident)
        if key not in self.effect_ids:
            self.effect_ids.add(key)
            self.effects.append({'id': key, 'hp': 0, 'sp': 10})

    def event_valid(self):
        e = self.event
        if not e or not all(k in e for k in ('event_id','patient_id','truth','left','right')):
            return False
        t, left, right = e['truth'], e['left'], e['right']
        if not t.get('verified') or not left.get('doc_id') or not right.get('doc_id') or left['doc_id'] == right['doc_id']:
            return False
        if any(x.get('event_id') != e['event_id'] or x.get('patient_id') != e['patient_id'] for x in (t,left,right)):
            return False
        return (t.get('result'), left.get('result'), right.get('result')) in (('dead','dead','discharged'),('refused','refused','taken'))

    def start_contradiction(self, token, *, actual=True, in_range=True):
        if not self._valid(token,actual=actual,room='bridge',actor='doublehead') or not in_range or not self.event_valid():
            return False
        self._done(token,'start_contradiction')
        self.conversation = True
        self.spoken.clear()
        return True

    def hear_statement(self, token, side, *, actual=True, complete=True, heard=True, formal_dialogue=False):
        if (side not in ('left','right') or not self._valid(token,actual=actual,room='bridge',actor='doublehead',avatar=False,physical=not formal_dialogue)
            or self.room != 'bridge' or not self.conversation or not self.event_valid() or (side == 'right' and 'left' not in self.spoken)):
            return False
        self._done(token,'hear_'+side)
        if complete:
            self.spoken.add(side)
        if heard:
            self.knowledge.add(('event',self.event['event_id'],side,'complete' if complete else 'partial'))
        if all(('event',self.event['event_id'],s,'complete') in self.knowledge for s in ('left','right')):
            self._effect('contradiction', self.event['event_id'])
        if self.spoken == {'left','right'}:
            self.conversation = False
        return True

    def read_event_screen(self, token, side, *, actual=True, visible=True):
        if side not in ('left','right') or not self._valid(token,actual=actual,room='bridge') or not visible or not self.event_valid():
            return False
        self._done(token,'screen_'+side)
        self.knowledge.add(('event_screen',self.event[side]['doc_id']))
        return True

    @property
    def can_claim_witness(self):
        return bool(self.event_valid() and self.event.get('avatar_witnessed'))

    def _identity_valid(self):
        p = self.identity
        if not p or not all(k in p for k in ('conflict_id','left','right')):
            return False
        a,b = p['left'],p['right']
        return bool(a.get('record_id') and b.get('record_id') and a['record_id'] != b['record_id']
                    and a.get('status') == 'cancelled' and b.get('status') == 'current'
                    and a.get('face_id') and a['face_id'] == b.get('face_id') and a.get('scar') != b.get('scar'))

    def start_identity(self, token, *, actual=True, visible=True):
        if not self._valid(token,actual=actual,room='identity') or not visible or not self._identity_valid():
            return False
        self._done(token,'start_identity')
        self.identity_started = True
        return True

    def _check_identity(self):
        if self._identity_valid() and all(('identity', self.identity['conflict_id'], side,part) in self.knowledge
                            for side in ('left','right') for part in ('document','match','face')):
            self._effect('identity',self.identity['conflict_id'])

    def read_identity(self, token, side, *, actual=True, visible=True):
        if (side not in ('left','right') or not self._valid(token,actual=actual,room='identity')
            or not visible or not self._identity_valid()):
            return False
        self._done(token,'read_identity_'+side)
        self.knowledge.add(('identity',self.identity['conflict_id'],side,'document'))
        self._check_identity()
        return True

    def match_identity(self, token, side, *, actual=True, passed=True):
        if (side not in ('left','right') or not self._valid(token,actual=actual,room='identity')
                or not self.identity_started or not self._identity_valid()):
            return False
        self._done(token,'match_'+side)
        if passed:
            self.matched.add(side)
        return True

    def see_match(self, token, side, *, actual=True, visible=True):
        if (side not in ('left','right') or not self._valid(token,actual=actual,room='identity')
                or not visible or side not in self.matched or not self._identity_valid()):
            return False
        self._done(token,'see_match_'+side)
        self.knowledge.add(('identity',self.identity['conflict_id'],side,'match'))
        self._check_identity()
        return True

    def see_face(self, token, side, *, actual=True, turn_complete=False, visible=True):
        if (side not in ('left','right') or not self._valid(token,actual=actual,room='identity',actor='doubleface')
            or not visible or not self._identity_valid() or (side != self.face_side and not turn_complete)):
            return False
        self._done(token,'see_face_'+side)
        self.face_side = side
        self.knowledge.add(('identity',self.identity['conflict_id'],side,'face'))
        self._check_identity()
        return True

    def open_original(self, token, *, actual=True, visible_to_actor=True):
        if not self._valid(token,actual=actual,room='index') or not self.label:
            return False
        self._done(token,'open_original')
        if visible_to_actor and self.actors.get('blankface') == 'index' and not self.label_used and not self.label_removed:
            self.label_used, self.label_phase = True, 'approach'
        return True

    def read_original(self, token, *, actual=True, visible=True, readable=True):
        if not self._valid(token,actual=actual,room='index') or not self.label or not visible or not readable:
            return False
        self._done(token,'read_original')
        self.knowledge.add(('name',self.label['name']))
        self.knowledge.add(('original',self.label['patient_id']))
        return True

    def observe_label(self, token, *, actual=True, visible=True):
        if not self._valid(token,actual=actual,room='index') or not self.label_removed or not visible:
            return False
        self._done(token,'observe_label')
        self.knowledge.add(('label_removed',self.label['label_id']))
        return True

    def verify_ids(self, token, *, actual=True, readable=True, body_patient=None, fee_patient=None):
        if (not self._valid(token,actual=actual,room='index') or not self.label or not readable
            or body_patient != self.label['patient_id'] or fee_patient != self.label['patient_id']):
            return False
        self._done(token,'verify_ids')
        self.knowledge.add(('id_match',self.label['patient_id'],self.label['body_id'],self.label['fee_id']))
        return True

    def reach_label(self, token, *, actual=True, path_clear=True):
        if (not self._valid(token,actual=actual,room='index',actor='blankface',avatar=False)
            or self.label_phase != 'approach' or not path_clear):
            return False
        self._done(token,'reach_label')
        self.label_phase = 'reached'
        return True

    def pinch_label(self, token, *, actual=True):
        if not self._valid(token,actual=actual,room='index',actor='blankface',avatar=False) or self.label_phase != 'reached':
            return False
        self._done(token,'pinch_label')
        self.label_phase, self.label_ms = 'pulling', 0
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative time')
        if (self.paused or self.dead or self.departed or self.label_phase != 'pulling'
                or self.actors.get('blankface') != 'index'):
            return
        self.label_ms = min(1000,self.label_ms+ms)
        if self.label_ms == 1000:
            self.label_removed, self.label_owner, self.label_phase = True,'blankface','done'
            self.history.append((self.attempt,'label_removed',self.label['label_id']))

    def interrupt_label(self, token, *, actual=True):
        if (not self._valid(token,actual=actual,room='index',actor='blankface',avatar=False)
            or self.label_phase not in ('approach','reached','pulling')):
            return False
        self._done(token,'interrupt_label')
        self.label_phase, self.label_ms = 'interrupted',0
        return True

    def query_name(self, token, *, actual=True, visible=True):
        if not self._valid(token,actual=actual,room='index') or not self.label or not visible:
            return None
        self._done(token,'query_name')
        value = 'not_found' if self.label_removed else 'found'
        self.knowledge.add(('query',self.label['name'],value))
        return value

    def cancel_avatar_search(self, token, *, actual=True):
        if not self._valid(token,actual=actual):
            return False
        self._done(token,'cancel_search')
        self.search_cancelled = True
        return True

    def reload(self):
        return deepcopy(self)
