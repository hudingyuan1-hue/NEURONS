import json, os
from pathlib import Path
import hypothesis, pytest, platform

rows=[]
def pytest_runtest_logreport(report):
    if report.when=='call':
        rows.append({'test':report.nodeid,'outcome':report.outcome,'seconds':round(report.duration,4),'failure':str(report.longrepr) if report.failed else None})

def pytest_sessionfinish(session,exitstatus):
    dest=Path(os.environ.get('RUN_REPORT','results/run.json'))
    dest.parent.mkdir(exist_ok=True,parents=True)
    dest.write_text(json.dumps({'exitstatus':int(exitstatus),'python':platform.python_version(),'hypothesis':hypothesis.__version__,'pytest':pytest.__version__,'tests':rows},ensure_ascii=False,indent=2))
