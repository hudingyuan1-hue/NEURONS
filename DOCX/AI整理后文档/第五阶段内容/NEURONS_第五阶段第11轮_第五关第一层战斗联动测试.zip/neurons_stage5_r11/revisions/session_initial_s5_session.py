"""R11 S5 first-floor integration. Actual collision/visibility callbacks only.
This is a rule model, not Unity movement, skill input, or on-disk persistence.
"""
from dataclasses import dataclass, field
from copy import deepcopy
from rules import Life
from awareness import Awareness
from s5_people import People5, EDGES, ROSTER
from s5_support import Support5
from combat_flow import CombatFlow, SPECS

ROOMS = ('atrium','memory','visual','decision','body','bridge')
CONNECTIONS = {r:{next(iter(e-{r})) for e in EDGES if r in e} for r in ROOMS}

@dataclass
class S5Session:
    life: Life=field(default_factory=lambda:Life(progress=5,place='S5_atrium'))
    awareness: Awareness=field(default_factory=Awareness)
    people: People5=field(default_factory=People5)
    support: Support5=field(default_factory=Support5)
    combat: CombatFlow=field(default_factory=CombatFlow)
    position: str='atrium'
    paused: bool=False
    loading: bool=False
    chased: bool=False
    seen: set=field(default_factory=set)
    applied: set=field(default_factory=set)
    holder: str|None=None
    hold_remaining: int=0
    hit_stop: int=0
    body_generation: int=0
    free_gap: int=800
    attack_generation: dict=field(default_factory=dict)
    serial: int=0
    wounds: list=field(default_factory=list)
    prior: dict=field(default_factory=dict)

    def __post_init__(self):
        if self.life.progress!=5 or self.life.phase!='alive':raise ValueError('actual S5 entry required')
        self.life.economy.battle=True
        for m in (self.people,self.support,self.combat):
            m.attempt=self.life.attempts[5];m.epoch=self.life.epoch
        # People5 constructed at another attempt needs the actual probability.
        for e in self.people.entities.values():e.spawn.k=self.life.attempts[5]
        self._visit(self.position)
        self._sync()

    @classmethod
    def from_s4(cls, source):
        if source.life.progress!=5 or source.life.phase!='alive':raise ValueError('S4 exit not completed')
        return cls(life=deepcopy(source.life),awareness=deepcopy(source.awareness),
                   prior={k:deepcopy(getattr(source,k)) for k in ('archive','cortex','records','routes','prior')})

    def active(self):return self.life.progress==5 and self.life.phase=='alive' and not(self.paused or self.loading)
    def blocked(self):return bool(self.holder or self.hit_stop or self.life.stun)
    def _t(self,label):self.serial+=1;return(self.life.attempts[5],(label,self.serial))
    def _p(self,label):return self.people.token(self._t(label))
    def node(self,token):
        self._sync()
        if not self.active() or token[0]!=self.life.epoch or token in self.seen:return False
        self.seen.add(token);return True

    def _release(self):
        if self.holder is not None:
            self.holder=None;self.hold_remaining=0
            self.body_generation+=1;self.free_gap=0

    def _sync(self):
        invalid=self.life.phase!='alive' or self.life.progress!=5
        self.people.sync_context(attempt=self.life.attempts[5],epoch=self.life.epoch,
            paused=self.paused,loading=self.loading,dead=invalid,avatar_room=self.position,chased=self.chased)
        actors={a:{'alive':e.alive and e.present,'room':e.room} for a,e in self.people.entities.items()}
        self.combat.sync_context(attempt=self.life.attempts[5],epoch=self.life.epoch,
            paused=self.paused or self.loading,dead=invalid,active=self.life.progress==5,actors=actors)
        current=self.combat.current(self.holder) if self.holder else None
        if self.holder and (not current or current['phase']!='held' or current['hold_target']!='avatar'):
            self._release()
        self.support.sync_context(attempt=self.life.attempts[5],epoch=self.life.epoch,
            paused=self.paused or self.loading,dead=invalid,hp=self.life.hp,avatar_room=self.position,
            actors={a:{'alive':e.alive,'present':e.present,'room':e.room} for a,e in self.people.entities.items()},
            chased=self.chased,body_blocked=self.blocked(),known_connections=CONNECTIONS)
        self.awareness.mode='battle';self.awareness.paused=self.paused or self.loading
        self.awareness.alive=not invalid

    def _visit(self,room):
        floor=2 if room=='bridge' else 1
        self.life.economy.credit(('explore',5,floor,room),1)

    def decision(self,visible_danger=False):
        if self.life.phase!='alive':return self.life.phase
        if self.paused or self.loading:return 'paused'
        if self.blocked():return 'wait_effect'
        if visible_danger:return 'evade'
        return 'continue_floor2' if self.position=='bridge' else 'escape'

    def move(self,token,dest,*,actual=True,passable=True):
        if not self.node(token) or self.blocked() or not actual or not passable or dest not in CONNECTIONS[self.position]:return False
        self.position=dest;self.life.place='S5_'+dest;self._visit(dest);self._sync();return True

    def spawn_check(self,token,actor,roll,*,first=False):
        if not self.node(token):return False
        return self.people.check_spawn(self._p('spawn'),actor,roll,first=first)

    def enter_pending(self,token,*,entry_free=True):
        if not self.node(token):return ()
        result=self.people.enter_pending(self._p('enter'),self.position,entry_free=entry_free)
        self._sync();return result

    def actor_move(self,token,actor,dest,*,passable=True,bed_passable=True):
        if not self.node(token):return False
        result=self.people.move(self._p('move'),actor,dest,passable=passable,bed_passable=bed_passable)
        self._sync();return result

    def observe(self,token,actor,*,actual_visible=True,avatar_pos=(0,0)):
        if not self.node(token):return False
        return self.people.observe(self._p('see'),actor,avatar_pos,actual_visible=actual_visible)

    def meet_parents(self,token,*,mutual_visible=True):
        if not self.node(token):return False
        return self.people.meet_parents(self._p('parents'),mutual_visible=mutual_visible)

    def start_attack(self,token,actor,*,target=None,direction=(1,0),actual_seen=True,range_ready=True,route_safe=True):
        if not self.node(token) or actor not in SPECS:return None
        e=self.people.entities[actor]
        target=target or e.target
        if not e.present or not e.alive or not target:return None
        if target=='avatar':
            if e.room!=self.position or not e.sees_avatar:return None
        else:
            other=self.people.entities.get(target)
            if other is None or not other.present or not other.alive or other.room!=e.room:return None
        aid=self.combat.start(self._t('start'),actor,target=target,direction=direction,
            actual_seen=actual_seen,range_ready=range_ready,route_safe=route_safe,
            body_free=not self.blocked(),free_gap_ms=self.free_gap,callback_epoch=self.life.epoch)
        if aid:self.attack_generation[aid]=self.body_generation
        return aid

    def bandage(self,token,*,actual_contact=True):
        if not self.node(token):return False
        return self.support.start_bandage(self._t('bandage'),actual_contact=actual_contact,callback_epoch=self.life.epoch)

    def suggest(self,token,dest,*,visible=True,reachable=True):
        if not self.node(token):return False
        return self.support.suggest_door(self._t('suggest'),dest,actual_visible=visible,actual_reachable=reachable,callback_epoch=self.life.epoch)

    def speak(self,token,actor):
        if not self.node(token):return None
        text=self.people.friend_dialogue(self._p('speech'),actor)
        if text:self.paused=True;self._sync()
        return text

    def kick_contact(self,token,actor,*,authorised=False,actual_body_hit=True):
        # Receives an already-authorised actual kick. Skill submission, cost and
        # attack timing are deliberately not invented by this adapter.
        if not self.node(token) or not authorised or self.blocked() or not actual_body_hit:return False
        result=self.people.damage(self._p('kick'),actor,15,source='avatar',actual=True)
        if result is None:return False
        self.combat.interrupt(actor,actual_body_hit=True,callback_epoch=self.life.epoch)
        if actor=='nurse':self.support.interrupt_bandage('nurse_attacked')
        self._sync();return True

    def release_grip(self,token,actor):
        if not self.node(token):return False
        result=self.combat.release(actor,callback_epoch=self.life.epoch)
        self._sync();return result

    def stop_motion(self,token,aid,*,actual_obstacle=True):
        if not self.node(token):return False
        return self.combat.stop_motion(aid,actual_obstacle=actual_obstacle,callback_epoch=self.life.epoch)

    def frame(self,token,*,contacts=(),complete_bandage=False,cross_to_bridge=False,hp_damage=0,sp_damage=0):
        if not self.node(token):return 'ignored'
        crossing=cross_to_bridge and self.position=='decision' and not self.blocked()
        old_blocked=self.blocked()
        proposed=None
        if complete_bandage and self.support.complete_bandage(self._t('finish_bandage'),callback_epoch=self.life.epoch):
            proposed=self.support.effects[-1]
        new=[]
        for contact in contacts:
            c=dict(contact);aid=c.pop('attack_id');target=c.pop('target','avatar')
            attack=self.combat.attacks.get(aid)
            if not attack:continue
            actor=self.people.entities[attack['actor']]
            target_room=self.position if target=='avatar' else getattr(self.people.entities.get(target),'room',None)
            if actor.room!=target_room:continue
            can_hold=(not self.blocked() and self.holder is None and self.free_gap>=800
                      and self.attack_generation.get(aid)==self.body_generation)
            effect=self.combat.contact(self._t('contact'),aid,target,
                can_hold=can_hold if target=='avatar' else True,callback_epoch=self.life.epoch,**c)
            if effect and effect['id'] not in self.applied:
                self.applied.add(effect['id']);new.append(effect)
        avatar=[e for e in new if e['target']=='avatar']
        npc=[e for e in new if e['target']!='avatar']
        hits=[]
        for e in npc:
            source=e['actor']
            # Only a verified still-moving bed from CombatFlow may submit this
            # environmental impact after its operator has already died.
            if source=='assistant' and not self.people.entities[source].alive:source='moving_bed'
            hits.append({'actor':e['target'],'amount':e['hp'],'source':source,'actual':True,'event_id':str(e['id'])})
            if e['target']=='nurse':self.support.interrupt_bandage('nurse_attacked')
        if hits:self.people.apply_hits(self._p('impact_batch'),hits)
        damage_hp=hp_damage+sum(e['hp'] for e in avatar)
        damage_sp=sp_damage+sum(e['sp'] for e in avatar)
        events=[('hp_damage',damage_hp),('sp_damage',damage_sp)]
        if proposed:events.append(('heal_hp',proposed['hp_heal']))
        result=self.life.frame(token,events)
        if proposed:
            self.support.resolve_bandage(proposed['id'],applied=result=='alive',survived=result=='alive')
        elif avatar or hp_damage or sp_damage:
            self.support.interrupt_bandage('avatar_attacked')
        if damage_hp or damage_sp:self.wounds.append((self.life.epoch,token,damage_hp,damage_sp))
        if result=='death':
            self._release();self.hit_stop=0;self._sync();return result
        if (damage_hp or damage_sp) and not self.hit_stop:self.hit_stop=250
        holds=[e for e in avatar if e['hold_ms']]
        if holds and self.holder is None:
            self.holder=holds[0]['actor'];self.hold_remaining=holds[0]['hold_ms'];self.body_generation+=1;self.free_gap=0
        if not old_blocked and self.blocked():self.free_gap=0
        if crossing:
            self.position='bridge';self.life.place='S5_bridge';self._visit('bridge')
        self._sync()
        return 'floor2' if crossing else result

    def tick(self,token,ms):
        if ms<0:raise ValueError('negative time')
        if not self.node(token):return False
        remaining=ms
        while remaining:
            durations=[x for x in (self.hold_remaining,self.hit_stop,self.life.stun) if x>0]
            step=min([remaining]+durations)
            was_blocked=self.blocked()
            self.life.tick(step);self.people.tick(step);self.combat.tick(step);self.support.tick(step)
            self.hit_stop=max(0,self.hit_stop-step)
            self.hold_remaining=max(0,self.hold_remaining-step)
            if self.holder and self.hold_remaining==0:self._release()
            if not was_blocked:self.free_gap=min(800,self.free_gap+step)
            remaining-=step;self._sync()
        return True

    def revive(self):
        if not self.life.revive():return False
        self.position='atrium';self.life.place='S5_atrium'
        self.holder=None;self.hold_remaining=self.hit_stop=0
        self.body_generation+=1;self.free_gap=800;self.chased=False
        self._sync();self._visit('atrium');return True

    def reload(self):return deepcopy(self)
