"""S5 first-floor attacks, abstract verified contact inputs; no physical simulation.
Sources S3:P1288-1408; S4:P142-159,P210-219,P246,P264-265.
"""
from dataclasses import dataclass, field
from copy import deepcopy

SPECS = {
    'father': dict(hp=15, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=False, reach=1.2),
    'mother': dict(hp=10, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=True, reach=1.2),
    'cat': dict(hp=10, sp=5, windup=600, active=400, recovery=800, cooldown=1500, grab=False, max_move=1.8),
    'doctor': dict(hp=15, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=False, reach=1.2),
    'assistant': dict(hp=20, sp=0, windup=1200, active=600, recovery=800, cooldown=2000, grab=False, max_move=3.0),
    'archivist': dict(hp=10, sp=0, windup=800, active=300, recovery=600, cooldown=1500, grab=True, reach=1.2),
    'orderly': dict(hp=15, sp=5, windup=800, active=300, recovery=600, cooldown=1500, grab=False, reach=1.6),
}
BUSY = {'windup', 'active', 'held', 'recovery', 'cooldown'}
SLOTS = {'windup', 'active', 'held', 'recovery'}

@dataclass
class CombatFlow:
    attempt: int = 1
    epoch: int = 0
    paused: bool = False
    dead: bool = False
    active: bool = True
    actors: dict = field(default_factory=dict)
    attacks: dict = field(default_factory=dict)
    seen: set = field(default_factory=set)
    effects: list = field(default_factory=list)
    releases: list = field(default_factory=list)
    facts: list = field(default_factory=list)
    clock: int = 0
    serial: int = 0
    last_avatar_start: int | None = None

    def _valid(self, token, callback_epoch=None):
        return (self.active and not self.dead and not self.paused
                and isinstance(token, tuple) and len(token) == 2
                and token[0] == self.attempt and token not in self.seen
                and (callback_epoch is None or callback_epoch == self.epoch))

    def _alive(self, target):
        return not self.dead if target == 'avatar' else bool(self.actors.get(target, {}).get('alive', False))

    def current(self, actor):
        return next((a for a in reversed(list(self.attacks.values()))
                     if a['actor'] == actor and a['phase'] in BUSY), None)

    @property
    def slots(self):
        return sum(a['target'] == 'avatar' and a['phase'] in SLOTS for a in self.attacks.values())

    def _release(self, a, reason):
        if a['hold_target'] is not None:
            self.releases.append({'attack_id': a['id'], 'actor': a['actor'],
                                  'target': a['hold_target'], 'reason': reason})
            a['hold_target'] = None

    def _phase(self, a, phase, reason=None):
        if a['phase'] == 'held' and phase != 'held':
            self._release(a, reason or phase)
        a['phase'], a['elapsed'] = phase, 0
        self.facts.append(('phase', a['id'], phase, reason))

    def sync_context(self, *, attempt, epoch, paused=False, dead=False, active=True, actors=None):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        changed = attempt != self.attempt or epoch != self.epoch
        if changed or dead or not active:
            for a in self.attacks.values():
                if a['phase'] in BUSY:
                    self._phase(a, 'finished', 'new_context' if changed else 'inactive')
            self.last_avatar_start = None
        if attempt != self.attempt:
            self.seen.clear()
        self.attempt, self.epoch = attempt, epoch
        self.paused, self.dead, self.active = paused, dead, active
        if actors is not None:
            self.actors = deepcopy(actors)
        # Destroyed actors cancel ordinary strikes; a launched bed retains motion.
        for a in self.attacks.values():
            if a['phase'] in {'windup', 'active', 'held'}:
                actor_alive = self._alive(a['actor'])
                target_alive = self._alive(a['target'])
                launched_bed = a['actor'] == 'assistant' and a['phase'] == 'active'
                if (not actor_alive or not target_alive) and not launched_bed:
                    self._phase(a, 'recovery', 'actor_or_target_left')
        return True

    def start(self, token, actor, target='avatar', direction='forward', *, actual_seen=True,
              range_ready=True, route_safe=True, body_free=True, free_gap_ms=800,
              callback_epoch=None):
        if not self._valid(token, callback_epoch) or actor not in SPECS:
            return None
        if not (self._alive(actor) and self._alive(target) and actual_seen and range_ready and route_safe):
            return None
        if self.current(actor) is not None:
            return None
        if target == 'avatar':
            if self.slots >= 2 or (self.last_avatar_start is not None and self.clock - self.last_avatar_start < 800):
                return None
            if SPECS[actor]['grab'] and (not body_free or free_gap_ms < 800):
                return None
        self.seen.add(token)
        self.serial += 1
        aid = (self.epoch, self.attempt, self.serial)
        a = dict(id=aid, actor=actor, target=target, direction=deepcopy(direction),
                 phase='windup', elapsed=0, started=self.clock, hit_targets=set(),
                 hold_target=None, hold_granted=False, room=self.actors[actor].get('room'))
        self.attacks[aid] = a
        if target == 'avatar':
            self.last_avatar_start = self.clock
        self.facts.append(('start', aid, actor, target, deepcopy(direction)))
        return aid

    def _effect(self, a, target, hp, sp, hold):
        eid = ('combat', a['id'], target, 'hold' if hold and target in a['hit_targets'] else 'hit')
        out = dict(id=eid, attack_id=a['id'], actor=a['actor'], target=target,
                   hp=hp, sp=sp, hold_ms=hold, direction=deepcopy(a['direction']))
        self.effects.append(out)
        return out

    def contact(self, token, attack_id, target='avatar', *, actual_contact=True,
                obstructed=False, grip_closed=False, can_hold=True, callback_epoch=None):
        if not self._valid(token, callback_epoch) or not actual_contact or obstructed:
            return None
        a = self.attacks.get(attack_id)
        if not a or a['id'][:2] != (self.epoch, self.attempt) or a['phase'] != 'active' or not self._alive(target):
            return None
        if not self._alive(a['actor']) and a['actor'] != 'assistant':
            return None
        spec = SPECS[a['actor']]
        first = target not in a['hit_targets']
        grant = bool(spec['grab'] and grip_closed and can_hold and not a['hold_granted'])
        if grant and target == 'avatar':
            grant = not any(b['phase'] == 'held' and b['hold_target'] == 'avatar' for b in self.attacks.values())
        if not first and not grant:
            return None
        self.seen.add(token)
        out = self._effect(a, target, spec['hp'] if first else 0, spec['sp'] if first else 0, 1200 if grant else 0)
        a['hit_targets'].add(target)
        if grant:
            a['hold_granted'], a['hold_target'] = True, target
            self._phase(a, 'held')
        return out

    def release(self, actor, *, callback_epoch=None):
        if callback_epoch is not None and callback_epoch != self.epoch:
            return False
        a = self.current(actor)
        if not a or a['phase'] != 'held':
            return False
        self._phase(a, 'recovery', 'actual_release')
        return True

    def interrupt(self, actor, *, actual_body_hit=True, callback_epoch=None):
        if not self.active or self.dead or self.paused or not actual_body_hit or (callback_epoch is not None and callback_epoch != self.epoch):
            return False
        a = self.current(actor)
        if not a or a['phase'] not in {'windup', 'active', 'held'}:
            return False
        if actor == 'assistant' and a['phase'] == 'active':
            self.facts.append(('assistant_hit_bed_continues', a['id']))
            return True
        self._phase(a, 'recovery', 'actual_interrupt')
        return True

    def stop_motion(self, attack_id, *, actual_obstacle=True, callback_epoch=None):
        if not self.active or self.dead or self.paused or not actual_obstacle or (callback_epoch is not None and callback_epoch != self.epoch):
            return False
        a = self.attacks.get(attack_id)
        if not a or a['id'][:2] != (self.epoch, self.attempt) or a['actor'] not in {'cat', 'assistant'} or a['phase'] != 'active':
            return False
        self._phase(a, 'recovery', 'physical_stop')
        return True

    def move_actor(self, actor, room, *, actual_move=True, callback_epoch=None):
        if not self.active or self.dead or self.paused or not actual_move or (callback_epoch is not None and callback_epoch != self.epoch) or not self._alive(actor):
            return False
        self.actors[actor]['room'] = room
        a = self.current(actor)
        if a:
            a['room'] = room
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if self.paused or self.dead or not self.active:
            return False
        self.clock += ms
        for a in self.attacks.values():
            rest = ms
            spec = SPECS[a['actor']]
            while rest > 0 and a['phase'] in BUSY:
                phase = a['phase']
                duration = 1200 if phase == 'held' else spec[phase]
                step = min(rest, duration - a['elapsed'])
                a['elapsed'] += step
                rest -= step
                if a['elapsed'] >= duration:
                    nxt = {'windup': 'active', 'active': 'recovery', 'held': 'recovery',
                           'recovery': 'cooldown', 'cooldown': 'finished'}[phase]
                    self._phase(a, nxt, 'timeout')
        return True
