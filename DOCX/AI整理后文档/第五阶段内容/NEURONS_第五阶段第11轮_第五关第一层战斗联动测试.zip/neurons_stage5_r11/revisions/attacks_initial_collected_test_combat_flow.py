from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from combat_flow import CombatFlow, SPECS

ACTORS = dict.fromkeys(SPECS)
ACTORS.update(dog=None,nurse=None,corner=None)

def make():
    f=CombatFlow()
    f.sync_context(attempt=1,epoch=0,actors={a:dict(alive=True,room='atrium') for a in ACTORS})
    return f

def tok(i, attempt=1): return (attempt,str(i))

def launch(f, actor, target='avatar'):
    a=f.start(tok(('s',actor,len(f.attacks))),actor,target)
    assert a is not None
    f.tick(SPECS[actor]['windup'])
    return a

@pytest.mark.parametrize('actor',list(SPECS))
def test_windup_real_contact_boundary(actor):
    f=make(); a=f.start(tok(1),actor); w=SPECS[actor]['windup']
    f.tick(w-1)
    assert f.contact(tok(2),a) is None
    f.tick(1)
    e=f.contact(tok(2),a)
    expected={'father':(15,0),'mother':(10,0),'cat':(10,5),'doctor':(15,0),'assistant':(20,0),'archivist':(10,0),'orderly':(15,5)}[actor]
    assert (e['hp'],e['sp'])==expected
    assert f.contact(tok(3),a) is None

@pytest.mark.parametrize('actor',list(SPECS))
def test_recovery_and_cooldown_are_sequential(actor):
    f=make(); a=launch(f,actor); p=SPECS[actor]
    f.tick(p['active']-1)
    assert f.attacks[a]['phase']=='active'
    f.tick(1)
    assert f.attacks[a]['phase']=='recovery'
    assert f.slots==1
    f.tick(p['recovery']-1)
    assert f.start(tok(9),actor) is None
    f.tick(1)
    assert f.attacks[a]['phase']=='cooldown' and f.slots==0
    f.tick(p['cooldown']-1)
    assert f.start(tok(9),actor) is None
    f.tick(1)
    assert f.start(tok(9),actor) is not None

@pytest.mark.parametrize('actor',list(SPECS))
@pytest.mark.parametrize('missing',['sight','range','safe'])
def test_actual_seen_range_safe_required(actor,missing):
    f=make(); kwargs={'actual_seen':True,'range_ready':True,'route_safe':True}
    kwargs[{'sight':'actual_seen','range':'range_ready','safe':'route_safe'}[missing]]=False
    assert f.start(tok(1),actor,**kwargs) is None
    assert not f.attacks

@pytest.mark.parametrize('actor',list(SPECS))
def test_miss_or_obstacle_is_not_damage(actor):
    f=make(); a=launch(f,actor)
    assert f.contact(tok(2),a,actual_contact=False) is None
    assert f.contact(tok(3),a,obstructed=True) is None
    assert f.effects==[]

@pytest.mark.parametrize('actor',['mother','archivist'])
def test_scrape_then_closed_grip_only_damage_once(actor):
    f=make(); a=launch(f,actor)
    e=f.contact(tok(2),a,grip_closed=False)
    assert e['hp']==10 and e['hold_ms']==0
    e2=f.contact(tok(3),a,grip_closed=True)
    assert e2['hp']==0 and e2['sp']==0 and e2['hold_ms']==1200
    assert len({e['id'] for e in f.effects})==2
    f.tick(1199)
    assert f.attacks[a]['phase']=='held' and f.slots==1
    f.tick(1)
    assert f.attacks[a]['phase']=='recovery' and len(f.releases)==1
    assert sum(e['hp'] for e in f.effects)==10

@pytest.mark.parametrize('actor',['mother','archivist'])
def test_no_hold_does_not_cancel_actual_damage(actor):
    f=make(); a=launch(f,actor)
    e=f.contact(tok(2),a,grip_closed=True,can_hold=False)
    assert (e['hp'],e['hold_ms'])==(10,0)
    assert f.attacks[a]['phase']=='active'

@pytest.mark.parametrize('actor',['mother','archivist'])
@pytest.mark.parametrize('body,gap',[(False,800),(True,0),(True,799)])
def test_grab_requires_new_free_800ms_before_windup(actor,body,gap):
    f=make()
    assert f.start(tok(1),actor,body_free=body,free_gap_ms=gap) is None


def test_global_gap_799_800_and_two_slots_through_recovery():
    f=make(); a=f.start(tok(1),'assistant'); f.tick(799)
    assert f.start(tok(2),'father') is None
    f.tick(1); b=f.start(tok(2),'father'); assert b is not None
    f.tick(800)
    assert f.slots==2
    assert f.start(tok(3),'cat') is None
    f.tick(900) # father recovery complete at 2500; assistant until2600
    assert f.slots==1
    assert f.start(tok(3),'cat') is not None


def test_non_avatar_target_does_not_reserve_slot_but_collateral_hurts():
    f=make(); a=f.start(tok(1),'father','mother',direction='west')
    b=f.start(tok(2),'doctor'); assert b is not None
    f.tick(800)
    assert f.slots==1
    e=f.contact(tok(3),a,'mother'); x=f.contact(tok(4),a,'avatar')
    assert e['hp']==x['hp']==15 and x['direction']=='west'
    assert f.slots==1 and f.attacks[a]['target']=='mother'


def test_hold_of_collateral_blocks_another_grip_not_another_real_hit():
    f=make(); a=f.start(tok(1),'mother','father'); b=f.start(tok(2),'archivist')
    f.tick(800); e=f.contact(tok(3),a,'avatar',grip_closed=True)
    h=f.contact(tok(4),b,'avatar',grip_closed=True)
    assert e['hold_ms']==1200 and h['hp']==10 and h['hold_ms']==0
    assert f.slots==1

@pytest.mark.parametrize('actor',['father','mother','cat','doctor','archivist','orderly'])
def test_real_body_hit_interrupts_pending_ordinary_attack(actor):
    f=make(); a=launch(f,actor)
    assert f.interrupt(actor,actual_body_hit=False) is False
    assert f.interrupt(actor) is True
    assert f.attacks[a]['phase']=='recovery'
    assert f.contact(tok(2),a) is None


def test_already_dealt_damage_survives_interrupt():
    f=make(); a=launch(f,'father'); e=f.contact(tok(2),a)
    f.interrupt('father')
    assert f.effects==[e] and e['hp']==15


def test_assistant_windup_body_hit_cancels_but_bed_frame_hit_does_not():
    f=make(); a=f.start(tok(1),'assistant'); f.tick(1199)
    assert not f.interrupt('assistant',actual_body_hit=False)
    assert f.interrupt('assistant')
    f.tick(1)
    assert f.contact(tok(2),a) is None


def test_launched_bed_survives_assistant_hit_or_death_then_stops():
    f=make(); a=launch(f,'assistant')
    assert f.interrupt('assistant')
    actors=deepcopy(f.actors); actors['assistant']['alive']=False
    f.sync_context(attempt=1,epoch=0,actors=actors)
    assert f.attacks[a]['phase']=='active'
    assert f.contact(tok(2),a)['hp']==20
    f.stop_motion(a)
    assert f.contact(tok(3),a,'dog') is None
    assert f.slots==1
    f.tick(800)
    assert f.slots==0

@pytest.mark.parametrize('actor',['cat','assistant'])
def test_actual_obstacle_stops_motion_without_extra_wall_damage(actor):
    f=make(); a=launch(f,actor)
    assert not f.stop_motion(a,actual_obstacle=False)
    assert f.stop_motion(a)
    assert f.effects==[] and f.contact(tok(2),a) is None


def test_attack_direction_and_elapsed_and_cooldown_survive_move():
    f=make(); direction=[1,0]; a=f.start(tok(1),'father',direction=direction)
    direction[0]=999; f.tick(600)
    f.move_actor('father','decision')
    assert f.attacks[a]['direction']==[1,0] and f.attacks[a]['elapsed']==600
    f.tick(1100)
    assert f.attacks[a]['phase']=='cooldown'
    f.move_actor('father','atrium')
    assert f.attacks[a]['phase']=='cooldown' and f.attacks[a]['elapsed']==0


def test_paused_world_does_not_start_advance_hit_or_release():
    f=make(); a=launch(f,'mother'); f.contact(tok(2),a,grip_closed=True)
    f.sync_context(attempt=1,epoch=0,paused=True,actors=f.actors)
    snap=deepcopy(f.attacks)
    f.tick(2000)
    assert f.start(tok(3),'father') is None and f.contact(tok(4),a) is None
    assert not f.release('mother')
    assert f.attacks==snap

@pytest.mark.parametrize('state',['dead','inactive','epoch','attempt'])
def test_terminal_change_invalidates_old_damage_and_releases(state):
    f=make(); a=launch(f,'mother'); f.contact(tok(2),a,grip_closed=True)
    kw=dict(attempt=1,epoch=0,actors=f.actors)
    kw.update({'dead':True} if state=='dead' else {'active':False} if state=='inactive' else {'epoch':1} if state=='epoch' else {'attempt':2,'epoch':1})
    f.sync_context(**kw)
    assert f.slots==0 and len(f.releases)==1
    assert f.contact(tok(3),a,callback_epoch=0) is None


def test_stale_epoch_async_callbacks_rejected():
    f=make(); a=launch(f,'assistant')
    assert f.contact(tok(2),a,callback_epoch=999) is None
    assert not f.stop_motion(a,callback_epoch=999)
    assert not f.interrupt('assistant',callback_epoch=999)
    assert not f.move_actor('assistant','body',callback_epoch=999)
    assert f.start(tok(3),'father',callback_epoch=999) is None


def test_dead_target_normal_pending_hit_cancelled_but_not_phantom_revived():
    f=make(); a=f.start(tok(1),'father','nurse')
    actors=deepcopy(f.actors);actors['nurse']['alive']=False
    f.sync_context(attempt=1,epoch=0,actors=actors)
    f.tick(800)
    assert f.contact(tok(2),a,'avatar') is None
    assert not f.actors['nurse']['alive']


def test_duplicate_token_cannot_start_or_hit_twice_and_rejected_input_not_consumed():
    f=make();assert f.start(tok(1),'father',actual_seen=False) is None
    a=f.start(tok(1),'father'); f.tick(800)
    assert f.start(tok(1),'mother') is None
    assert f.contact(tok(2),a) is not None
    assert f.contact(tok(2),a) is None


def test_reload_exact_state_and_next_contact_dedup():
    f=make();a=launch(f,'father');f.contact(tok(2),a)
    g=deepcopy(f)
    assert g.contact(tok(3),a) is None
    assert g.__dict__==f.__dict__


def test_large_tick_equivalent_to_small_ticks_in_timing():
    f=make();a=f.start(tok(1),'assistant');g=deepcopy(f)
    f.tick(9999)
    for _ in range(9999):g.tick(1)
    assert f.attacks==g.attacks and f.slots==g.slots==0


class AttackMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__(); self.f=make(); self.i=0
    def token(self):
        self.i+=1;return tok(self.i,self.f.attempt)
    @rule(actor=st.sampled_from(list(SPECS)),victim=st.sampled_from(['avatar','dog','mother','father']),sight=st.booleans(),safe=st.booleans(),gap=st.sampled_from([0,799,800]))
    def start(self,actor,victim,sight,safe,gap):
        self.f.start(self.token(),actor,victim,actual_seen=sight,route_safe=safe,free_gap_ms=gap)
    @rule(ms=st.sampled_from([0,1,249,300,599,600,799,800,1199,1200,2000]))
    def tick(self,ms): self.f.tick(ms)
    @rule(actor=st.sampled_from(list(SPECS)),victim=st.sampled_from(['avatar','dog','mother']),actual=st.booleans(),blocked=st.booleans(),closed=st.booleans(),canhold=st.booleans())
    def hit(self,actor,victim,actual,blocked,closed,canhold):
        a=self.f.current(actor)
        if a:self.f.contact(self.token(),a['id'],victim,actual_contact=actual,obstructed=blocked,grip_closed=closed,can_hold=canhold)
    @rule(actor=st.sampled_from(list(SPECS)),actual=st.booleans())
    def interrupt(self,actor,actual):self.f.interrupt(actor,actual_body_hit=actual)
    @rule(actor=st.sampled_from(list(SPECS)),actual=st.booleans())
    def stop(self,actor,actual):
        a=self.f.current(actor)
        if a:self.f.stop_motion(a['id'],actual_obstacle=actual)
    @rule(actor=st.sampled_from(list(SPECS)))
    def release(self,actor):self.f.release(actor)
    @rule(actor=st.sampled_from(list(SPECS)),room=st.sampled_from(['atrium','decision','body']))
    def move(self,actor,room):self.f.move_actor(actor,room)
    @rule(pause=st.booleans())
    def pause(self,pause):self.f.sync_context(attempt=self.f.attempt,epoch=self.f.epoch,paused=pause,actors=self.f.actors)
    @rule()
    def death_revive(self):
        self.f.sync_context(attempt=self.f.attempt,epoch=self.f.epoch,dead=True,actors=self.f.actors)
        self.f.sync_context(attempt=self.f.attempt+1,epoch=self.f.epoch+1,actors=self.f.actors)
    @rule()
    def reload(self):self.f=deepcopy(self.f)
    @invariant()
    def invariants(self):
        assert 0<=self.f.slots<=2
        assert sum(a['phase']=='held' and a['hold_target']=='avatar' for a in self.f.attacks.values())<=1
        ids=[e['id'] for e in self.f.effects];assert len(ids)==len(set(ids))
        damaged=[(e['attack_id'],e['target']) for e in self.f.effects if e['hp'] or e['sp']]
        assert len(damaged)==len(set(damaged))
        for actor in SPECS:
            assert sum(a['actor']==actor and a['phase'] in {'windup','active','held','recovery','cooldown'} for a in self.f.attacks.values())<=1
        starts=[a for a in self.f.attacks.values() if a['target']=='avatar']
        for a,b in zip(starts,starts[1:]):
            if a['id'][:2]==b['id'][:2]:assert b['started']-a['started']>=800

TestAttackMachine=AttackMachine.TestCase
TestAttackMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
