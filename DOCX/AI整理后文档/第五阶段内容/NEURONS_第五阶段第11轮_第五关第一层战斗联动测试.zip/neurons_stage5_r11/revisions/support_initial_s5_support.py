"""S5 first-floor friendly interactions; effect proposals require host settlement.
Sources: S3:P1295-1306,P1317-1328,P1339-1349; S4:P156-165,P264,P291.
No actor movement, collision geometry, dialogue, item inventory, or Life mutation.
"""
from copy import deepcopy
from dataclasses import dataclass, field


@dataclass
class Support5:
    attempt: int = 1
    epoch: int = 0
    hp: int = 100
    avatar_room: str = 'atrium'
    actors: dict = field(default_factory=dict)
    paused: bool = False
    dead: bool = False
    chased: bool = False
    body_blocked: bool = False
    active: bool = True
    known_connections: dict = field(default_factory=dict)
    progress_ms: int = 0
    phase: str = 'idle'
    used: bool = False
    material_started: bool = False
    material_count: int = 0
    bandaged: bool = False
    effects: list = field(default_factory=list)
    settlements: list = field(default_factory=list)
    facts: list = field(default_factory=list)
    seen: set = field(default_factory=set)
    pending_id: object = None
    suggestion: object = None
    contact_room: object = None
    serial: int = 0

    def _present(self, actor):
        state = self.actors.get(actor, {})
        return (state.get('alive', False) and state.get('present', False)
                and state.get('room') == self.avatar_room)

    def _live(self):
        return self.active and not self.dead and self.hp > 0 and not self.paused

    def _eligible(self):
        return (self._live() and self._present('nurse') and self.hp < 100
                and not self.chased and not self.body_blocked)

    def _token(self, token, callback_epoch=None):
        return (isinstance(token, tuple) and len(token) == 2
                and token[0] == self.attempt
                and (callback_epoch is None or callback_epoch == self.epoch)
                and (self.epoch, token) not in self.seen)

    def _mark(self, token):
        self.seen.add((self.epoch, token))

    def sync_context(self, *, attempt, epoch, paused=False, dead=False, hp=100,
                     avatar_room='atrium', actors=None, chased=False,
                     body_blocked=False, active=True, known_connections=None):
        if attempt < self.attempt or epoch < self.epoch:
            return False
        new_attempt = attempt != self.attempt
        old_hp, old_room, old_epoch = self.hp, self.avatar_room, self.epoch
        if new_attempt:
            self.interrupt_bandage('new_attempt')
            self.progress_ms = 0
            self.phase = 'idle'
            self.used = False
            self.material_started = False
            self.material_count = 0
            self.bandaged = False
            self.pending_id = None
            self.contact_room = None
            self.suggestion = None
            self.seen.clear()
        self.attempt, self.epoch = attempt, epoch
        self.paused, self.dead, self.hp = bool(paused), bool(dead), max(0, min(100, hp))
        self.avatar_room = avatar_room
        self.actors = deepcopy(actors or {})
        self.chased, self.body_blocked, self.active = bool(chased), bool(body_blocked), bool(active)
        if known_connections is not None:
            self.known_connections = {k: set(v) for k, v in known_connections.items()}
        # A formal pause freezes contact. Actual harm/departure interrupts it.
        disrupted = (dead or self.hp <= 0 or not active or chased or body_blocked
                     or not self._present('nurse') or old_room != avatar_room
                     or old_epoch != epoch or (not new_attempt and self.hp < old_hp))
        if disrupted:
            self.interrupt_bandage('context_change')
        return True

    def start_bandage(self, token, *, actual_contact=True, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._eligible()
                or not actual_contact or self.used or self.pending_id is not None
                or self.phase in {'bandaging', 'ready', 'completed'}):
            return False
        self._mark(token)
        if not self.material_started:
            self.material_started = True
            self.material_count += 1
        self.contact_room = self.avatar_room
        self.phase = 'ready' if self.progress_ms >= 3000 else 'bandaging'
        self.facts.append(('bandage_contact', self.attempt, self.epoch))
        return True

    def interrupt_bandage(self, reason='actual_interrupt'):
        if self.phase not in {'bandaging', 'ready', 'awaiting_resolution'}:
            return False
        # No partial heal or fresh materials. Host may already have queued the
        # proposal; settlement checks pending identity and live state again.
        self.pending_id = None
        self.contact_room = None
        self.phase = 'interrupted'
        self.facts.append(('bandage_interrupted', reason, self.progress_ms))
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative elapsed time')
        if self.paused:
            return
        if self.phase == 'bandaging' and self._eligible():
            self.progress_ms = min(3000, self.progress_ms + ms)
            if self.progress_ms == 3000:
                self.phase = 'ready'

    def complete_bandage(self, token, *, actual_completed=True, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._eligible()
                or self.phase != 'ready' or not actual_completed or self.used
                or self.progress_ms != 3000 or self.contact_room != self.avatar_room):
            return False
        self._mark(token)
        self.serial += 1
        self.pending_id = ('s5_bandage', self.epoch, self.attempt, self.serial)
        self.effects.append({'id': self.pending_id, 'kind': 'bandage',
                             'hp_heal': 20, 'sp_heal': 0,
                             'attempt': self.attempt, 'epoch': self.epoch})
        self.phase = 'awaiting_resolution'
        return True

    def resolve_bandage(self, effect_id, *, applied, survived):
        if self.pending_id != effect_id or self.phase != 'awaiting_resolution':
            return False
        ok = bool(applied and survived and self.active and not self.dead and self.hp > 0)
        self.settlements.append({'id': effect_id, 'applied': ok})
        self.pending_id = None
        if ok:
            self.used = self.bandaged = True
            self.phase = 'completed'
        else:
            self.phase = 'interrupted'
            self.contact_room = None
        return ok

    def suggest_door(self, token, door, *, actual_visible, actual_reachable,
                     existing=True, callback_epoch=None):
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('corner') or not actual_visible
                or not actual_reachable or not existing
                or door not in self.known_connections.get(self.avatar_room, set())):
            return False
        self._mark(token)
        self.suggestion = (self.avatar_room, door)
        self.facts.append(('door_indicated', self.attempt, self.suggestion))
        return True

    def dog_intercepts(self, token, actual_hit_order, *, actual_geometry=True,
                       callback_epoch=None):
        # Caller supplies verified collision order; this never removes an
        # avatar collision still present in an attack's actual area.
        if (not self._token(token, callback_epoch) or not self._live()
                or not self._present('dog') or not actual_geometry
                or not actual_hit_order or actual_hit_order[0] != 'dog'):
            return False
        self._mark(token)
        self.facts.append(('dog_intercepts', self.attempt, tuple(actual_hit_order)))
        return True
