from copy import deepcopy
from collections import deque
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s5_session import S5Session, CONNECTIONS
from combat_flow import SPECS
from s4_session import S4Session

class Driver:
    def __init__(self):self.s=S5Session();self.serial=0
    def n(self):self.serial+=1;return(self.s.life.epoch,self.serial)
    def tick(self,ms):return self.s.tick(self.n(),ms)
    def go(self,dest):
        q=deque([(self.s.position,[])]);seen={self.s.position}
        while q:
            here,path=q.popleft()
            if here==dest:
                for room in path:assert self.s.move(self.n(),room)
                return
            for room in CONNECTIONS[here]-seen:seen.add(room);q.append((room,path+[room]))
        raise AssertionError('unknown route')
    def add(self,actor,room=None):
        # Explicit encounter fixture, not evidence of a random spawn roll.
        e=self.s.people.entities[actor];e.present=True;e.room=room or e.home;e.spawn.state='present'
        if actor=='assistant':e.bed_room=e.room
        self.s._sync();return e
    def windup(self,actor,room=None,target='avatar'):
        self.go(room or self.s.people.entities[actor].home);self.add(actor,self.s.position)
        if target=='avatar':assert self.s.observe(self.n(),actor)
        aid=self.s.start_attack(self.n(),actor,target=target)
        assert aid
        self.tick(SPECS[actor]['windup']);return aid

def test_actual_s4_exit_preserves_resources_evidence_and_adds_only_first_scene_reward():
    old=S4Session();old.life.progress=5;old.life.place='S5_atrium';old.life.hp=31;old.life.sp=12;old.life.epoch=7
    old.life.economy.n=0;old.awareness.hints.add('read_actual_record')
    s=S5Session.from_s4(old)
    assert (s.life.hp,s.life.sp,s.life.economy.n,s.life.economy.battle)==(31,12,1,True)
    assert 'read_actual_record' in s.awareness.hints and s.awareness.mode=='battle'
    assert s.people.epoch==s.combat.epoch==s.support.epoch==7
    assert s.people.entities['father'].spawn.k==s.life.attempts[5]
    with pytest.raises(ValueError):S5Session.from_s4(S4Session())

@pytest.mark.parametrize('hp,sp,n,r',[(1,0,0,999),(1,1,0,999),(1,19,0,999),(1,100,0,999),(100,0,0,999),(100,1,5,0),(100,19,0,0),(100,100,0,999)])
def test_no_people_no_skill_no_resource_gate_to_second_floor(hp,sp,n,r):
    d=Driver();s=d.s;s.life.hp=hp;s.life.sp=sp;s.life.emptied=sp==0;s.life.economy.n=n
    s.life.economy.c=0;s.life.economy.global_r=r
    d.go('decision');assert s.frame(d.n(),cross_to_bridge=True)=='floor2'
    assert s.life.progress==5 and s.position=='bridge' and s.decision()=='continue_floor2'
    assert not s.life.rest() and not hasattr(s,'search')
    assert all(not e.present for e in s.people.entities.values())

def test_scene_income_once_across_loops_reload_and_actual_death():
    d=Driver();s=d.s;start=s.life.economy.n
    d.go('memory');d.go('visual');d.go('atrium');assert s.life.economy.n==start+2
    d.s=s=s.reload();d.go('memory');assert s.life.economy.n==start+2
    assert s.frame(d.n(),hp_damage=100)=='death';assert s.revive()
    d.go('memory');assert s.life.economy.n==start+2

def test_spawn_requires_free_entry_and_preserves_pending_without_duplicate_reentry():
    d=Driver();s=d.s
    assert s.spawn_check(d.n(),'father',0,first=True)
    assert s.enter_pending(d.n(),entry_free=False)==()
    assert s.people.entities['father'].spawn.state=='pending'
    assert s.enter_pending(d.n())==('father',)
    father=s.people.entities['father'];d.go('memory');d.tick(20000);d.go('atrium')
    assert not s.spawn_check(d.n(),'father',0) and s.people.entities['father'] is father

@pytest.mark.parametrize('actor,hp,sp',[('father',15,0),('mother',10,0),('cat',10,5),('doctor',15,0),('assistant',20,0),('archivist',10,0),('orderly',15,5)])
def test_actual_hit_values_and_repeated_limb_contacts_once(actor,hp,sp):
    d=Driver();aid=d.windup(actor);s=d.s
    c={'attack_id':aid,'actual_contact':True}
    assert s.frame(d.n(),contacts=[c,c])=='alive'
    assert (s.life.hp,s.life.sp)==(100-hp,100-sp)
    s.frame(d.n(),contacts=[c]);assert (s.life.hp,s.life.sp)==(100-hp,100-sp)

def test_miss_wall_and_unseen_actor_do_not_hit_or_start():
    d=Driver();s=d.s;d.add('father')
    assert not s.start_attack(d.n(),'father',target='avatar')
    assert s.observe(d.n(),'father');aid=s.start_attack(d.n(),'father');assert aid;d.tick(800)
    s.frame(d.n(),contacts=[{'attack_id':aid,'actual_contact':False},{'attack_id':aid,'obstructed':True}])
    assert s.life.hp==100

def test_parent_dog_actual_shatter_and_avatar_collateral_do_not_awaken_or_boost():
    d=Driver();s=d.s;d.add('dog');aid=d.windup('father',target='dog')
    start=(s.life.total,s.life.attempts.copy(),s.life.economy.n,s.life.economy.c)
    s.frame(d.n(),contacts=[{'attack_id':aid,'target':'dog'},{'attack_id':aid,'target':'avatar'}])
    assert not s.people.entities['dog'].alive and s.life.hp==85
    assert not s.life.economy.awakening and s.people.street_boost==0
    assert (s.life.total,s.life.attempts,s.life.economy.n,s.life.economy.c)==start
    assert not s.people.dog_repeated_death_feedback(witnessed=True)
    d.tick(250);d.go('memory');d.go('atrium');assert not s.people.entities['dog'].present

def test_father_presence_and_missed_swing_do_not_kill_dog():
    d=Driver();s=d.s;d.add('dog');aid=d.windup('father',target='dog')
    s.frame(d.n(),contacts=[{'attack_id':aid,'target':'dog','actual_contact':False}])
    assert s.people.entities['dog'].hp==60

def test_parents_do_not_retarget_an_already_started_swing():
    d=Driver();s=d.s;d.add('father');s.observe(d.n(),'father')
    aid=s.start_attack(d.n(),'father',direction=(2,0));d.add('mother','atrium')
    assert s.meet_parents(d.n())
    assert s.people.entities['father'].target=='mother'
    assert (s.combat.attacks[aid]['target'],s.combat.attacks[aid]['direction'])==('avatar',(2,0))
    assert not s.life.economy.awakening and s.life.total==1

def test_both_parents_actual_same_frame_lethal_hits_are_not_lost_to_iteration_order():
    d=Driver();s=d.s;d.add('father');d.add('mother','atrium')
    s.people.entities['father'].hp=s.people.entities['mother'].hp=10
    assert s.meet_parents(d.n())
    a=s.start_attack(d.n(),'father');b=s.start_attack(d.n(),'mother');assert a and b;d.tick(800)
    s.frame(d.n(),contacts=[{'attack_id':a,'target':'mother'},{'attack_id':b,'target':'father'}])
    assert not s.people.entities['father'].alive and not s.people.entities['mother'].alive
    assert s.life.hp==100 and s.life.phase=='alive' and not s.life.economy.awakening

def test_nurse_interruption_retains_progress_single_material_and_no_partial_healing():
    d=Driver();s=d.s;d.go('memory');d.add('nurse');s.life.hp=50
    assert s.bandage(d.n());d.tick(1500);s.frame(d.n(),sp_damage=5)
    assert s.support.phase=='interrupted' and s.support.progress_ms==1500 and s.life.hp==50
    d.tick(250);assert s.bandage(d.n());d.tick(1499)
    s.frame(d.n(),complete_bandage=True);assert s.life.hp==50
    d.tick(1);s.frame(d.n(),complete_bandage=True)
    assert s.life.hp==70 and s.life.sp==95 and s.support.used and s.support.material_count==1
    assert not s.bandage(d.n())

@pytest.mark.parametrize('damage,expected',[(49,'alive'),(50,'death'),(100,'death')])
def test_completed_bandage_cannot_reverse_same_frame_lethal_damage(damage,expected):
    d=Driver();s=d.s;d.go('memory');d.add('nurse');s.life.hp=50
    assert s.bandage(d.n());d.tick(3000)
    assert s.frame(d.n(),complete_bandage=True,hp_damage=damage)==expected
    assert s.life.hp==(21 if expected=='alive' else 0)
    assert s.support.used==(expected=='alive')

def test_nurse_hurt_interrupts_avatar_bandage_without_hurting_avatar():
    d=Driver();s=d.s;d.go('memory');d.add('nurse');d.add('father','memory');s.life.hp=50
    assert s.bandage(d.n());d.tick(1000)
    a=s.start_attack(d.n(),'father',target='nurse');assert a;d.tick(800)
    s.frame(d.n(),contacts=[{'attack_id':a,'target':'nurse'}])
    assert s.support.phase=='interrupted' and s.support.progress_ms==1800
    assert s.life.hp==50 and s.people.entities['nurse'].hp==25

def test_hold_stun_hitstop_overlap_and_free_gap_before_new_grab():
    d=Driver();s=d.s;aid=d.windup('mother');d.add('archivist','decision')
    assert s.observe(d.n(),'archivist')
    s.frame(d.n(),contacts=[{'attack_id':aid,'grip_closed':True}],sp_damage=100)
    assert s.holder=='mother' and s.life.stun==1000
    d.tick(1199);assert s.blocked();d.tick(1);assert not s.blocked() and s.free_gap==0
    assert not s.start_attack(d.n(),'archivist');d.tick(799);assert not s.start_attack(d.n(),'archivist')
    d.tick(1);assert s.start_attack(d.n(),'archivist')

def test_release_early_and_actor_death_end_physical_grip_immediately():
    d=Driver();s=d.s;aid=d.windup('archivist')
    s.frame(d.n(),contacts=[{'attack_id':aid,'grip_closed':True}]);d.tick(250)
    assert s.release_grip(d.n(),'archivist') and not s.blocked() and s.free_gap==0

def test_other_actual_hit_during_hold_damages_without_second_holder_or_extended_hitstop():
    d=Driver();s=d.s;d.go('decision');d.add('mother');d.add('father','decision')
    s.observe(d.n(),'mother');a=s.start_attack(d.n(),'mother');d.tick(800)
    s.observe(d.n(),'father');b=s.start_attack(d.n(),'father');d.tick(100)
    s.frame(d.n(),contacts=[{'attack_id':a,'grip_closed':True}]);d.tick(700)
    assert s.holder=='mother'
    s.frame(d.n(),contacts=[{'attack_id':b}]);assert s.life.hp==75 and s.holder=='mother' and s.hold_remaining==500
    d.tick(500);assert not s.blocked()

def test_pause_freezes_dialogue_attack_resources_and_bandage():
    d=Driver();s=d.s;d.go('memory');d.add('nurse');s.life.hp=50;s.life.economy.n=0
    assert s.bandage(d.n());d.tick(1000);assert s.speak(d.n(),'nurse')
    snap=(s.support.progress_ms,s.life.economy.fraction,s.people.time_ms,s.combat.clock)
    assert not d.tick(10000)
    assert (s.support.progress_ms,s.life.economy.fraction,s.people.time_ms,s.combat.clock)==snap
    s.paused=False;d.tick(2000);s.frame(d.n(),complete_bandage=True);assert s.life.hp==70
    assert s.speak(d.n(),'nurse') is None

def test_friend_speech_not_queued_after_chase_and_death():
    d=Driver();s=d.s;d.add('dog');s.chased=True
    assert s.speak(d.n(),'dog') is None
    s.chased=False;s.people.damage(s.people.token('actual_death'),'dog',60,source='environment')
    assert s.speak(d.n(),'dog') is None

def test_corner_indication_does_not_open_fake_exit_or_force_route():
    d=Driver();s=d.s;d.go('visual');d.add('corner')
    assert s.suggest(d.n(),'memory') and not s.suggest(d.n(),'bridge')
    assert s.position=='visual';d.go('atrium');d.go('decision')
    assert s.frame(d.n(),cross_to_bridge=True)=='floor2'

def test_first_floor_crossing_keeps_same_attacker_and_windup_direction():
    d=Driver();s=d.s;d.go('decision');d.add('father','decision');s.observe(d.n(),'father')
    aid=s.start_attack(d.n(),'father',direction=(1,2));d.tick(400)
    assert s.frame(d.n(),cross_to_bridge=True)=='floor2'
    assert s.actor_move(d.n(),'father','bridge')
    assert s.combat.attacks[aid]['phase']=='windup' and s.combat.attacks[aid]['elapsed']==400
    d.tick(400);s.frame(d.n(),contacts=[{'attack_id':aid}]);assert s.life.hp==85
    assert len([a for a in s.combat.attacks.values() if a['actor']=='father'])==1

@pytest.mark.parametrize('damage,expected',[(0,'floor2'),(99,'floor2'),(100,'death')])
def test_damage_and_actual_floor_crossing_one_node(damage,expected):
    d=Driver();s=d.s;d.go('decision')
    assert s.frame(d.n(),hp_damage=damage,cross_to_bridge=True)==expected
    assert s.position==('decision' if expected=='death' else 'bridge')
    assert s.life.progress==5

def test_assistant_started_bed_keeps_motion_when_operator_hit_then_physical_stop():
    d=Driver();s=d.s;aid=d.windup('assistant');assistant=s.people.entities['assistant'];assistant.hp=15
    assert s.kick_contact(d.n(),'assistant',authorised=True)
    assert not assistant.alive and s.combat.attacks[aid]['phase']=='active'
    s.frame(d.n(),contacts=[{'attack_id':aid}]);assert s.life.hp==80
    assert s.stop_motion(d.n(),aid)
    s.frame(d.n(),contacts=[{'attack_id':aid}]);assert s.life.hp==80

def test_kick_bed_frame_or_unauthorised_input_cannot_damage_operator():
    d=Driver();s=d.s;d.go('body');d.add('assistant')
    assert not s.kick_contact(d.n(),'assistant',authorised=False)
    assert not s.kick_contact(d.n(),'assistant',authorised=True,actual_body_hit=False)
    assert s.people.entities['assistant'].hp==60

def test_dead_assistant_moving_bed_can_still_hit_another_present_npc():
    d=Driver();s=d.s;aid=d.windup('assistant');d.add('dog','body');s.people.entities['assistant'].hp=15
    assert s.kick_contact(d.n(),'assistant',authorised=True)
    s.frame(d.n(),contacts=[{'attack_id':aid,'target':'dog'}]);assert s.people.entities['dog'].hp==40

@pytest.mark.parametrize('attempt',[1,5,6,1000000])
def test_actual_death_advances_s5_once_clears_attacks_preserves_cooldown_and_no_search(attempt):
    d=Driver();s=d.s;s.life.attempts[5]=attempt;s._sync();aid=d.windup('father')
    old=d.n();s.life.economy.skills['skin'].remaining=1100;s.life.economy.n=0
    assert s.frame(d.n(),hp_damage=100)=='death'
    assert not s.move(d.n(),'memory') and s.revive() and not s.revive()
    assert (s.life.total,s.life.attempts[5],s.life.attempts[4],s.position)==(4,attempt+1,1,'atrium')
    assert (s.life.hp,s.life.sp,s.life.economy.n)==(100,100,5)
    assert s.life.economy.skills['skin'].remaining==1100 and s.life.economy.battle
    assert s.frame(old,contacts=[{'attack_id':aid}])=='ignored'
    assert all(not e.present for e in s.people.entities.values()) and not hasattr(s,'search')

class S5Machine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.revives=0
        for actor in self.d.s.people.entities:self.d.add(actor)
    @rule(ms=st.sampled_from([0,1,249,250,799,800,999,1000,1199,1200,3000,4000]))
    def tick(self,ms):self.d.tick(ms)
    @rule(dest=st.sampled_from(list(CONNECTIONS)))
    def move(self,dest):self.d.s.move(self.d.n(),dest)
    @rule(actor=st.sampled_from(list(SPECS)))
    def attack(self,actor):
        s=self.d.s;s.observe(self.d.n(),actor);s.start_attack(self.d.n(),actor)
    @rule(actor=st.sampled_from(list(SPECS)),contact=st.booleans(),closed=st.booleans())
    def hit(self,actor,contact,closed):
        s=self.d.s;a=s.combat.current(actor)
        if a:s.frame(self.d.n(),contacts=[{'attack_id':a['id'],'actual_contact':contact,'grip_closed':closed}])
    @rule(actor=st.sampled_from(list(SPECS)),dest=st.sampled_from(list(CONNECTIONS)))
    def actor_move(self,actor,dest):self.d.s.actor_move(self.d.n(),actor,dest)
    @rule()
    def bandage(self):self.d.s.bandage(self.d.n());self.d.s.frame(self.d.n(),complete_bandage=True)
    @rule()
    def parents(self):self.d.s.meet_parents(self.d.n())
    @rule()
    def crossing(self):self.d.s.frame(self.d.n(),cross_to_bridge=True)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused;self.d.s._sync()
    @rule()
    def death(self):self.d.s.frame(self.d.n(),hp_damage=100)
    @rule()
    def revive(self):
        if self.d.s.revive():self.revives+=1
    @rule()
    def reload(self):self.d.s=self.d.s.reload()
    @invariant()
    def invariants(self):
        s=self.d.s
        assert s.life.progress==5 and 0<=s.life.hp<=100 and 0<=s.life.sp<=100
        assert s.life.total==1+3*self.revives and s.life.attempts[5]==1+self.revives
        assert s.life.economy.n>=0 and s.life.economy.c>=0 and s.combat.slots<=2
        assert len(s.people.entities)==10 and not hasattr(s,'search')
        assert s.support.material_count<=1 and s.people.street_boost==0 and not s.life.economy.awakening
        if s.life.phase=='dead':assert s.life.hp==0 and s.holder is None
        if s.holder:assert s.combat.current(s.holder)['hold_target']=='avatar'

TestS5Machine=S5Machine.TestCase
TestS5Machine.settings=settings(max_examples=250,stateful_step_count=85,deadline=None,database=None)
