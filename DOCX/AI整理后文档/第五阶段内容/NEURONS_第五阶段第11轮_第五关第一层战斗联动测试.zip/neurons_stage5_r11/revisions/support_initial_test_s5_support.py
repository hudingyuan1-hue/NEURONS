from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s5_support import Support5

CONNECTIONS = {'atrium': {'memory', 'visual', 'decision', 'body'},
               'memory': {'atrium', 'visual'}, 'visual': {'atrium', 'memory'}}


def make(hp=50, attempt=1, room='memory'):
    s = Support5(attempt=attempt, epoch=10)
    s.sync_context(attempt=attempt, epoch=10, hp=hp, avatar_room=room,
                   actors={n: {'alive': True, 'present': True, 'room': room}
                           for n in ('nurse', 'corner', 'dog')},
                   known_connections=CONNECTIONS)
    return s


def sync(s, **kw):
    p = dict(attempt=s.attempt, epoch=s.epoch, hp=s.hp, paused=s.paused,
             dead=s.dead, avatar_room=s.avatar_room, actors=s.actors,
             chased=s.chased, body_blocked=s.body_blocked, active=s.active)
    p.update(kw)
    return s.sync_context(**p)


def tok(s, x):
    return (s.attempt, x)


def ready(s):
    assert s.start_bandage(tok(s, 'start'))
    s.tick(3000)
    assert s.phase == 'ready'


@pytest.mark.parametrize('ms,can_finish', [(0, False), (1,False), (2999,False),
                                         (3000,True), (3001,True), (20000,True)])
def test_cumulative_time_threshold(ms, can_finish):
    s = make()
    assert s.start_bandage(tok(s, 'start'))
    s.tick(ms)
    assert s.complete_bandage(tok(s, 'finish')) == can_finish
    assert s.hp == 50 and not s.used
    assert len(s.effects) == int(can_finish)
    if can_finish:
        assert s.effects[0]['hp_heal'] == 20 and s.effects[0]['sp_heal'] == 0
        assert s.resolve_bandage(s.effects[0]['id'], applied=True, survived=True)
        assert s.used and s.bandaged


@pytest.mark.parametrize('invalid', ['full_hp','dead','zero_hp','absent','npc_dead','other_room',
                                    'chased','blocked','paused','inactive','not_contact','old_token','old_epoch'])
def test_invalid_start_spends_nothing(invalid):
    s = make()
    args = {}
    t = tok(s, 'start')
    if invalid == 'full_hp': sync(s,hp=100)
    if invalid == 'zero_hp': sync(s,hp=0)
    if invalid == 'dead': sync(s,dead=True)
    if invalid == 'absent': sync(s,actors={})
    if invalid == 'npc_dead':
        a = deepcopy(s.actors); a['nurse']['alive']=False; sync(s,actors=a)
    if invalid == 'other_room':
        a = deepcopy(s.actors); a['nurse']['room']='atrium'; sync(s,actors=a)
    if invalid == 'chased': sync(s,chased=True)
    if invalid == 'blocked': sync(s,body_blocked=True)
    if invalid == 'paused': sync(s,paused=True)
    if invalid == 'inactive': sync(s,active=False)
    if invalid == 'not_contact': args['actual_contact']=False
    if invalid == 'old_token': t=(s.attempt-1,'start')
    if invalid == 'old_epoch': args['callback_epoch']=s.epoch-1
    assert not s.start_bandage(t,**args)
    assert s.progress_ms==0 and s.material_count==0 and not s.used and not s.effects


@pytest.mark.parametrize('cause', ['hit','leave','npc_hit','grab','chase','npc_leave','npc_die','death','level_leave'])
def test_interruption_preserves_material_and_partial_progress(cause):
    s=make()
    s.start_bandage(tok(s, 'start')); s.tick(1700)
    if cause=='hit': sync(s,hp=40)
    if cause=='leave': sync(s,avatar_room='atrium')
    if cause=='npc_hit': s.interrupt_bandage('nurse_attacked')
    if cause=='grab': sync(s,body_blocked=True)
    if cause=='chase': sync(s,chased=True)
    if cause=='npc_leave': sync(s,actors={})
    if cause=='npc_die':
        a=deepcopy(s.actors); a['nurse']['alive']=False; sync(s,actors=a)
    if cause=='death': sync(s,dead=True,hp=0)
    if cause=='level_leave': sync(s,active=False)
    assert s.phase=='interrupted'
    s.tick(5000)
    assert s.progress_ms==1700 and s.material_count==1 and not s.effects and not s.used
    assert not s.complete_bandage(tok(s,'late'))
    if cause in {'death','npc_die'}:
        return
    actors={n:{'alive':True,'present':True,'room':'memory'} for n in ('nurse','corner','dog')}
    sync(s,hp=40,dead=False,active=True,actors=actors,avatar_room='memory',chased=False,body_blocked=False)
    assert s.start_bandage(tok(s,'resume'))
    s.tick(1299)
    assert not s.complete_bandage(tok(s,'too_early'))
    s.tick(1)
    assert s.complete_bandage(tok(s,'finish'))
    assert s.material_count==1


def test_formal_pause_freezes_keeps_contact():
    s=make(); s.start_bandage(tok(s,'start')); s.tick(900)
    sync(s,paused=True); s.tick(50000)
    assert s.progress_ms==900 and s.phase=='bandaging'
    assert not s.complete_bandage(tok(s,'finish'))
    sync(s,paused=False); s.tick(2100)
    assert s.complete_bandage(tok(s,'finish'))


@pytest.mark.parametrize('attempt',[1,2,8,1000000])
def test_once_per_actual_s5_attempt_and_not_epoch(attempt):
    s=make(attempt=attempt); ready(s)
    s.complete_bandage(tok(s,'finish')); eid=s.effects[-1]['id']
    assert s.resolve_bandage(eid,applied=True,survived=True)
    assert not s.resolve_bandage(eid,applied=True,survived=True)
    sync(s,avatar_room='atrium'); sync(s,avatar_room='memory',epoch=s.epoch+1)
    assert not s.start_bandage(tok(s,'reenter'))
    assert s.used and s.bandaged and s.material_count==1
    sync(s,attempt=attempt+1,epoch=s.epoch+1,hp=100)
    assert not s.used and not s.bandaged and s.progress_ms==0 and s.material_count==0
    assert not s.start_bandage(tok(s,'full'))
    sync(s,hp=80)
    assert s.start_bandage(tok(s,'new_injury'))


@pytest.mark.parametrize('death_timing',['before_complete','after_proposal','settlement'])
def test_death_same_frame_cannot_revive_or_spend_success(death_timing):
    s=make(hp=10); ready(s)
    if death_timing=='before_complete':
        sync(s,hp=0,dead=True)
        assert not s.complete_bandage(tok(s,'finish'))
    else:
        assert s.complete_bandage(tok(s,'finish'))
        eid=s.effects[-1]['id']
        if death_timing=='after_proposal': sync(s,hp=0,dead=True)
        assert not s.resolve_bandage(eid,applied=False,survived=False)
    assert not s.used and not s.bandaged
    assert s.progress_ms==3000 and s.material_count==1


def test_rejected_proposal_can_resume_without_new_material_or_extra_heal():
    s=make(); ready(s); s.complete_bandage(tok(s,'finish'))
    eid=s.effects[-1]['id']
    assert not s.resolve_bandage(eid,applied=False,survived=True)
    assert not s.start_bandage(tok(s,'start')) # original callback consumed
    assert s.start_bandage(tok(s,'resume'))
    assert s.complete_bandage(tok(s,'finish2'))
    eid2=s.effects[-1]['id']; assert eid2 != eid
    assert not s.resolve_bandage(eid,applied=True,survived=True)
    assert s.resolve_bandage(eid2,applied=True,survived=True)
    assert s.material_count==1 and sum(x['applied'] for x in s.settlements)==1


def test_reload_preserves_incomplete_material_and_success():
    s=make(); s.start_bandage(tok(s,'start')); s.tick(1450)
    s=deepcopy(s); s.tick(1550); s.complete_bandage(tok(s,'finish'))
    assert s.resolve_bandage(s.effects[-1]['id'],applied=True,survived=True)
    s=deepcopy(s)
    assert s.used and s.bandaged and s.material_count==1
    assert not s.start_bandage(tok(s,'again'))


@pytest.mark.parametrize('invalid',['invisible','unreachable','not_exist','unknown_connection','absent','dead','paused','npc_other_room','old_epoch'])
def test_corner_never_invents_open_or_safe_exit(invalid):
    s=make(); args=dict(actual_visible=True,actual_reachable=True,existing=True); door='atrium'
    if invalid=='invisible': args['actual_visible']=False
    if invalid=='unreachable': args['actual_reachable']=False
    if invalid=='not_exist': args['existing']=False
    if invalid=='unknown_connection': door='S6_exit'
    if invalid=='absent': sync(s,actors={})
    if invalid=='dead': sync(s,dead=True)
    if invalid=='paused': sync(s,paused=True)
    if invalid=='npc_other_room':
        a=deepcopy(s.actors); a['corner']['room']='visual'; sync(s,actors=a)
    if invalid=='old_epoch': args['callback_epoch']=9
    assert not s.suggest_door(tok(s,'point'),door,**args)
    assert s.suggestion is None and not s.effects


def test_corner_indication_does_not_guarantee_safety_or_move_avatar():
    s=make(); sync(s,chased=True)
    assert s.suggest_door(tok(s,'point'),'visual',actual_visible=True,actual_reachable=True)
    assert s.avatar_room=='memory' and s.chased and not s.effects
    sync(s,actors={})
    assert s.suggestion==('memory','visual')
    assert CONNECTIONS['memory']=={'atrium','visual'}


@pytest.mark.parametrize('order,expected',[((),False),(('avatar',),False),(('dog',),True),
                                          (('avatar','dog'),False),(('dog','avatar'),True)])
def test_dog_actual_collision_order_not_remote_immunity(order,expected):
    s=make(room='atrium'); original=tuple(order)
    assert s.dog_intercepts(tok(s,'hit'),order)==expected
    assert tuple(order)==original and s.hp==50 and not s.effects
    if expected:
        assert s.facts[-1][2]==original


@pytest.mark.parametrize('bad',['missing','dead','remote','unverified','stale'])
def test_dog_no_fake_remote_interception(bad):
    s=make(room='atrium'); kw={}
    if bad=='missing': sync(s,actors={})
    if bad in {'dead','remote'}:
        a=deepcopy(s.actors)
        if bad=='dead': a['dog']['alive']=False
        else: a['dog']['room']='memory'
        sync(s,actors=a)
    if bad=='unverified': kw['actual_geometry']=False
    if bad=='stale': kw['callback_epoch']=9
    assert not s.dog_intercepts(tok(s,'hit'),('dog','avatar'),**kw)


class SupportMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.s=make(); self.n=0
        self.successes={1:0}

    def token(self):
        self.n+=1; return tok(self.s,self.n)

    @rule(actual=st.booleans())
    def start(self,actual):
        old=(self.s.progress_ms,self.s.material_count,self.s.used)
        result=self.s.start_bandage(self.token(),actual_contact=actual)
        if result: assert actual and self.s.hp<100 and not self.s.chased and not self.s.body_blocked
        else: assert old==(self.s.progress_ms,self.s.material_count,self.s.used)

    @rule(ms=st.sampled_from([0,1,500,1499,1500,2999,3000,10000]))
    def time(self,ms):
        before=self.s.progress_ms; paused=self.s.paused
        self.s.tick(ms)
        if paused: assert self.s.progress_ms==before
        assert not self.s.effects or all(e['hp_heal']==20 and e['sp_heal']==0 for e in self.s.effects)

    @rule(what=st.sampled_from(['hit','chase','grab','leave','pause','absent','resume','death']))
    def context(self,what):
        if what=='hit': sync(self.s,hp=max(0,self.s.hp-7))
        elif what=='chase': sync(self.s,chased=True)
        elif what=='grab': sync(self.s,body_blocked=True)
        elif what=='leave': sync(self.s,avatar_room='atrium')
        elif what=='pause': sync(self.s,paused=not self.s.paused)
        elif what=='absent': sync(self.s,actors={})
        elif what=='death': sync(self.s,hp=0,dead=True)
        else:
            # Resuming never restores actual death or invents a respawn.
            a={n:{'alive':True,'present':True,'room':'memory'} for n in ('nurse','corner','dog')}
            sync(self.s,actors=a,avatar_room='memory',chased=False,body_blocked=False,paused=False)

    @rule(actual=st.booleans(),survived=st.booleans())
    def complete(self,actual,survived):
        hp=self.s.hp
        if self.s.complete_bandage(self.token(),actual_completed=actual):
            assert self.s.progress_ms==3000 and actual
            effect=self.s.effects[-1]
            accepted=self.s.resolve_bandage(effect['id'],applied=survived,survived=survived)
            if accepted:
                self.successes[self.s.attempt]+=1
                sync(self.s,hp=min(100,hp+20))
        else: assert self.s.hp==hp

    @rule()
    def next_actual_attempt(self):
        a=self.s.attempt+1
        sync(self.s,attempt=a,epoch=self.s.epoch+1,hp=100,dead=False,chased=False,body_blocked=False)
        self.successes[a]=0

    @rule()
    def reload(self):
        self.s=deepcopy(self.s)

    @rule()
    def corner_or_dog(self):
        self.s.suggest_door(self.token(),'visual',actual_visible=True,actual_reachable=True)
        self.s.dog_intercepts(self.token(),('dog','avatar'))

    @invariant()
    def conservation(self):
        assert 0<=self.s.progress_ms<=3000
        assert self.s.material_count in (0,1)
        assert all(n<=1 for n in self.successes.values())
        assert self.s.used==self.s.bandaged
        if self.s.used: assert self.s.phase=='completed'
        if self.s.phase=='awaiting_resolution': assert self.s.pending_id is not None
        assert all(e['hp_heal']==20 and e['sp_heal']==0 for e in self.s.effects)

TestSupportMachine=SupportMachine.TestCase
TestSupportMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
