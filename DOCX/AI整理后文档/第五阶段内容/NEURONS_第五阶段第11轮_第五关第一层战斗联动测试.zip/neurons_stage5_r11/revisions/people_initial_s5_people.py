"""S5 first-floor identities, finite appearance and observable NPC state.

No geometry, attack timing, healing, dialogue engine or rewards are simulated here.
Source: S1:P324-369; S3:P1288-1408; S4:P96-120/P216/P231-235.
"""
from dataclasses import dataclass, field
from copy import deepcopy
from rules import Spawn


ROOMS = ('atrium', 'memory', 'visual', 'decision', 'body')
EDGES = {frozenset(e) for e in (
    ('atrium', 'memory'), ('atrium', 'visual'), ('atrium', 'decision'),
    ('atrium', 'body'), ('memory', 'visual'), ('decision', 'bridge'))}
ROSTER = {
    'dog': ('atrium', 'friendly', 60, 'S1_dog'),
    'father': ('atrium', 'hostile', 80, 'S1_father'),
    'nurse': ('memory', 'friendly', 40, 'S2_junior_nurse'),
    'archivist': ('memory', 'hostile', 60, 'S2_archivist'),
    'corner': ('visual', 'friendly', 40, 'S3_corner_patient'),
    'orderly': ('visual', 'hostile', 60, 'S3_ordinary_orderly'),
    'mother': ('decision', 'hostile', 80, 'S1_mother'),
    'cat': ('decision', 'hostile', 30, 'S1_cat'),
    'doctor': ('body', 'hostile', 60, 'S2_check_doctor'),
    'assistant': ('body', 'hostile', 60, 'S2_check_assistant'),
}
FRIEND_TEXT = {
    'dog': '𩇬䵉䶴䂙䨻䵊䴓㱎㔿𩉻！',
    'nurse': '䶺䴔䶳䆐䴒䶵㗊𩇯䵙䲈䶼䴡。',
    'corner': '㱌䶹䶱䴕䲈䶼䴡䵿䶳䴴䵳！',
}


@dataclass(frozen=True)
class Token:
    attempt: int
    event_id: str
    epoch: int = 0


@dataclass
class Entity:
    actor: str
    home: str
    alignment: str
    max_hp: int
    identity: str
    spawn: Spawn
    hp: int = 0
    alive: bool = True
    present: bool = False
    room: str | None = None
    target: str | None = None
    last_seen: tuple | None = None
    sees_avatar: bool = False
    bed_room: str | None = None
    spoken: bool = False

    def __post_init__(self):
        self.hp = self.max_hp


@dataclass
class People5:
    attempt: int = 1
    epoch: int = 0
    paused: bool = False
    dead: bool = False
    avatar_room: str = 'atrium'
    chased: bool = False
    loading: bool = False
    entities: dict = field(default_factory=dict)
    time_ms: int = 0
    batch_at: dict = field(default_factory=dict)
    done: set = field(default_factory=set)
    history: list = field(default_factory=list)
    prior_seen: set = field(default_factory=set)
    seen_here: set = field(default_factory=set)
    s1_dog_died: bool = False
    resources: tuple = (0, 0)
    awakening: int = 0
    street_boost: int = 0

    def __post_init__(self):
        assert self.attempt >= 1
        if not self.entities:
            self.entities = {actor: Entity(actor, home, side, hp, identity,
                                Spawn('s5', self.attempt))
                             for actor, (home, side, hp, identity) in ROSTER.items()}

    def token(self, event_id):
        return Token(self.attempt, str(event_id), self.epoch)

    def _ok(self, token):
        return (isinstance(token, Token) and token.attempt == self.attempt
                and token.epoch == self.epoch and not self.paused
                and not self.dead and not self.loading)

    def _fresh(self, token, operation, actor=''):
        return self._ok(token) and (operation, actor, token.event_id) not in self.done

    def _mark(self, token, operation, actor=''):
        self.done.add((operation, actor, token.event_id))

    def sync_context(self, *, attempt=None, epoch=None, paused=None, dead=None,
                     avatar_room=None, chased=None, loading=None):
        if attempt is not None and attempt != self.attempt:
            if attempt < self.attempt:
                return False
            self.attempt = attempt
            self.entities = {}
            self.__post_init__()
            self.done.clear()
            self.batch_at.clear()
            self.time_ms = 0
            self.seen_here.clear()
        if epoch is not None:
            self.epoch = epoch
        if paused is not None:
            self.paused = paused
        if dead is not None:
            self.dead = dead
        if chased is not None:
            self.chased = chased
        if loading is not None:
            self.loading = loading
        if avatar_room is not None and avatar_room != self.avatar_room:
            previous = self.avatar_room
            self.avatar_room = avatar_room
            for entity in self.entities.values():
                if entity.home == previous:
                    entity.spawn.leave()
                entity.sees_avatar = False
        return True

    def tick(self, ms):
        if ms < 0:
            raise ValueError('negative time')
        if self.paused or self.dead or self.loading:
            return False
        self.time_ms += ms
        for entity in self.entities.values():
            entity.spawn.tick(ms)
        return True

    def check_spawn(self, token, actor, roll, *, first=False):
        if actor not in self.entities or not self._fresh(token, 'check', actor):
            return False
        entity = self.entities[actor]
        if self.avatar_room != entity.home:
            return False
        consumed = entity.spawn.check(roll, first=first)
        if consumed:
            self._mark(token, 'check', actor)
        return consumed

    def enter_pending(self, token, room, *, entry_free=True):
        if (not self._fresh(token, 'batch', room) or room != self.avatar_room
                or not entry_free or room not in ROOMS
                or self.time_ms - self.batch_at.get(room, -10000) < 10000):
            return ()
        batch = [entity for entity in self.entities.values()
                 if entity.home == room and entity.spawn.state == 'pending']
        if not batch:
            return ()
        for entity in batch:
            entity.spawn.enter()
            entity.present = True
            entity.room = room
            if entity.actor == 'assistant':
                entity.bed_room = room
        self.batch_at[room] = self.time_ms
        self._mark(token, 'batch', room)
        return tuple(entity.actor for entity in batch)

    def move(self, token, actor, dest, *, passable=True, bed_passable=True):
        if actor not in self.entities or not self._fresh(token, 'move', actor):
            return False
        entity = self.entities[actor]
        if (not entity.alive or not entity.present or not passable
                or frozenset((entity.room, dest)) not in EDGES
                or (actor == 'assistant' and not bed_passable)):
            return False
        entity.room = dest
        entity.sees_avatar = False
        if actor == 'assistant':
            entity.bed_room = dest
        self._mark(token, 'move', actor)
        return True

    def observe(self, token, actor, avatar_pos, *, actual_visible=True):
        if actor not in self.entities or not self._fresh(token, 'observe', actor):
            return False
        entity = self.entities[actor]
        if (not entity.alive or not entity.present or entity.room != self.avatar_room
                or not actual_visible):
            entity.sees_avatar = False
            return False
        entity.last_seen = (self.avatar_room, deepcopy(avatar_pos))
        entity.sees_avatar = True
        self.seen_here.add(entity.identity)
        if entity.alignment == 'hostile':
            opponent = self.entities.get(entity.target)
            if opponent is None or not opponent.alive or not opponent.present:
                entity.target = 'avatar'
        self._mark(token, 'observe', actor)
        return True

    def lose_sight(self, actor):
        self.entities[actor].sees_avatar = False

    def meet_parents(self, token, *, mutual_visible=True):
        if not self._fresh(token, 'parents') or not mutual_visible:
            return False
        father, mother = self.entities['father'], self.entities['mother']
        if (not all(e.alive and e.present for e in (father, mother))
                or father.room != mother.room):
            return False
        father.target, mother.target = 'mother', 'father'
        self._mark(token, 'parents')
        self.history.append({'kind': 'parents_met', 'attempt': self.attempt,
                             'epoch': self.epoch, 'event': token.event_id})
        return True

    def damage(self, token, actor, amount, *, source=None, actual=True):
        if (actor not in self.entities or not self._fresh(token, 'damage', actor)
                or not actual or amount < 0):
            return None
        entity = self.entities[actor]
        if not entity.alive or not entity.present:
            return None
        attacker = self.entities.get(source)
        if attacker is not None and (not attacker.alive or not attacker.present
                                     or attacker.room != entity.room):
            return None
        if source in ('avatar', 'player') and entity.room != self.avatar_room:
            return None
        before = entity.hp
        shattered = actor == 'dog' and source == 'father'
        entity.hp = 0 if shattered else max(0, entity.hp - amount)
        killed = entity.hp == 0
        if killed:
            entity.alive = False
            entity.present = False
            entity.target = None
            entity.spawn.retire()
            for other in self.entities.values():
                if other.target == actor:
                    other.target = None
        result = {'kind': 'damage', 'attempt': self.attempt, 'epoch': self.epoch,
                  'event': token.event_id, 'actor': actor, 'source': source,
                  'hp_loss': before - entity.hp, 'killed': killed,
                  'shattered': shattered, 'resources': (0, 0),
                  'awakening': 0, 'street_boost': 0}
        self.history.append(result)
        self._mark(token, 'damage', actor)
        return result

    def retire(self, token, actor):
        if actor not in self.entities or not self._fresh(token, 'retire', actor):
            return False
        entity = self.entities[actor]
        if not entity.present:
            return False
        entity.present = False
        entity.target = None
        entity.spawn.retire()
        self._mark(token, 'retire', actor)
        return True

    def friend_dialogue(self, token, actor):
        if actor not in FRIEND_TEXT or not self._fresh(token, 'speech', actor):
            return None
        entity = self.entities[actor]
        if (self.chased or not entity.present or not entity.alive
                or entity.room != self.avatar_room or entity.spoken):
            return None
        entity.spoken = True
        self._mark(token, 'speech', actor)
        return FRIEND_TEXT[actor]

    def recognizes_previous_identity(self, actor):
        entity = self.entities[actor]
        return entity.identity in self.prior_seen and entity.identity in self.seen_here

    def dog_repeated_death_feedback(self, *, witnessed=False):
        return (witnessed and self.s1_dog_died and any(
            e.get('actor') == 'dog' and e.get('shattered')
            and e.get('attempt') == self.attempt for e in self.history))

    def snapshot(self):
        return deepcopy(self)

    @classmethod
    def restore(cls, snapshot):
        if not isinstance(snapshot, cls):
            raise TypeError('People5 snapshot required')
        return deepcopy(snapshot)
