"""R10 Fourth-level rules adapter, source S1:P220-323/S3:P1062-1284.
Room edges are canonical. Local collisions/visibility are actual engine inputs.
Not a Unity AI, spawn, animation, skill-input or disk-save implementation.
"""
from dataclasses import dataclass,field
from copy import deepcopy
from collections import deque
import random
from rules import Life,Search,search_ms
from awareness import Awareness
from archive_events import ArchiveEvents
from cortex_events import CortexEvents
from white_records import WhiteRecords
from white_routes import WhiteRoutes

F1=('atrium','memory','visual','decision','body')
F2=('bridge','rhythm','index','fork','exit','identity')
POINT_ROOMS=tuple(r for r,n in zip(F1+F2,(3,7,6,7,8,4,4,6,3,7,7)) for _ in range(n))
EDGES={frozenset(('atrium',r)) for r in F1[1:]}
EDGES.update(frozenset(p) for p in (('memory','visual'),('decision','bridge'),
 ('bridge','index'),('index','fork'),('fork','exit'),('bridge','rhythm'),
 ('rhythm','identity'),('identity','exit'),('fork','bridge')))
ACTOR_ROOMS={'backturn':'atrium','stitched':'memory','blind':'visual','mimic':'decision','clamp':'body',
 'doublehead':'bridge','twitch':'rhythm','blankface':'index','reverse':'fork','face':'exit','doubleface':'identity'}
ARCHIVE_ACTIONS={'open_original','reach_paper','pinch_paper','cancel_reading','interrupt_paper',
 'acquire_paper','read_fields','watch','operate_face','interrupt_video','observe_video','replay','overlay','read_death_record'}
CORTEX_ACTIONS={'back_approach','back_turn','back_read','mimic_witness','mimic_complete','mimic_write',
 'read_mimic','decision_actual','read_consent','clamp_touch','clamp_step','hand_clear',
 'clamp_interrupt','clamp_close','clamp_read'}
RECORD_ACTIONS={'start_contradiction','hear_statement','read_event_screen','start_identity','read_identity',
 'match_identity','see_match','see_face','open_original','reach_label','pinch_label','interrupt_label',
 'query_name','cancel_avatar_search','read_original','observe_label','verify_ids'}
ROUTE_ACTIONS={'approach_twitch','pass_twitch','accept_guidance','route_step','recognize_loop',
 'interrupt_guidance','start_face','raise_face','contact_face','interrupt_face','observe_twitch','release_face'}

@dataclass
class S4Session:
    life: Life=field(default_factory=lambda:Life(progress=4,place='S4'))
    awareness: Awareness=field(default_factory=Awareness)
    archive: ArchiveEvents=field(default_factory=ArchiveEvents)
    cortex: CortexEvents=field(default_factory=CortexEvents)
    records: WhiteRecords=field(default_factory=WhiteRecords)
    routes: WhiteRoutes=field(default_factory=WhiteRoutes)
    rng_seed: int=2026101310
    targets: tuple|None=None
    key_point: int|None=None
    position: str='atrium'
    actors: dict=field(default_factory=lambda:dict.fromkeys(ACTOR_ROOMS))
    paused: bool=False
    loading: bool=False
    seen: set=field(default_factory=set)
    applied: set=field(default_factory=set)
    search_elapsed: int=0
    search_duration: int=0
    feedback: bool=False
    holder: str|None=None
    hold_remaining: int=0
    hit_stop: int=0
    drug_stop: int=0
    body_generation: int=0
    clamp_generation: int|None=None
    need_gap: bool=False
    gap: int=800
    door_unlocked: bool=False
    door_open: bool=False
    opening: bool=False
    serial: int=0
    prior: dict=field(default_factory=dict)

    def __post_init__(self):
        if self.life.progress!=4 or self.life.phase!='alive':raise ValueError('actual S4 entry required')
        self.rng=random.Random(self.rng_seed)
        if self.targets is None:self.targets=tuple(self.rng.sample(range(31),8)+self.rng.sample(range(31,62),8))
        self._check_targets()
        if self.key_point is None:self.key_point=self.rng.choice(self.targets)
        if self.key_point not in self.targets:raise ValueError('key must be in actual attempt targets')
        self.search=Search(level=4,key_point=self.key_point,attempt=self.life.attempts[4])
        # Bind newly constructed S4 event models to actual entry generation.
        for module in (self.archive,self.cortex,self.records,self.routes):
            module.attempt=self.life.attempts[4];module.epoch=self.life.epoch
        self._sync()

    def _check_targets(self):
        if len(set(self.targets))!=16 or sum(0<=x<31 for x in self.targets)!=8 or sum(31<=x<62 for x in self.targets)!=8:
            raise ValueError('S4 selects eight real points per floor')

    @classmethod
    def from_s3(cls,source,**kw):
        if source.life.progress!=4 or source.life.phase!='alive':raise ValueError('source has not actually exited S3')
        return cls(life=deepcopy(source.life),awareness=deepcopy(source.awareness),
            prior={k:deepcopy(getattr(source,k)) for k in ('records','corner','cleaning','transport','patient_history','work') if hasattr(source,k)},**kw)

    def active(self):return self.life.phase=='alive' and self.life.progress==4 and not(self.paused or self.loading)
    def blocked(self):return bool(self.holder or self.life.stun or self.hit_stop or self.drug_stop)
    def _rt(self,label):self.serial+=1;return(self.life.attempts[4],(label,self.serial))
    def node(self,token,formal=False):
        self._sync()
        if self.life.phase!='alive' or self.life.progress!=4 or self.loading or self.paused and not formal:return False
        if token[0]!=self.life.epoch or token in self.seen:return False
        self.seen.add(token);return True

    def _sync(self):
        invalid=self.life.phase!='alive' or self.life.progress!=4
        shared=dict(attempt=self.life.attempts[4],epoch=self.life.epoch,room=self.position,
                    paused=self.paused or self.loading,dead=invalid)
        self.archive.sync_context(**shared,actors={'stitched':self.actors.get('stitched')=='memory',
            'blind':self.actors.get('blind')=='visual'},avatar_blocked=self.blocked())
        self.cortex.sync_context(**shared,actors={x:self.actors.get(x) for x in ('backturn','mimic','clamp')},avatar_blocked=self.blocked())
        self.records.sync_context(**shared,actors={x:self.actors.get(x) for x in ('doublehead','blankface','doubleface')},avatar_able=not self.blocked())
        self.routes.sync_context(**shared,actors={x:self.actors.get(x) for x in ('reverse','twitch','face')},
            active=self.life.progress==4,holder_free=not self.blocked() and (not self.need_gap or self.gap>=800),body_generation=self.body_generation)
        # Physical release/actor departure may happen before the cap expires.
        # Do not leave the authoritative body held after the contact has ended.
        if ((self.holder=='face' and not self.routes.held)
            or (self.holder=='clamp' and self.cortex.clamp_phase!='held')):
            self._release()
        self.awareness.paused=self.paused or self.loading

    def cancel_current(self):
        for t in list(self.search.pending):self.search.settle(t,'cancel')
        self.search_elapsed=0;self.opening=False
        self.archive._cancel_reading()

    def decision(self):
        if self.life.phase!='alive':return self.life.phase
        if self.life.progress!=4:return 'battle_escape'
        if self.paused or self.loading:return 'paused'
        if self.blocked():return 'wait_effect'
        return 'exit' if self.search.key_owner=='avatar' else 'search'

    def distances(self):
        d={self.position:0};q=deque([self.position])
        while q:
            p=q.popleft()
            for edge in EDGES:
                if p in edge:
                    n=next(iter(edge-{p}))
                    if n not in d:d[n]=d[p]+1;q.append(n)
        return d

    def next_point(self,occupied=()):
        if self.decision()!='search':return None
        pending={p for _,p in self.search.pending.values()}
        choices=[p for p in self.targets if p not in self.search.complete and p not in occupied and p not in pending]
        if not choices:choices=[p for p in range(62) if p not in self.search.complete and p not in occupied and p not in pending]
        d=self.distances()
        return min(choices,key=lambda p:(d[POINT_ROOMS[p]],p)) if choices else None

    def move(self,token,dest,actual=True):
        if not self.node(token) or not actual or self.blocked() or frozenset((self.position,dest)) not in EDGES:return False
        self.cancel_current();self.position=dest;self.feedback=False;self._sync();return True

    def actor_move(self,token,actor,dest,actual=True):
        if not self.node(token) or not actual or actor not in self.actors:return False
        old=self.actors[actor]
        if old is None or frozenset((old,dest)) not in EDGES:return False
        self.actors[actor]=dest
        if self.holder==actor:self._release()
        self._sync();return True

    def start_search(self,token,point,kind='normal',reachable=True):
        if not self.node(token) or self.blocked() or self.feedback or self.decision()!='search' or not reachable:return None
        if not 0<=point<62 or POINT_ROOMS[point]!=self.position:return None
        t=self.search.start(point)
        if t:self.search_elapsed=0;self.search_duration=search_ms(4,kind,self.life.attempts[4],self.life.sp)
        return t

    def complete_search(self,token,ident):
        if not self.node(token) or self.blocked() or self.search_elapsed<self.search_duration:return False
        info=self.search.pending.get(ident)
        if not info:return False
        self.search.settle(ident);self.feedback=True
        self.life.economy.credit(('S4search',self.life.attempts[4],info[1]),1)
        return True

    def finish_feedback(self,token):
        if not self.node(token):return False
        self.feedback=False;return True

    def cancel_action(self,token,actual=True):
        if not self.node(token) or not actual or self.blocked():return False
        self.cancel_current();return True

    def action(self,token,group,name,**kw):
        formal=group=='records' and name=='hear_statement' and kw.get('formal_dialogue',False)
        if not self.node(token,formal):return False
        groups={'archive':ARCHIVE_ACTIONS,'cortex':CORTEX_ACTIONS,'records':RECORD_ACTIONS,'routes':ROUTE_ACTIONS}
        if name not in groups.get(group,set()):return False
        if group=='routes' and name in ('route_step','start_face','contact_face'):return False # authoritative movement / exit frame below
        if group=='cortex' and name=='clamp_step' and kw.get('step')=='pull':
            if self.blocked() or self.need_gap and self.gap<800:return False
        if group=='cortex' and name=='clamp_close':
            kw['can_hold']=not self.blocked() and self.clamp_generation==self.body_generation and (not self.need_gap or self.gap>=800)
        result=getattr(getattr(self,group),name)(self._rt(name),**kw)
        if result and group=='cortex' and name=='clamp_step' and kw.get('step')=='pull':self.clamp_generation=self.body_generation
        self._commit(token);self._sync();return result

    def _effects(self):
        fresh=[]
        for name in ('cortex','records','routes'):
            module=getattr(self,name)
            for effect in module.effects:
                ident=(name,effect['id'])
                if ident not in self.applied:
                    self.applied.add(ident);fresh.append((name,effect))
        return fresh

    def _commit(self,token,hp=0,sp=0,exit_ready=False):
        effects=self._effects();damage_hp=hp+sum(x['hp'] for _,x in effects);damage_sp=sp+sum(x['sp'] for _,x in effects)
        ev=[('hp_damage',damage_hp),('sp_damage',damage_sp)]
        if exit_ready:ev.append(('exit',True))
        result=self.life.frame((self.life.epoch,('S4',token[1])),ev)
        if damage_hp or any(name=='routes' for name,_ in effects):self.cancel_current()
        if damage_hp and self.life.phase=='alive':self.hit_stop=max(self.hit_stop,250)
        if self.life.stun:self.cancel_current()
        if result in ('death','exit'):
            self.cancel_current();self._release();self.hit_stop=self.drug_stop=0
            self.awareness.transition('death' if result=='death' else 'level')
            if result=='exit':
                self.life.finish_exit();self.life.place='S5_atrium';self.position='atrium'
                self.awareness.transition('battle')
        else:
            for name,effect in effects:
                duration=effect.get('hold_ms',effect.get('hold',0))
                if duration and self.holder is None:
                    self.holder='clamp' if name=='cortex' else 'face';self.hold_remaining=duration
                    self.cancel_current()
        if self.need_gap and self.blocked():self.gap=0
        self._sync();return result

    def _release(self):
        if self.holder:
            self.holder=None;self.hold_remaining=0;self.body_generation+=1;self.need_gap=True;self.gap=0

    def begin_open(self,token,actual=True,seen=True):
        if not self.node(token) or not actual or self.blocked() or self.position!='exit' or self.search.key_owner!='avatar':return False
        self.cancel_current();self.opening=True
        self.routes.start_face(self._rt('start_face'),key=True,opening=True,seen=seen)
        self._sync();return True

    def unlock(self,token,actual=True):
        if not self.node(token) or not actual or not self.opening or self.blocked():return False
        self.door_unlocked=True;return True

    def push_door(self,token,actual=True):
        if not self.node(token) or not actual or self.blocked() or self.position!='exit' or not self.door_unlocked:return False
        self.door_open=True;return True

    def damage_or_exit(self,token,hp=0,sp=0,crossed=False):
        if not self.node(token):return 'ignored'
        ready=crossed and self.position=='exit' and self.search.key_owner=='avatar' and self.door_open and not self.blocked()
        return self._commit(token,hp,sp,ready)

    def face_contact(self,token,actual_contact=True,crossed=False,hp=0):
        if not self.node(token):return 'ignored'
        ready=crossed and self.position=='exit' and self.search.key_owner=='avatar' and self.door_open and not self.blocked()
        self.routes.contact_face(self._rt('face_contact'),actual_contact=actual_contact,callback_generation=self.body_generation)
        return self._commit(token,hp=hp,exit_ready=ready)

    def follow_guidance(self,token,dest,actual=True):
        if not self.node(token) or not actual or self.blocked() or frozenset((self.position,dest)) not in EDGES:return False
        if not self.routes.route_step(self._rt('route_step'),dest,actual=True):return False
        self.cancel_current();self.position=dest;self.feedback=False;self._sync();return True

    def tick(self,token,ms):
        if ms<0:raise ValueError('negative elapsed time')
        if not self.node(token):return False
        remaining=ms
        while remaining and self.active():
            limits=[n for n in (self.hold_remaining,self.life.stun,self.hit_stop,self.drug_stop) if n>0]
            dt=min([remaining,*limits]);free=not self.blocked()
            if free:
                if self.need_gap:self.gap=min(800,self.gap+dt)
                if self.search.pending:self.search_elapsed+=dt
            self.life.tick(dt);self.hit_stop=max(0,self.hit_stop-dt);self.drug_stop=max(0,self.drug_stop-dt)
            for module in (self.archive,self.cortex,self.records,self.routes):module.tick(dt)
            if self.holder:
                self.hold_remaining=max(0,self.hold_remaining-dt)
                if self.hold_remaining==0:self._release()
            remaining-=dt
        self._sync();return True

    def revive(self):
        if not self.life.revive():return False
        self.life.place='S4';self.position='atrium';self._release()
        self.hit_stop=self.drug_stop=0;self.gap=800;self.need_gap=False
        self.actors=dict.fromkeys(ACTOR_ROOMS);self.door_unlocked=self.door_open=self.opening=False
        self.targets=tuple(self.rng.sample(range(31),8)+self.rng.sample(range(31,62),8))
        self.key_point=self.rng.choice(self.targets);self.search.restart(self.key_point)
        self.search_elapsed=0;self.feedback=False;self.awareness.new_attempt();self._sync();return True

    def reload(self):return deepcopy(self)
