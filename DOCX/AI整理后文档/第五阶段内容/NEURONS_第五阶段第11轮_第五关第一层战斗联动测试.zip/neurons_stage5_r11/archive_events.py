"""S3:P1080-1116; S4:T17R6-7. Abstract actual callbacks, not scene simulation."""
from dataclasses import dataclass, field
from copy import deepcopy

@dataclass
class ArchiveEvents:
    attempt: int = 1
    epoch: int = 0
    event_id: str = 'fixture_event'
    subject: str = 'fixture_subject'
    original: dict = field(default_factory=lambda: {'name':'fixture_A','injury':'recorded'})
    revision: dict = field(default_factory=lambda: {'name':'fixture_B','injury':'none'})
    faces: tuple = ('fixture_face_a','fixture_face_b')
    facts: dict = field(default_factory=dict)
    room: str = 'memory'
    actors: dict = field(default_factory=lambda: {'stitched':True,'blind':False})
    paused: bool = False
    dead: bool = False
    avatar_blocked: bool = False
    seen: set = field(default_factory=set)
    paper_phase: str = 'idle'
    paper_used: bool = False
    reading: bool = False
    tear_ms: int = 0
    pieces: dict = field(default_factory=lambda: {'whole':'world'})
    read_values: dict = field(default_factory=dict)
    knowledge: set = field(default_factory=set)
    history: list = field(default_factory=list)
    video_started: bool = False
    selected: str | None = None
    face_work: str | None = None
    face_ms: int = 0
    masked: set = field(default_factory=set)
    operation_seen: set = field(default_factory=set)
    masking_witnessed: set = field(default_factory=set)
    effects: list = field(default_factory=list)

    def sync_context(self, *, attempt=None, epoch=None, room=None, actors=None,
                     paused=None, dead=None, avatar_blocked=None):
        old_epoch=self.epoch
        if attempt is not None and attempt < self.attempt: return False
        if attempt is not None and attempt > self.attempt:
            self.attempt=attempt
            self.seen.clear()
            # Knowledge, actual ownership and damaged material survive; do not
            # invent replacement originals or second copies of owned fragments.
            self._cancel_reading()
            self.paper_phase='ended' if self.paper_used else 'idle'
            self.face_work=None; self.face_ms=0
        if epoch is not None: self.epoch=epoch
        if room is not None: self.room=room
        if actors is not None: self.actors=dict(actors)
        if paused is not None: self.paused=paused
        if dead is not None: self.dead=dead
        if avatar_blocked is not None: self.avatar_blocked=avatar_blocked
        if self.dead or self.epoch != old_epoch:
            self._cancel_reading(); self.face_work=None; self.face_ms=0
            if self.paper_phase not in ('idle','ended'): self.paper_phase='ended'
        if not self.actors.get('stitched') and self.paper_phase in ('approaching','reached','pinched'):
            self.paper_phase='ended'
        if not self.actors.get('blind'):
            self.face_work=None; self.face_ms=0
        return True

    def _node(self, token, room=None, avatar=False):
        if not isinstance(token,tuple) or len(token)!=2 or token[0]!=self.attempt: return False
        if token in self.seen or self.paused or self.dead: return False
        if room is not None and self.room != room: return False
        if avatar and self.avatar_blocked: return False
        self.seen.add(token); return True

    def _cancel_reading(self):
        self.reading=False
        for piece,owner in tuple(self.pieces.items()):
            if owner=='held': self.pieces[piece]='world'

    def open_original(self, token, *, actual=True):
        if not self._node(token,'memory',True) or not actual: return False
        if self.paper_used or 'whole' not in self.pieces or self.pieces['whole']=='npc': return False
        self.reading=True
        if self.pieces['whole']=='world': self.pieces['whole']='held'
        if self.actors.get('stitched'):
            self.paper_used=True; self.paper_phase='approaching'
        self.history.append(('opened',self.event_id)); return True

    def reach_paper(self,token,*,actual=True):
        if not self._node(token) or not actual: return False
        if not self.actors.get('stitched') or self.paper_phase!='approaching': return False
        if self.pieces.get('whole')=='avatar': self.paper_phase='ended'; return False
        self.paper_phase='reached'; return True

    def pinch_paper(self,token,*,actual=True):
        if not self._node(token) or not actual: return False
        if not self.actors.get('stitched') or self.paper_phase!='reached': return False
        if self.pieces.get('whole')=='avatar': self.paper_phase='ended'; return False
        self.paper_phase='pinched'; self.history.append(('pinched',self.event_id)); return True

    def cancel_reading(self,token):
        if not self._node(token): return False
        self._cancel_reading(); return True

    def interrupt_paper(self,token,*,actual=True):
        if not self._node(token) or not actual: return False
        if self.paper_phase not in ('approaching','reached','pinched'): return False
        self.paper_phase='ended'; return True

    def acquire_paper(self,token,piece,*,actual=True,reachable=True):
        if not self._node(token,'memory',True) or not actual or not reachable: return False
        if self.pieces.get(piece) not in ('world','held'): return False
        self.pieces[piece]='avatar'; self.history.append(('acquired',piece))
        if piece=='whole' and self.paper_phase in ('approaching','reached','pinched'):
            self.paper_phase='ended'
        return True

    def tick(self,ms):
        if ms<0: raise ValueError('negative elapsed time')
        if self.paused or self.dead: return
        if self.paper_phase=='pinched' and self.actors.get('stitched'):
            advance=min(ms,2000-self.tear_ms)
            if advance and 'whole' in self.pieces:
                owner=self.pieces.pop('whole')
                if owner=='avatar':
                    self.pieces['whole']='avatar'; self.paper_phase='ended'; advance=0
                else:
                    self.pieces={'corner':'held' if self.reading else 'world','remainder':'world'}
            self.tear_ms+=advance
            if self.tear_ms==2000:
                self.paper_phase='ended'
                if self.pieces.get('remainder')=='world': self.pieces['remainder']='npc'
                self.history.append(('tear_completed',self.event_id))
        if self.face_work is not None and self.actors.get('blind'):
            self.face_ms=min(1000,self.face_ms+ms)
            if self.face_ms==1000:
                face=self.face_work; self.masked.add(face)
                if face in self.operation_seen and self.room=='visual': self.masking_witnessed.add(face)
                self.history.append(('masked',face))
                self.face_work=None; self.face_ms=0

    def read_fields(self,token,version,fields,*,event_id=None,subject=None,
                    visible=True,readable=True,material_available=True):
        if not self._node(token,'memory',True) or not visible or not readable or not material_available: return False
        if version not in ('original','revision'): return False
        if version=='original' and not any(x in ('world','held','avatar') for x in self.pieces.values()): return False
        event_id=self.event_id if event_id is None else event_id
        subject=self.subject if subject is None else subject
        source=self.original if version=='original' else self.revision
        for name in fields:
            if name in source: self.read_values[(version,event_id,subject,name)]=source[name]
        return True

    def compare_field(self,name):
        a=('original',self.event_id,self.subject,name); b=('revision',self.event_id,self.subject,name)
        return a in self.read_values and b in self.read_values and self.read_values[a]!=self.read_values[b]

    def watch(self,token,event_id,*,nonempty=True,actual=True,screen='tv'):
        if not self._node(token,'visual',True) or not actual or not nonempty: return False
        if event_id != self.event_id or event_id not in self.facts: return False
        if self.facts[event_id].get('subject') != self.subject: return False
        self.selected=event_id; self.video_started=True
        self.knowledge.add(('watched',event_id)); return True

    def operate_face(self,token,face,*,actual=True,visible=False):
        if not self._node(token) or not actual: return False
        if not self.video_started or not self.actors.get('blind') or self.face_work is not None: return False
        if face not in self.faces or face in self.masked: return False
        self.face_work=face; self.face_ms=0
        if visible and self.room=='visual': self.operation_seen.add(face)
        else: self.operation_seen.discard(face)
        return True

    def interrupt_video(self,token,*,actual=True):
        if not self._node(token) or not actual or self.face_work is None: return False
        self.face_work=None; self.face_ms=0; return True

    def observe_video(self,token,*,faces=(),clothes=False,action=False,visible=True):
        if not self._node(token,'visual',True) or not visible or self.selected is None: return False
        for face in faces:
            if face in self.faces and face not in self.masked:
                self.knowledge.add(('face',self.selected,face))
        if clothes: self.knowledge.add(('clothes',self.selected))
        if action: self.knowledge.add(('action',self.selected))
        for face in self.masked & self.masking_witnessed:
            self.knowledge.add(('saw_masking',self.selected,face))
        return True

    def replay(self,token,event_id,*,actual=True):
        if not self._node(token,avatar=True) or not actual: return False
        if self.room not in ('memory','visual'): return False
        if event_id not in self.facts: return False
        self.knowledge.add(('replayed',event_id)); return True

    def overlay(self,token,*,at_frame=False,visible=True):
        if not self._node(token,'visual',True) or not at_frame or not visible or self.selected is None: return False
        self.knowledge.add(('overlay_seen',self.selected)); return True

    def read_death_record(self,token,subject,*,actual=True,readable=True):
        if not self._node(token,avatar=True) or not actual or not readable: return False
        self.knowledge.add(('record_says_dead',subject)); return True

    def confirmed_death(self,subject):
        return any(v.get('subject')==subject and v.get('kind')=='death' for v in self.facts.values())

    def reload(self): return deepcopy(self)
