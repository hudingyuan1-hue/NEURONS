"""S2 integration of independently tested Life, Economy, Search and Hospital.

Life is canonical between operations. Hospital is a transactional subsystem:
pull -> apply -> push exactly once. Public calls require epoch/node identities.
Actual movement, contact, perception and completed animations are external
facts; this is NOT a Unity simulation or a complete all-skills implementation.
"""
from dataclasses import dataclass, field
from copy import deepcopy
from rules import Life, Search, SEARCH
from hospital import Hospital

@dataclass
class HospitalSession:
    life: Life = field(default_factory=lambda:Life(progress=2,place='S2'))
    hospital: Hospital = field(default_factory=Hospital)
    search: Search = field(default_factory=lambda:Search(level=2,key_point=11))
    targets: tuple = tuple(range(12))  # Fixture target pool, not spawn sampling.
    room: str = 'waiting'
    paused: bool = False
    feedback: bool = False
    hit_stop: int = 0
    grip_gap: int = 800
    need_gap: bool = False
    doctor_harm_known: bool = False
    food_action: object = None
    food_ms: int = 0
    seen: set = field(default_factory=set)
    witness_paid: set = field(default_factory=set)
    transfer: object = None
    log: list = field(default_factory=list)

    def __post_init__(self):
        assert self.life.progress==2 and self.search.level==2
        assert len(self.targets)==12 and len(set(self.targets))==12 and self.search.key_point in self.targets
        self.hospital.episode=self.life.attempts[2]
        self.life.economy.battle=False
        self._pull()

    def active(self):
        return self.life.phase=='alive' and self.life.progress==2 and not self.paused

    def node(self, token):
        if not self.active() or token[0]!=self.life.epoch or token in self.seen: return False
        self.seen.add(token)
        return True

    def _pull(self):
        h=self.hospital; l=self.life
        h.hp,h.sp=l.hp,l.sp
        h.dead=l.phase=='dead'; h.paused=self.paused
        h.empty_stop=l.stun; h.empty_armed=not l.emptied

    def cancel_normal(self):
        for t in list(self.search.pending): self.search.settle(t,'cancel')
        self.hospital.interrupt_cup()
        self.hospital.bandaging=False
        self.food_action=None; self.food_ms=0

    def _push(self, before_holder=None, physical_hit=False):
        h=self.hospital; l=self.life
        newly_empty=l.sp>0 and h.sp==0 and h.empty_stop>0
        l.hp,l.sp=h.hp,h.sp
        l.stun=h.empty_stop; l.emptied=not h.empty_armed
        if h.dead:
            l.phase=l.economy.phase='dead'; l.stun=0
            self.cancel_normal(); h.holder=None
            self.hit_stop=0
            return
        if newly_empty or h.holder is not None: self.cancel_normal()
        if physical_hit:
            if not self.hit_stop: self.hit_stop=250
            self.cancel_normal()
        if before_holder is not None and h.holder is None:
            self.need_gap=True; self.grip_gap=0

    def blocked(self):
        h=self.hospital
        return bool(h.holder or h.drug_stop or self.life.stun or self.hit_stop)

    def _call(self, name, **kw):
        self._pull(); before=self.hospital.holder; hp=self.life.hp
        result=getattr(self.hospital,name)(**kw)
        self._push(before,physical_hit=self.hospital.hp<hp)
        return result

    def decision(self,danger=False):
        if self.life.phase=='dead': return 'dead'
        if self.life.progress!=2: return 'departed'
        if self.paused: return 'paused'
        if self.blocked(): return 'wait_effect'
        if danger: return 'evade'
        if self.search.key_owner=='avatar': return 'exit'
        if self.search.key_owner=='ground' and self.search.dropped_visible: return 'pickup'
        if self.food_action is not None: return 'eat'
        kinds=list(self.life.food.values())
        if self.life.hp<=50 and 'chocolate' in kinds: return 'eat'
        if self.life.sp<=50 and any(k in kinds for k in ('porridge','candy','chocolate')): return 'eat'
        if self.life.sp<50 or self.search.used>=SEARCH[2][2]: return 'bed'
        return 'search'

    def start_search(self,token,point):
        if not self.node(token): return None
        if self.room=='ward' or self.feedback or point not in self.targets or self.decision()!='search': return None
        if self.hospital.cup in ('held','raising') or self.hospital.bandaging: return None
        return self.search.start(point)

    def finish_feedback(self,token):
        if not self.node(token): return False
        self.feedback=False
        return True

    def hospital_action(self,token,name,**kw):
        if not self.node(token): return False
        # External actual contact/location checks precede this interface.
        if name=='begin_exam':
            if self.search.pending or self.feedback or self.blocked() or self.decision() in ('exit','bed','eat'): return False
            kw['dangerous']=self.doctor_harm_known or kw.get('dangerous',False)
        if name=='prepare' and self.decision() in ('exit','bed','eat'): return False
        if name in ('grip_exam','grip_guard'):
            if self.hospital.holder or self.blocked() or (self.need_gap and self.grip_gap<800): return False
        if name in ('take_cup','raise_cup','start_bandage'):
            if self.blocked() or self.search.pending or self.feedback or self.food_action is not None: return False
            if self.decision() in ('exit','bed'): return False
        allowed={'give_prescription','prepare','take_cup','raise_cup','interrupt_cup','refuse',
                 'complete_false_label','begin_exam','grip_exam','end_exam','withdraw',
                 'doctor_hit_releases','file_report','receive_report','approach_guard',
                 'grip_guard','release_guard','start_bandage','interrupt_bandage'}
        if name not in allowed: return False
        result=self._call(name,**kw)
        if result and name in ('grip_exam','grip_guard'):
            self.need_gap=True; self.grip_gap=0
        return result

    def begin_food(self,token,item,danger=False):
        if not self.node(token) or self.blocked() or danger or item not in self.life.food or self.food_action is not None: return False
        self.cancel_normal(); self.food_action=item; self.food_ms=0
        return True

    def batch(self,token,events):
        """One node's actual facts, each supplied once; duplicate node rejected.

        Supported: search_done(token), search_cancel(token), damage((hp,sp)),
        needle(True), swallow(True), food(item), exit(True), transfer(event).
        New action invitations, skills and elapsed time are separate boundaries.
        """
        if not self.node(token): return 'ignored'
        self._pull(); h=self.hospital; l=self.life
        ev=list(events)
        can_exit_before=not self.blocked()
        food_ready=(self.food_action if self.food_ms>=1500 and not self.blocked() else None)
        # Actual completion survives a same-node cancellation request; pending
        # work is cancelled by subsequent real control/empty effects.
        complete={v for k,v in ev if k=='search_done'}
        for t in complete:
            info=self.search.pending.get(t)
            if info and not self.blocked():
                old=self.search.income; self.search.settle(t)
                if self.search.income>old:
                    l.economy.credit(('S2-search',self.search.attempt,info[1]),1)
                self.feedback=True
        for k,v in ev:
            if k=='search_cancel' and v not in complete and self.search.settle(v,'cancel'): self.feedback=True
        before_holder=h.holder; hp_before=h.hp
        # Damage and actual medical contact precede restoration / exit.
        for k,v in ev:
            if k=='damage': h._damage(hp=v[0],sp=v[1])
            elif k=='needle' and v:
                if h.insert_needle(): self.doctor_harm_known=True
            elif k=='swallow' and v: h.swallow()
            elif k=='transfer':
                ident=v['id']
                if v['attempt']==l.attempts[2] and ident not in self.witness_paid:
                    self.witness_paid.add(ident); h._damage(sp=v['sp_damage'])
        self._push(before_holder,physical_hit=h.hp<hp_before)
        if l.phase=='dead': return 'death'
        if food_ready is not None and any(k=='food' and v==food_ready for k,v in ev):
            l.frame((l.epoch,('S2-food',token[1])),[('food',food_ready)])
            self.food_action=None; self.food_ms=0; self._pull()
        if any(k=='exit' and v for k,v in ev) and can_exit_before and not h.holder and self.search.key_owner=='avatar':
            l.frame((l.epoch,('S2-exit',token[1])),[('exit',True)])
            l.finish_exit(); self.cancel_normal(); h.holder=None
            self.hit_stop=0; h.drug_stop=h.empty_stop=0
            return 'exit'
        return 'alive'

    def tick(self,token,ms,route=True,contact=True):
        assert ms>=0
        if not self.node(token): return False
        remaining=ms
        while remaining and self.active():
            self._pull(); h=self.hospital
            limits=[v for v in (h.drug_stop,h.empty_stop,self.hit_stop) if v>0]
            if h.holder=='doctor': limits.append(max(1,4000-h.hold_ms))
            if h.holder=='guard': limits.append(max(1,6000-h.guard_ms))
            if h.exam=='sampling': limits.append(max(1,2000-h.sample_ms))
            step=min([remaining,*limits])
            was_free=not self.blocked(); before=h.holder
            if was_free and self.need_gap: self.grip_gap=min(800,self.grip_gap+step)
            if was_free and self.food_action is not None: self.food_ms+=step
            h.tick(step,contact=contact,route=route)
            self.hit_stop=max(0,self.hit_stop-step)
            self.life.economy.paused=False; self.life.economy.tick(step)
            self._push(before)
            remaining-=step
        return True

    def skill(self,token,name,actual=True,hit=False):
        if not self.node(token): return 'invalid'
        # This round wires only six actions needed for S2 branches. No control
        # or skill tree unlock simulation; caller supplies already unlocked skills.
        if name not in ('skin','gut','withdraw','knee','fear','joy'): return 'unmodeled'
        mental=name in ('fear','joy')
        valid=mental or not (self.life.stun or self.hit_stop or self.hospital.drug_stop or self.hospital.holder)
        # Doctor-specific actual knee contact may release a grip if executable.
        if name=='knee' and self.hospital.holder=='doctor' and not (self.life.stun or self.hit_stop or self.hospital.drug_stop): valid=True
        result=self.life.economy.cast(name,valid=valid,body_reacts=actual)
        if result!='reacted': return result
        if name in ('skin','gut','withdraw','knee','fear'):
            for t in list(self.search.pending): self.search.settle(t,'cancel')
        if name=='gut' and self.hospital.cup in ('held','raising'): self._call('refuse')
        if name=='withdraw': self._call('withdraw')
        if name=='knee' and hit: self._call('doctor_hit_releases')
        if name in ('fear','joy'):
            kind='sp_damage' if name=='fear' else 'heal_sp'
            self.life.frame((self.life.epoch,('S2-skill',token[1])),[(kind,15 if name=='fear' else 20)])
            self._pull()
            if self.life.stun: self.cancel_normal()
        return result

    def change_room(self,token,room):
        if not self.node(token) or room not in ('ward','waiting','exam','pharmacy','office') or self.blocked(): return False
        self.cancel_normal(); self.room=room
        return True

    def _reset_attempt(self):
        self.search.restart(self.search.key_point)
        self.hospital.new_attempt()
        self.hospital.episode=self.life.attempts[2]
        self.room='ward'; self.feedback=False
        self.hit_stop=0; self.need_gap=False; self.grip_gap=800
        self.food_action=None; self.food_ms=0
        if self.transfer is not None: self.transfer.reset_attempt(self.life.attempts[2])
        self._pull()

    def rest(self,token,completed=True):
        if not self.node(token) or not completed or self.room!='ward' or self.blocked(): return False
        if self.decision() not in ('bed','search'): return False
        if not self.life.rest(): return False
        self._reset_attempt(); return True

    def revive(self):
        if not self.life.revive(): return False
        self.life.place='S2'; self._reset_attempt(); return True

    def reload(self):
        return deepcopy(self) # state snapshot only; not filesystem save testing.
