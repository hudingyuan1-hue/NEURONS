from copy import deepcopy
from itertools import permutations,product
import pytest
from hypothesis import given,settings,strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant,precondition
from rules import Skill
from hospital_session import HospitalSession

class Driver:
    def __init__(self,s=None): self.s=s or HospitalSession(); self.seq=0
    def n(self): self.seq+=1; return (self.s.life.epoch,self.seq)
    def action(self,name,**kw): return self.s.hospital_action(self.n(),name,**kw)
    def tick(self,ms,**kw): return self.s.tick(self.n(),ms,**kw)
    def batch(self,*events): return self.s.batch(self.n(),events)

def offer_guard(d):
    d.s.hospital.guard_present=True
    assert d.action('file_report') and d.action('receive_report') and d.action('approach_guard')

def grip_doctor(d):
    assert d.action('begin_exam') and d.action('grip_exam')

def cup(d):
    assert d.action('give_prescription') and d.action('prepare')
    assert d.action('take_cup') and d.action('raise_cup')

def equip(s):
    # Fixtures only: do not grant these unlocks in actual gameplay.
    for name,cost,power,cd in [('skin',1,1,2000),('gut',1,1,2000),('withdraw',2,2,4000),
                              ('knee',2,2,4000),('fear',3,3,8000),('joy',3,3,8000)]:
        s.life.economy.skills[name]=Skill(cost,power,cd)

def facts(s):
    return deepcopy((s.life,s.hospital,s.search,s.doctor_harm_known,s.hit_stop,s.grip_gap,
                     s.need_gap,s.feedback,s.food_action,s.food_ms,s.room,s.witness_paid))

def test_actual_grip_cancels_search_once_no_reward():
    d=Driver(); t=d.s.start_search(d.n(),0); n=d.s.life.economy.n
    offer_guard(d); assert d.action('grip_guard')
    assert d.s.search.used==1 and not d.s.search.pending and d.s.search.income==0
    assert (d.s.life.hp,d.s.life.sp)==(95,90) and d.s.life.economy.n==n
    d.batch(('search_done',t)); assert d.s.search.income==0 and d.s.search.used==1

@pytest.mark.parametrize('kind',['search','cup','bandage','food'])
def test_mental_empty_cancels_unfinished_ordinary_action(kind):
    d=Driver(); s=d.s
    if kind=='search':s.start_search(d.n(),0)
    if kind=='cup':cup(d);d.tick(500)
    if kind=='bandage':s.life.hp=50;s._pull();d.action('start_bandage');d.tick(1500)
    if kind=='food':s.life.food['c']='candy';s.begin_food(d.n(),'c');d.tick(500)
    d.batch(('damage',(0,100)))
    assert s.life.sp==0 and s.life.stun==1000 and not s.search.pending
    assert s.hospital.cup!='raising' and not s.hospital.bandaging and s.food_action is None
    assert s.search.income==0
    d.tick(1000);assert s.decision()=='bed'
    d.batch(('damage',(0,10)));assert s.life.stun==0

@pytest.mark.parametrize('restored',[19,20,100])
def test_empty_rearm_boundary(restored):
    d=Driver();d.batch(('damage',(0,100)));d.tick(1000)
    d.s.life.frame((0,('fixture_restore',1)),[('heal_sp',restored)]);d.s._pull()
    d.batch(('damage',(0,100)))
    assert d.s.life.stun==(1000 if restored>=20 else 0)

def test_invitation_waits_for_search_and_feedback():
    d=Driver();t=d.s.start_search(d.n(),0)
    assert not d.action('begin_exam')
    d.batch(('search_done',t));assert not d.action('begin_exam')
    d.s.finish_feedback(d.n());assert d.action('begin_exam')

@pytest.mark.parametrize('reason',['key','low_sp','budget'])
@pytest.mark.parametrize('name',['begin_exam','prepare'])
def test_departure_not_overridden_by_new_invitation(reason,name):
    d=Driver()
    if reason=='key': d.s.search.key_owner='avatar'
    elif reason=='low_sp':d.s.life.sp=49
    else:d.s.search.used=12
    d.action('give_prescription')
    assert not d.action(name)
    assert d.s.decision()==('exit' if reason=='key' else 'bed')

@pytest.mark.parametrize('end',['manual','sample','timeout'])
def test_next_grip_waits_800ms_after_recovery(end):
    d=Driver();grip_doctor(d)
    if end=='manual':d.action('end_exam')
    elif end=='sample':d.batch(('needle',True));d.tick(2000)
    else:d.tick(4000)
    assert not d.s.blocked()
    offer_guard(d)
    assert not d.action('grip_guard')
    d.tick(799);assert not d.action('grip_guard')
    d.tick(1);assert d.action('grip_guard')
    assert (d.s.life.hp,d.s.life.sp)==(90 if end=='sample' else 95,90)

def test_grip_gap_starts_after_drug_and_empty_stop_end():
    d=Driver();cup(d);d.tick(1000);d.batch(('swallow',True))
    # Actual preceding grip released at this boundary; overlapping stops survive.
    d.s.need_gap=True;d.s.grip_gap=0;d.s.life.sp=0;d.s.life.stun=1000;d.s._pull()
    offer_guard(d)
    d.tick(999);assert d.s.grip_gap==0 and not d.action('grip_guard')
    d.tick(1);assert d.s.grip_gap==0
    d.tick(799);assert not d.action('grip_guard')
    d.tick(1);assert d.action('grip_guard')

def test_hit_during_gap_requires_fresh_actionable_interval():
    d=Driver();grip_doctor(d);d.action('end_exam');offer_guard(d)
    d.tick(600);d.batch(('damage',(1,0)));d.tick(250)
    assert d.s.grip_gap==0
    d.tick(799);assert not d.action('grip_guard')
    d.tick(1);assert d.action('grip_guard')

def test_repeated_hits_do_not_extend_ordinary_hit_stun():
    d=Driver();d.batch(('damage',(1,0)));assert d.s.hit_stop==250
    d.tick(200);d.batch(('damage',(1,0)))
    assert d.s.hit_stop==50 and d.s.life.hp==98
    d.tick(50);assert not d.s.blocked()

def test_long_tick_and_sliced_ticks_equal_after_grip_release():
    a=Driver();grip_doctor(a);offer_guard(a)
    b=Driver(a.s.reload());b.seq=a.seq
    a.tick(4800)
    for ms in [2000,1999,1,799,1]:b.tick(ms)
    assert facts(a.s)==facts(b.s)
    assert a.action('grip_guard') and b.action('grip_guard')

@pytest.mark.parametrize('end',['rest','death'])
def test_doctor_memory_and_cooldown_survive_real_restart(end):
    d=Driver();equip(d.s);d.s.life.economy.n=1
    grip_doctor(d);d.batch(('needle',True));d.tick(2000)
    d.s.life.economy.skills['skin'].remaining=1234
    if end=='rest':
        d.s.change_room(d.n(),'ward');assert d.s.rest(d.n())
    else:d.batch(('damage',(100,0)));assert d.s.revive()
    s=d.s
    assert s.doctor_harm_known and s.hospital.needle_count==0
    assert s.life.economy.n==5 and s.life.economy.skills['skin'].remaining==1234
    assert s.life.attempts[2]==2 and s.life.total==(2 if end=='rest' else 4)
    assert d.action('begin_exam') and s.hospital.exam=='refused'

def test_same_room_return_and_reload_do_not_reset_results():
    d=Driver();d.s.life.hp=70;d.s._pull();d.action('start_bandage');d.tick(3000)
    d.action('file_report');d.s.change_room(d.n(),'office');d.s.change_room(d.n(),'ward')
    before=facts(d.s);d.s=d.s.reload();assert facts(d.s)==before
    assert d.s.hospital.healed and d.s.hospital.report=='desk'
    assert not d.action('start_bandage') and d.s.life.attempts[2]==1

@pytest.mark.parametrize('n',[0,4,5,17])
def test_rest_resource_floor_and_growth_commit_once(n):
    d=Driver();s=d.s;s.room='ward';s.life.economy.n=n
    skin=s.life.economy.skills['skin'];skin.pending=True;skin.remaining=1500
    token=d.n();assert s.rest(token)
    assert not s.rest(token)
    assert s.life.economy.n==max(5,n) and skin.resistance==1 and skin.remaining==1500
    assert s.life.attempts[2]==2 and s.search.attempt==2

@pytest.mark.parametrize('blocked',['paused','dead','gripped','not_completed','wrong_room'])
def test_invalid_rest_cannot_reset_attempt(blocked):
    d=Driver();s=d.s;s.room='ward';s.life.hp=5
    if blocked=='paused':s.paused=True
    elif blocked=='dead':d.batch(('damage',(5,0)))
    elif blocked=='gripped':grip_doctor(d)
    elif blocked=='wrong_room':s.room='waiting'
    before=facts(s)
    assert not s.rest(d.n(),completed=blocked!='not_completed')
    assert facts(s)==before

@pytest.mark.parametrize('order',list(permutations(range(2))))
@pytest.mark.parametrize('hp,sp,damage',[(5,100,(5,0)),(6,100,(5,0)),(100,10,(0,10))])
def test_exit_same_node_damage_priority(order,hp,sp,damage):
    d=Driver();s=d.s;s.life.hp=hp;s.life.sp=sp;s.search.key_owner='avatar';s._pull()
    ev=[('damage',damage),('exit',True)]
    d.batch(*(ev[i] for i in order))
    if hp<=damage[0]:assert s.life.phase=='dead' and s.life.progress==2
    else:
        assert s.life.progress==3 and (s.life.hp,s.life.sp)==(hp-damage[0],sp-damage[1])
        assert s.life.economy.n==8 and s.life.economy.c==5

@pytest.mark.parametrize('order',list(permutations(range(2))))
def test_lethal_damage_beats_completed_food(order):
    d=Driver();s=d.s;s.life.hp=5;s.life.food['choc']='chocolate';s._pull()
    assert s.begin_food(d.n(),'choc');d.tick(1500)
    ev=[('damage',(5,0)),('food','choc')];d.batch(*(ev[i] for i in order))
    assert s.life.phase=='dead' and s.life.food=={'choc':'chocolate'} and s.life.economy.n==5

@pytest.mark.parametrize('elapsed',[0,1499,1500])
def test_food_consumption_timing_and_single_income(elapsed):
    d=Driver();s=d.s;s.life.sp=40;s.life.food['p']='porridge';s._pull()
    s.begin_food(d.n(),'p');d.tick(elapsed);token=d.n();s.batch(token,[('food','p')])
    if elapsed<1500:assert s.life.sp==40 and s.life.economy.n==5 and 'p' in s.life.food
    else:assert s.life.sp==100 and s.life.economy.n==10 and s.life.economy.c==4 and 'p' not in s.life.food
    before=facts(s);s.batch(token,[('food','p')]);assert facts(s)==before

def test_damage_before_swallow_interrupts_food_without_consumption():
    d=Driver();s=d.s;s.life.food['c']='candy';s.begin_food(d.n(),'c');d.tick(1499)
    d.batch(('damage',(1,0)));d.tick(1000);d.batch(('food','c'))
    assert s.life.food=={'c':'candy'} and s.life.economy.n==5

@pytest.mark.parametrize('effect',['no_money','resisted','reacted','interrupted'])
def test_skill_cost_resistance_search_and_actual_reaction(effect):
    d=Driver();s=d.s;equip(s);s.life.economy.n=0 if effect=='no_money' else 5
    t=s.start_search(d.n(),0)
    if effect=='resisted':s.life.economy.skills['skin'].resistance=1
    result=s.skill(d.n(),'skin',actual=effect!='interrupted')
    assert result=={'no_money':'invalid','resisted':'resisted','reacted':'reacted','interrupted':'interrupted'}[effect]
    assert s.life.economy.n==(0 if effect=='no_money' else 4)
    assert bool(s.search.pending)==(effect!='reacted')
    if effect!='reacted':d.batch(('search_done',t));assert s.search.income==1
    else:assert s.search.income==0 and s.search.used==1

def test_joy_does_not_release_grip_or_drug_stop():
    d=Driver();s=d.s;equip(s);grip_doctor(d);s.hospital.drug_stop=1000;s.life.sp=0;s.life.stun=1000;s._pull()
    assert s.skill(d.n(),'joy')=='reacted'
    assert s.life.sp==20 and s.life.stun==1000 and s.hospital.drug_stop==1000 and s.hospital.holder=='doctor'
    before=s.life.economy.n
    assert s.skill(d.n(),'withdraw')=='invalid' and s.life.economy.n==before

def test_nurse_and_medicine_do_not_grant_search_resources():
    d=Driver();s=d.s;s.life.hp=60;s._pull();d.action('start_bandage');d.tick(3000)
    cup(d);d.tick(1000);d.batch(('swallow',True));d.tick(1000)
    assert (s.life.hp,s.life.sp)==(70,85)
    assert (s.life.economy.n,s.life.economy.c,s.search.used)==(5,3,0)

@pytest.mark.parametrize('hp,sp,n',[(1,100,0),(1,49,0),(100,0,0),(50,50,4)])
def test_no_npc_high_resistance_route_remains_available(hp,sp,n):
    d=Driver();s=d.s;s.life.hp=hp;s.life.sp=sp;s.life.economy.n=n;s.life.economy.c=0
    s.life.economy.skills['skin'].resistance=999;s._pull()
    if sp<50:
        s.change_room(d.n(),'ward');assert s.rest(d.n());s.change_room(d.n(),'waiting')
    expected_start=s.life.economy.n
    for p in range(12):
        t=s.start_search(d.n(),p);assert t
        d.batch(('search_done',t));s.finish_feedback(d.n())
    assert s.search.key_owner=='avatar' and s.search.used==12
    assert d.batch(('exit',True))=='exit' and s.life.progress==3
    assert s.life.economy.n==expected_start+15 and s.life.economy.c==2

def test_old_callbacks_after_exit_or_revive_have_no_effect():
    d=Driver();s=d.s;old=d.n();d.batch(('damage',(100,0)));s.revive()
    before=facts(s);assert s.batch(old,[('needle',True),('damage',(100,100))])=='ignored';assert facts(s)==before
    s.search.key_owner='avatar';d.batch(('exit',True));before=facts(s)
    assert s.batch(d.n(),[('damage',(100,100))])=='ignored' and facts(s)==before

def test_paused_world_preserves_all_timers_and_resources():
    d=Driver();s=d.s;equip(s);cup(d);d.tick(500);s.life.economy.skills['skin'].remaining=2000;s.paused=True
    before=facts(s);d.tick(10000);d.batch(('swallow',True));s.skill(d.n(),'fear')
    assert facts(s)==before

@settings(max_examples=200,deadline=None)
@given(parts=st.lists(st.integers(0,800),min_size=1,max_size=15))
def test_split_free_grip_gap_is_additive(parts):
    d=Driver();grip_doctor(d);d.action('end_exam')
    for ms in parts:d.tick(ms)
    assert d.s.grip_gap==min(800,sum(parts))

class IntegratedHospitalMachine(RuleBasedStateMachine):
    def __init__(self):super().__init__();self.d=Driver();equip(self.d.s)
    @precondition(lambda self:self.d.s.active())
    @rule(p=st.integers(0,11))
    def start(self,p):self.d.s.start_search(self.d.n(),p)
    @precondition(lambda self:self.d.s.active())
    @rule(completed=st.booleans())
    def settle(self,completed):
        ev=[('search_done' if completed else 'search_cancel',t) for t in self.d.s.search.pending]
        self.d.batch(*ev);self.d.s.finish_feedback(self.d.n())
    @rule(ms=st.sampled_from([0,1,249,250,799,800,1000,3000,6000]))
    def tick(self,ms):self.d.tick(ms)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused
    @precondition(lambda self:self.d.s.active())
    @rule(hp=st.sampled_from([0,1,5,100]),sp=st.sampled_from([0,10,15,100]))
    def damage(self,hp,sp):self.d.batch(('damage',(hp,sp)))
    @precondition(lambda self:self.d.s.active())
    @rule(name=st.sampled_from(['skin','gut','withdraw','knee','fear','joy']))
    def skill(self,name):self.d.s.skill(self.d.n(),name,hit=True)
    @precondition(lambda self:self.d.s.active())
    @rule(name=st.sampled_from(['begin_exam','grip_exam','end_exam','give_prescription','prepare','take_cup',
                             'raise_cup','refuse','file_report','receive_report','approach_guard','grip_guard','start_bandage']))
    def medical(self,name):self.d.s.hospital.guard_present=True;self.d.action(name)
    @precondition(lambda self:self.d.s.active())
    @rule(kind=st.sampled_from(['needle','swallow','exit']))
    def completed(self,kind):self.d.batch((kind,True))
    @rule()
    def revive(self):self.d.s.revive()
    @precondition(lambda self:self.d.s.active())
    @rule()
    def bed(self):self.d.s.change_room(self.d.n(),'ward');self.d.s.rest(self.d.n());self.d.s.change_room(self.d.n(),'waiting')
    @rule()
    def reload(self):
        before=facts(self.d.s);self.d.s=self.d.s.reload();assert facts(self.d.s)==before
    @invariant()
    def coherent(self):
        s=self.d.s;h=s.hospital;l=s.life
        assert (l.hp,l.sp)==(h.hp,h.sp)
        assert 0<=l.hp<=100 and 0<=l.sp<=100 and l.economy.n>=0 and l.economy.c>=0
        assert s.search.used<=12 and h.healing_count<=1 and h.medication_count<=1
        assert h.needle_count<=1 and h.guard_damage_count<=1
        assert h.episode==l.attempts[2]
        if l.phase=='dead':assert not s.search.pending and not h.holder

TestIntegratedHospital=IntegratedHospitalMachine.TestCase
TestIntegratedHospital.settings=settings(max_examples=300,stateful_step_count=80,deadline=None)
