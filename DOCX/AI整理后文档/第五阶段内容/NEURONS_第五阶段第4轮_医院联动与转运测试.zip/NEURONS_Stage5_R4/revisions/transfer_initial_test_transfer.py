from copy import deepcopy
from itertools import product

import pytest
from hypothesis import given, settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant

from transfer import Transfer


def prepared():
    t = Transfer()
    assert t.issue_patient_order()
    assert t.start_patient()
    assert t.patient_step('handover')
    return t


def finish(t, observed=(True, True, True)):
    for step, seen in zip(('grab_frame', 'release_fingers', 'depart'), observed):
        assert t.patient_step(step, seen=seen)


@pytest.mark.parametrize('observed', list(product([False, True], repeat=3)))
def test_full_witness_requires_all_three_actual_visible_events(observed):
    t = prepared()
    finish(t, observed)
    events = t.drain_events()
    assert len(events) == int(all(observed))
    assert t.saw_departure is observed[-1]
    assert t.shoe_evidence and t.photo == 'footrest'
    if events:
        assert events == [{'id': ('S2-transfer', 1, 'S2-wheelchair'),
                           'attempt': 1, 'kind': 'full_witness', 'sp_damage': 10}]


@pytest.mark.parametrize('missing', ['guide', 'patient', 'worker', 'paper', 'idle'])
def test_patient_cannot_start_without_prerequisite(missing):
    t = Transfer()
    t.issue_patient_order()
    if missing == 'guide': t.set_presence(nurse=False)
    if missing == 'patient': t.set_presence(patient=False)
    if missing == 'worker': t.set_presence(worker=False)
    if missing == 'paper': t.patient_order = False
    if missing == 'idle':
        t.issue_bag_order()
        t.start_bag()
    assert not t.start_patient()
    assert t.patient == 'waiting'
    assert not t.shoe_dropped and not t.events


@pytest.mark.parametrize('form', ['laundry', 'patient_check', 'prescription', 'unknown'])
def test_paperwork_does_not_cross_authorize_patient(form):
    t = Transfer()
    assert not t.issue_patient_order(form=form)
    assert not t.start_patient()


@pytest.mark.parametrize('form', ['patient', 'patient_check', 'prescription', 'unknown'])
def test_paperwork_does_not_cross_authorize_bag(form):
    t = Transfer()
    assert not t.issue_bag_order(form=form)
    assert not t.start_bag()


@pytest.mark.parametrize('actual,match', [(False, True), (True, False), (False, False)])
def test_unreceived_or_mismatched_orders_cannot_start(actual, match):
    t = Transfer()
    assert not t.issue_patient_order(actual=actual, match=match)
    assert not t.issue_bag_order(actual=actual, match=match)
    assert not t.start_patient() and not t.start_bag()


def test_registration_delays_handover_but_cannot_revoke_committed_transfer():
    t = Transfer()
    t.issue_patient_order()
    t.set_nurse_busy(True)
    assert not t.start_patient()
    t.set_nurse_busy(False)
    assert t.start_patient()
    t.set_nurse_busy(True)
    assert not t.patient_step('handover')
    t.set_nurse_busy(False)
    assert t.patient_step('handover')
    t.set_nurse_busy(True)
    finish(t)
    assert len(t.events) == 1 and t.patient == 'departed'


@pytest.mark.parametrize('first', ['bag', 'patient'])
def test_shared_worker_cannot_run_both_jobs_and_can_work_sequentially(first):
    t = Transfer()
    t.issue_bag_order()
    t.issue_patient_order()
    if first == 'bag':
        assert t.start_bag()
        assert not t.start_patient()
        for step in ('check_tag', 'lift', 'depart'): assert t.bag_step(step)
        assert t.start_patient()
        assert t.patient_step('handover')
        finish(t)
    else:
        assert t.start_patient()
        assert not t.start_bag()
        assert t.patient_step('handover')
        finish(t)
        assert t.start_bag()
        for step in ('check_tag', 'lift', 'depart'): assert t.bag_step(step)
    assert t.worker_job is None and t.bag == 'removed' and t.patient == 'departed'


def test_blocked_patient_waits_at_actual_node_and_no_evidence_is_preissued():
    t = prepared()
    for _ in range(100):
        assert not t.patient_step('grab_frame', route_clear=False, seen=True)
        assert not t.write_departure_record()
        assert not t.collect_photo()
    assert not t.shoe_dropped and not t.shoe_evidence
    assert t.patient_step('grab_frame', seen=True)
    assert t.shoe_dropped and not t.shoe_evidence and t.photo == 'footrest'
    assert t.patient_step('release_fingers', seen=True)
    for _ in range(100):
        assert not t.patient_step('depart', route_clear=False, seen=True)
    assert t.patient == 'released' and not t.shoe_evidence and not t.events
    assert t.patient_step('depart', seen=True)
    assert t.shoe_evidence and len(t.events) == 1


def test_blocked_bag_keeps_carried_position_no_scene_reload_respawn():
    t = Transfer()
    t.issue_bag_order()
    t.start_bag()
    assert not t.bag_step('lift')
    assert not t.bag_step('check_tag', match=False)
    assert t.bag_step('check_tag') and t.bag_step('lift')
    for _ in range(50):
        assert not t.bag_step('depart', route_clear=False)
        t = t.save_load().reenter()
        assert t.bag == 'carried' and t.worker_job == 'bag'
    assert t.bag_step('depart')
    assert t.reenter().bag == 'removed'
    assert not t.start_bag()


def test_bag_reading_never_owns_worker_or_proves_patient_identity():
    t = Transfer()
    t.issue_bag_order()
    t.start_bag()
    for _ in range(100): assert t.read_bag_tag()
    for step in ('check_tag', 'lift', 'depart'): assert t.bag_step(step)
    assert not t.read_bag_tag()
    assert t.read_laundry_stub()
    assert not t.known_patient_id and not t.departure_record and not t.events


def test_false_record_and_photo_collection_require_real_transfer():
    t = prepared()
    assert not t.write_departure_record() and not t.collect_photo()
    finish(t, (False, False, False))
    assert t.write_departure_record() and t.collect_photo()
    assert t.photo == 'unclaimed' and not t.can_challenge_record()
    assert not t.events and not t.saw_departure


def test_challenge_requires_identity_and_full_witness_and_record():
    t = prepared()
    finish(t)
    assert not t.can_challenge_record()
    assert t.write_departure_record()
    assert not t.can_challenge_record()
    assert not t.identify_patient(match=False)
    assert t.identify_patient()
    assert t.can_challenge_record()


def test_duplicate_departure_load_and_reentry_cannot_repeat_damage_or_photo():
    t = prepared()
    finish(t)
    assert len(t.drain_events()) == 1
    assert t.collect_photo()
    for _ in range(100):
        t = t.save_load().reenter()
        assert not t.patient_step('depart', seen=True)
        assert not t.collect_photo()
        assert not t.drain_events()


@pytest.mark.parametrize('attempt', [0, 1, -1, True, 1.0])
def test_invalid_attempt_reset_keeps_current_state(attempt):
    t = prepared()
    t.patient_step('grab_frame', seen=True)
    old = deepcopy(t)
    assert not t.reset_attempt(attempt)
    assert t == old


def test_real_new_attempt_resets_local_outcomes_and_retains_history():
    t = prepared()
    finish(t)
    t.identify_patient()
    t.write_departure_record()
    old_event = t.drain_events()[0]
    assert t.reset_attempt(2)
    assert t.patient == 'waiting' and t.worker_job is None
    assert not t.events and not t.departure_record and not t.shoe_evidence
    assert (1, t.patient_id, 'full_witness') in t.knowledge
    assert (1, t.patient_id, 'transferred') in t.facts
    t.issue_patient_order()
    t.start_patient()
    t.patient_step('handover')
    finish(t)
    assert t.drain_events()[0]['id'] != old_event['id']


@pytest.mark.parametrize('step', ['handover', 'grab_frame', 'release_fingers', 'depart'])
def test_pause_or_unexecuted_callback_never_commits(step):
    t = Transfer()
    t.issue_patient_order()
    t.start_patient()
    for earlier in ('handover', 'grab_frame', 'release_fingers', 'depart'):
        if earlier == step: break
        t.patient_step(earlier, seen=True)
    before = deepcopy(t)
    assert not t.patient_step(step, actual=False, seen=True)
    assert t == before
    t.paused = True
    before = deepcopy(t)
    assert not t.patient_step(step, seen=True)
    assert t == before


def test_dead_observer_cannot_acquire_complete_witness_even_if_visible():
    t = prepared()
    t.patient_step('grab_frame', seen=True)
    t.patient_step('release_fingers', seen=True)
    t.patient_step('depart', seen=True, observer_alive=False)
    assert t.patient == 'departed' and not t.events


@given(st.permutations(['handover', 'grab_frame', 'release_fingers', 'depart']))
@settings(max_examples=24, deadline=None)
def test_out_of_order_callbacks_do_not_fabricate_transfer(sequence):
    t = Transfer()
    t.issue_patient_order()
    t.start_patient()
    for step in sequence: t.patient_step(step, seen=True)
    expected = tuple(sequence) == ('handover', 'grab_frame', 'release_fingers', 'depart')
    assert (t.patient == 'departed') is expected
    assert len(t.events) == int(expected)


class TransferMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.t = Transfer()
        self.delivered = set()

    @rule(nurse=st.booleans(), patient=st.booleans(), worker=st.booleans(), busy=st.booleans())
    def presence(self, nurse, patient, worker, busy):
        self.t.set_presence(nurse, patient, worker)
        self.t.set_nurse_busy(busy)

    @rule(actual=st.booleans(), match=st.booleans())
    def orders(self, actual, match):
        self.t.issue_patient_order(actual, match)
        self.t.issue_bag_order(actual, match)

    @rule(patient_first=st.booleans())
    def start(self, patient_first):
        (self.t.start_patient if patient_first else self.t.start_bag)()

    @rule(step=st.sampled_from(['handover', 'grab_frame', 'release_fingers', 'depart']),
          actual=st.booleans(), route=st.booleans(), seen=st.booleans())
    def patient(self, step, actual, route, seen):
        before = deepcopy(self.t)
        result = self.t.patient_step(step, actual, route, seen)
        if not result: assert self.t == before

    @rule(step=st.sampled_from(['check_tag', 'lift', 'depart']), actual=st.booleans(),
          route=st.booleans(), match=st.booleans())
    def bag(self, step, actual, route, match):
        before = deepcopy(self.t)
        result = self.t.bag_step(step, actual, route, match)
        if not result: assert self.t == before

    @rule(paused=st.booleans())
    def pause(self, paused):
        self.t.paused = paused

    @rule()
    def observe_and_record(self):
        self.t.read_bag_tag()
        self.t.read_laundry_stub()
        self.t.identify_patient()
        self.t.write_departure_record()
        self.t.collect_photo()

    @rule()
    def reload_and_drain(self):
        before = deepcopy(self.t)
        self.t = self.t.save_load().reenter()
        assert self.t == before
        for event in self.t.drain_events():
            assert event['id'] not in self.delivered
            self.delivered.add(event['id'])
            assert event['sp_damage'] == 10

    @rule()
    def new_attempt(self):
        before = self.t.attempt
        assert self.t.reset_attempt(before + 1)
        assert not self.t.events and not self.t.witnessed

    @invariant()
    def causal_facts_and_exclusive_actor(self):
        t = self.t
        if t.patient in ('queued', 'pushing', 'gripping', 'released'):
            assert t.worker_job == 'patient'
        if t.bag == 'carried': assert t.worker_job == 'bag'
        if t.shoe_evidence or t.departure_record or t.photo == 'unclaimed':
            assert t.patient == 'departed'
        if t.patient == 'departed':
            assert t.shoe_dropped and (t.attempt, t.patient_id, 'transferred') in t.facts
        for event in t.events:
            assert (event['attempt'], t.patient_id, 'full_witness') in t.knowledge
            assert event['id'] in t.emitted_ids
        assert len({e['id'] for e in t.events}) == len(t.events)


TestTransferMachine = TransferMachine.TestCase
TestTransferMachine.settings = settings(max_examples=200, stateful_step_count=60,
                                        deadline=None, derandomize=False)
