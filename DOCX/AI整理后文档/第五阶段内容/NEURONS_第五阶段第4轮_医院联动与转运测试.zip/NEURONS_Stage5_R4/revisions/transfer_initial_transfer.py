"""S2 shared porter and transfer facts. Geometry/actual contact supplied by caller.

S3:P372-436/T8/T12/T20; S4:T15R2/P182. Does not change avatar values.
Formal dialogue, actual visibility and reached route nodes remain external facts.
"""
from dataclasses import dataclass, field
from copy import deepcopy


@dataclass
class Transfer:
    attempt: int = 1
    patient_id: str = 'S2-wheelchair'
    bag_id: str = 'S2-laundry'
    guide_present: bool = True
    patient_present: bool = True
    worker_present: bool = True
    nurse_busy: bool = False
    paused: bool = False
    world_active: bool = True
    worker_job: str | None = None
    patient_order: bool = False
    bag_order: bool = False
    patient: str = 'waiting'
    bag: str = 'ground'
    bag_tag_checked: bool = False
    shoe_dropped: bool = False
    photo: str = 'held'
    shoe_evidence: bool = False
    departure_record: bool = False
    known_patient_id: bool = False
    known_bag_tag: bool = False
    saw_departure: bool = False
    witnessed: set = field(default_factory=set)
    facts: set = field(default_factory=set)
    knowledge: set = field(default_factory=set)
    emitted_ids: set = field(default_factory=set)
    events: list = field(default_factory=list)

    def active(self):
        return self.world_active and not self.paused

    def set_presence(self, nurse=None, patient=None, worker=None):
        if nurse is not None:
            self.guide_present = bool(nurse)
        if patient is not None:
            self.patient_present = bool(patient)
        if worker is not None:
            self.worker_present = bool(worker)

    def set_nurse_busy(self, busy):
        self.nurse_busy = bool(busy)

    def issue_patient_order(self, actual=True, match=True, ident=None, form='patient'):
        if not (self.active() and actual and match and form == 'patient'
                and (ident is None or ident == self.patient_id)):
            return False
        self.patient_order = True
        return True

    def issue_bag_order(self, actual=True, match=True, ident=None, form='laundry'):
        if not (self.active() and actual and match and form == 'laundry'
                and (ident is None or ident == self.bag_id)):
            return False
        self.bag_order = True
        return True

    def start_patient(self):
        if not (self.active() and self.guide_present and self.patient_present
                and self.worker_present and self.patient_order
                and self.worker_job is None and self.patient == 'waiting'
                and not self.nurse_busy):
            return False
        self.worker_job, self.patient = 'patient', 'queued'
        return True

    def start_bag(self):
        if not (self.active() and self.worker_present and self.bag_order
                and self.worker_job is None and self.bag == 'ground'):
            return False
        self.worker_job = 'bag'
        return True

    def patient_step(self, step, actual=True, route_clear=True, seen=False,
                     observer_alive=True):
        if not (self.active() and actual and self.worker_job == 'patient'
                and self.worker_present and self.patient_present):
            return False
        before = {'handover': 'queued', 'grab_frame': 'pushing',
                  'release_fingers': 'gripping', 'depart': 'released'}
        if before.get(step) != self.patient:
            return False
        if step == 'handover':
            if not self.guide_present or self.nurse_busy:
                return False
            self.patient = 'pushing'
        elif step == 'grab_frame':
            if not route_clear:
                return False
            self.patient, self.shoe_dropped, self.photo = 'gripping', True, 'footrest'
        elif step == 'release_fingers':
            if not self.guide_present:
                return False
            self.patient = 'released'
        else:
            if not route_clear:
                return False
            self.patient, self.worker_job = 'departed', None
            self.shoe_evidence = True
            self.facts.add((self.attempt, self.patient_id, 'transferred'))
        if seen and observer_alive and step in ('grab_frame', 'release_fingers', 'depart'):
            self.witnessed.add(step)
            self.knowledge.add((self.attempt, self.patient_id, 'saw_' + step))
            if step == 'depart':
                self.saw_departure = True
        required = {'grab_frame', 'release_fingers', 'depart'}
        if step == 'depart' and self.witnessed == required:
            ident = ('S2-transfer', self.attempt, self.patient_id)
            if ident not in self.emitted_ids:
                self.emitted_ids.add(ident)
                self.events.append({'id': ident, 'attempt': self.attempt,
                                    'kind': 'full_witness', 'sp_damage': 10})
                self.knowledge.add((self.attempt, self.patient_id, 'full_witness'))
        return True

    def bag_step(self, step, actual=True, route_clear=True, match=True):
        if not (self.active() and actual and self.worker_job == 'bag' and self.worker_present):
            return False
        if step == 'check_tag' and self.bag == 'ground' and match:
            self.bag_tag_checked = True
        elif step == 'lift' and self.bag == 'ground' and self.bag_tag_checked:
            self.bag = 'carried'
        elif step == 'depart' and self.bag == 'carried' and route_clear:
            self.bag, self.worker_job = 'removed', None
            self.facts.add((self.attempt, self.bag_id, 'removed'))
        else:
            return False
        return True

    def read_bag_tag(self, actual=True):
        if not (self.active() and actual and self.bag != 'removed'):
            return False
        self.known_bag_tag = True
        self.knowledge.add((self.attempt, self.bag_id, 'tag_read'))
        return True

    def read_laundry_stub(self, actual=True):
        if not (self.active() and actual and self.bag == 'removed'):
            return False
        self.known_bag_tag = True
        self.knowledge.add((self.attempt, self.bag_id, 'stub_read'))
        return True

    def identify_patient(self, actual=True, match=True):
        if not (self.active() and actual and match):
            return False
        self.known_patient_id = True
        self.knowledge.add((self.attempt, self.patient_id, 'identified'))
        return True

    def write_departure_record(self, actual=True):
        # The wording can be false, but cannot create physical transfer or witness.
        if not (self.active() and actual and self.patient == 'departed'):
            return False
        self.departure_record = True
        self.facts.add((self.attempt, self.patient_id, 'false_departure_record'))
        return True

    def collect_photo(self, actual=True, match=True):
        # Later unclaimed-property collection, not a player inventory reward.
        if not (self.active() and actual and match and self.patient == 'departed'
                and self.photo == 'footrest'):
            return False
        self.photo = 'unclaimed'
        self.facts.add((self.attempt, self.patient_id, 'photo_collected'))
        return True

    def can_challenge_record(self):
        return (self.departure_record and self.known_patient_id
                and (self.attempt, self.patient_id, 'full_witness') in self.knowledge)

    def drain_events(self):
        result, self.events = self.events, []
        return result

    def reenter(self):
        # Scene switches never reconstruct this entity or its local event state.
        return self

    def save_load(self):
        return deepcopy(self)

    def reset_attempt(self, attempt):
        if type(attempt) is not int or attempt <= self.attempt:
            return False
        fresh = type(self)(attempt=attempt, patient_id=self.patient_id, bag_id=self.bag_id)
        fresh.facts, fresh.knowledge = set(self.facts), set(self.knowledge)
        fresh.emitted_ids = set(self.emitted_ids)
        self.__dict__.update(fresh.__dict__)
        return True
