"""Reproduce preserved failures without replacing the corrected current model."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root=Path(__file__).resolve().parent
cases=[
 ('session', {'hospital_session.py':'revisions/session_initial/hospital_session.py',
              'test_hospital_session.py':'revisions/session_initial/test_hospital_session.py',
              'rules.py':'revisions/r3_rules.py','hospital.py':'revisions/r3_hospital.py'},
  ['test_hospital_session.py','-k','mental_empty_cancels_unfinished_ordinary_action or hit_during_gap']),
 ('unread_record', {'transfer.py':'revisions/transfer_initial_transfer.py',
                    'test_transfer.py':'revisions/transfer_evidence_initial_test.py'},
  ['test_transfer.py','-k','unread_false_record_does_not_unlock_challenge']),
]
for name,files,selectors in cases:
 with tempfile.TemporaryDirectory(prefix='neurons-r4-') as tmp:
  for dst,src in files.items():shutil.copy2(root/src,Path(tmp)/dst)
  r=subprocess.run([sys.executable,'-m','pytest','-q',*selectors,'--hypothesis-seed=2026101204'],
                   cwd=tmp,env=dict(os.environ),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  out=root/'results'/f'reproduced_{name}.log';out.write_text(r.stdout,encoding='utf-8')
  print(name,'expected=1 actual=',r.returncode,out.name)
  if r.returncode!=1:raise SystemExit('Unexpected reproduction result')
