"""Replay the six real recorded failures using archived pre-fix sources."""
from pathlib import Path
import subprocess,sys,tempfile,shutil

root=Path(__file__).resolve().parent
groups=[
    ('round1_extension',{'rules.py':'revisions/r1_rules.py','test_dog_regression.py':'test_dog_regression.py'},['test_dog_regression.py']),
    ('family_initial',{'rules.py':'revisions/family_initial_rules.py','family.py':'revisions/family_initial_family.py','test_family.py':'revisions/family_initial_test_family.py'},[
        'test_family.py::test_startle_reads_precancel_cat_target[2]',
        'test_family.py::test_dog_starts_with_tenth_avatar_search',
        'test_family.py::test_new_attempt_allows_parents_again_after_mother_rest'])]
for name,files,tests in groups:
    with tempfile.TemporaryDirectory(prefix='neurons_'+name+'_') as tmp:
        for dest,source in files.items(): shutil.copy2(root/source,Path(tmp)/dest)
        print(name,flush=True)
        result=subprocess.run([sys.executable,'-m','pytest','-q','--hypothesis-seed=2026101202',*tests],cwd=tmp)
        if result.returncode!=1: raise SystemExit('Expected recorded test failure, received '+str(result.returncode))
print('Both archived failure groups reproduced as expected.')
