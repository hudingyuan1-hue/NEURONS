"""R14: paid skills connect to each exploration host's one authoritative Search.

S2:P27-36/P64-92; S3 person-specific facts; S4:P20-23/P53/T14/P264.
All geometry, handoffs and visible actions are actual host callbacks. No engine
physics/animation or arbitrary participant presence is inferred by this model.
"""
from copy import deepcopy
from fractions import Fraction
from awareness import Awareness
from player_skills import PlayerSkills
from skill_effects import SkillEffects


class NativeAdapter:
    level=0

    def __init__(self,host):
        self.host=host
        if not self.level:self.level=host.life.progress
        self.awareness=getattr(host,'awareness',Awareness())
        self.serial=0

    @property
    def life(self):return self.host.life

    @property
    def search(self):return self.host.search

    @property
    def position(self):return getattr(self.host,'position',getattr(self.host,'room',None))

    @property
    def current_search(self):
        return next((ident for ident,(actor,_) in self.search.pending.items() if actor=='avatar'),None)

    def token(self,label='event'):
        self.serial+=1
        return self.life.epoch,('R14',self.serial,label)

    def sync(self,paused=False,loading=False):
        self.host.paused=bool(paused or loading)
        if hasattr(self.host,'loading'):self.host.loading=bool(loading)
        if hasattr(self.host,'_pull'):self.host._pull()
        elif hasattr(self.host,'_sync'):self.host._sync()
        self.life.economy.paused=bool(paused or loading)

    def blocked(self):return self.host.blocked()

    def rescue_skills(self):return ()

    def cancel_current_search(self):
        ident=self.current_search
        if ident is None:return False
        actor,point=self.search.pending[ident]
        result=self.search.settle(ident,'cancel')
        if result:
            if hasattr(self.host,'search_elapsed'):self.host.search_elapsed=0
            self.on_cancel_search(ident,point)
        return result

    def on_cancel_search(self,ident,point):pass

    def limits(self):
        return [getattr(self.host,k,0) for k in ('hit_stop','drug_stop','hold_remaining')]+[self.life.stun]

    def vitals(self,token,hp_damage=0,sp_damage=0,sp_heal=0):
        return self.life.frame(token,[('hp_damage',hp_damage),('sp_damage',sp_damage),('heal_sp',sp_heal)])

    def context(self):
        ident=self.current_search
        if ident is not None:return (str(self.position),'search',self.search.pending[ident][1])
        return (str(self.position),'idle','avatar')

    def apply(self,proposal,**facts):return None

    def contact(self,name,cast_id,**facts):return False

    def can_handoff(self,kind,identity,**facts):return False

    def handoff_valid(self,kind,identity,**facts):return True

    def cancel_handoff(self,identity):return False

    def complete_handoff(self,kind,identity,**facts):return False

    def control(self,action,**facts):return False

    def start(self,point,kind='normal',**facts):raise NotImplementedError

    def finish(self,ident,actual=True,**facts):raise NotImplementedError

    def advance(self,ms,search_factor=Fraction(1),action_paused=False):raise NotImplementedError

    def next_point(self,occupied=()):
        if hasattr(self.host,'next_point'):return self.host.next_point(occupied=occupied)
        if self.host.decision()!='search':return None
        pending={p for _,p in self.search.pending.values()}
        return next((p for p in self.host.targets if p not in self.search.complete and p not in occupied and p not in pending),None)


class ExplorationSkills:
    def __init__(self,adapter):
        self.adapter=adapter;self.host=adapter.host
        self.book=PlayerSkills(self.life.economy)
        self.effects=SkillEffects();self.awareness=adapter.awareness
        self.menu=None;self.closing=False;self.external_pause=False;self.loading=False
        self.host_pause=bool(self.host.paused);self.host_loading=bool(getattr(self.host,'loading',False))
        self._last_host_pause=self.host_pause;self._last_host_loading=self.host_loading
        self._marker=self._life_marker();self._last_hp=self.life.hp;self._was_blocked=self.adapter.blocked()
        self.applied=set();self.contact_done=set();self.commands={};self.feedback={}
        self.deferred_points={};self.handoff=None;self.handoff_history={}
        self.prefer_away_from=None
        self.pending_motion=None;self.events=[];self.clock=0
        self._sync()

    @property
    def life(self):return self.adapter.life

    @property
    def search(self):return self.adapter.search

    @property
    def paused(self):return bool(self.menu is not None or self.closing or self.external_pause or self.loading or self.host_pause or self.host_loading)

    @property
    def active(self):return self.life.phase=='alive' and self.life.progress==self.adapter.level

    def token(self,label='skill'):return self.adapter.token(label)

    def _life_marker(self):return (self.life.epoch,self.life.phase,self.life.progress)

    def _end(self,kind):
        self.book.end_context(kind);self.effects.clear_transients()
        self.awareness.transition('death' if kind=='death' else 'level')
        self.commands.clear();self.feedback.clear();self.deferred_points.clear();self.pending_motion=None
        self.prefer_away_from=None
        self.cancel_handoff()

    def cancel_handoff(self):
        if not self.handoff:return False
        h=self.handoff;h['status']='cancelled';self.handoff=None
        self.adapter.cancel_handoff(h['id'])
        return True

    def _sync(self):
        marker=self._life_marker();old=self._marker
        if marker[0]!=old[0] or marker[2]!=old[2] or marker[1]!=old[1] and marker[1] in ('dead','transition','ended'):
            self._end('death' if marker[1]=='dead' else 'level')
        self._marker=marker
        hpause=bool(self.host.paused);hload=bool(getattr(self.host,'loading',False))
        if hpause!=self._last_host_pause:self.host_pause=hpause
        if hload!=self._last_host_loading:self.host_loading=hload
        self.adapter.sync(paused=self.paused,loading=self.loading or self.host_loading)
        self._last_host_pause=bool(self.host.paused);self._last_host_loading=bool(getattr(self.host,'loading',False))
        if self.handoff:
            h=self.handoff
            if h['position']!=self.adapter.position or not self.adapter.handoff_valid(h['kind'],h['id'],**h['facts']):
                self.cancel_handoff()
        blocked=self.adapter.blocked()
        if self.life.hp<self._last_hp or blocked and not self._was_blocked:
            self.effects.interrupt_kick(actual=True);self.pending_motion=None
        self._last_hp=self.life.hp;self._was_blocked=blocked
        attack=self.effects.current_attack
        rescue=tuple(self.adapter.rescue_skills())
        self.book.sync_context(mode='explore',paused=self.paused,
            menu='cast' if self.menu=='cast' and not self.closing and not (self.external_pause or self.host_pause or self.host_loading) else None,
            loading=self.loading or self.host_loading,alive=self.active,
            transitioning=self.life.phase=='transition',body_blocked=blocked,
            attack_in_progress=self.effects.body_busy() or self.pending_motion is not None,
            attack_has_hit=bool(attack and attack['hit_targets']),
            can_cancel_attack=self.effects.may_cancel_attack('skin'),
            fourth_wall_restricted=self.awareness.restriction,
            rescue_allowed=bool(rescue),rescue_skills=rescue)
        self.life.economy.phase=self.life.phase
        self.awareness.paused=self.paused;self.awareness.alive=self.active;self.awareness.mode='explore'
        self.effects.paused=self.paused;self.effects.dead=not self.active

    def open_menu(self,kind='cast'):
        self._sync()
        if not self.active or self.loading or self.host_loading or kind not in ('cast','upgrade'):return False
        self.menu=kind;self.closing=False;self._sync();return True

    def close_menu(self,actual_finished=True):
        if self.menu is None:return False
        self.closing=True
        if actual_finished:self.menu=None;self.closing=False
        self._sync();return actual_finished

    def set_pause(self,value=False,loading=False):
        self.external_pause=bool(value);self.loading=bool(loading);self._sync()

    def set_host_pause(self,value=False,loading=False):
        self.host_pause=bool(value);self.host_loading=bool(loading);self._sync()

    def submit(self,name,token=None,**facts):
        self._sync()
        if self.closing or self.host_pause or self.host_loading or self.external_pause:return None
        # A S2 physical contact exception is not the S1 fourth-wall rescue exception.
        if not self.awareness.allowed_intervention():return None
        return self.book.submit(token or self.token('submit'),name,**facts)

    def react(self,cast_id,actual=True,perceived=True,hp_damage=0,**facts):
        self._sync();cast=self.book.casts.get(cast_id)
        if (not self.active or self.paused or not cast or cast['epoch']!=self.book.epoch
                or cast_id in self.applied or cast['status'] not in ('committed','resisted')):return None
        name=cast['name'];context=self.adapter.context();action_id=getattr(self.host,'action',None)
        conscious=not self.life.stun
        if cast['resisted']:
            if not actual:return None
            self.applied.add(cast_id)
            self.awareness.observe(cast_id,name,context,perceived=perceived,reaction=False,resisted=True,
                                   conscious=conscious,action_id=action_id)
            return dict(cast_id=cast_id,resisted=True)
        rescue=name in self.adapter.rescue_skills()
        if not actual or self.adapter.blocked() and name not in ('fear','happy') and not rescue:
            return self.book.interrupt(cast_id)
        ident=self.adapter.current_search
        effect_facts=dict(facts)
        if ident is not None:
            point=self.search.pending[ident][1]
            effect_facts['current_point']=point
            if name=='fear':
                alternative=self.adapter.next_point(occupied=tuple(self.deferred_points)+(point,))
                effect_facts['only_current_point']=alternative is None and self.host.decision()=='search'
        if self.handoff and self.handoff['status']=='pending':
            effect_facts.update(pending_handoff=True,handoff_id=self.handoff['id'],handoff_acquired=False)
        else:effect_facts.update(pending_handoff=False,handoff_acquired=False)
        proposal=self.effects.begin(cast,actual_reaction=True,
                                    body_available=not self.adapter.blocked() or rescue,**effect_facts)
        if not proposal:return self.book.interrupt(cast_id)
        control=name=='control'
        if not self.book.react(cast_id,actual=True,body_reacted=not control,duration_ms=proposal['duration_ms']):
            raise AssertionError('native reaction lost committed payment')
        self.applied.add(cast_id)
        if proposal.get('motion_duration_external'):self.pending_motion=cast_id
        if proposal.get('defer_current_point_ms'):
            self.deferred_points[proposal['deferred_point']]=proposal['defer_current_point_ms']
        if proposal.get('prefer_other_points') and ident is not None and not proposal.get('defer_current_point_ms'):
            self.prefer_away_from=point
        if proposal.get('handoff_delay_ms') and self.handoff and proposal['handoff_id']==self.handoff['id']:
            self.handoff['delay']=max(self.handoff['delay'],proposal['handoff_delay_ms'])
        if control:self.awareness.start_control(cast_id)
        outcome=self.adapter.vitals(self.token('skill_vitals'),hp_damage=hp_damage,
                    sp_damage=proposal['sp_damage'],sp_heal=proposal['sp_heal'])
        self._sync()
        if not self.active:return proposal
        if not control:
            self.awareness.observe(cast_id,name,context,perceived=perceived,reaction=True,conscious=conscious,
                action_id=action_id,changes_intent=bool(facts.get('changes_intent',False)))
        if proposal['cancel_search']:self.adapter.cancel_current_search()
        self.adapter.apply(proposal,**facts)
        self.feedback[name]=dict(cast_id=cast_id,proposal=deepcopy(proposal),control_has_action=False if control else None)
        self.events.append(proposal);self._sync();return proposal

    def contact(self,cast_id,actual=True,**facts):
        self._sync();cast=self.book.casts.get(cast_id)
        if (not self.active or self.paused or not actual or not cast or cast['epoch']!=self.book.epoch
                or cast['status']!='reacted' or cast_id in self.contact_done):return False
        name=cast['name']
        if name=='knee':
            attack=self.effects.kicks.get(('player_kick',cast_id))
            if not attack or attack['phase']!='active' or attack['cancelled']:return False
        if self.adapter.blocked() and name not in self.adapter.rescue_skills():return False
        result=self.adapter.contact(name,cast_id,**facts)
        if result:
            self.contact_done.add(cast_id)
            if name=='knee':attack['hit_targets'].add(facts.get('target','native_target'))
        self._sync();return result

    def start_search(self,point,kind='normal',**facts):
        self._sync()
        if (not self.active or self.paused or self.adapter.blocked() or self.effects.body_busy()
                or self.pending_motion is not None or self.deferred_points.get(point,0)>0):return None
        result=self.adapter.start(point,kind=kind,controlled=self.book.control_active,**facts)
        if result is not None and point!=self.prefer_away_from:self.prefer_away_from=None
        return result

    def complete_search(self,ident=None,actual=True,**facts):
        self._sync()
        if not self.active or self.paused or not actual or self.adapter.blocked() or self.effects.body_busy() or self.pending_motion is not None:return False
        return self.adapter.finish(ident if ident is not None else self.adapter.current_search,actual=actual,**facts)

    def next_point(self):
        self._sync()
        if not self.active or self.paused:return None
        occupied=tuple(p for p,t in self.deferred_points.items() if t>0)
        if self.prefer_away_from is not None:
            other=self.adapter.next_point(occupied=occupied+(self.prefer_away_from,))
            if other is not None:return other
        return self.adapter.next_point(occupied=occupied)

    def begin_handoff(self,kind,identity,**facts):
        self._sync()
        key=(self.life.epoch,identity)
        if (not self.active or self.paused or self.adapter.blocked() or self.handoff
                or key in self.handoff_history or not self.adapter.can_handoff(kind,identity,**facts)):return False
        record=dict(id=identity,key=key,kind=kind,facts=deepcopy(facts),status='pending',delay=0,position=self.adapter.position)
        self.handoff=self.handoff_history[key]=record;return True

    def complete_handoff(self,identity,actual=True,**facts):
        self._sync();h=self.handoff
        if (not self.active or self.paused or self.adapter.blocked() or not actual or not h
                or h['id']!=identity or h['status']!='pending' or h['delay']>0
                or h['position']!=self.adapter.position or self.effects.body_busy()):return False
        result=self.adapter.complete_handoff(h['kind'],identity,**{**h['facts'],**facts})
        if result:h['status']='completed';self.handoff=None
        self._sync();return result

    def command(self,kind,action=None,**facts):
        self._sync()
        result=self.book.control_command(self.token('command'),kind,**facts)
        if not result:return None
        result.update(action=action,facts=deepcopy(facts),position=self.adapter.position)
        self.commands[result['id']]=result;return deepcopy(result)

    def control_action(self,command_id,actual=True,**facts):
        self._sync();cmd=self.commands.get(command_id)
        if (not self.active or self.paused or not actual or self.adapter.blocked() or not cmd
                or cmd.get('completed') or not self.book.control_active or cmd['cast_id']!=self.book.control_id):return False
        action=cmd['action'];kwargs={**cmd['facts'],**facts}
        for key in ('valid_target','reachable','permitted','distance','facing_valid'):kwargs.pop(key,None)
        if action=='start_search':
            result=self.start_search(kwargs.pop('point'),**kwargs)
        elif action=='complete_search':result=self.complete_search(**kwargs)
        elif action=='complete_handoff':result=self.complete_handoff(**kwargs)
        else:result=self.adapter.control(action,**kwargs)
        if not result:return False
        cmd['completed']=True
        if hasattr(self.adapter,'control_completed') and action in ('start_search','complete_search','complete_handoff'):
            self.adapter.control_completed(action,command_id,**kwargs)
        elif hasattr(self.adapter,'control_witness'):
            self.adapter.control_witness(cmd['cast_id'],**kwargs)
        self.book.confirm_control_body(cmd['cast_id'],actual=True)
        self.awareness.control_action(cmd['cast_id'],command_id,self.adapter.context(),actual=True,
             against_intent=bool(facts.get('against_intent',True)),kind=cmd['kind'])
        if 'control' in self.feedback:self.feedback['control']['control_has_action']=True
        if self.adapter.position!=cmd['position'] and self.handoff:
            self.cancel_handoff()
        self._sync();return result

    def end_control(self):
        result=self.book.end_control()
        if result:self.awareness.end_control();self.effects.end_control();self.commands.clear()
        self._sync();return result

    def finish_motion(self,cast_id,actual_finished=True):
        self._sync()
        if not actual_finished or not self.active or self.paused or self.pending_motion!=cast_id:return False
        self.pending_motion=None;return True

    def tick(self,ms):
        if not isinstance(ms,int) or ms<0:raise ValueError('nonnegative integer milliseconds')
        self._sync()
        if not self.active or self.paused:return False
        remaining=ms
        while remaining and self.active and not self.paused:
            limits=list(self.effects.remaining_by_name.values())+[self.book.control_remaining]
            limits+=list(self.deferred_points.values())+list(self.adapter.limits())
            if self.handoff:limits.append(self.handoff['delay'])
            step=min([remaining]+[int(t) for t in limits if t>0])
            if step<=0:raise ValueError('sub-millisecond host clock is unsupported')
            action_paused=self.effects.body_busy() or self.pending_motion is not None
            factor=Fraction(3,4) if self.effects.remaining('thermal') else Fraction(1)
            was_control=self.book.control_active
            self.adapter.advance(step,search_factor=factor,action_paused=action_paused)
            self.book.tick(step,advance_economy=False);self.effects.tick(step)
            if was_control and not self.book.control_active:
                self.awareness.end_control();self.effects.end_control();self.commands.clear()
            for p,t in list(self.deferred_points.items()):
                if t<=step:del self.deferred_points[p]
                else:self.deferred_points[p]=t-step
            if self.handoff:self.handoff['delay']=max(0,self.handoff['delay']-step)
            self.clock+=step;remaining-=step;self._sync()
        return True

    def play_feedback(self,name,safe=True):
        self._sync()
        if not self.active or self.paused or not safe or self.adapter.blocked() or self.effects.body_busy() or self.pending_motion is not None:return None
        f=self.feedback.get(name)
        if not f or name=='control' and not f['control_has_action']:return None
        self.feedback.pop(name);self.set_pause(True);return f
