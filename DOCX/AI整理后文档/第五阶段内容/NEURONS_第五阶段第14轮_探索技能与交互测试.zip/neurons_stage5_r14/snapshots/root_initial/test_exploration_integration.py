"""New R14 cross-host contracts, not a rerun of inherited skill-unit tests."""
from fractions import Fraction
import pytest
from hypothesis import given, settings, strategies as st
from exploration_core import ExplorationSkills
from player_skills import CATALOG
from s2_skill_adapter import S2SkillAdapter
from s3_skill_adapter import S3SkillAdapter
from s4_skill_adapter import S4SkillAdapter


def setup(level):
    a={2:S2SkillAdapter,3:S3SkillAdapter,4:S4SkillAdapter}[level]()
    if level==3:a.host.position=(2,'corridor')
    c=ExplorationSkills(a)
    c.life.economy.n=c.life.economy.c=100
    for name in CATALOG:
        if name!='skin':assert c.book.unlock(name)
    return c,1 if level==3 else 0


def elapsed(c,ident):
    return c.adapter.progress[ident] if c.adapter.level==2 else c.host.search_elapsed


def duration(c,ident):
    return c.adapter.durations[ident] if c.adapter.level==2 else c.host.search_duration


def cast(c,name,**facts):
    row=c.submit(name)
    assert row
    assert c.react(row['id'],perceived=False,**facts)
    return row


@pytest.mark.parametrize('level',[2,3,4])
def test_one_native_search_one_charge_one_reward_and_duplicate_noop(level):
    c,p=setup(level);shared=c.search
    ident=c.start_search(p)
    assert ident is not None
    c.tick(duration(c,ident)-1)
    assert not c.complete_search(ident)
    c.tick(1)
    assert c.complete_search(ident)
    assert not c.complete_search(ident)
    assert c.search is c.host.search is shared
    assert c.search.used==1 and c.search.income==1
    assert c.life.economy.n==101


@pytest.mark.parametrize('level',[2,3,4])
def test_resisted_cancel_keeps_pending_search_and_exact_paid_once(level):
    c,p=setup(level);ident=c.start_search(p)
    c.tick(500)
    c.life.economy.skills['skin'].resistance=1
    t=c.token('resisted');row=c.submit('skin',token=t)
    assert row['resisted'] and c.life.economy.n==99
    assert not c.submit('skin',token=t)
    assert c.react(row['id'],perceived=False)['resisted']
    assert not c.react(row['id'],perceived=False)
    assert ident in c.search.pending and elapsed(c,ident)==500
    assert c.life.economy.skills['skin'].successes==0
    c.tick(duration(c,ident)-500)
    assert c.complete_search(ident)
    assert c.life.economy.n==100 and c.search.used==1


@pytest.mark.parametrize('level',[2,3,4])
def test_invalid_cancelled_and_insufficient_submit_do_not_cancel_search(level):
    c,p=setup(level);ident=c.start_search(p)
    assert not c.submit('skin',cancelled=True)
    assert not c.submit('skin',valid_target=False)
    assert c.life.economy.n==100
    c.life.economy.n=0
    assert not c.submit('skin')
    assert ident in c.search.pending and c.search.used==1
    c.tick(duration(c,ident))
    assert c.complete_search(ident) and c.life.economy.n==1


@pytest.mark.parametrize('level',[2,3,4])
def test_actual_cancel_no_reward_then_restart_uses_new_attempt(level):
    c,p=setup(level);ident=c.start_search(p)
    c.tick(1000);row=cast(c,'skin')
    assert ident not in c.search.pending and c.search.income==0
    assert not c.complete_search(ident) and not c.react(row['id'])
    assert c.search.used==1 and c.life.economy.n==99
    assert not c.start_search(p)
    c.tick(500);again=c.start_search(p)
    assert again is not None and again!=ident and c.search.used==2
    assert elapsed(c,again)==0
    c.tick(duration(c,again))
    assert c.complete_search(again) and c.life.economy.n==100


@pytest.mark.parametrize('level',[2,3,4])
def test_overlapping_pause_and_menu_closing_do_not_advance_or_execute(level):
    c,p=setup(level);ident=c.start_search(p)
    c.open_menu();row=c.submit('thermal')
    assert row and c.life.economy.n==99
    assert not c.react(row['id'])
    c.close_menu(actual_finished=False)
    assert not c.submit('skin')
    c.tick(5000);assert elapsed(c,ident)==0
    c.set_host_pause(True);c.close_menu()
    c.tick(1000);assert elapsed(c,ident)==0
    assert not c.react(row['id'])
    c.set_host_pause(False);assert c.react(row['id'],perceived=False)
    c.tick(1000);assert elapsed(c,ident)==750


@pytest.mark.parametrize('level',[2,3,4])
def test_control_elapsed_and_cooldown_freeze_during_world_pause(level):
    c,p=setup(level);row=cast(c,'control')
    assert c.book.control_remaining==6000
    c.tick(2000)
    c.set_pause(True);c.tick(9000)
    assert c.book.control_remaining==4000
    c.set_pause(False);c.tick(4000)
    assert not c.book.control_active
    assert c.life.economy.skills['control'].remaining==20000
    assert not c.book.control_command(c.token('late'), 'interact')
    c.tick(1000)
    assert c.life.economy.skills['control'].remaining==19000
    assert c.life.economy.n==95


@pytest.mark.parametrize('level',[2,3,4])
def test_lethal_same_callback_cannot_complete_or_accept_late_skill(level):
    c,p=setup(level);ident=c.start_search(p)
    c.tick(duration(c,ident));row=c.submit('skin')
    c.adapter.vitals(c.token('lethal'),hp_damage=100)
    assert not c.complete_search(ident)
    assert not c.react(row['id'])
    assert c.life.phase=='dead' and c.life.economy.n==99
    assert not c.search.complete and not c.search.pending
    assert not c.submit('happy')


@pytest.mark.parametrize('level',[2,3,4])
def test_thermal_fraction_survives_small_ticks_and_pause_boundary(level):
    c,p=setup(level);ident=c.start_search(p)
    cast(c,'thermal')
    for _ in range(3):c.tick(1)
    assert elapsed(c,ident)==Fraction(9,4)
    c.set_pause(True);c.tick(999);c.set_pause(False)
    c.tick(2997)
    assert elapsed(c,ident)==2250
    c.tick(1)
    assert elapsed(c,ident)==2251


@pytest.mark.parametrize('level',[2,3,4])
def test_startle_needs_actual_movement_completion_not_a_timer_guess(level):
    c,p=setup(level);ident=c.start_search(p)
    row=cast(c,'startle')
    c.tick(30000)
    assert not c.start_search(p)
    assert not c.finish_motion(row['id'],actual_finished=False)
    assert c.finish_motion(row['id'])
    assert c.start_search(p) is not None
    assert c.search.income==0 and c.search.used==2


@settings(max_examples=180,deadline=None,database=None)
@given(level=st.sampled_from([2,3,4]),
       actions=st.lists(st.tuples(st.sampled_from(['search','finish','tick','pause','feedback','skin','thermal','tinnitus','fear','happy']),
                                   st.integers(0,6000)),min_size=5,max_size=70))
def test_random_paid_skill_search_pause_reward_conservation(level,actions):
    c,p=setup(level);shared=c.search;spent=0
    for action,value in actions:
        if action=='search':c.start_search(p+(value%2))
        elif action=='finish':c.complete_search(actual=bool(value%2))
        elif action=='tick':c.tick(value)
        elif action=='pause':c.set_pause(bool(value%2))
        elif action=='feedback':
            if not c.paused:
                c.host.finish_feedback(c.token('feedback'))
        else:
            row=c.submit(action)
            if row:
                spent+=CATALOG[action].cost
                c.react(row['id'],perceived=False)
        assert c.search is shared is c.host.search
        assert len(c.search.pending)<=1
        assert c.life.economy.n==100-spent+len(c.search.complete)
        assert c.search.income==len(c.search.complete)
        assert c.life.hp==100 and c.life.sp>=0
        if level in (2,3):assert c.search.used<={2:12,3:14}[level]
