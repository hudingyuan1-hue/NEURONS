from fractions import Fraction
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s2_skill_adapter import S2SkillAdapter, POINT_ROOMS
from rules import Skill


def adapter(room='waiting'):
    a = S2SkillAdapter()
    a.host.room = room
    return a


def proposal(skill, ident=1):
    return {'skill': skill, 'cast_id': ('cast', ident)}


def prepare_cup(a, state='prepared'):
    h=a.host
    assert h.hospital_action(a.token('rx'), 'give_prescription', ident='rx-1')
    assert h.hospital_action(a.token('prepare'), 'prepare')
    if state in ('held','raising'):
        assert h.hospital_action(a.token('take'), 'take_cup')
    if state=='raising':
        assert h.hospital_action(a.token('raise'), 'raise_cup')


@pytest.mark.parametrize('point,room', [(0,'waiting'),(5,'waiting'),(6,'exam'),(13,'exam'),
                                       (14,'pharmacy'),(20,'pharmacy'),(21,'office'),(31,'office')])
def test_physical_point_boundaries_and_control_non_targets(point,room):
    a=adapter(room)
    original=a.search
    a.life.economy.control=True
    ident=a.start(point, controlled=True)
    assert ident is not None and a.search is original
    assert a.search.pending[ident]==('avatar',point)
    a.advance(5000)
    n=a.life.economy.n
    assert a.finish(ident)
    assert a.life.economy.n==n+1
    assert ('S2-search',a.search.attempt,point) in a.life.economy.paid
    assert not a.finish(ident)


@pytest.mark.parametrize('room,point', [('waiting',6),('exam',5),('pharmacy',21),('office',20),('ward',0),('waiting',32),('waiting',-1)])
def test_no_cross_room_or_nonexistent_point_even_in_control(room,point):
    a=adapter(room);a.life.economy.control=True
    assert a.start(point, controlled=True) is None
    assert a.search.used==0


@pytest.mark.parametrize('kind,duration',[('simple',4000),('normal',5000),('complex',6000)])
def test_exact_search_duration(kind,duration):
    a=adapter();ident=a.start(0,kind)
    a.advance(duration-1)
    assert not a.finish(ident)
    a.advance(1)
    assert a.finish(ident)


def test_tinnitus_keeps_search_identity_attempt_and_income_once():
    a=adapter();original=a.search;ident=a.start(0)
    a.advance(2000);a.advance(1000,action_paused=True);a.advance(2999)
    assert a.progress[ident]==4999 and a.search.used==1
    assert not a.finish(ident)
    a.advance(1);assert a.finish(ident)
    assert a.search is original and a.search.income==1


def test_thermal_rational_progress_not_reset_or_extra_attempt():
    a=adapter();ident=a.start(0)
    a.advance(1000);a.advance(3000,search_factor=Fraction(3,4))
    assert a.progress[ident]==3250
    assert not a.finish(ident)
    a.advance(1750);assert a.finish(ident)
    assert a.search.used==1


def test_low_sp_factor_once_and_attempt_practice():
    a=adapter();a.life.sp=10;a.life.economy.control=True;a.life.attempts[2]=3
    ident=a.start(0,controlled=True)
    assert a.durations[ident]==5625
    a.advance(5624);assert not a.finish(ident)
    a.advance(1);assert a.finish(ident)


def test_menus_pause_every_timer_but_tinnitus_does_not_pause_world():
    a=adapter('exam');h=a.host
    assert h.hospital_action(a.token('exam'),'begin_exam')
    assert h.hospital_action(a.token('grip'),'grip_exam')
    h.batch(a.token('needle'),[('needle',True)])
    a.life.economy.skills['skin'].remaining=2000
    hp=a.life.hp
    a.sync(paused=True)
    assert not a.advance(1000,action_paused=True)
    assert h.hospital.sample_ms==0 and a.life.economy.skills['skin'].remaining==2000
    a.sync(paused=False)
    a.advance(1000,action_paused=True)
    assert h.hospital.sample_ms==1000 and h.hospital.hold_ms==1000
    assert a.life.economy.skills['skin'].remaining==1000 and a.life.hp==hp
    a.advance(1000,action_paused=True)
    assert h.hospital.sample_valid and h.hospital.holder is None


def test_ear_pause_cup_raising_but_not_drug_stop():
    a=adapter('pharmacy');prepare_cup(a,'raising')
    a.advance(750);a.advance(1000,action_paused=True)
    assert a.host.hospital.cup_progress==750
    a.advance(250)
    assert a.control('swallow',actual_swallow=True)
    assert a.life.sp==85 and a.host.hospital.drug_stop==1000
    a.advance(1000,action_paused=True)
    assert a.host.hospital.drug_stop==0


def test_thermal_does_not_slow_medical_hold_or_cup():
    a=adapter('pharmacy');prepare_cup(a,'raising')
    a.advance(1000,search_factor=Fraction(3,4))
    assert a.host.hospital.cup_progress==1000
    assert a.control('swallow',actual_swallow=True)


@pytest.mark.parametrize('kind',['receipt','prescription','pharmacy_prescription','cup'])
def test_handoff_needs_real_offer_in_correct_room(kind):
    a=adapter()
    assert not a.can_handoff(kind,'unknown')
    assert not a.offer_handoff(kind,'unknown')
    assert not a.complete_handoff(kind,'unknown')
    assert not a.offer_handoff('report','r1',actual_offer=True,participant_present=True)


def test_prescription_cup_handoffs_do_not_double_charge_or_duplicate():
    a=adapter('exam');n=a.life.economy.n
    assert a.offer_handoff('prescription','tx1',actual_offer=True,participant_present=True,document_id='rx1')
    assert a.complete_handoff('prescription','tx1')
    assert not a.complete_handoff('prescription','tx1')
    a.host.room='pharmacy'
    assert a.offer_handoff('pharmacy_prescription','tx2',actual_offer=True,participant_present=True,document_id='rx1')
    assert a.complete_handoff('pharmacy_prescription','tx2')
    assert a.offer_handoff('cup','tx3',actual_offer=True,participant_present=True,document_id='rx1')
    assert a.complete_handoff('cup','tx3')
    assert a.host.hospital.cup=='held' and a.host.hospital.medication_count==0
    assert not a.can_handoff('cup','tx3') and a.life.economy.n==n


def test_dry_receipt_busy_only_blocks_uncommitted_patient_handover():
    a=adapter();t=a.host.transfer
    assert t.issue_patient_order()
    assert a.offer_handoff('receipt','receipt',actual_offer=True,participant_present=True)
    assert t.nurse_busy and not t.start_patient()
    assert a.complete_handoff('receipt','receipt')
    assert t.start_patient() and t.patient_step('handover')
    assert a.offer_handoff('receipt','receipt2',actual_offer=True,participant_present=True)
    assert t.patient_step('grab_frame')
    assert t.patient=='gripping'


@pytest.mark.parametrize('skill,flag',[('withdraw','actual_hand_withdrawn'),('startle','actual_out_of_range')])
def test_actual_cup_receive_interruption_not_refusal(skill,flag):
    a=adapter('pharmacy');prepare_cup(a)
    assert a.offer_handoff('cup','cup1',actual_offer=True,participant_present=True,document_id='rx-1')
    assert a.apply(proposal(skill),**{flag:False})
    assert a.can_handoff('cup','cup1')
    assert a.apply(proposal(skill,2),**{flag:True})
    assert not a.can_handoff('cup','cup1')
    assert a.host.hospital.cup=='prepared' and not a.host.hospital.medicine_closed


@pytest.mark.parametrize('state',['held','raising'])
def test_gut_actual_before_swallow_refuses_without_medicine_effect(state):
    a=adapter('pharmacy');prepare_cup(a,state)
    n=a.life.economy.n
    assert a.apply(proposal('gut'),nurse_seen=True)
    assert a.host.hospital.cup=='refused' and a.host.hospital.refusal_witnessed
    assert not a.host.hospital.swallow()
    assert a.life.sp==100 and a.life.economy.n==n
    assert not a.apply(proposal('gut'))


def test_gut_after_swallow_never_refunds_or_reopens():
    a=adapter('pharmacy');prepare_cup(a,'raising');a.advance(1000)
    assert a.control('swallow',actual_swallow=True)
    a.apply(proposal('gut'))
    assert a.life.sp==85 and a.host.hospital.cup=='consumed'
    assert a.host.hospital.medication_count==1


@pytest.mark.parametrize('gripped',[False,True])
def test_withdraw_actual_before_grip_only_and_assistant_witness(gripped):
    a=adapter('exam');h=a.host
    assert h.hospital_action(a.token('exam'),'begin_exam')
    if gripped: assert h.hospital_action(a.token('grip'),'grip_exam')
    assert a.apply(proposal('withdraw'),actual_hand_withdrawn=True,assistant_seen=True)
    assert (h.hospital.holder=='doctor')==gripped
    assert bool(h.people.labels)==(not gripped)


def test_doctor_knee_actual_contact_after_needle_releases_without_refund():
    a=adapter('exam');h=a.host
    assert h.hospital_action(a.token('exam'),'begin_exam')
    assert h.hospital_action(a.token('grip'),'grip_exam')
    h.batch(a.token('needle'),[('needle',True)])
    assert a.life.hp==95
    h.tick(a.token('hitstop'),250)
    assert a.rescue_skills()=={'knee'}
    assert not a.contact('knee','cast1',target='doctor',actual_contact=False)
    assert a.contact('knee','cast1',target='doctor',actual_contact=True,assistant_seen=True)
    assert h.hospital.holder is None and h.hospital.sample_interrupted
    assert not h.hospital.sample_valid and a.life.hp==95
    assert list(h.people.labels.values())==['攻击行为']
    assert not a.contact('knee','cast1',target='doctor',actual_contact=True)


@pytest.mark.parametrize('facts',[{'target':'bedframe','actual_contact':True},
 {'target':'doctor','actual_contact':True,'obstructed':True},
 {'target':'doctor','actual_contact':True,'distance_m':1.01},
 {'target':'doctor','actual_contact':True,'front':False},
 {'target':'doctor','actual_contact':True,'actual_body_contact':False}])
def test_knee_no_remote_fake_doctor_contact(facts):
    a=adapter('exam');h=a.host
    h.hospital_action(a.token('exam'),'begin_exam');h.hospital_action(a.token('grip'),'grip_exam')
    assert not a.contact('knee','cast',**facts)
    assert h.hospital.holder=='doctor' and not h.people.labels


@pytest.mark.parametrize('visible,present,witness',[(False,True,True),(True,False,True),(True,True,False),(True,True,True)])
def test_patient_hint_actual_witness_only(visible,present,witness):
    a=adapter();a.host.people.patient_present=present
    a.apply(proposal('skin'),visible=visible,patient_seen=witness)
    assert a.host.people.hint_pending==(visible and present and witness)
    assert a.awareness.stage==0


def test_tinnitus_internal_sound_not_automatic_patient_witness():
    a=adapter();a.apply(proposal('tinnitus'),patient_seen=True)
    assert not a.host.people.hint_pending
    a.apply(proposal('tinnitus',2),patient_seen=True,visible=True)
    assert a.host.people.hint_pending


def test_happy_during_hold_restores_sp_not_grip_or_prior_harm():
    a=adapter('exam');h=a.host
    h.hospital_action(a.token('exam'),'begin_exam');h.hospital_action(a.token('grip'),'grip_exam')
    a.life.sp=20;a.life.hp=90;h._pull()
    a.vitals(a.token('happy'),sp_heal=20)
    assert a.life.sp==40 and a.life.hp==90 and h.hospital.holder=='doctor'


def test_legitimate_control_exit_without_treatment_or_person_dependency():
    a=adapter();a.life.economy.control=True
    assert not a.control('exit',actual_crossing=True)
    a.search.key_owner='avatar'
    assert not a.control('exit',actual_crossing=False)
    assert a.control('exit',actual_crossing=True)
    assert a.life.progress==3


def test_control_room_topology_crossing_and_search_budget():
    a=adapter('exam');a.life.economy.control=True
    assert not a.control('move',room='pharmacy',actual_crossing=True,route_clear=True)
    assert not a.control('move',room='waiting',actual_crossing=False,route_clear=True)
    assert a.control('move',room='waiting',actual_crossing=True,route_clear=True)
    assert a.control('move',room='pharmacy',actual_crossing=True,route_clear=True)
    a.search.used=12
    assert a.control('search',point=14,actual_at_point=True,reachable=True) is None
    assert a.control('move',room='waiting',actual_crossing=True,route_clear=True)


class HospitalSkillSequences(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.a=adapter();self.original=self.a.search
        self.expected={};self.paused=False

    @rule(point=st.integers(0,5),kind=st.sampled_from(['simple','normal','complex']))
    def start_search(self,point,kind):
        ident=self.a.start(point,kind)
        if ident:self.expected[ident]=Fraction(0)

    @rule(ms=st.integers(0,2500),mode=st.sampled_from(['ordinary','ear','thermal']))
    def elapse(self,ms,mode):
        pending=list(self.a.search.pending)
        factor=Fraction(3,4) if mode=='thermal' else Fraction(1)
        self.a.advance(ms,search_factor=factor,action_paused=mode=='ear')
        if not self.paused and mode!='ear':
            for ident in pending:
                if ident in self.a.search.pending:self.expected[ident]+=ms*factor

    @rule()
    def finish(self):
        for ident in list(self.a.search.pending):
            can=not self.paused and self.expected[ident]>=self.a.durations[ident]
            assert self.a.finish(ident)==can
        if self.a.host.feedback and not self.paused:self.a.host.finish_feedback(self.a.token('feedback'))

    @rule()
    def cancel(self):
        if self.paused:return
        for ident in list(self.a.search.pending):
            self.a.search.settle(ident,'cancel');self.a.on_cancel_search(ident,None)

    @rule(value=st.booleans())
    def pause(self,value):
        self.paused=value;self.a.sync(paused=value)

    @invariant()
    def identities_and_money(self):
        assert self.a.search is self.original
        assert self.a.search.used<=12
        assert self.a.life.economy.n==5+self.a.search.income
        assert self.a.search.income==len(self.a.search.complete)
        for ident in self.a.search.pending:assert self.a.progress[ident]==self.expected[ident]


TestHospitalSkillSequences=HospitalSkillSequences.TestCase
TestHospitalSkillSequences.settings=settings(max_examples=200,stateful_step_count=70,deadline=None)


def test_leaving_receipt_handoff_releases_guide_without_undoing_prior_transfer():
    a=adapter();t=a.host.transfer
    assert a.offer_handoff('receipt','r1',actual_offer=True,participant_present=True)
    assert a.control('move',room='exam',actual_crossing=True,route_clear=True)
    assert not t.nurse_busy
    assert not a.can_handoff('receipt','r1')


def test_one_avatar_handoff_does_not_free_guide_while_another_is_pending():
    a=adapter()
    assert a.offer_handoff('receipt','r1',actual_offer=True,participant_present=True)
    assert not a.offer_handoff('receipt','r2',actual_offer=True,participant_present=True)


def core(room='waiting'):
    from exploration_core import ExplorationSkills
    c=ExplorationSkills(adapter(room))
    c.life.economy.n=50;c.life.economy.c=30
    for name in ('gut','pores','thermal','tinnitus','dry','knee','withdraw','startle','fear','happy','control'):
        assert c.book.unlock(name)
    return c


def cast(c,name,**facts):
    rec=c.submit(name)
    assert rec is not None
    outcome=c.react(rec['id'],**facts)
    assert outcome
    return rec['id'],outcome


def test_core_s2_tinnitus_actual_paid_search_resume_native_income():
    c=core();ident=c.start_search(0);c.tick(1000)
    n=c.life.economy.n
    cid,_=cast(c,'tinnitus',patient_seen=True)
    assert c.life.economy.n==n-1 and not c.host.people.hint_pending
    c.tick(1000);assert c.adapter.progress[ident]==1000
    c.tick(4000);assert c.complete_search(ident)
    assert c.life.economy.n==n and c.search.used==1
    assert len(c.awareness.evidence)==1


def test_core_s2_thermal_does_not_double_tick_economy_or_drop_search():
    c=core();ident=c.start_search(0);c.tick(1000)
    _,p=cast(c,'thermal')
    c.tick(3000)
    assert c.adapter.progress[ident]==3250
    c.tick(1750);assert c.complete_search(ident)
    assert c.search.used==1 and c.book.economy.skills['thermal'].remaining==0


def test_core_s2_dry_actual_handoff_plus_two_seconds_no_revoke():
    c=core('exam');a=c.adapter
    assert a.offer_handoff('prescription','rx-tx',actual_offer=True,participant_present=True,document_id='rx-doc')
    assert c.begin_handoff('prescription','rx-tx')
    cid,p=cast(c,'dry')
    assert p['handoff_delay_ms']==2000 and c.host.hospital.prescription is None
    assert not c.complete_handoff('rx-tx')
    c.tick(1999);assert not c.complete_handoff('rx-tx')
    c.tick(1);assert c.complete_handoff('rx-tx')
    assert c.host.hospital.prescription=='rx-doc'
    c.tick(2000);cast(c,'dry')
    assert c.host.hospital.prescription=='rx-doc' and c.handoff is None


def test_core_s2_gut_refusal_records_actual_witness_and_fee_once():
    c=core('pharmacy');prepare_cup(c.adapter,'raising')
    n=c.life.economy.n
    cid,p=cast(c,'gut',nurse_seen=True)
    assert c.host.hospital.cup=='refused' and c.host.hospital.refusal_witnessed
    assert c.life.economy.n==n-1 and c.life.sp==100
    assert not c.react(cid,nurse_seen=True)
    assert c.host.hospital_action(c.token('label'),'complete_false_label',witnessed_complete=True)
    assert c.host.hospital.false_label_known and c.host.hospital.medication_count==0


def test_core_s2_knee_doctor_grip_special_actual_contact():
    c=core('exam');h=c.host
    h.hospital_action(c.token('exam'),'begin_exam');h.hospital_action(c.token('grip'),'grip_exam')
    n=c.life.economy.n
    cid,p=cast(c,'knee')
    assert c.life.economy.n==n-2 and h.hospital.holder=='doctor'
    assert not c.contact(cid,target='doctor',actual_contact=True,assistant_seen=True)
    c.tick(150)
    assert c.contact(cid,target='doctor',actual_contact=True,assistant_seen=True)
    assert h.hospital.holder is None and list(h.people.labels.values())==['攻击行为']
    assert not c.contact(cid,target='doctor',actual_contact=True)
    assert c.life.economy.skills['knee'].successes==1


def test_core_s2_guard_hold_does_not_get_doctor_rescue_exception():
    c=core('office');h=c.host
    h.hospital_action(c.token('report'),'file_report');h.hospital_action(c.token('receive'),'receive_report')
    h.hospital_action(c.token('approach'),'approach_guard');h.hospital_action(c.token('grip'),'grip_guard')
    c.tick(250)
    assert h.hospital.holder=='guard' and c.submit('knee') is None
    old=c.life.sp;cast(c,'happy')
    assert c.life.sp==min(100,old+20) and h.hospital.holder=='guard'
    c.tick(5750);assert h.hospital.holder is None


def test_core_s2_control_actual_non_target_search_and_room_route():
    c=core('pharmacy');n=c.life.economy.n
    cid,p=cast(c,'control')
    ident=c.start_search(14,actual_at_point=True)
    assert ident and c.search.used==1
    c.tick(5000);assert c.complete_search(ident)
    assert c.life.economy.n==n-5+1
    assert c.search.key_owner=='hidden'
    c.host.finish_feedback(c.token('feedback'))
    cmd=c.command('move',action='move',room='exam',actual_crossing=True,route_clear=True)
    assert cmd and not c.control_action(cmd['id'])
    cmd=c.command('move',action='move',room='waiting',actual_crossing=True,route_clear=True)
    assert cmd and c.control_action(cmd['id'])
    assert c.host.room=='waiting'


def test_core_s2_resisted_does_not_cancel_search_or_create_witness():
    c=core();ident=c.start_search(0)
    c.life.economy.skills['withdraw'].resistance=2
    cid,p=cast(c,'withdraw',actual_hand_withdrawn=True,patient_seen=True)
    assert p['resisted'] and ident in c.search.pending
    assert not c.host.people.hint_pending
    c.tick(5000);assert c.complete_search(ident)


def test_core_s2_pause_paid_cast_never_moves_or_completes_handoff_early():
    c=core('exam');a=c.adapter
    a.offer_handoff('prescription','tx',actual_offer=True,participant_present=True)
    assert c.begin_handoff('prescription','tx') and c.open_menu()
    rec=c.submit('dry');n=c.life.economy.n
    assert rec and not c.react(rec['id'])
    assert not c.tick(5000) and not c.complete_handoff('tx')
    assert c.life.economy.n==n
    assert c.close_menu();assert c.react(rec['id'])
    c.tick(2000);assert c.complete_handoff('tx')
