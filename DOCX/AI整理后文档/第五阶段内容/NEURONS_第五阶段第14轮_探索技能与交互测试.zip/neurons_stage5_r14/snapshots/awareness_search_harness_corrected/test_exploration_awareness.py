"""S2:P36: only an actually completed normal autonomous action ends restriction.
All evidence, ownership, identification and search completion use actual core APIs.
"""
import pytest
from exploration_core import ExplorationSkills
from s2_skill_adapter import S2SkillAdapter
from s3_skill_adapter import S3SkillAdapter
from s4_skill_adapter import S4SkillAdapter
from s4_session import S4Session


def make(level):
    if level==2:a=S2SkillAdapter()
    elif level==3:
        a=S3SkillAdapter()
        assert a.host.move(a.token('actual-stairs'),(2,'stairs'))
    else:a=S4SkillAdapter(S4Session(targets=tuple(range(8))+tuple(range(31,39)),key_point=7))
    c=ExplorationSkills(a)
    c.life.economy.n=40;c.life.economy.c=20
    for name in ('pores','withdraw','happy','control'):assert c.book.unlock(name)
    return c


def react(c,name):
    r=c.submit(name);assert r
    assert c.react(r['id'])
    return r['id']


def identified_during_controlled_search(level):
    c=make(level)
    react(c,'skin');c.tick(2000)
    assert c.start_search(0,'simple')
    react(c,'skin');c.tick(2000)
    react(c,'skin');c.tick(2000)
    assert c.awareness.stage==2 and not c.awareness.restriction
    react(c,'control')
    cmd=c.command('interact',action='start_search',point=0,actual_at_point=True)
    assert cmd
    ident=c.control_action(cmd['id'],against_intent=True,kind='simple')
    assert ident and c.awareness.stage==3 and c.awareness.restriction
    return c,ident


@pytest.mark.parametrize('level',[2,3,4])
def test_normal_autonomous_search_completes_identification_restriction(level):
    c,controlled=identified_during_controlled_search(level)
    assert c.adapter.cancel_current_search()
    assert c.end_control()
    assert c.awareness.restriction
    ident=c.start_search(0,'simple');assert ident
    c.tick({2:4000,3:4800,4:5600}[level])
    assert c.complete_search(ident)
    assert not c.awareness.restriction


@pytest.mark.parametrize('level',[2,3,4])
def test_player_controlled_search_does_not_clear_identification_restriction(level):
    c,ident=identified_during_controlled_search(level)
    c.tick({2:4000,3:4800,4:5600}[level])
    assert c.book.control_active
    assert c.complete_search(ident)
    assert c.awareness.restriction
