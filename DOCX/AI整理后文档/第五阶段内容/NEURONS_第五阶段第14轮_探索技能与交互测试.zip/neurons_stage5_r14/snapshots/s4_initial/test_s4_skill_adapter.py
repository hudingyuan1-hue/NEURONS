from fractions import Fraction

import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant

from s4_session import S4Session
from s4_skill_adapter import S4SkillAdapter


def adapter(room='atrium', actors=()):
    h = S4Session(targets=tuple(range(8)) + tuple(range(31, 39)), key_point=7)
    h.position = room
    for actor in actors:
        h.actors[actor] = room
    h._sync()
    return S4SkillAdapter(h)


def act(a, group, name, **kw):
    return a.host.action(a.token(name), group, name, **kw)


def clamp(a):
    assert act(a, 'cortex', 'clamp_touch', actual_contact=True, hand_inside=True)
    for step in ('look', 'grip', 'pull'):
        assert act(a, 'cortex', 'clamp_step', step=step)


def face(a):
    a.search.key_owner = 'avatar'
    assert a.host.begin_open(a.token('begin'))
    assert act(a, 'routes', 'raise_face')


def paper(a):
    assert act(a, 'archive', 'open_original')
    assert act(a, 'archive', 'reach_paper')
    assert act(a, 'archive', 'pinch_paper')


def proposal(name, cancel=False):
    return {'skill': name, 'cast_id': ('cast', name), 'cancel_search': cancel}


def test_wrong_room_unreachable_and_early_completion_do_not_reward():
    a = adapter()
    before = a.life.economy.n
    assert a.start(3) is None
    assert a.start(0, reachable=False) is None
    ident = a.start(0)
    assert ident
    assert not a.finish(ident)
    assert a.life.economy.n == before
    a.advance(a.host.search_duration)
    assert not a.finish(ident, actual=False)
    assert a.finish(ident)
    assert not a.finish(ident)
    assert a.life.economy.n == before + 1


def test_thermal_scales_only_search_and_exact_fraction():
    a = adapter('rhythm', ('twitch',))
    ident = a.start(35)
    assert ident
    for _ in range(5):
        a.advance(1, Fraction(3, 4))
    assert a.host.search_elapsed == Fraction(15, 4)
    assert a.host.routes.twitch_ms == 5
    a.advance(1195, Fraction(3, 4))
    assert a.host.search_elapsed == 900
    assert a.host.routes.twitch_ms == 1200


def test_tinnitus_pause_is_avatar_only_and_resumes_same_search():
    a = adapter('rhythm', ('twitch',))
    ident = a.start(35)
    a.advance(400)
    used = a.search.used
    a.advance(1000, action_paused=True)
    assert a.host.search_elapsed == 400
    assert a.host.routes.twitch_ms == 1400
    assert ident in a.search.pending and a.search.used == used
    a.advance(600)
    assert a.host.search_elapsed == 1000


def test_world_pause_freezes_npc_and_search():
    a = adapter('rhythm', ('twitch',))
    a.start(35)
    a.host.paused = True
    a.advance(1000)
    assert a.host.search_elapsed == a.host.routes.twitch_ms == 0


def test_body_release_split_does_not_double_apply_low_sp_speed():
    a = adapter()
    a.life.sp = 10
    a.start(0)
    duration = a.host.search_duration
    a.host.hit_stop = 250
    a.advance(1250, Fraction(3, 4))
    assert a.host.search_elapsed == 750
    assert a.host.search_duration == duration


@pytest.mark.parametrize('name', ['skin', 'gut', 'withdraw', 'startle', 'fear', 'control'])
def test_cancel_reading_releases_only_not_acquired_paper(name):
    a = adapter('memory', ('stitched',))
    paper(a)
    a.advance(100)
    assert a.host.archive.pieces['corner'] == 'held'
    a.host.archive.pieces['prior_piece'] = 'avatar'
    a.host.archive.knowledge.add('previously_read')
    a.apply(proposal(name, True))
    assert a.host.archive.pieces['corner'] == 'world'
    assert a.host.archive.pieces['prior_piece'] == 'avatar'
    assert 'previously_read' in a.host.archive.knowledge
    a.advance(1900)
    assert a.host.archive.pieces['remainder'] == 'npc'


def test_skill_search_cancel_preserves_open_door_and_completed_material():
    a = adapter()
    a.host.door_open = a.host.door_unlocked = a.host.opening = True
    a.host.archive.pieces['prior'] = 'avatar'
    ident = a.start(0)
    a.advance(2000)
    n = a.life.economy.n
    assert a.cancel_current_search()
    assert ident not in a.search.pending and not a.search.complete
    assert a.life.economy.n == n
    assert a.host.door_open and a.host.door_unlocked and a.host.opening
    assert a.host.archive.pieces['prior'] == 'avatar'


def test_tinnitus_does_not_freeze_clamp_windup_or_auto_remove_hand():
    a = adapter('body', ('clamp',))
    clamp(a)
    a.apply(proposal('tinnitus'))
    a.advance(800, action_paused=True)
    assert a.host.cortex.windup_ms == 800
    assert a.host.cortex.hand_inside
    assert act(a, 'cortex', 'clamp_close', actual_contact=True)
    assert a.life.hp == 90 and a.host.holder == 'clamp'


@pytest.mark.parametrize('name', ['skin', 'gut', 'withdraw', 'startle'])
def test_pre_clamp_escape_requires_actual_hand_clear(name):
    a = adapter('body', ('clamp',))
    clamp(a)
    a.apply(proposal(name, True))
    assert a.host.cortex.hand_inside
    a.apply(proposal(name, True), actual_hand_clear=True)
    assert not a.host.cortex.hand_inside
    a.advance(800)
    assert act(a, 'cortex', 'clamp_close', actual_contact=True)
    assert a.life.hp == 100 and a.host.cortex.clamp_phase == 'done'


def test_actual_operator_kick_interrupts_before_clamp_but_not_after():
    a = adapter('body', ('clamp',))
    clamp(a)
    assert not a.contact('knee', 1, target='clamp', obstructed=True)
    assert not a.contact('knee', 1, target='clamp', contact_kind='table')
    assert a.contact('knee', 1, target='clamp')
    a.advance(800)
    assert not act(a, 'cortex', 'clamp_close', actual_contact=True)
    assert a.life.hp == 100
    b = adapter('body', ('clamp',))
    clamp(b)
    b.advance(800)
    assert act(b, 'cortex', 'clamp_close', actual_contact=True)
    assert not b.contact('knee', 2, target='clamp')
    assert b.life.hp == 90


@pytest.mark.parametrize('name', ['withdraw', 'happy', 'control'])
def test_already_clamped_skill_does_not_clear_hold(name):
    a = adapter('body', ('clamp',))
    clamp(a)
    a.advance(800)
    act(a, 'cortex', 'clamp_close', actual_contact=True)
    a.apply(proposal(name, True), actual_hand_clear=True)
    assert a.host.holder == 'clamp'
    a.advance(1000)
    assert a.host.holder is None and a.life.hp == 90


def test_face_approach_continues_during_tinnitus_and_sp_not_rolled_back():
    a = adapter('exit', ('face',))
    face(a)
    assert a.host.unlock(a.token('unlock'))
    assert a.host.push_door(a.token('push'))
    a.advance(800, action_paused=True)
    assert a.host.routes.face_phase == 'ready'
    assert a.host.face_contact(a.token('contact')) == 'alive'
    assert a.life.sp == 85 and a.host.holder == 'face'
    assert a.host.door_open and a.host.door_unlocked
    assert not a.contact('knee', 'late', target='face')
    a.vitals(a.token('happy'), sp_heal=20)
    assert a.life.sp == 100 and a.host.holder == 'face'
    a.advance(1200)
    assert a.host.holder is None


def test_face_dodge_needs_actual_displacement_not_arm_only():
    a = adapter('exit', ('face',))
    face(a)
    a.apply(proposal('withdraw', True), actual_hand_clear=True)
    assert a.host.routes.face_phase == 'raising'
    a.apply(proposal('startle', True), actual_out_of_face_contact=False)
    assert a.host.routes.face_phase == 'raising'
    a.apply(proposal('startle', True), actual_out_of_face_contact=True)
    assert a.host.routes.face_phase == 'finished'
    assert a.host.routes.face_used


def test_control_uses_native_route_and_key_gate_then_true_exit():
    a = adapter()
    assert not a.control('move', dest='exit', permitted=True)
    assert not a.control('begin_open', permitted=True)
    assert a.control('move', dest='decision')
    assert a.control('move', dest='bridge')
    assert a.control('move', dest='index')
    assert a.control('move', dest='fork')
    assert a.control('move', dest='exit')
    assert not a.control('begin_open')
    a.search.key_owner = 'avatar'
    assert not a.control('push_door')
    assert a.control('begin_open')
    assert a.control('unlock')
    assert a.control('push_door')
    assert a.control('exit')
    assert a.life.progress == 5 and a.life.place == 'S5_atrium'
    assert not a.control('move', dest='decision')


def test_control_finish_cannot_bypass_search_duration():
    a = adapter()
    ident = a.control('start_search', point=0)
    assert ident
    assert not a.control('complete_search', ident=ident, permitted=True)
    a.advance(a.host.search_duration)
    assert a.control('complete_search', ident=ident)
    assert not a.control('complete_search', ident=ident)


def test_vitals_zero_sp_cancels_pending_but_heal_does_not_clear_drug():
    a = adapter()
    ident = a.start(0)
    a.life.sp = 10
    a.vitals(a.token('fear'), sp_damage=15)
    assert a.life.sp == 0 and a.life.stun == 1000
    assert ident not in a.search.pending
    a.host.drug_stop = 800
    a.vitals(a.token('happy'), sp_heal=20)
    assert a.life.sp == 20 and a.life.stun == 1000 and a.host.drug_stop == 800


def test_death_wins_over_exit_without_rollback():
    a = adapter('exit')
    a.search.key_owner = 'avatar'
    assert a.control('begin_open')
    assert a.control('unlock')
    assert a.control('push_door')
    assert not a.control('exit', hp=100)
    assert a.life.phase == 'dead' and a.life.progress == 4
    assert not a.start(48)


def test_paper_handoff_is_real_avatar_transfer_not_npc_tearing():
    a = adapter('memory', ('stitched',))
    assert not a.can_handoff('paper', 'whole')
    assert act(a, 'archive', 'open_original')
    assert a.can_handoff('paper', 'whole')
    assert not a.can_handoff('npc_to_npc', 'whole')
    assert a.complete_handoff('paper', 'whole')
    assert not a.complete_handoff('paper', 'whole')
    assert a.host.archive.pieces['whole'] == 'avatar'


def test_cancel_does_not_cancel_blankface_npc_transaction():
    a = adapter('index', ('blankface',))
    a.host.records.label = {'name': 'fixture', 'label_id': 'label', 'patient_id': 'patient'}
    assert act(a, 'records', 'open_original')
    assert act(a, 'records', 'reach_label')
    assert act(a, 'records', 'pinch_label')
    a.apply(proposal('skin', True))
    assert not a.can_handoff('label', 'label')
    a.advance(1000, action_paused=True)
    assert a.host.records.label_removed


def test_visible_mimic_records_true_movement_not_internal_skill():
    a = adapter('decision', ('mimic',))
    a.apply(proposal('tinnitus'))
    assert a.host.cortex.mimic_phase == 'idle'
    a.apply(proposal('tinnitus'), visible_to_mimic=True, actual_visible_movement=True)
    assert a.host.cortex.mimic_phase == 'watching'
    assert act(a, 'cortex', 'mimic_complete')
    assert act(a, 'cortex', 'mimic_write')
    actual = next(iter(a.host.cortex.actual_actions.values()))
    assert actual == {'movement': 'turn_head', 'source': 'player'}


def test_control_activation_not_mimic_but_actual_action_is():
    a = adapter('decision', ('mimic',))
    a.apply(proposal('control', True), visible_to_mimic=True, actual_visible_movement=True)
    assert a.host.cortex.mimic_phase == 'idle'
    ident = a.control('start_search', point=16,
                      visible_to_mimic=True, actual_visible_movement=True)
    assert ident
    actual = next(iter(a.host.cortex.actual_actions.values()))
    assert actual['source'] == 'full_control'


def test_fear_occupied_target_changes_native_choice_without_deleting_point():
    a = adapter()
    first = a.next_point()
    assert first == 0
    assert a.next_point(occupied={first}) == 1
    assert a.next_point() == first


class S4ClockMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.a = adapter('rhythm', ('twitch',))
        self.ident = self.a.start(35)
        self.expected_search = Fraction(0)
        self.expected_world = 0
        self.paused = False

    @rule(ms=st.integers(0, 2000), slow=st.booleans(), stop=st.booleans())
    def advance(self, ms, slow, stop):
        factor = Fraction(3, 4) if slow else Fraction(1)
        self.a.advance(ms, factor, action_paused=stop)
        if not self.paused:
            self.expected_search += ms * (0 if stop else factor)
            self.expected_world += ms

    @rule(paused=st.booleans())
    def pause(self, paused):
        self.paused = paused
        self.a.host.paused = paused

    @rule()
    def false_completion(self):
        before = self.a.life.economy.n
        assert not self.a.finish(self.ident, actual=False)
        assert self.a.life.economy.n == before

    @invariant()
    def clocks_and_rewards(self):
        assert self.a.host.search_elapsed == self.expected_search
        assert self.a.host.routes.twitch_ms == self.expected_world % 2700
        assert self.ident in self.a.search.pending
        assert self.a.life.economy.n == 5


TestS4ClockMachine = S4ClockMachine.TestCase
TestS4ClockMachine.settings = settings(max_examples=200, stateful_step_count=70,
                                       deadline=None, database=None)
