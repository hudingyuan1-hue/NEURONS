"""R14 hospital adapter. Actual geometry and NPC availability remain input facts.

S1:P32/P44/P55/P65/P76; S3:T8-T15/P449-500/P531-535;
S4:P53-66/T14/P175/T15R3/T16R2. No legacy skill() calls or new fees.
"""
from fractions import Fraction
from exploration_core import NativeAdapter
from evidence_session import EvidenceSession
from rules import search_ms, SEARCH

POINT_ROOMS = {**dict.fromkeys(range(0, 6), 'waiting'),
               **dict.fromkeys(range(6, 14), 'exam'),
               **dict.fromkeys(range(14, 21), 'pharmacy'),
               **dict.fromkeys(range(21, 32), 'office')}


class S2SkillAdapter(NativeAdapter):
    def __init__(self, host=None):
        super().__init__(host or EvidenceSession())
        self.progress = {}
        self.durations = {}
        self.handoffs = {}
        self.closed_handoffs = set()
        self.applied = set()
        self.contacts = set()
        self.receipt_owned = set()
        self.clock = 0

    def sync(self, paused=False, loading=False):
        super().sync(paused=paused, loading=loading)
        self._prune_handoffs()

    def cancel_handoff(self, identity):
        tx = self.handoffs.get(identity)
        if not tx or tx['closed']:
            return False
        tx['closed'] = True
        tx['interrupted'] = True
        self.closed_handoffs.add(identity)
        if tx['kind'] == 'receipt':
            self.host.transfer.set_nurse_busy(False)
        return True

    def _prune_handoffs(self):
        for identity, tx in list(getattr(self, 'handoffs', {}).items()):
            if (tx['room'] != self.host.room or tx['epoch'] != self.life.epoch
                    or self.life.phase != 'alive' or self.life.progress != 2
                    or tx['kind'] == 'receipt' and not self.host.transfer.guide_present):
                self.cancel_handoff(identity)

    def start(self, point, kind='normal', **facts):
        h = self.host
        if (kind not in ('simple', 'normal', 'complex') or POINT_ROOMS.get(point) != h.room
                or not facts.get('reachable', True) or not facts.get('actual_at_point', True)):
            return None
        if facts.get('controlled', False):
            if (not self.life.economy.control or not h.active() or h.blocked() or h.feedback
                    or h.action is not None or h.search.pending or h.hospital.bandaging
                    or h.hospital.cup in ('held', 'raising') or h.food_action is not None
                    or h.search.key_owner == 'avatar' or h.search.used >= SEARCH[2][2]):
                return None
            ident = h.search.start(point)
            if ident is not None:
                h.action = ('search', self.life.epoch, ident)
                h.action_context = ('S2:' + h.room, 'search', point)
        else:
            ident = h.start_search(self.token('search'), point)
        if ident is not None:
            self.progress[ident] = Fraction(0)
            self.durations[ident] = search_ms(2, kind, self.life.attempts[2], self.life.sp)
        return ident

    def finish(self, ident, actual=True, **facts):
        if (not actual or not self.host.active() or self.blocked()
                or ident not in self.search.pending
                or self.progress.get(ident, -1) < self.durations.get(ident, 0)):
            return False
        point = self.search.pending[ident][1]
        if POINT_ROOMS[point] != self.host.room:
            return False
        self.host.batch(self.token('search-complete'), [('search_done', ident)])
        return ident not in self.search.pending and point in self.search.complete

    def on_cancel_search(self, ident, point):
        self.host._search_ended()

    def limits(self):
        h = self.host.hospital
        out = [x for x in (self.life.stun, self.host.hit_stop, h.drug_stop) if x > 0]
        if h.holder == 'doctor':
            out.append(max(1, 4000 - h.hold_ms))
        if h.holder == 'guard':
            out.append(max(1, 6000 - h.guard_ms))
        if h.exam == 'sampling':
            out.append(max(1, 2000 - h.sample_ms))
        return out

    def rescue_skills(self):
        h = self.host.hospital
        if h.holder == 'doctor' and not (self.life.stun or self.host.hit_stop or h.drug_stop):
            return {'knee'}
        return set()

    def advance(self, ms, search_factor=Fraction(1), action_paused=False):
        if not self.host.active():
            return False
        h = self.host.hospital
        before_cup, cup_clock = h.cup, h.cup_progress
        before_food, food_clock = self.host.food_action, self.host.food_ms
        pending = dict(self.search.pending)
        was_free = not self.blocked()
        result = self.host.tick(self.token('world-tick'), ms)
        if not result:
            return False
        self.clock += ms
        # Only the avatar action clock pauses. Doctor sampling, drug duration,
        # guard transport, nurse bandaging and shared cooldowns already ticked.
        if action_paused:
            if before_cup == 'raising' and h.cup == before_cup:
                h.cup_progress = cup_clock
            if before_food is not None and self.host.food_action == before_food:
                self.host.food_ms = food_clock
        if was_free and not action_paused:
            for ident, (actor, point) in pending.items():
                if actor == 'avatar' and ident in self.search.pending:
                    self.progress[ident] = self.progress.get(ident, Fraction(0)) + Fraction(ms) * search_factor
        return True

    def apply(self, proposal, **facts):
        cast_id = proposal['cast_id']
        if cast_id in self.applied or not self.host.active():
            return False
        self.applied.add(cast_id)
        name = proposal['skill']
        h = self.host.hospital
        # No visible effect can be inferred from an internal auditory stimulus.
        visible = facts.get('visible', name != 'tinnitus')
        if name != 'control':
            self.host.people.patient_witness(cast_id, visible=visible,
                                            witnessed=facts.get('patient_seen', False))
        if name == 'gut' and h.cup in ('held', 'raising'):
            self.host.hospital_action(self.token('gut-refusal'), 'refuse',
                                     nurse_witness=facts.get('nurse_seen', False))
        elif name in ('withdraw', 'startle'):
            moved = facts.get('actual_hand_withdrawn', False) if name == 'withdraw' else facts.get('actual_out_of_range', False)
            if moved:
                before = h.exam
                self.host.hospital_action(self.token('avoid-grip'), 'withdraw')
                if self.host.room == 'exam' and before in ('offered', 'refused'):
                    self.host.people.observe_exam(('withdraw', cast_id), 'withdraw',
                                                   witnessed=facts.get('assistant_seen', False))
                if h.cup in ('prepared', 'interrupted'):
                    for tx in self.handoffs.values():
                        if tx['kind'] == 'cup' and not tx['closed']:
                            tx['interrupted'] = True
                elif h.cup in ('held', 'raising'):
                    self.host.hospital_action(self.token('cup-interrupted'), 'interrupt_cup')
        self.host._search_ended()
        return True

    def control_witness(self, cast_id, **facts):
        return self.host.people.patient_witness(cast_id, visible=facts.get('visible', False),
                                                witnessed=facts.get('patient_seen', False))

    def contact(self, name, cast_id, **facts):
        if (name != 'knee' or cast_id in self.contacts or not self.host.active()
                or self.host.room != 'exam' or facts.get('target') != 'doctor'
                or not facts.get('actual_contact', False) or not facts.get('actual_body_contact', True)
                or facts.get('obstructed', False) or not facts.get('front', True)
                or facts.get('distance_m', 0) > 1):
            return False
        self.contacts.add(cast_id)
        self.host.people.observe_exam(('contact', cast_id), 'knee', hit=True,
                                     witnessed=facts.get('assistant_seen', False))
        # The exploration result is doctor's actual release, not battle HP15.
        h = self.host.hospital
        if h.holder == 'doctor':
            return self.host.hospital_action(self.token('doctor-kick'), 'doctor_hit_releases', actual=True)
        if h.exam in ('offered', 'refused'):
            return self.host.hospital_action(self.token('doctor-interrupted'), 'end_exam')
        return True

    def vitals(self, token, hp_damage=0, sp_damage=0, sp_heal=0):
        before = self.host.hospital.holder
        old_hp = self.life.hp
        result = self.life.frame(token, [('hp_damage', hp_damage), ('sp_damage', sp_damage), ('heal_sp', sp_heal)])
        self.host._pull()
        self.host._push(before, physical_hit=self.life.hp < old_hp)
        if self.life.stun or self.life.phase == 'dead':
            self.host.cancel_normal()
        return result

    def offer_handoff(self, kind, identity, *, actual_offer=False, participant_present=False,
                      matched=True, **facts):
        h = self.host.hospital
        rooms = {'receipt': 'waiting', 'prescription': 'exam',
                 'pharmacy_prescription': 'pharmacy', 'cup': 'pharmacy'}
        if (kind not in rooms or self.host.room != rooms[kind] or not actual_offer
                or not participant_present or not self.host.active() or self.blocked()
                or identity in self.handoffs or identity in self.closed_handoffs
                or any(not tx['closed'] and not tx['interrupted'] for tx in self.handoffs.values())):
            return False
        if kind == 'receipt' and not self.host.transfer.guide_present:
            return False
        document_id = facts.get('document_id', identity)
        if kind == 'pharmacy_prescription' and (h.prescription != document_id or not matched or h.medicine_closed):
            return False
        if kind == 'cup' and (h.cup_id != document_id or h.cup not in ('prepared', 'interrupted') or h.medicine_closed):
            return False
        self.handoffs[identity] = {'kind': kind, 'closed': False, 'interrupted': False,
                                   'room': self.host.room, 'epoch': self.life.epoch, 'document_id': document_id}
        if kind == 'receipt':
            self.host.transfer.set_nurse_busy(True)
        return True

    def can_handoff(self, kind, identity, **facts):
        tx = self.handoffs.get(identity)
        if (not tx or tx['kind'] != kind or tx['closed'] or tx['interrupted']
                or tx['room'] != self.host.room or tx['epoch'] != self.life.epoch
                or not self.host.active() or self.blocked()):
            return False
        h = self.host.hospital
        if kind == 'cup':
            return h.cup_id == tx['document_id'] and h.cup in ('prepared', 'interrupted') and not h.medicine_closed
        if kind == 'pharmacy_prescription':
            return h.prescription == tx['document_id'] and h.cup == 'none' and not h.medicine_closed
        return True

    def complete_handoff(self, kind, identity, **facts):
        if not self.can_handoff(kind, identity) or not facts.get('actual', True):
            return False
        h = self.host
        if kind == 'receipt':
            self.receipt_owned.add(identity)
            h.transfer.set_nurse_busy(False)
            ok = True
        elif kind == 'prescription':
            ok = h.hospital_action(self.token('prescription-received'), 'give_prescription', ident=self.handoffs[identity]['document_id'])
        elif kind == 'pharmacy_prescription':
            ok = h.hospital_action(self.token('prescription-handed-over'), 'prepare', actual_handover=True, match=True)
        else:
            ok = h.hospital_action(self.token('cup-received'), 'take_cup', actual=True)
        if ok:
            self.handoffs[identity]['closed'] = True
            self.closed_handoffs.add(identity)
        return ok

    def control(self, action, **facts):
        if not self.host.active() or self.blocked() or not facts.get('actual', True):
            return False
        if action == 'move':
            dest = facts.get('room')
            if not facts.get('actual_crossing', False) or not facts.get('route_clear', False):
                return False
            if dest == self.host.room or (self.host.room != 'waiting' and dest != 'waiting'):
                return False
            result = self.host.change_room(self.token('controlled-room'), dest)
            if result:
                self._prune_handoffs()
            return result
        if action == 'search':
            return self.start(facts.get('point'), facts.get('kind', 'normal'), controlled=True,
                              actual_at_point=facts.get('actual_at_point', False), reachable=facts.get('reachable', False))
        if action == 'exit':
            if self.host.room != 'waiting' or not facts.get('actual_crossing', False):
                return False
            return self.host.batch(self.token('controlled-exit'), [('exit', True)]) == 'exit'
        if action == 'pickup_key':
            return self.search.pickup() if facts.get('actual_contact', False) else False
        if action == 'swallow':
            if self.host.room != 'pharmacy' or not facts.get('actual_swallow', False):
                return False
            before = self.host.hospital.medication_count
            self.host.batch(self.token('controlled-swallow'), [('swallow', True)])
            return self.host.hospital.medication_count > before
        return False
