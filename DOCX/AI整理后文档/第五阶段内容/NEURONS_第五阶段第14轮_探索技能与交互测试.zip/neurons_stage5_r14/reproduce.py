"""Reproduce only Round 14; keep delivered historical evidence unchanged."""
import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
FILES=['test_s2_skill_adapter.py','test_s3_skill_adapter.py',
       'test_s4_skill_adapter.py','test_exploration_integration.py',
       'test_exploration_awareness.py']

if __name__=='__main__':
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    dest=ROOT/'reproduction'/stamp
    dest.mkdir(parents=True)
    env=os.environ.copy()
    env['RUN_REPORT']=str(dest/'results.json')
    command=[sys.executable,'-m','pytest',*FILES,'-q',
             '--hypothesis-seed=2026101315','--hypothesis-show-statistics']
    result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True)
    log=result.stdout+result.stderr
    (dest/'run.log').write_text(log,encoding='utf-8')
    print(log)
    print('Evidence:',dest)
    raise SystemExit(result.returncode)
