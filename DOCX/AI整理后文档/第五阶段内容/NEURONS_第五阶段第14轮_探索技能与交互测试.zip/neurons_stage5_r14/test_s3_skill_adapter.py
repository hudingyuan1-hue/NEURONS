from fractions import Fraction
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s3_skill_adapter import S3SkillAdapter


def goto(a, destination):
    h = a.host
    paths = {
        (1, 'reception'): [(1, 'reception')],
        (1, 'ward'): [(1, 'reception'), (1, 'ward')],
        (1, 'exam'): [(1, 'reception'), (1, 'exam')],
        (1, 'treatment'): [(1, 'reception'), (1, 'treatment')],
        (2, 'stairs'): [(1, 'reception'), (2, 'stairs')],
    }
    if h.position[0] == 2:
        if h.position != (2, 'corridor') and h.position != (2, 'stairs'):
            assert h.move(a.token('corridor'), (2, 'corridor'))
        if h.position == (2, 'corridor'):
            assert h.move(a.token('stairs'), (2, 'stairs'))
        assert h.move(a.token('ground'), (1, 'reception'))
    if destination in paths:
        path = paths[destination]
    else:
        path = [(1, 'reception'), (2, 'stairs'), (2, 'corridor'), destination]
    for room in path:
        if h.position != room:
            assert h.move(a.token('goto'), room)


def cup(a, state='ready'):
    h = a.host
    goto(a, (1, 'treatment'))
    h.actors['pharmacist'] = h.position
    h.actors['nurse'] = h.position
    assert h.medication.issue_order('order')
    assert h.medicine_action(a.token('prepare'), 'prepare', order_id='order', cup_id='cup')
    if state in ('held', 'raising', 'swallowed'):
        assert h.medicine_action(a.token('take'), 'take')
    if state in ('raising', 'swallowed'):
        assert h.medicine_action(a.token('raise'), 'raise_cup')
    if state == 'swallowed':
        a.advance(1000)
        assert h.medicine_action(a.token('swallow'), 'swallow', nurse_seen=True)


def drawer(a):
    h = a.host
    goto(a, (2, 'work'))
    h.actors['supervisor'] = h.position
    h._sync()
    assert a.start(43, controlled=True)
    assert h.hand_position(a.token('hand'), True)
    for action in ('notice', 'reach', 'windup'):
        assert h.work_action(a.token(action), action)


def reaching(a, kind='wrist'):
    h = a.host
    room = (1, 'ward') if kind == 'wrist' else (1, 'exam')
    goto(a, room)
    actor = 'orderly' if kind == 'wrist' else 'assistant'
    h.actors[actor] = room
    if kind == 'assistant':
        h.actors['doctor'] = room
    assert h.begin_procedure(a.token('procedure'), kind, doctor_signal=True)
    assert h.reach(a.token('reach'), refused=True)


@pytest.mark.parametrize('room', ['reception', 'ward', 'exam', 'treatment', 'office'])
def test_floor_one_never_becomes_searchable(room):
    a = S3SkillAdapter()
    if room == 'office':
        assert a.host.move(a.token('office'), (1, room))
    else:
        goto(a, (1, room))
    assert a.start(0) is None
    assert a.start(43, controlled=True) is None
    assert a.search.used == 0


def test_controlled_search_outside_autonomous_pool_keeps_pool_and_key_rules():
    a = S3SkillAdapter(); h = a.host
    goto(a, (2, 'work')); pool = h.targets
    assert a.start(43) is None
    ident = a.start(43, controlled=True)
    assert ident and h.targets == pool
    a.advance(h.search_duration)
    assert a.finish(ident)
    assert h.search.key_owner == 'hidden' and h.life.economy.n == 6
    assert not a.finish(ident)


@pytest.mark.parametrize('point', [-1, 45, 100])
def test_controlled_search_rejects_nonexistent_point(point):
    a = S3SkillAdapter(); goto(a, (2, 'work'))
    assert a.start(point, controlled=True) is None
    assert a.search.used == 0


def test_key_completion_actual_once_and_at_correct_room():
    a = S3SkillAdapter(); goto(a, (2, 'group'))
    i = a.start(13)
    assert i
    a.advance(a.host.search_duration)
    assert not a.finish(i, actual=False)
    assert a.search.key_owner == 'hidden'
    assert a.finish(i)
    assert a.search.key_owner == 'avatar'
    assert not a.finish(i)
    assert a.life.economy.n == 6


def test_cancel_search_does_not_cancel_rest_or_cup_or_npc():
    a = S3SkillAdapter(); h = a.host
    # No search exists; cancelling it must not mutate these independent states.
    cup(a, 'raising')
    h.rest_action = True
    h.ordinary_job = {'target': 'postop', 'state': 'locating', 'report': 'fixture'}
    a.cancel_current_search()
    assert h.rest_action and h.medication.cup_state == 'raising'
    assert h.ordinary_job['state'] == 'locating'


def test_cancel_live_search_gives_no_reward_or_key():
    a = S3SkillAdapter(); goto(a, (2, 'group'))
    i = a.start(13); a.advance(100)
    a.cancel_current_search()
    assert i not in a.search.pending and a.life.economy.n == 5
    assert a.search.key_owner == 'hidden'
    assert not a.finish(i)


def test_thermal_progress_is_fractional_and_does_not_double_low_sp():
    a = S3SkillAdapter(); goto(a, (2, 'stairs'))
    # Low SP is tested as an already selected native duration. Native decision
    # at SP<50 correctly returns bed; no new autonomous search is invented.
    assert a.start(0)
    a.advance(1, Fraction(3, 4)); a.advance(3, Fraction(3, 4))
    assert a.host.search_elapsed == 3
    a.advance(1000, action_paused=True)
    assert a.host.search_elapsed == 3
    a.advance(7)
    assert a.host.search_elapsed == 10


def test_tinnitus_pauses_cup_action_not_world_drug_timer():
    a = S3SkillAdapter(); cup(a, 'raising')
    a.advance(500, action_paused=True)
    assert a.host.medication.raising_ms == 0
    a.advance(1000)
    assert a.host.medication.raising_ms == 1000
    assert a.host.medicine_action(a.token('swallow'), 'swallow')
    a.advance(500, action_paused=True)
    assert a.host.drug_stop == 1000


def test_pause_stops_world_while_tinnitus_does_not_stop_holder():
    a = S3SkillAdapter(); reaching(a)
    h = a.host
    assert h.grip(a.token('grip'), tighten=True)
    a.sync(paused=True)
    assert not a.advance(1000)
    assert h.hold_ms == 0
    a.sync(paused=False)
    a.advance(2000, action_paused=True)
    assert h.holder is None and h.life.hp == 95 and h.life.sp == 95


@pytest.mark.parametrize('state', ['ready', 'held', 'raising'])
def test_gut_pre_swallow_refuses_once_without_drug(state):
    a = S3SkillAdapter(); cup(a, state)
    assert a.apply({'skill': 'gut'}, nurse_seen=True)
    assert a.host.medication.cup_state == 'refused'
    assert a.life.sp == 100 and not a.host.drug_stop
    assert not a.apply({'skill': 'gut'})


def test_gut_after_swallow_never_returns_damage_or_drug():
    a = S3SkillAdapter(); cup(a, 'swallowed')
    assert not a.apply({'skill': 'gut'})
    assert a.life.sp == 80 and a.host.drug_stop == 1500
    a.vitals(a.token('happy'), sp_heal=20)
    assert a.life.sp == 100 and a.host.drug_stop == 1500


@pytest.mark.parametrize('name', ['skin', 'gut', 'pores', 'thermal', 'tinnitus', 'happy', 'control'])
def test_skill_success_without_hand_withdrawal_does_not_prevent_drawer_damage(name):
    a = S3SkillAdapter(); drawer(a)
    a.apply({'skill': name})
    assert a.host.work_action(a.token('close'), 'close', contact=True)
    assert a.life.hp == 90
    assert a.host.holder == 'supervisor'
    a.advance(1000, action_paused=True)
    assert a.host.holder is None


@pytest.mark.parametrize('name', ['skin', 'gut', 'withdraw', 'startle', 'fear', 'control'])
def test_actual_drawer_hand_withdrawal_prevents_one_clamp(name):
    a = S3SkillAdapter(); drawer(a)
    assert a.apply({'skill': name}, hand_withdrawn=True)
    assert a.host.work_action(a.token('close'), 'close', contact=True)
    assert a.life.hp == 100 and a.host.work.attempt_used


@pytest.mark.parametrize('name,facts', [('withdraw', {'hand_withdrawn': True}), ('startle', {'outside_range': True})])
def test_actual_defense_avoids_pregrip_only(name, facts):
    a = S3SkillAdapter(); reaching(a)
    assert a.contact(name, 'c1', **facts)
    assert a.host.procedure is None and a.life.hp == 100
    assert not a.contact(name, 'c1', **facts)


@pytest.mark.parametrize('name,facts', [('withdraw', {'hand_withdrawn': True}), ('startle', {'outside_range': True}),
                                    ('knee', {'actual_contact': True, 'actual_body_contact': True, 'front': True, 'distance_m': 0.5, 'target': 'assistant'})])
def test_existing_wrist_is_not_free_skill_release(name, facts):
    a = S3SkillAdapter(); reaching(a, 'assistant')
    assert a.host.grip(a.token('grip'), tighten=True)
    assert not a.contact(name, 'skill', **facts)
    assert a.host.holder == 'assistant' and a.life.hp == 95


@pytest.mark.parametrize('change', [{'actual_contact': False}, {'actual_body_contact': False}, {'front': False}, {'distance_m': 1.01}, {'obstructed': True}, {'target': 'worker'}])
def test_knee_cannot_interrupt_drawer_without_real_operator_contact(change):
    a = S3SkillAdapter(); drawer(a)
    facts = dict(actual_contact=True, actual_body_contact=True, front=True, distance_m=1, target='supervisor')
    facts.update(change)
    assert not a.contact('knee', 'kick', **facts)
    assert a.host.work.stage == 'windup'


def test_actual_knee_operator_contact_stops_pending_drawer_and_is_idempotent():
    a = S3SkillAdapter(); drawer(a)
    facts = dict(actual_contact=True, actual_body_contact=True, front=True, distance_m=1, target='supervisor')
    assert a.contact('knee', 'kick', **facts)
    assert not a.host.work_action(a.token('close'), 'close')
    assert a.life.hp == 100 and not a.contact('knee', 'kick', **facts)


def chief_document(a):
    goto(a, (2, 'corridor')); h = a.host
    h.actors['chief'] = h.position; h._sync()
    doc = h.records.add_record('old_report', 'avatar')
    assert h.records.take_document(doc)
    assert h.records.read_document(doc)
    return doc


def test_chief_handoff_needs_actual_avatar_document_and_completion_keeps_knowledge():
    a = S3SkillAdapter(); doc = chief_document(a); h = a.host
    assert not a.can_handoff('chief_document', doc)
    assert not a.can_handoff('chief_document', 'unknown', actual_pending=True)
    assert a.can_handoff('chief_document', doc, actual_pending=True)
    assert h.chief_busy and doc in h.records.owned
    assert not a.complete_handoff('chief_document', doc, actual=False)
    assert a.complete_handoff('chief_document', doc, actual=True)
    assert doc not in h.records.owned and doc in a.chief_holding
    assert doc in h.records.read_ids and doc not in h.records.inaccessible
    assert not h.chief_busy and not a.complete_handoff('chief_document', doc)


def test_remote_or_rejected_chief_handoff_cannot_block_npc_report():
    a = S3SkillAdapter(); h = a.host; doc = chief_document(a)
    assert h.move(a.token('leave'), (2, 'activity'))
    assert not a.can_handoff('chief_document', doc, actual_pending=True)
    assert not h.chief_busy
    h.records.report_received = True
    a.apply({'skill': 'dry'})
    assert h.records.report_received


def test_real_handoff_releases_chief_when_avatar_leaves():
    a = S3SkillAdapter(); doc = chief_document(a)
    assert a.can_handoff('chief_document', doc, actual_pending=True)
    assert a.host.move(a.token('leave'), (2, 'activity'))
    a.advance(1)
    assert not a.host.chief_busy
    assert not a.complete_handoff('chief_document', doc)


def test_cup_handoff_guards_real_identity_and_never_revokes_received_cup():
    a = S3SkillAdapter(); cup(a)
    assert not a.can_handoff('cup', 'fake', actual_pending=True)
    assert a.can_handoff('cup', 'cup', actual_pending=True)
    assert a.complete_handoff('cup', 'cup')
    assert a.host.medication.cup_state == 'held'
    assert not a.can_handoff('cup', 'cup', actual_pending=True)
    assert not a.apply({'skill': 'dry'})
    assert a.host.medication.cup_state == 'held'


def test_control_movement_cannot_teleport_or_exit_without_key():
    a = S3SkillAdapter()
    assert not a.control('move', dest=(2, 'work'))
    assert not a.control('exit')
    assert a.life.progress == 3
    assert a.control('move', dest=(2, 'stairs'))
    assert not a.control('make_key', permitted=True)


def test_control_observation_requires_reachable_fact():
    a = S3SkillAdapter(); goto(a, (2, 'quiet'))
    assert not a.control('observe')
    assert a.control('observe', reachable=True)
    a.host.drug_stop = 100
    assert not a.control('observe', reachable=True)


class S3ActionState(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.a = S3SkillAdapter()
        goto(self.a, (2, 'stairs'))
        self.last = None

    @rule(point=st.integers(min_value=0, max_value=5), controlled=st.booleans())
    def search(self, point, controlled):
        result = self.a.start(point, controlled=controlled)
        if result:
            self.last = result

    @rule(ms=st.sampled_from([0, 1, 249, 1000, 6000, 10000]), factor=st.sampled_from([Fraction(1), Fraction(3, 4)]), frozen=st.booleans())
    def time(self, ms, factor, frozen):
        old = self.a.host.search_elapsed
        pending = dict(self.a.search.pending)
        self.a.advance(ms, factor, frozen)
        if frozen and pending == self.a.search.pending:
            assert self.a.host.search_elapsed == old

    @rule(actual=st.booleans())
    def finish(self, actual):
        before = self.a.life.economy.n
        result = self.a.finish(self.last, actual=actual)
        if not result:
            assert self.a.life.economy.n == before

    @rule()
    def cancel(self):
        self.a.cancel_current_search()

    @rule(paused=st.booleans())
    def pause(self, paused):
        self.a.sync(paused=paused)

    @rule(dest=st.sampled_from([(2, 'stairs'), (2, 'corridor'), (2, 'activity'), (1, 'reception')]))
    def move(self, dest):
        self.a.control('move', dest=dest)

    @rule()
    def feedback(self):
        self.a.host.finish_feedback(self.a.token('feedback'))

    @invariant()
    def reward_and_space(self):
        h = self.a.host
        assert h.search is self.a.search
        assert h.search.used <= 14
        assert h.life.economy.n == 5 + len(h.search.complete)
        assert h.search.key_owner == 'hidden'
        assert len(h.search.pending) <= 1
        assert h.life.hp == h.life.sp == 100


TestS3ActionState = S3ActionState.TestCase
TestS3ActionState.settings = settings(max_examples=200, stateful_step_count=70, deadline=None)


def core(a=None):
    from exploration_core import ExplorationSkills
    c = ExplorationSkills(a or S3SkillAdapter())
    c.life.economy.n = c.life.economy.c = 100
    for name in ('gut', 'pores', 'thermal', 'tinnitus', 'dry', 'knee', 'withdraw', 'startle', 'fear', 'happy', 'control'):
        assert c.book.unlock(name)
    return c


def cast(c, name, **facts):
    paid = c.submit(name)
    assert paid is not None
    assert c.react(paid['id'], **facts)
    return paid['id']


def test_core_thermal_and_tinnitus_change_only_avatar_search_clock():
    a = S3SkillAdapter(); goto(a, (2, 'stairs')); c = core(a)
    ident = c.start_search(0)
    cast(c, 'thermal'); c.tick(1000)
    assert a.host.search_elapsed == 750
    cast(c, 'tinnitus'); c.tick(1000)
    assert a.host.search_elapsed == 750
    c.tick(1000)
    assert a.host.search_elapsed == 1500
    c.tick(a.host.search_duration - 1500)
    assert c.complete_search(ident)


def test_core_dry_delays_real_cup_handoff_two_unpaused_seconds():
    a = S3SkillAdapter(); cup(a); c = core(a)
    assert c.begin_handoff('cup', 'cup', actual_pending=True)
    cast(c, 'dry')
    assert not c.complete_handoff('cup')
    c.tick(1000)
    c.set_pause(True); c.tick(9000)
    assert a.host.medication.cup_state == 'ready'
    c.set_pause(False); c.tick(999)
    assert not c.complete_handoff('cup')
    c.tick(1)
    assert c.complete_handoff('cup')
    assert a.host.medication.cup_state == 'held'
    assert not c.complete_handoff('cup')


def test_core_dry_after_cup_receipt_does_not_revoke_or_apply_delay():
    a = S3SkillAdapter(); cup(a, 'held'); c = core(a)
    paid = c.submit('dry'); p = c.react(paid['id'])
    assert not p.get('handoff_delay_ms')
    assert a.host.medication.cup_state == 'held'
    assert c.life.economy.n == 99


def test_core_gut_pre_swallow_rejects_without_clear_or_refund():
    a = S3SkillAdapter(); cup(a, 'raising'); c = core(a)
    cast(c, 'gut', nurse_seen=True)
    assert a.host.medication.cup_state == 'refused'
    assert c.life.economy.n == 99 and c.life.sp == 100
    assert not a.host.medicine_action(a.token('swallow_after'), 'swallow')


def test_core_knee_contacts_operator_only_during_real_active_window():
    a = S3SkillAdapter(); drawer(a); c = core(a)
    ident = cast(c, 'knee')
    facts = dict(actual_contact=True, actual_body_contact=True, front=True, distance_m=1, target='supervisor')
    assert not c.contact(ident, **facts)
    assert a.host.work.stage == 'windup'
    c.tick(150)
    assert c.contact(ident, **facts)
    assert not c.contact(ident, **facts)
    assert not a.host.work_action(a.token('close'), 'close')
    assert c.life.hp == 100 and c.life.economy.n == 98


def test_core_actual_withdrawal_retains_key_reward_and_search_object():
    a = S3SkillAdapter(); drawer(a); c = core(a); shared = c.search
    ident = cast(c, 'withdraw')
    assert c.contact(ident, hand_withdrawn=True)
    assert a.host.work_action(a.token('close'), 'close')
    assert c.life.hp == 100 and c.search is shared is a.host.search
    assert not shared.pending and shared.income == 0


def test_core_happy_heals_but_does_not_remove_drug_stop():
    a = S3SkillAdapter(); cup(a, 'swallowed'); c = core(a)
    cast(c, 'happy')
    assert c.life.sp == 100 and a.host.drug_stop == 1500
    assert not c.submit('control')
    c.tick(1500)
    assert c.submit('control')


def test_core_control_search_uses_native_points_and_cannot_teleport():
    a = S3SkillAdapter(); goto(a, (2, 'work')); c = core(a)
    cast(c, 'control')
    bad = c.command('move', action='move', dest=(1, 'ward'))
    assert bad and not c.control_action(bad['id'])
    cmd = c.command('interact', action='start_search', point=43)
    assert cmd and c.control_action(cmd['id'])
    assert a.search.used == 1 and a.host.targets == tuple(range(14))


def test_core_lethal_damage_closes_chief_handoff_without_confiscation():
    a = S3SkillAdapter(); doc = chief_document(a); c = core(a)
    assert c.begin_handoff('chief_document', doc, actual_pending=True)
    cast(c, 'dry')
    a.vitals(a.token('lethal'), hp_damage=100)
    c.tick(1)
    assert c.life.phase == 'dead' and c.handoff is None
    assert not a.host.chief_busy
    assert doc in a.host.records.owned


@pytest.mark.parametrize('sp', [0, 19, 49])
def test_core_control_may_search_low_sp_after_actual_stun_finished(sp):
    a = S3SkillAdapter(); goto(a, (2, 'work')); a.life.sp = sp
    if sp == 0:
        a.life.emptied = True
    c = core(a)
    assert a.host.decision() == 'bed'
    cast(c, 'control')
    cmd = c.command('interact', action='start_search', point=43)
    assert cmd and c.control_action(cmd['id'])
    assert a.search.used == 1 and len(a.search.pending) == 1


@pytest.mark.parametrize('block', ['budget', 'holder', 'drug', 'stun', 'feedback', 'rest', 'cup', 'key'])
def test_controlled_low_sp_search_still_respects_native_gates(block):
    a = S3SkillAdapter(); goto(a, (2, 'work')); h = a.host
    h.life.sp = 19
    if block == 'budget': h.search.used = 14
    elif block == 'holder': h.holder = 'supervisor'
    elif block == 'drug': h.drug_stop = 1
    elif block == 'stun': h.life.stun = 1
    elif block == 'feedback': h.feedback = True
    elif block == 'rest': h.rest_action = True
    elif block == 'cup': h.medication.cup_state = 'held'
    elif block == 'key': h.search.key_owner = 'avatar'
    used = h.search.used
    assert a.start(43, controlled=True) is None
    assert h.search.used == used


def prepare_testimony(a):
    h = a.host
    goto(a, (2, 'activity'))
    h.actors['postop'] = h.position; h._sync()
    event = h.report_action(a.token('wound'), 'begin_wound', event='wound')
    assert event
    h.actors['informant'] = h.position; h._sync()
    assert h.report_action(a.token('witness'), 'see_wound', event_key=event)
    h.actors['informant'] = h.actors['chief'] = (2, 'corridor')
    goto(a, (2, 'corridor')); h._sync()
    return event


def test_core_dry_does_not_freeze_npc_to_npc_report_without_avatar_handoff():
    a = S3SkillAdapter(); event = prepare_testimony(a); c = core(a)
    cast(c, 'dry')
    assert a.host.report_action(a.token('report'), 'receive_testimony', event_key=event,
                                target='postop', statement='fixture actual received')
    assert event in a.host.ward.testimonies
    assert a.host.ward.testimonies[event]['target'] == 'postop'


def test_core_real_chief_handoff_delays_report_then_preserves_received_report():
    a = S3SkillAdapter(); event = prepare_testimony(a); doc = chief_document(a); c = core(a)
    assert c.begin_handoff('chief_document', doc, actual_pending=True)
    cast(c, 'dry')
    h = a.host
    assert not h.report_action(a.token('busy_report'), 'receive_testimony', event_key=event,
                               target='postop', statement='fixture actual received')
    c.tick(1999)
    assert not c.complete_handoff(doc)
    c.tick(1)
    assert c.complete_handoff(doc)
    assert h.report_action(a.token('report'), 'receive_testimony', event_key=event,
                           target='postop', statement='fixture actual received')
    assert event in h.ward.testimonies
    # Ownership/knowledge of that report belongs to the NPC, not the skill.
    c.tick(2000)
    cast(c, 'dry')
    assert event in h.ward.testimonies


def test_handoff_pause_and_body_restriction_do_not_cancel_physical_transaction():
    a = S3SkillAdapter(); doc = chief_document(a); c = core(a)
    assert c.begin_handoff('chief_document', doc, actual_pending=True)
    c.set_pause(True)
    assert c.handoff and a.host.chief_busy
    c.set_pause(False)
    a.host.drug_stop = 1000
    c.tick(1)
    assert c.handoff and a.host.chief_busy
    assert a.handoff_valid('chief_document', doc)
    c.tick(999)
    assert c.complete_handoff(doc)


def test_core_cancelled_cup_handoff_can_resume_same_actual_cup():
    a = S3SkillAdapter(); cup(a); c = core(a)
    assert c.begin_handoff('cup', 'cup', actual_pending=True)
    cast(c, 'dry')
    assert a.host.move(a.token('leave'), (1, 'reception'))
    c.tick(1)
    assert c.handoff is None and a.host.medication.cup_state == 'ready'
    assert a.host.move(a.token('return'), (1, 'treatment'))
    new = c.begin_handoff('cup', 'cup', actual_pending=True)
    assert new
    assert not c.complete_handoff('cup')
    assert not c.complete_handoff('cup', generation=new['generation'] - 1)
    assert c.complete_handoff('cup', generation=new['generation'])
    assert a.host.medication.cup_state == 'held'


def test_core_control_take_cup_cannot_bypass_pending_dry_delay():
    a = S3SkillAdapter(); cup(a); c = core(a)
    assert c.begin_handoff('cup', 'cup', actual_pending=True)
    cast(c, 'dry'); cast(c, 'control')
    command = c.command('interact', action='take_cup')
    assert command and not c.control_action(command['id'])
    assert a.host.medication.cup_state == 'ready'
    c.tick(2000)
    command = c.command('interact', action='complete_handoff', identity='cup')
    assert command and c.control_action(command['id'])
    assert a.host.medication.cup_state == 'held'
