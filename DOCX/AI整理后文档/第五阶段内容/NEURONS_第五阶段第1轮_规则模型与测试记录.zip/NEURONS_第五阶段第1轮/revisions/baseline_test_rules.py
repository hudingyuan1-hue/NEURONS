"""Independent boundary expectations and action-sequence invariants.

Fixtures can construct rare states directly. This is test setup only, not
authorization to inject state into the actual game.
"""
from copy import deepcopy
from itertools import permutations
import pytest
from hypothesis import given, settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant, initialize
from rules import Economy, Skill, Search, Life, Spawn, SEARCH, probability, search_ms, save_load

SEQ = settings(max_examples=200, stateful_step_count=60, deadline=None, database=None)

@pytest.mark.parametrize('n', [0,1,4,5,9,10,99])
def test_revive_floor_not_income(n):
    e=Economy(n=n,c=0)
    e.restart(); e.restart()
    assert (e.n,e.c)==(max(n,5),0)

@pytest.mark.parametrize('mode', ['exploration','battle','pause','control','loading','dead'])
def test_clock_boundaries(mode):
    e=Economy(n=0,battle=mode!='exploration')
    e.fraction=3999
    e.paused=mode=='pause'; e.control=mode=='control'
    if mode in ('loading','dead'): e.phase=mode
    e.tick(1)
    assert (e.n,e.fraction)==((1,0) if mode=='battle' else (0,3999))

def test_income_crosses_regen_cap_without_wallet_cap():
    e=Economy(n=4,battle=True,fraction=3999)
    e.credit('reward',10,2)
    assert (e.n,e.c,e.fraction)==(14,5,0)
    e.tick(40000)
    assert e.n==14
    assert not e.credit('reward',10,2)

@pytest.mark.parametrize('power,resistance,global_r,result',[(1,0,0,'reacted'),(1,1,0,'resisted'),(2,1,1,'resisted'),(3,1,1,'reacted')])
def test_strict_resistance(power,resistance,global_r,result):
    e=Economy(n=5,global_r=global_r)
    e.skills['skin']=Skill(1,power,2000,resistance)
    assert e.cast()==result
    assert e.n==4 and e.skills['skin'].remaining==2000

@pytest.mark.parametrize('reason',['funds','cooldown','body','active','locked','dead'])
def test_invalid_free(reason):
    e=Economy()
    if reason=='funds': e.n=0
    if reason=='cooldown': e.skills['skin'].remaining=1
    if reason=='active': e.skills['skin'].active=True
    if reason=='dead': e.phase='dead'
    before=deepcopy(e)
    assert e.cast('missing' if reason=='locked' else 'skin',valid=reason!='body')=='invalid'
    assert e==before

def test_pending_adaptation_partial_count_and_commit_once():
    e=Economy(n=50)
    e.skills['skin'].power=9
    for _ in range(2): e.cast(); e.tick(2000)
    e.restart()
    assert e.skills['skin'].successes==2
    e.cast(); e.tick(2000)
    for _ in range(8): e.cast(); e.tick(2000)
    assert e.skills['skin'].pending and e.skills['skin'].resistance==0
    e.restart(); e.restart()
    assert e.skills['skin'].resistance==1 and e.skills['skin'].successes==0

def test_awakening_idempotent_and_delayed():
    e=Economy()
    for _ in range(4):
        e.awaken('dog_killed_by_father'); e.awaken('parent_collapse')
    assert e.global_r==0 and len(e.pending_g)==2
    e.restart(); e.restart()
    assert e.global_r==2
    assert not e.awaken('ordinary_death')

@pytest.mark.parametrize('n,c,battle,other_pass,expected',[
    (0,0,True,False,False),(4,0,True,False,False),(5,0,True,False,True),
    (9,0,True,False,True),(10,0,True,False,False),(5,1,True,False,False),
    (5,0,False,False,False),(5,0,True,True,False)])
def test_reconnect_boundary(n,c,battle,other_pass,expected):
    e=Economy(n=n,c=c,battle=battle,global_r=2)
    e.skills['skin'].resistance=2
    e.skills['skin'].remaining=1500
    if other_pass: e.skills['joy']=Skill(3,99,8000)
    assert e.reconnect()==expected
    assert e.n == n-(5 if expected else 0)
    assert e.skills['skin'].remaining==1500
    assert e.skills['skin'].successes==0
    if expected: assert e.skills['skin'].power==5

@given(n=st.integers(0,100),c=st.integers(0,20),r=st.integers(1,1000),g=st.integers(0,2))
@settings(max_examples=300,deadline=None,database=None)
def test_high_resistance_has_affordable_repair_path(n,c,r,g):
    e=Economy(n=n,c=c,battle=True,global_r=g)
    e.skills['skin'].resistance=r
    for _ in range(c+n//10+4):
        if not e.all_blocked(): break
        if e.c: assert e.upgrade()
        elif e.n>=10: assert e.convert()
        elif e.n<5: e.tick(20000)
        else: assert e.reconnect()
    assert not e.all_blocked()
    assert e.n>=0 and e.c>=0

def test_zero_resource_repair_then_skin_24_game_seconds():
    e=Economy(n=0,c=0,battle=True,global_r=2)
    e.skills['skin'].resistance=100
    e.tick(19999); assert not e.reconnect()
    e.tick(1); assert e.reconnect()
    assert e.cast()=='invalid'
    e.tick(3999); assert e.cast()=='invalid'
    e.tick(1); assert e.cast()=='reacted'
    assert (e.n,e.c)==(0,0)

@pytest.mark.parametrize('level,key',[(l,k) for l in range(1,5) for k in range(SEARCH[l][1])])
def test_each_key_position_without_npcs_or_resources(level,key):
    s=Search(level,key)
    for p in range(SEARCH[level][1]):
        token=s.start(p)
        assert token is not None
        s.settle(token)
        if s.key_owner=='avatar': break
    assert s.action()=='exit'
    assert s.income==key+1 and s.used==key+1

def test_last_dog_completion_precedes_bed():
    s=Search(key_point=10)
    for p in range(9): s.settle(s.start(p))
    dog=s.start(10,'dog')
    s.settle(s.start(9),'cancel')
    assert s.used==10 and s.action(0)=='wait_current_dog'
    s.settle(dog)
    assert s.action(0)=='wait_current_dog'
    before=(s.used,s.income)
    assert s.deliver() and s.action(0)=='exit'
    assert (s.used,s.income)==before

def test_dog_drop_requires_actual_visibility():
    s=Search(key_point=1)
    s.settle(s.start(1,'dog'))
    s.dog_leave()
    assert not s.pickup()
    s.dropped_visible=True
    assert s.pickup() and s.action(0)=='exit'
    assert s.used==0 and s.income==1

def test_s4_cancelled_last_key_is_not_dead_end():
    s=Search(level=4,key_point=15)
    for p in range(15): s.settle(s.start(p))
    s.settle(s.start(15),'cancel')
    assert s.used==16 and s.action(0)=='search'
    assert s.settle(s.start(15))
    assert s.used==17 and s.action(0)=='exit' and s.attempt==1

def test_old_search_callback_cannot_settle_new_attempt():
    s=Search(key_point=0)
    old=s.start(0)
    s.restart(0)
    current=s.start(0)
    assert not s.settle(old)
    assert s.income==0 and s.used==1 and current in s.pending
    assert s.settle(current) and s.income==1

@pytest.mark.parametrize('sp,expected',[(100,'search'),(50,'search'),(49,'bed'),(20,'bed'),(19,'bed'),(0,'bed')])
def test_low_sp_action_and_key_override(sp,expected):
    s=Search()
    assert s.action(sp)==expected
    s.key_owner='avatar'
    assert s.action(sp)=='exit'
    assert s.action(sp,danger=True)=='evade'

@pytest.mark.parametrize('k,mult',[(1,1),(2,.95),(4,.85),(5,.8),(6,.8),(1000000,.8)])
def test_search_practice_cap(k,mult):
    assert search_ms(3,'normal',k,20)==round(6000*mult)
    assert search_ms(3,'normal',k,19)==round(7500*mult)

@pytest.mark.parametrize('damage,expected',[(99,'exit'),(100,'death'),(101,'death')])
def test_damage_heal_exit_order_permutations(damage,expected):
    for ev in permutations([('hp_damage',damage),('heal_hp',20),('exit',True)]):
        x=Life()
        assert x.frame((0,'batch'),ev)==expected
        assert x.hp==(0 if expected=='death' else 21)

def test_mental_empty_rearms_only_at_twenty():
    x=Life(sp=1)
    x.frame((0,1),[('sp_damage',1)]); assert x.stun==1000
    x.tick(1000)
    x.frame((0,2),[('heal_sp',19)])
    x.frame((0,3),[('sp_damage',19)]); assert x.stun==0
    x.frame((0,4),[('heal_sp',20)])
    x.frame((0,5),[('sp_damage',20)]); assert x.stun==1000

def test_zero_sp_valid_exit_no_replayed_stun():
    x=Life(sp=1)
    assert x.frame((0,1),[('sp_damage',1),('exit',True)])=='exit'
    assert (x.sp,x.stun,x.emptied)==(0,0,True)
    x.finish_exit()
    assert (x.sp,x.stun,x.emptied)==(0,0,True)

def test_double_food_and_lethal_food_transaction():
    x=Life(hp=1,sp=0,food={'one':'chocolate'})
    x.frame((0,1),[('food','one'),('food','one')])
    assert (x.hp,x.sp,x.economy.n,x.economy.c)==(16,15,8,4)
    assert not x.food
    y=Life(hp=1,food={'one':'chocolate'})
    y.frame((0,1),[('food','one'),('hp_damage',1)])
    assert y.phase=='dead' and y.economy.n==5 and 'one' in y.food

def test_collapse_lethal_and_revive_exactly_once():
    x=Life()
    x.frame((0,1),[('collapse',True),('hp_damage',100),('exit',True)])
    assert x.revive() and not x.revive()
    assert (x.total,x.attempts[1],x.intruder)==(4,2,100001)
    assert x.economy.global_r==1
    assert x.frame((0,1),[('hp_damage',100)])=='ignored'
    assert x.hp==100

@pytest.mark.parametrize('progress,place,respawn',[(1,'S1','S1_spawn'),(1,'hiddenStreet','S1_spawn'),(4,'S4','S4_spawn'),(5,'S5','S5_atrium'),(6,'S6','S5_atrium'),(6,'S5_atrium','S5_atrium')])
def test_death_keeps_progress_not_physical_map(progress,place,respawn):
    x=Life(progress=progress,place=place)
    x.economy.battle = progress>=5 or place=='hiddenStreet'
    x.s5_snapshot={'nurse_used':True,'dead':{'father'},'props':{'cart_moved'}}
    x.frame((0,1),[('hp_damage',100)])
    x.revive()
    assert (x.place,x.total,x.attempts[progress])==(respawn,4,2)
    assert all(v==1 for k,v in x.attempts.items() if k!=progress)
    assert x.s5_snapshot=={'nurse_used':True,'dead':{'father'},'props':{'cart_moved'}}
    assert x.economy.battle==(progress>=5)

def test_s6_retry_does_not_refresh_s5_or_reward_again():
    x=Life(progress=6,place='S6')
    x.economy.battle=True
    x.s5_snapshot['nurse_used']=True
    for i in range(3):
        x.frame((x.epoch,i),[('hp_damage',100)])
        x.revive()
        assert x.place=='S5_atrium'
    assert x.total==10 and x.attempts[6]==4 and x.attempts[5]==1
    x.frame((x.epoch,9),[('exit',True)])
    x.finish_exit()
    assert x.place=='S6' and x.economy.n==5 and x.economy.c==3
    assert x.s5_snapshot['nurse_used']

def test_hidden_exit_e1_no_s6_bonus():
    x=Life(); x.enter_hidden()
    x.frame((x.epoch,1),[('exit',True)])
    assert x.finish_exit()=='E1'
    assert x.progress==1 and (x.economy.n,x.economy.c)==(5,3)

@pytest.mark.parametrize('kind,base,cap',[('ordinary',50,70),('patient',35,55),('s4',45,65),('s5',55,75)])
def test_probability_key_attempts(kind,base,cap):
    assert [probability(kind,k) for k in (1,2,5,6,1000000)]==[base,base+5,cap,cap,cap]

def test_returns_count_only_game_time_and_max_three():
    s=Spawn()
    s.check(9999,first=True)
    s.leave(); s.tick(20000,paused=True); assert not s.check(0)
    s.leave(); s.tick(19999); assert not s.check(0)
    for _ in range(5):
        s.leave(); s.tick(20000); s.check(9999)
    assert s.checks==3 and s.state=='unseen'

def test_pending_does_not_redraw_and_retired_does_not_respawn():
    s=Spawn(); s.check(0,first=True)
    s.enter(free=False); assert s.state=='pending'
    for _ in range(4): s.leave(); s.tick(20000); s.check(0)
    assert s.checks==1
    s.enter(); s.retire()
    s.leave(); s.tick(20000); s.check(0); s.enter()
    assert s.state=='retired' and s.checks==1


class EconomySequence(RuleBasedStateMachine):
    @initialize(n=st.integers(0,20),c=st.integers(0,5),r=st.integers(0,10))
    def begin(self,n,c,r):
        self.e=Economy(n=n,c=c,battle=True)
        self.e.skills['skin'].resistance=r
        self.ledger_n=n; self.ledger_c=c
        self.rewards=set(); self.elapsed=0

    @rule(token=st.integers(0,8),amount=st.integers(1,8))
    def reward(self,token,amount):
        fresh=token not in self.rewards
        assert self.e.credit(token,amount)==fresh
        if fresh: self.ledger_n+=amount; self.rewards.add(token)

    @rule(valid=st.booleans(),reacts=st.booleans())
    def cast(self,valid,reacts):
        s=self.e.skills['skin']; b=(s.power,s.resistance,self.e.global_r)
        result=self.e.cast(valid=valid,body_reacts=reacts)
        if result!='invalid':
            self.ledger_n-=1
            assert (result=='resisted') == (b[0]<=b[1]+b[2])

    @rule(ms=st.integers(0,20000),paused=st.booleans(),control=st.booleans())
    def clock(self,ms,paused,control):
        self.e.paused=paused; self.e.control=control
        expected=min(5-self.ledger_n,(self.e.fraction+ms)//4000) if self.ledger_n<5 and not paused and not control else 0
        self.e.tick(ms); self.ledger_n+=expected

    @rule()
    def spend_cluster(self):
        ok=self.e.upgrade()
        if ok: self.ledger_c-=1

    @rule()
    def exchange(self):
        ok=self.e.convert()
        if ok: self.ledger_n-=10; self.ledger_c+=1

    @rule()
    def reconnect(self):
        old=self.e.skills['skin'].remaining
        if self.e.reconnect(): self.ledger_n-=5
        assert self.e.skills['skin'].remaining==old

    @rule(identity=st.sampled_from(['dog_killed_by_father','parent_collapse','other']))
    def awakening(self,identity): self.e.awaken(identity)

    @rule()
    def restart(self):
        self.e.restart(); self.ledger_n=max(self.ledger_n,5)

    @rule()
    def snapshot(self):
        old=self.e; self.e=save_load(old); assert self.e==old

    @invariant()
    def balances_and_adaptation(self):
        assert (self.e.n,self.e.c)==(self.ledger_n,self.ledger_c)
        assert self.e.n>=0 and self.e.c>=0
        assert 0<=self.e.fraction<4000
        assert self.e.n<5 or self.e.fraction==0
        assert 0<=self.e.global_r<=2
        s=self.e.skills['skin']; assert s.successes in (0,1,2)
        assert not s.pending or s.successes==0

TestEconomySequence=EconomySequence.TestCase
TestEconomySequence.settings=SEQ

class SearchSequence(RuleBasedStateMachine):
    @initialize(level=st.integers(1,4),key=st.integers(0,9))
    def begin(self,level,key):
        self.s=Search(level,key); self.tokens=[]; self.rewarded=set()

    @rule(point=st.integers(0,16),dog=st.booleans())
    def start(self,point,dog):
        token=self.s.start(point,'dog' if dog else 'avatar')
        if token: self.tokens.append(token)

    @rule(index=st.integers(0,50),complete=st.booleans())
    def settle(self,index,complete):
        if not self.tokens: return
        token=self.tokens[index%len(self.tokens)]
        action=self.s.pending.get(token)
        if action and complete: self.rewarded.add((self.s.attempt,action[1]))
        self.s.settle(token,'complete' if complete else 'cancel')

    @rule()
    def deliver(self): self.s.deliver()

    @rule()
    def retire(self): self.s.dog_leave()

    @rule(visible=st.booleans())
    def pickup(self,visible):
        self.s.dropped_visible=visible; self.s.pickup()

    @rule(key=st.integers(0,9))
    def restart(self,key): self.s.restart(key)

    @rule()
    def save(self): self.s=save_load(self.s)

    @invariant()
    def search_accounting(self):
        assert self.s.income==len(self.rewarded)
        assert self.s.level==4 or self.s.used<=SEARCH[self.s.level][2]
        assert self.s.dog_starts<=3
        assert len({p for a,p in self.s.pending.values()})==len(self.s.pending)
        assert self.s.key_owner in ('hidden','dog','avatar','ground')
        if self.s.key_owner=='avatar': assert self.s.action(0)=='exit'

TestSearchSequence=SearchSequence.TestCase
TestSearchSequence.settings=SEQ

class LifecycleSequence(RuleBasedStateMachine):
    @initialize(progress=st.integers(1,6))
    def begin(self,progress):
        self.x=Life(progress=progress,place=f'S{progress}')
        self.x.economy.battle=progress>=5
        self.dead_count=0; self.rest_count=0; self.attempts={i:1 for i in range(1,7)}
        self.serial=0; self.old=[]

    @rule(hp=st.integers(0,110),sp=st.integers(0,110),heal=st.integers(0,30),exit=st.booleans())
    def events(self,hp,sp,heal,exit):
        self.serial+=1; token=(self.x.epoch,self.serial); self.old.append(token)
        self.x.frame(token,[('hp_damage',hp),('sp_damage',sp),('heal_hp',heal),('exit',exit)])

    @rule()
    def revive(self):
        if self.x.revive():
            self.dead_count+=1; self.attempts[self.x.progress]+=1

    @rule()
    def rest(self):
        if self.x.rest(): self.rest_count+=1; self.attempts[self.x.progress]+=1

    @rule()
    def transfer(self): self.x.finish_exit()

    @rule(index=st.integers(0,100))
    def stale_callback(self,index):
        if not self.old: return
        before=deepcopy(self.x)
        assert self.x.frame(self.old[index%len(self.old)],[('hp_damage',100)])=='ignored'
        assert self.x==before

    @rule(ms=st.integers(0,3000),paused=st.booleans())
    def clock(self,ms,paused): self.x.tick(ms,paused)

    @rule()
    def snapshot(self): self.x=save_load(self.x)

    @invariant()
    def lifecycle_counts(self):
        assert self.x.total==1+3*self.dead_count+self.rest_count
        assert self.x.intruder==100000+self.dead_count
        assert self.x.attempts==self.attempts
        assert 0<=self.x.hp<=100 and 0<=self.x.sp<=100
        if self.x.phase=='alive': assert self.x.hp>0
        if self.x.progress==6 and self.x.place.startswith('S5'): assert self.x.economy.battle

TestLifecycleSequence=LifecycleSequence.TestCase
TestLifecycleSequence.settings=SEQ

class SpawnSequence(RuleBasedStateMachine):
    @initialize(kind=st.sampled_from(['ordinary','patient','s4','s5']),k=st.integers(1,1000))
    def begin(self,kind,k): self.s=Spawn(kind,k)

    @rule(roll=st.integers(0,9999))
    def initial(self,roll): self.s.check(roll,first=True)

    @rule()
    def leave(self): self.s.leave()

    @rule(ms=st.integers(0,25000),paused=st.booleans())
    def time(self,ms,paused):
        before=self.s.outside; self.s.tick(ms,paused)
        if paused: assert self.s.outside==before

    @rule(roll=st.integers(0,9999))
    def back(self,roll): self.s.check(roll)

    @rule(free=st.booleans())
    def enter(self,free): self.s.enter(free)

    @rule()
    def retire(self): self.s.retire()

    @rule()
    def snapshot(self): self.s=save_load(self.s)

    @rule()
    def restart(self): self.s.restart()

    @invariant()
    def caps(self):
        assert 0<=self.s.checks<=3
        assert self.s.state in ('unseen','pending','present','retired')
        assert probability(self.s.kind,self.s.k)<=75

TestSpawnSequence=SpawnSequence.TestCase
TestSpawnSequence.settings=SEQ
