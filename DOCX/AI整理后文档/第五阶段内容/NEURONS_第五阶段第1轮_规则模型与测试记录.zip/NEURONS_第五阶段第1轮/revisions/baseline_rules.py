"""NEURONS design model; not Unity code. Units: integer game milliseconds.

Source anchors refer to sources/stage*.txt. Callers must supply actual action
completion/contact; geometry, animation and AI route feasibility are not modeled.
"""
from dataclasses import dataclass, field
from copy import deepcopy

@dataclass
class Skill:
    cost: int
    power: int
    cooldown: int
    resistance: int = 0
    successes: int = 0
    pending: bool = False
    remaining: int = 0
    active: bool = False

@dataclass
class Economy:
    n: int = 5
    c: int = 3
    battle: bool = False
    phase: str = 'alive'
    paused: bool = False
    control: bool = False
    fraction: int = 0
    global_r: int = 0
    awakening: set = field(default_factory=set)
    pending_g: set = field(default_factory=set)
    paid: set = field(default_factory=set)
    skills: dict = field(default_factory=lambda: {'skin': Skill(1, 1, 2000)})

    def credit(self, token, n=0, c=0):
        # S4:T2, P11-15: explicit income, once per reward identity.
        if token in self.paid:
            return False
        assert n >= 0 and c >= 0
        self.paid.add(token)
        self.n += n
        self.c += c
        if self.n >= 5:
            self.fraction = 0
        return True

    def tick(self, ms):
        assert ms >= 0
        if self.paused or self.phase != 'alive':
            return
        for s in self.skills.values():
            s.remaining = max(0, s.remaining - ms)
        if not self.battle or self.control or self.n >= 5:
            return
        self.fraction += ms
        add = min(5-self.n, self.fraction//4000)
        self.n += add
        self.fraction -= add*4000
        if self.n >= 5:
            self.fraction = 0

    def cast(self, name='skin', valid=True, body_reacts=True):
        # Only economic commit + resistance + adaptation. No animation simulation.
        s = self.skills.get(name)
        if (not s or not valid or self.phase != 'alive' or self.control
                or s.remaining or s.active or self.n < s.cost):
            return 'invalid'
        self.n -= s.cost
        s.remaining = s.cooldown
        if s.power <= s.resistance + self.global_r:
            return 'resisted'
        if body_reacts and not s.pending:
            s.successes += 1
            if s.successes == 3:
                s.pending, s.successes = True, 0
        return 'reacted' if body_reacts else 'interrupted'

    def upgrade(self, name='skin'):
        if self.c < 1 or name not in self.skills or self.phase != 'alive':
            return False
        self.c -= 1
        self.skills[name].power += 1
        return True

    def convert(self):
        if self.n < 10 or self.phase != 'alive':
            return False
        self.n -= 10
        self.c += 1
        return True

    def all_blocked(self):
        return all(s.power <= s.resistance+self.global_r for s in self.skills.values())

    def reconnect(self):
        if not (self.battle and self.phase == 'alive' and self.all_blocked()
                and self.c == 0 and 5 <= self.n < 10):
            return False
        self.n -= 5
        s = self.skills['skin']
        s.power = s.resistance + self.global_r + 1
        return True

    def awaken(self, identity):
        if identity not in ('dog_killed_by_father', 'parent_collapse'):
            return False
        if identity in self.awakening:
            return False
        self.awakening.add(identity)
        self.pending_g.add(identity)
        return True

    def restart(self, death=True):
        self.n = max(5, self.n)
        self.fraction = 0
        self.phase = 'alive'
        self.control = False
        self.global_r += len(self.pending_g)
        self.pending_g.clear()
        for s in self.skills.values():
            s.resistance += int(s.pending)
            s.pending = False
            s.active = False
        # Partial successes and remaining cooldown persist: S2:P45, S4:P23.

SEARCH = {1:(11,10,10), 2:(32,12,12), 3:(45,14,14), 4:(62,16,16)}

@dataclass
class Search:
    level: int = 1
    key_point: int = 0
    attempt: int = 1
    used: int = 0
    sequence: int = 0
    pending: dict = field(default_factory=dict)
    complete: set = field(default_factory=set)
    dog_starts: int = 0
    key_owner: str = 'hidden'
    income: int = 0
    dropped_visible: bool = False

    def start(self, point, actor='avatar'):
        capacity, targets, budget = SEARCH[self.level]
        if self.key_owner == 'avatar' or point in self.complete or not 0 <= point < capacity:
            return None
        if any(a == actor or p == point for a,p in self.pending.values()):
            return None
        if actor == 'avatar':
            if self.level < 4 and self.used >= budget:
                return None
            self.used += 1
        elif actor == 'dog':
            if self.level != 1 or self.dog_starts >= 3 or self.used >= budget or self.key_owner != 'hidden':
                return None
            self.dog_starts += 1
        else:
            return None
        self.sequence += 1
        token = (self.attempt, self.sequence)
        self.pending[token] = (actor, point)
        return token

    def settle(self, token, result='complete'):
        if token not in self.pending:
            return False
        actor,point = self.pending.pop(token)
        if result == 'complete' and point not in self.complete:
            self.complete.add(point)
            self.income += 1
            if point == self.key_point and self.key_owner == 'hidden':
                self.key_owner = actor
        return True

    def deliver(self):
        if self.key_owner != 'dog':
            return False
        self.key_owner = 'avatar'
        return True

    def dog_leave(self):
        for token,(a,p) in list(self.pending.items()):
            if a == 'dog':
                self.settle(token, 'cancel')
        if self.key_owner == 'dog':
            self.key_owner = 'ground'

    def pickup(self):
        if self.key_owner == 'ground' and self.dropped_visible:
            self.key_owner = 'avatar'
            return True
        return False

    def action(self, sp=100, danger=False):
        if danger: return 'evade'
        if self.key_owner == 'avatar': return 'exit'
        if self.key_owner == 'ground' and self.dropped_visible: return 'pickup'
        if self.key_owner == 'dog' or any(a == 'dog' for a,p in self.pending.values()): return 'wait_current_dog'
        if self.level < 4 and (sp < 50 or self.used >= SEARCH[self.level][2]): return 'bed'
        return 'search'

    def restart(self, key_point):
        self.attempt += 1
        self.used = self.sequence = self.dog_starts = 0
        self.pending.clear()
        self.complete.clear()
        self.key_point = key_point
        self.key_owner = 'hidden'
        self.dropped_visible = False


@dataclass
class Life:
    progress: int = 1
    place: str = 'S1'
    total: int = 1
    attempts: dict = field(default_factory=lambda:{i:1 for i in range(1,7)})
    intruder: int = 100000
    epoch: int = 0
    hp: int = 100
    sp: int = 100
    phase: str = 'alive'
    emptied: bool = False
    stun: int = 0
    pending_exit: bool = False
    seen: set = field(default_factory=set)
    food: dict = field(default_factory=dict)
    economy: Economy = field(default_factory=Economy)
    s5_snapshot: dict = field(default_factory=lambda:{'nurse_used':False,'dead':set(),'props':set()})

    def frame(self, token, events):
        # Batch actual completions for a single verdict node, not callback order.
        if token[0] != self.epoch or token in self.seen or self.phase != 'alive':
            return 'ignored'
        self.seen.add(token)
        if any(k == 'collapse' for k,v in events):
            self.economy.awaken('parent_collapse')
            self.hp = self.sp = 0
            self.phase = self.economy.phase = 'dead'
            self.stun = 0
            return 'death'
        self.hp = max(0, self.hp - sum(v for k,v in events if k == 'hp_damage'))
        self.sp = max(0, self.sp - sum(v for k,v in events if k == 'sp_damage'))
        if self.hp == 0:
            self.phase = self.economy.phase = 'dead'
            self.stun = 0
            return 'death'
        hit_zero = self.sp == 0 and not self.emptied
        if hit_zero:
            self.emptied, self.stun = True, 1000
        for k,v in events:
            if k == 'heal_hp': self.hp = min(100, self.hp + v)
            if k == 'heal_sp': self.sp = min(100, self.sp + v)
            if k == 'food' and v in self.food:
                item = self.food.pop(v)
                if item == 'porridge':
                    self.sp = 100
                    self.economy.credit(('food',v),5,1)
                elif item == 'candy':
                    self.sp = min(100,self.sp+20)
                    self.economy.credit(('food',v),5,0)
                elif item == 'chocolate':
                    self.hp, self.sp = min(100,self.hp+15), min(100,self.sp+15)
                    self.economy.credit(('food',v),3,1)
        if self.sp >= 20: self.emptied = False
        if any(k == 'exit' and v for k,v in events):
            self.phase = self.economy.phase = 'transition'
            self.stun = 0
            return 'exit'
        return 'alive'

    def tick(self, ms, paused=False):
        self.economy.paused = paused
        self.economy.tick(ms)
        if self.phase == 'alive' and not paused:
            self.stun = max(0,self.stun-ms)

    def revive(self):
        if self.phase != 'dead': return False
        self.total += 3
        self.attempts[self.progress] += 1
        self.intruder += 1
        self.epoch += 1
        self.hp = self.sp = 100
        self.stun = 0
        self.emptied = False
        self.phase = 'alive'
        self.place = 'S5_atrium' if self.progress >= 5 else f'S{self.progress}_spawn'
        self.economy.restart()
        return True

    def rest(self):
        if not (self.phase == 'alive' and self.progress <= 3 and self.place != 'hiddenStreet'):
            return False
        # Caller supplies actual safe bed-rest completion, not merely reaching a bed.
        self.total += 1
        self.attempts[self.progress] += 1
        self.epoch += 1
        self.hp = self.sp = 100
        self.emptied = False
        self.stun = 0
        self.economy.restart(death=False)
        return True

    def finish_exit(self):
        if self.phase != 'transition': return False
        self.epoch += 1
        if self.place == 'hiddenStreet' or self.progress == 6 and self.place == 'S6':
            self.phase = self.economy.phase = 'ended'
            return 'E1' if self.place == 'hiddenStreet' else 'E2'
        if self.progress == 6: # S5 return path -> already registered S6 attempt.
            self.place = 'S6'
        else:
            self.progress += 1
            self.place = f'S{self.progress}'
            self.economy.credit(('unlock',self.progress),3,2)
        self.phase = self.economy.phase = 'alive'
        self.economy.battle = self.progress >= 5
        return True

    def enter_hidden(self):
        # Caller must supply actual father carry; no normal key gate modeled here.
        assert self.progress == 1
        self.place = 'hiddenStreet'
        self.epoch += 1
        self.economy.battle = True


def probability(kind, k):
    assert k >= 1
    base = {'ordinary':50,'patient':35,'s4':45,'s5':55}[kind]
    return base + 5*min(k-1,4)

@dataclass
class Spawn:
    kind: str = 'ordinary'
    k: int = 1
    checks: int = 0
    state: str = 'unseen'
    outside: int = 0
    away: bool = False

    def leave(self):
        if not self.away: self.outside = 0
        self.away = True

    def tick(self, ms, paused=False):
        if self.away and not paused: self.outside += ms

    def check(self, roll, first=False):
        assert 0 <= roll < 10000
        allowed = (first and self.checks == 0) or (not first and self.checks > 0 and self.away and self.outside >= 20000)
        p = probability(self.kind,self.k)* (100 if self.checks == 0 else 50)
        if not first: self.away = False
        if not allowed or self.state != 'unseen' or self.checks >= 3: return False
        self.checks += 1
        if roll < p: self.state = 'pending'
        return True

    def enter(self, free=True):
        if self.state == 'pending' and free: self.state = 'present'

    def retire(self):
        if self.state == 'present': self.state = 'retired'

    def restart(self):
        self.k += 1
        self.checks = self.outside = 0
        self.state = 'unseen'
        self.away = False


def search_ms(level, kind, k, sp):
    base = {1:4000,2:5000,3:6000,4:7000}[level]
    kind_pct = {'simple':80,'normal':100,'complex':120}[kind]
    practice = 100-5*min(k-1,4)
    return base*kind_pct*practice*(125 if sp<20 else 100)//1000000

def save_load(obj):
    """Exact snapshot abstraction; does not test Unity serialization or file I/O."""
    return deepcopy(obj)
