"""Reproduce the two real first-run failures in an isolated temporary folder."""
from pathlib import Path
import tempfile, shutil, subprocess, sys

root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='neurons_baseline_') as tmp:
    dst=Path(tmp)
    for name in ['rules.py','test_rules.py']:
        shutil.copy2(root/'revisions'/('baseline_'+name),dst/name)
    result=subprocess.run([sys.executable,'-m','pytest','-q','--hypothesis-seed=20261012',
        'test_rules.py::test_high_resistance_has_affordable_repair_path',
        'test_rules.py::test_death_keeps_progress_not_physical_map[1-hiddenStreet-S1_spawn]'],cwd=dst)
    raise SystemExit(result.returncode)
