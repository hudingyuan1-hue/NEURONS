from pathlib import Path
import json

root = Path(__file__).resolve().parent
s = json.loads((root / 'results/SUMMARY.json').read_text())
counts = '\n'.join(f"- {file}：{count}项。" for file, count in s['by_file'].items())
body = f'''NEURONS｜第五阶段第15轮：掌控操作、实际抽样与人物概率

结论
本轮{s['unique_latest_tests']}个唯一测试项的最新执行结果全部通过；4项属性/状态测试共{s['hypothesis_passing_latest']}个通过样本。
第五阶段尚未完成。本轮是Python规则模型与已有宿主的接入验证，未运行或修改Unity工程。

一、本轮完成
1. 第二至四关补齐掌控独立转向、食品实际食用、自主行动及第四面墙试探入口。继续使用同一宿主Life、Search和经济对象。
2. 食品需真实完成；暂停、吞服前打断、非致命伤与已完成食用同节点、致命伤、重复回调分别判定。食用不返搜寻次数、不替代挣脱，不产生虚构识破证据。
3. 自主行动、搜寻、食用、交接与掌控接管互斥；真实完成后释放占用。第二关保留原自主动作身份，第四关不覆盖原宿主action方法。
4. 第一至四关接真实候选点、目标组与钥匙抽样；第三关只在二层搜寻，第四关每层8个初始目标。公开选点接口不读取隐藏钥匙。
5. 同一实际尝试内换房、取消、再次同步不重抽；实际休息/死亡重启后绑定新尝试，不替换Search，不删除进行中动作。猫占位与钥匙位置分别抽取。
6. 第一关接猫狗独立概率、父母第2/4/6/8次角色搜寻后的检查与排队；实际进入才产生碰面，礼物实际放置时一次抽定。死亡总周目+3不误增3次本关概率。
7. 第二至五关前两层建立有限人物调度：首次及两次合法重返检查、离房20秒、后续半概率、同房新增批次10秒、联动组共享检查、成员独立满足出场条件、同身份不复制。
8. 第五关第三层与Street明确走既有特殊流程；普通概率调度不接管本身人格必现与Street全员名单。
9. 第一至四关实际随机配置接公开选点与宿主搜寻，固定种子走真实房间邻接回调，验证到取得钥匙。该基线不等于完整通关或真实寻路。

二、真实失败与修订
- 交接入口未排除食用/自主行动并发：2项首败；补互斥后仅复测2项。
- 已完成食用与同节点非致命伤被误当成吞服前打断：3项首败；分清动作完成边界，38项受影响食品测试通过。
- 第四关初始目标暂时均受阻时，公开选点未提供其他合法补查点：1项首败；修正补查，不删除受阻原目标、不重抽钥匙。
- 新尝试的宿主绑定接口尚未提供：6项新增用例首败；补齐绑定，与补查合并窄复测18项。此项是接入缺口，不算6个独立游戏机制错误。
- 本轮人物调度草稿11个身份键与已有跨关身份总账不一致：5项首败；统一身份键，只复测17项相关登记、联动与映射用例。
上述缺陷属于本轮新增规则模型和接入实现，不能反推Unity工程也有相同缺陷。
集成验证的执行及发现另见 integration_notes.txt；完整失败保存在results/FAILURE_HISTORY.json，修前代码在snapshots/。

三、统计口径
{counts}
最新结果按pytest nodeid去重；不累加窄复测，不把前14轮用例算入本轮。
Hypothesis：掌控操作180、钥匙/目标200、人物调度200、第一关专属概率160，共740个通过样本；另49个无效生成被丢弃，未计为通过。
固定seed：2026101316；Python3.12.14；pytest9.1.1；Hypothesis6.169.0。
另做4关各12,000份固定种子抽样，共48,000份配置；钥匙位置及序位统计在results/sampling_frequency.json。这是有限频数诊断，不是均匀性证明。
第一关猫狗首轮/封顶轮各100×100显式联合格共20,000组，包含在对应2个pytest测试内；不混入Hypothesis数量。
50份继承模块SHA256全部保持不变；原依据指纹见sources/manifest.json。

四、依据与未覆盖
来源仍是此前四阶段合并修订文档，提取文本位于sources/stage1.txt至stage4.txt。主要依据为S2:P25—36/T14/T15，S4:P49—66/P94—141/P161/P264/P273/P276；各模块notes列出细项。
没有改原对白、人物关系、技能费用、概率表、资源数值或关卡结构。
实际接触、可见性、入口是否空闲、吞服完成、转向完成及可通行路线由外部真实事实输入；没有模拟动画、碰撞体、视野、物理移动速度。
有限概率模块目前与跨关身份总账对齐，尚未逐一接入所有NPC宿主行为与联动事件。不能从“抽中待登场”推导“事件必定完成”。
snapshot/deepcopy仅验证内存续接，不代表真实磁盘序列化、保存文件兼容或崩溃恢复。
随机寻钥匙基线未覆盖全部人物干扰、资源不足、高抗性和低精神组合到最终结局；这些归后续整合验证。
无限周目不能穷举；规则模拟不等于实机验收。

五、剩余3组，预计3—4轮
D剩余：人物概率调度逐一接入实际NPC宿主条件，验证同关关键周目的刷新、人物互斥与连锁结果。
E：真实序列化/恢复、旧事件与旧动作回调去重、跨尝试交接、第六关死亡返回第五关后的状态继承。
F：资源不足、低精神、高抗性、关键人物缺席的完整路线及结局；失败后仅复测受影响分支。
下一轮仍为第五阶段，先收完D的宿主连接，再进入E。预计轮次以现有未覆盖项为依据；新增反例单独列入，不提前宣告完成。

六、复现与证据
安装：python -m pip install -r requirements.txt
执行：python reproduce.py
输出进入新的reproduction/时间戳目录，不覆盖本轮首败和复测证据。
定向执行示例：python -m pytest test_exploration_operations.py -q --hypothesis-seed=2026101316
原始执行结果：results/*.json及同名.log；统计：results/SUMMARY.json。
快照包含该时点测试及被改模块；复现首败时复制整个包到临时目录，再以指定snapshots子目录文件覆盖同名文件，运行对应失败nodeid，不要直接覆盖交付版本。
Hypothesis官方状态机文档：https://hypothesis.readthedocs.io/en/latest/stateful.html

自省：只做既有规则建模、接入、测试及修复；未新增剧情、未改原对白与数值，未冒充Unity验收。
'''
(root / 'README.txt').write_text(body, encoding='utf-8')
continue_text = f'''继续NEURONS第五阶段。第15轮最新{s['unique_latest_tests']}个唯一测试通过、740个通过Hypothesis样本；不是Unity实机验收。
先读README.txt、results/SUMMARY.json与CONTINUE.txt，不重新整轮跑旧测试。

新增：exploration_operations.py、search_sampling.py、spawn_schedule.py、family_random.py；5个test文件，notes详述API。50份继承模块未改，指纹在inherited_integrity.json。
已完成C余项；D完成实际目标/钥匙抽样、第一关专属人物抽签、第二至五关有限调度和身份映射，以及随机配置至取得钥匙的基线接通。
下一轮只接D剩余NPC宿主联动，不重写概率表或造人物。之后E真实序列化及S6→S5，再F不利配置完整流程。剩3组估3—4轮。

接口注意：
1 ExplorationOperations(adapter)复用原宿主。complete_food interrupted_before_swallow=True仅表示吞服前实际中断；同节点已完成食用与非致命伤分别结算，致命伤优先。
2 掌控转向需要实际方向回调；自主试探只有真实正常自主行动完成才解除限制，不能由提交输入推断完成。
3 AttemptSampler.bind_restarted_host必须在宿主实际重启后调用；同尝试重复绑定不删除pending。公开next_point不接收key_point。
4 SpawnSchedule enter实际入房、materialize传实际eligible集合、retire实际退场；联动组抽中不等于所有成员同步出现或效果自动发生。
5 SpawnSchedule与全部NPC宿主还未接完，restart只接受外部真实尝试事件；需接Life实际事件去重，避免重复死亡回调重抽。
6 第五关第三层100%本身人格、第六关45身份不是普通概率池；Street返程不调用普通restart，应恢复既有第五关退出状态。
7 deepcopy/snapshot不是持久化。真正存读档必须另测事件身份、generation、随机状态和未完成动作。
8 FamilyRandom人物随机域独立；狗行动不计父母检查节点，选中排队不等于实际碰面；初始猫占位与钥匙位置分别抽取。

本轮17个已保存首败含6个新增接口未实现用例，不能全称游戏机制缺陷；其他新增集成执行见integration_notes.txt。修后仅复测受影响部分。
用户要求极简结论、实际可复现证据、每轮自省和剩余轮次；原对白与数值不擅改。
'''
(root / 'CONTINUE.txt').write_text(continue_text, encoding='utf-8')
