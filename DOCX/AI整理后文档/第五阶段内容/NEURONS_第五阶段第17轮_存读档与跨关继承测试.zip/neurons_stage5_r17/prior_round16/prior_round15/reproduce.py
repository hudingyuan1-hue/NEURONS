"""Run this round in a new evidence directory; do not overwrite original runs."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
out = root / 'reproduction' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
out.mkdir(parents=True)
for path in root.glob('*.py'):
    shutil.copy2(path, out / path.name)
shutil.copytree(root / 'sources', out / 'sources')
shutil.copy2(root / 'requirements.txt', out / 'requirements.txt')
env = dict(os.environ, RUN_REPORT=str(out / 'run.json'))
tests = sorted(p.name for p in root.glob('test_*.py'))
command = [sys.executable, '-m', 'pytest', *tests, '-q',
           '--hypothesis-seed=2026101316', '--hypothesis-show-statistics']
result = subprocess.run(command, cwd=out, env=env, capture_output=True, text=True)
(out / 'run.log').write_text(result.stdout + result.stderr, encoding='utf-8')
(out / 'command.json').write_text(json.dumps(command, ensure_ascii=False, indent=2), encoding='utf-8')
print(result.stdout)
if result.stderr:
    print(result.stderr, file=sys.stderr)
print('Evidence:', out)
raise SystemExit(result.returncode)
