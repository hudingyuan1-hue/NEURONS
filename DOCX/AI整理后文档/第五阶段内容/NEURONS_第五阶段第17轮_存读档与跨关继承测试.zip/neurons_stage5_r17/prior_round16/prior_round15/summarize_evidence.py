"""Merge actual execution evidence; no test execution or expected-result fabrication."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
result_dir = root / 'results'
latest = {}
failures = []
runs = []
props = {}
for path in sorted(result_dir.glob('*.json'), key=lambda p: (p.stat().st_mtime_ns, p.name)):
    if path.name in ('SUMMARY.json', 'FAILURE_HISTORY.json'):
        continue
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or 'tests' not in data:
        continue
    counts = Counter(t['outcome'] for t in data['tests'])
    runs.append({'report': path.name, 'exitstatus': data['exitstatus'], 'outcomes': dict(counts)})
    for row in data['tests']:
        item = dict(row, report=path.name)
        latest[row['test']] = item
        if row['outcome'] == 'failed':
            failures.append(item)
    log = path.with_suffix('.log')
    if log.exists():
        body = log.read_text(encoding='utf-8')
        for match in re.finditer(r'^(test_[^\n]+):\n(.*?)(?=^test_|\Z)', body, re.M | re.S):
            stat = re.search(r'(\d+) passing, (\d+) failing, and (\d+) invalid test cases', match[2])
            if stat:
                props[match[1]] = dict(zip(('passing', 'failing', 'invalid'), map(int, stat.groups())))
                props[match[1]]['report'] = path.name
inherited = json.loads((root / 'inherited_integrity.json').read_text())['files']
changed = [r['file'] for r in inherited if hashlib.sha256((root / r['file']).read_bytes()).hexdigest() != r['sha256']]
summary = {
    'round': 15, 'phase': 5, 'seed': 2026101316,
    'runs': runs,
    'unique_latest_tests': len(latest),
    'unique_latest_outcomes': dict(Counter(r['outcome'] for r in latest.values())),
    'by_file': dict(Counter(t.split('::')[0] for t in latest)),
    'properties_latest': props,
    'hypothesis_passing_latest': sum(p['passing'] for p in props.values()),
    'hypothesis_invalid_latest': sum(p['invalid'] for p in props.values()),
    'initial_failure_observations': len(failures),
    'inherited_files': len(inherited), 'inherited_files_changed': changed,
    'latest_tests': list(latest.values()),
    'limits': ['Only round 15 tests; previous rounds not rerun or counted.',
               'Callbacks supply actual movement/contact facts; no Unity validation.',
               'Finite generated examples; not exhaustive over infinite attempts.']
}
(result_dir / 'SUMMARY.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
(result_dir / 'FAILURE_HISTORY.json').write_text(json.dumps(failures, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('latest_tests','runs','properties_latest','limits')}, ensure_ascii=False, indent=2))
