import math
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from exploration_operations import ExplorationOperations
from s2_skill_adapter import S2SkillAdapter
from s3_skill_adapter import S3SkillAdapter
from s4_skill_adapter import S4SkillAdapter
from player_skills import CATALOG
from rules import Skill


def make(level):
    op = ExplorationOperations({2:S2SkillAdapter,3:S3SkillAdapter,4:S4SkillAdapter}[level]())
    op.life.economy.n = 100
    for name,spec in CATALOG.items():
        op.life.economy.skills[name] = Skill(spec.cost,spec.power,spec.cooldown)
    return op


def cast(op, name, **facts):
    result = op.submit(name)
    assert result is not None
    assert op.react(result['id'], **facts)
    return result['id']


def move_facts(level):
    return {'room':'exam'} if level == 2 else {'dest':(1,'ward') if level == 3 else 'memory'}


def destination(level):
    return move_facts(level).get('room',move_facts(level).get('dest'))


def observe(op, target='table', probe=False, **kw):
    identity = op.begin_autonomous('interact', target, probe=probe, **kw)
    assert identity is not None
    return identity


def finish_observe(op, identity, target='table'):
    return op.complete_autonomous(identity, action='observe', target=target,
                                  actual_contact=True, same_room=True, reachable=True)


def attain_awareness(op):
    for i,name in enumerate(('skin','skin','pores')):
        identity = observe(op, str(i))
        cast(op,name)
        op.tick(2000)
        assert finish_observe(op,identity,str(i))
    assert op.awareness.stage == 2


@pytest.mark.parametrize('level',[2,3,4])
@pytest.mark.parametrize('kind,sp,hp,n,c',[
    ('porridge',100,40,5,1),('candy',60,40,5,0),('chocolate',55,55,3,1)])
def test_food_exact_duration_and_unique_effects(level,kind,sp,hp,n,c):
    op=make(level);op.life.sp=op.life.hp=40;op.life.food['item']=kind;op._sync()
    before=(op.life.economy.n,op.life.economy.c,op.search.used)
    action=op.begin_food('item');assert action
    op.tick(1499);assert not op.complete_food(action)
    assert 'item' in op.life.food
    op.tick(1);assert op.complete_food(action)
    assert (op.life.sp,op.life.hp)==(sp,hp)
    assert (op.life.economy.n-before[0],op.life.economy.c-before[1])==(n,c)
    assert op.search.used==before[2]
    assert not op.complete_food(action)


@pytest.mark.parametrize('level',[2,3,4])
def test_full_health_manual_food_and_fourthwall_restriction(level):
    op=make(level);op.awareness.restriction=True;op.life.food['item']='chocolate'
    start=op.life.economy.n
    action=op.begin_food('item');op.tick(1500)
    assert op.complete_food(action)
    assert op.life.hp==op.life.sp==100 and op.life.economy.n==start+3
    assert op.awareness.restriction


@pytest.mark.parametrize('level',[2,3,4])
@pytest.mark.parametrize('block',['pause','loading','stun'])
def test_food_pause_or_body_limit(level,block):
    op=make(level);op.life.food['x']='candy';action=op.begin_food('x');op.tick(700)
    if block=='pause':op.set_pause(True)
    elif block=='loading':op.set_pause(False,loading=True)
    else:op.life.stun=500
    op.tick(1000)
    assert not op.complete_food(action)
    assert 'x' in op.life.food
    if block!='stun':
        op.set_pause(False);op.tick(800);assert op.complete_food(action)
    else:assert op.food_action is None


@pytest.mark.parametrize('level',[2,3,4])
def test_damage_at_food_completion_fatal_wins(level):
    op=make(level);op.life.hp=10;op.life.food['x']='chocolate';op._sync()
    action=op.begin_food('x');op.tick(1500)
    assert not op.complete_food(action,hp_damage=10)
    assert op.life.phase=='dead' and 'x' in op.life.food
    assert not op.complete_food(action)


@pytest.mark.parametrize('level',[2,3,4])
def test_auto_food_priority_and_interruption_requires_next_real_action(level):
    op=make(level);op.life.hp=op.life.sp=40;op._sync()
    op.life.food.update(p='porridge',c='candy',h='chocolate')
    assert op.automatic_food()=='h'
    action=op.begin_food(automatic=True);assert action
    op.tick(1500);assert not op.complete_food(action,hp_damage=1)
    op.tick(1000)
    assert op.begin_food(automatic=True) is None
    action=observe(op);assert finish_observe(op,action)
    assert op.begin_food(automatic=True)


@pytest.mark.parametrize('level',[2,3,4])
def test_manual_and_auto_never_consume_same_food_twice(level):
    op=make(level);op.life.sp=40;op._sync();op.life.food['x']='porridge'
    action=op.begin_food(automatic=True)
    assert op.begin_food('x') is None
    op.tick(1500);assert op.complete_food(action)
    assert op.begin_food('x') is None


@pytest.mark.parametrize('level',[2,3,4])
def test_turn_real_completion_no_move_no_evidence_no_added_cost(level):
    op=make(level);attain_awareness(op);op.tick(3000)
    cast(op,'control');before=op.life.economy.n;position=op.adapter.position
    cmd=op.command('turn',action='turn',facing=(1,0));assert cmd
    assert not op.control_action(cmd['id'],actual=False)
    assert not op.control_action(cmd['id'],actual_facing=(0,1))
    assert op.control_action(cmd['id'],actual_facing=(1,0))
    assert op.facing==(1,0) and op.adapter.position==position
    assert op.life.economy.n==before and op.awareness.stage==2
    assert not op.control_action(cmd['id'])
    assert op.command('kick',distance=.5) is None


@pytest.mark.parametrize('facing',[(0,0),(math.nan,1),(math.inf,0),None,'left',(True,0),(1,)])
def test_bad_turn_has_no_command_or_cost(facing):
    op=make(4);cast(op,'control');balance=op.life.economy.n
    assert op.command('turn',action='turn',facing=facing) is None
    assert op.life.economy.n==balance and not op.commands


@pytest.mark.parametrize('level',[2,3,4])
def test_turn_pending_paused_grabbed_expired(level):
    op=make(level);cast(op,'control');cmd=op.command('turn',action='turn',facing=(1,0))
    op.set_pause(True);assert not op.control_action(cmd['id']);op.tick(5000)
    assert op.book.control_remaining==6000
    op.set_pause(False);op.life.stun=1000;assert not op.control_action(cmd['id'])
    op.tick(6000);assert not op.control_action(cmd['id'])


@pytest.mark.parametrize('level',[2,3,4])
def test_real_probe_changes_intent_and_following_action_clears_restriction(level):
    op=make(level);attain_awareness(op)
    identity=observe(op,probe=True)
    assert op.awareness.probe and op.awareness.probe['action_id']==identity
    cast(op,'skin',changes_intent=True)
    op.tick(500)
    assert not op.complete_autonomous(identity,actual=False)
    assert finish_observe(op,identity)
    assert op.awareness.stage==3 and op.awareness.restriction
    follow=observe(op,'next');assert finish_observe(op,follow,'next')
    assert not op.awareness.restriction


@pytest.mark.parametrize('level',[2,3,4])
def test_safe_move_probe_uses_host_route_no_teleport(level):
    op=make(level);attain_awareness(op)
    action=op.begin_autonomous('move',destination(level),probe=True)
    before=op.adapter.position
    assert not op.complete_autonomous(action,**move_facts(level))
    assert op.adapter.position==before
    cast(op,'skin',changes_intent=True);op.tick(500)
    assert op.complete_autonomous(action,**move_facts(level),actual_crossing=True,route_clear=True)
    assert op.adapter.position==destination(level) and op.awareness.stage==3


@pytest.mark.parametrize('level',[2,3,4])
def test_probe_no_intervention_or_environment_damage_not_identification(level):
    op=make(level);attain_awareness(op);action=observe(op,probe=True)
    op.adapter.vitals(op.token('environment'),sp_damage=1);op._sync()
    assert finish_observe(op,action)
    assert op.awareness.stage==2
    second=observe(op,'second',probe=True)
    assert op.awareness.probe is None
    assert finish_observe(op,second,'second')


@pytest.mark.parametrize('level',[2,3,4])
def test_control_interrupts_existing_autonomous_probe(level):
    op=make(level);attain_awareness(op);op.tick(3000)
    action=observe(op,probe=True)
    cast(op,'control')
    assert op.autonomous is None and op.awareness.probe is None
    assert not finish_observe(op,action)
    assert op.awareness.stage==2
    assert op.begin_autonomous('interact','x',probe=True) is None


@pytest.mark.parametrize('level',[2,3,4])
def test_probe_action_epoch_and_food_boundary_not_replayed(level):
    op=make(level);op.life.food['x']='candy'
    action=op.begin_food('x');op.tick(1500)
    op.life.frame(op.token('fatal'),[('hp_damage',100)]);op._sync()
    assert not op.complete_food(action) and 'x' in op.life.food
    assert op.life.revive();op._sync()
    assert not op.complete_food(action)


class FoodOperationsMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.op=make(4)
        self.op.life.hp=self.op.life.sp=40;self.op._sync()
        self.initial={f'{kind}-{i}':kind for i in range(2) for kind in ('porridge','candy','chocolate')}
        self.op.life.food.update(self.initial)
        self.n,self.c=self.op.life.economy.n,self.op.life.economy.c
        self.action=None

    @rule(index=st.integers(0,5),automatic=st.booleans(),safe=st.booleans())
    def begin(self,index,automatic,safe):
        result=self.op.begin_food(list(self.initial)[index],automatic=automatic,safe=safe)
        if result:self.action=result

    @rule(ms=st.sampled_from([0,1,499,500,1000,1499,1500,3000]))
    def tick(self,ms):self.op.tick(ms)

    @rule(paused=st.booleans())
    def pause(self,paused):self.op.set_pause(paused)

    @rule(actual=st.booleans())
    def finish(self,actual):
        if self.action:self.op.complete_food(self.action,actual=actual)

    @rule()
    def damage(self):
        if not self.op.paused:
            self.op.adapter.vitals(self.op.token('damage'),hp_damage=1);self.op._sync()

    @rule()
    def normal_action(self):
        identity=self.op.begin_autonomous('interact','table')
        if identity:finish_observe(self.op,identity)

    @invariant()
    def each_actual_food_consumed_and_paid_once(self):
        consumed=set(self.initial)-set(self.op.life.food)
        expected_n=sum(3 if self.initial[k]=='chocolate' else 5 for k in consumed)
        expected_c=sum(self.initial[k]!='candy' for k in consumed)
        assert self.op.life.economy.n-self.n==expected_n
        assert self.op.life.economy.c-self.c==expected_c
        assert 0<=self.op.life.hp<=100 and 0<=self.op.life.sp<=100


TestFoodOperations=FoodOperationsMachine.TestCase
TestFoodOperations.settings=settings(max_examples=180,stateful_step_count=35,deadline=None,database=None)
