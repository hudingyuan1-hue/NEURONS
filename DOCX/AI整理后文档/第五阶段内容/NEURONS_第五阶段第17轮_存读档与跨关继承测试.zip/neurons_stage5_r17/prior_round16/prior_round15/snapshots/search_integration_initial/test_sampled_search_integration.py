"""Actual model composition; path edges and completed motion are fixture facts.
No hidden-key coordinates are supplied to target selection or route choice.
"""
from collections import deque
from copy import deepcopy
import json
from pathlib import Path
import pytest

from exploration_operations import ExplorationOperations
from rules import search_ms
from search_sampling import CONFIG, build_host, next_point
from s2_skill_adapter import S2SkillAdapter
from s3_skill_adapter import S3SkillAdapter
from s4_skill_adapter import S4SkillAdapter

SEEDS = (0, 1, 2, 7, 17, 31, 97, 2026101316)


def graph_for(level):
    if level == 1:
        return set()
    if level == 2:
        return {frozenset(('waiting', room)) for room in ('ward', 'exam', 'pharmacy', 'office')}
    if level == 3:
        from s3_session import EDGES
    else:
        from s4_session import EDGES
    return EDGES


def current_room(level, host):
    return 'bedroom' if level == 1 else host.room if level == 2 else host.position


def distances_and_paths(origin, edges):
    distances, paths, queue = {origin: 0}, {origin: []}, deque([origin])
    while queue:
        current = queue.popleft()
        for edge in sorted(edges, key=lambda e: sorted(map(str, e))):
            if current not in edge:
                continue
            neighbor = next(iter(edge - {current}))
            if neighbor not in distances:
                distances[neighbor] = distances[current] + 1
                paths[neighbor] = paths[current] + [neighbor]
                queue.append(neighbor)
    return distances, paths


def configure(level, seed):
    host, sampler = build_host(level, seed)
    if level == 1:
        op = None
    else:
        if level == 2:
            host.people.patient_present = host.people.assistant_present = host.people.guard_present = False
            host.hospital.nurse_present = False
        else:
            host.actors = dict.fromkeys(host.actors)
        op = ExplorationOperations({2: S2SkillAdapter, 3: S3SkillAdapter, 4: S4SkillAdapter}[level](host))
    return host, sampler, op


def go_to(level, host, op, destination, edges, trace):
    origin = current_room(level, host)
    _, paths = distances_and_paths(origin, edges)
    assert destination in paths
    for step in paths[destination]:
        previous = current_room(level, host)
        identity = op.begin_autonomous('move', step)
        assert identity is not None
        facts = {'room': step} if level == 2 else {'dest': step}
        assert not op.complete_autonomous(identity, actual=False, actual_crossing=True, route_clear=True, **facts)
        assert current_room(level, host) == previous
        assert op.complete_autonomous(identity, actual_crossing=True, route_clear=True, **facts)
        assert frozenset((previous, current_room(level, host))) in edges
        trace.append(('move', previous, current_room(level, host)))


def search_one(level, host, sampler, op, plan, point, trace):
    prior_income, prior_n = host.search.income, host.life.economy.n
    identity = host.start_search(point) if level == 1 else op.start_search(point)
    assert identity is not None
    pending = deepcopy(host.search.pending)
    assert sampler.sync(host.life) is plan
    assert sampler.bind_restarted_host(host) is plan
    assert host.search.pending == pending and sampler.draws == 1
    if level == 1:
        assert host.settle(identity)
        assert not host.settle(identity)
    else:
        duration = search_ms(level, 'normal', host.life.attempts[level], host.life.sp)
        assert op.tick(duration - 1)
        assert not op.complete_search(identity)
        assert host.search.income == prior_income
        assert op.tick(1)
        assert op.complete_search(identity)
        assert not op.complete_search(identity)
        assert host.finish_feedback(op.token('feedback_finished'))
    assert host.search.income == prior_income + 1
    assert host.life.economy.n == prior_n + 1
    trace.append(('complete', point))


def run_search(level, seed, cancel_first=False):
    host, sampler, op = configure(level, seed)
    plan = sampler.sync(host.life)
    edges = graph_for(level)
    initial_n = host.life.economy.n
    trace, chosen = [], []
    cancelled, skill_cost = False, 0
    limit = CONFIG[level][1] + (int(cancel_first) if level == 4 else 0)
    while host.search.key_owner != 'avatar' and host.search.used < limit:
        room = current_room(level, host)
        distances, _ = distances_and_paths(room, edges)
        point = next_point(plan, room=room, distances=distances, completed=host.search.complete,
                           pending=[p for actor, p in host.search.pending.values()],
                           key_acquired=host.search.key_owner == 'avatar')
        assert point is not None and point in plan.targets
        go_to(level, host, op, plan.room_for(point), edges, trace)
        if cancel_first and not cancelled:
            identity = host.start_search(point) if level == 1 else op.start_search(point)
            assert identity is not None
            pending = deepcopy(host.search.pending)
            assert sampler.bind_restarted_host(host) is plan
            assert host.search.pending == pending
            before_n = host.life.economy.n
            if level == 1:
                assert host.settle(identity, complete=False)
            else:
                cast = op.submit('skin')
                assert cast and op.react(cast['id'])
                skill_cost = before_n - host.life.economy.n
                assert skill_cost == 1
                assert op.tick(500)
            assert identity not in host.search.pending and point not in host.search.complete
            assert host.search.income == 0
            assert host.life.economy.n == before_n - skill_cost
            assert sampler.sync(host.life) is plan and sampler.draws == 1
            cancelled = True
            trace.append(('cancel', point))
            continue
        chosen.append(point)
        search_one(level, host, sampler, op, plan, point, trace)
    assert len(chosen) == len(set(chosen)) == len(host.search.complete)
    assert host.search.income == len(chosen)
    assert host.life.economy.n == initial_n + len(chosen) - skill_cost
    assert sampler.draws == 1
    if not cancel_first or level == 4:
        assert host.search.key_owner == 'avatar'
    elif host.search.key_owner != 'avatar':
        assert host.search.used == CONFIG[level][1]
        assert (host.search.action() if level == 1 else host.decision()) == 'bed'
    if host.search.key_owner == 'avatar':
        assert next_point(plan, room=current_room(level, host), distances={},
                          completed=host.search.complete, key_acquired=True) is None
    # This trace records observed completions only. Hidden key is not consulted.
    record = {'level': level, 'seed': seed, 'cancel_first': cancel_first, 'used': host.search.used,
              'completed_count': len(chosen), 'key_acquired': host.search.key_owner == 'avatar',
              'income': host.search.income, 'trace': trace,
              'scope': 'rules model; actual movement/crossing supplied facts, not Unity navigation'}
    dest = Path('results') / f'search_integration_S{level}_{seed}_{int(cancel_first)}.json'
    dest.write_text(json.dumps(record, ensure_ascii=False, indent=2))


@pytest.mark.parametrize('level', range(1, 5))
@pytest.mark.parametrize('seed', SEEDS)
def test_sampled_targets_complete_through_real_room_graph(level, seed):
    run_search(level, seed)


@pytest.mark.parametrize('level', range(1, 5))
@pytest.mark.parametrize('seed', (0, 17))
def test_actual_cancel_consumes_opportunity_without_redraw_or_reward(level, seed):
    run_search(level, seed, cancel_first=True)
