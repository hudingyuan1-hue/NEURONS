"""R15 actual-attempt sampling; S1:T1/P18/P32/P94 and S4:P49-62/P153.

PublicPlan contains no secret key data. next_point accepts only public state.
Placement is a separate engine/test interface. Geometry is supplied by callers.
No spawn-frequency rules, story data, or new search budget is introduced.
"""
from dataclasses import dataclass
import random
from rules import Life, Search

CONFIG = {1: (11, 10), 2: (32, 12), 3: (45, 14), 4: (62, 16)}


def room_map(level):
    if level == 1:
        return tuple('bedroom' for _ in range(11))
    if level == 2:
        return tuple(r for r, n in (('waiting', 6), ('exam', 8),
                                     ('pharmacy', 7), ('office', 11)) for _ in range(n))
    if level == 3:
        from s3_session import POINT_ROOMS
        return tuple((2, r) for r in POINT_ROOMS)
    if level == 4:
        from s4_session import POINT_ROOMS
        return POINT_ROOMS
    raise ValueError('only S1-S4 contain search points')


@dataclass(frozen=True)
class PublicPlan:
    level: int
    attempt: int
    candidates: tuple
    targets: tuple
    rooms: tuple

    def room_for(self, point):
        if type(point) is not int or point not in self.candidates:
            raise ValueError('not a legal candidate')
        return self.rooms[point]


@dataclass(frozen=True)
class Placement:
    key_point: int
    cat_point: int | None


class AttemptSampler:
    def __init__(self, seed):
        if type(seed) is not int:
            raise TypeError('integer seed required')
        self.seed = seed
        self._plans = {}
        self._placements = {}
        self.draws = 0

    def _rng(self, level, attempt, domain):
        # Separate domains prevent cat/spawn draws perturbing target/key draws.
        return random.Random(f'NEURONS-R15:{self.seed}:{level}:{attempt}:{domain}')

    def sync(self, life, *, eligible=None, cat_present=False):
        level = life.progress
        if level not in CONFIG or life.phase != 'alive' or life.place == 'hiddenStreet':
            raise ValueError('actual living S1-S4 attempt required')
        attempt = life.attempts[level]
        if type(attempt) is not int or attempt < 1:
            raise ValueError('positive actual attempt required')
        previous = self._plans.get(level)
        if previous and previous.attempt == attempt:
            # Movement, cancellation, save restoration and supplementary checks
            # are not new attempts, regardless of total cycle / actor presence.
            return previous
        if previous and attempt != previous.attempt + 1:
            raise ValueError('actual attempts advance once; no rollback or jump')
        capacity, count = CONFIG[level]
        candidates = tuple(range(capacity)) if eligible is None else tuple(eligible)
        if (len(set(candidates)) != len(candidates)
                or any(type(p) is not int or not 0 <= p < capacity for p in candidates)):
            raise ValueError('eligible points must be unique legal point identities')
        candidates = tuple(sorted(candidates))
        rng = self._rng(level, attempt, 'targets')
        if level == 4:
            floors = [tuple(p for p in candidates if p < 31),
                      tuple(p for p in candidates if p >= 31)]
            if any(len(f) < 8 for f in floors):
                raise ValueError('insufficient reachable S4 points on a floor')
            targets = tuple(rng.sample(floors[0], 8) + rng.sample(floors[1], 8))
        else:
            if len(candidates) < count:
                raise ValueError('insufficient reachable points; do not shrink budget')
            targets = tuple(rng.sample(candidates, count))
        key_point = self._rng(level, attempt, 'key').choice(targets)
        cat_point = (self._rng(level, attempt, 'cat').choice(candidates)
                     if level == 1 and cat_present else None)
        plan = PublicPlan(level, attempt, candidates, targets, room_map(level))
        self._plans[level] = plan
        self._placements[level] = Placement(key_point, cat_point)
        self.draws += 1
        return plan

    def placement(self, level):
        return self._placements[level]

    def new_search(self, level):
        plan = self._plans[level]
        return Search(level=level, attempt=plan.attempt,
                      key_point=self._placements[level].key_point)


def next_point(plan, *, room, distances, completed=(), pending=(), blocked=(),
               key_acquired=False):
    """Nearest currently reachable unfinished target; no hidden-key argument.

    Callers provide actual graph distances / observed blockers. S4 may use all
    remaining legal candidates after its initial targets have been completed.
    Temporarily blocked targets do not count as completed initial targets.
    """
    if key_acquired:
        return None
    complete = set(completed)
    denied = complete | set(pending) | set(blocked)
    pool = plan.targets
    if plan.level == 4 and set(plan.targets) <= complete:
        pool = plan.candidates
    available = [p for p in pool if p not in denied
                 and (plan.rooms[p] == room or distances.get(plan.rooms[p]) is not None)]
    return min(available, key=lambda p: (0 if plan.rooms[p] == room else distances[plan.rooms[p]], p),
               default=None)


def build_host(level, seed, *, host_cls=None, life=None, cat_present=False):
    """Fresh host with sampled targets/key; no existing action is overwritten.

    Returning sampler separately makes lifecycle integration explicit. Native
    rest/revive must finish before sync(life) and installation of new_search().
    """
    if level not in CONFIG:
        raise ValueError('only S1-S4 contain search points')
    life = life if life is not None else Life(progress=level, place=f'S{level}')
    if life.progress != level:
        raise ValueError('host level differs from actual progress')
    sampler = AttemptSampler(seed)
    plan = sampler.sync(life, cat_present=cat_present)
    placement = sampler.placement(level)
    if level == 1:
        from family import Family
        host = (host_cls or Family)(life=life, search=sampler.new_search(level),
                                   cat='occupying' if cat_present else 'absent',
                                   cat_point=placement.cat_point or 0)
        host.targets = plan.targets
    elif level == 2:
        from evidence_session import EvidenceSession
        host = (host_cls or EvidenceSession)(life=life, search=sampler.new_search(level),
                                            targets=plan.targets)
    elif level == 3:
        from ward_final_session import WardFinalSession
        host = (host_cls or WardFinalSession)(life=life, search=sampler.new_search(level),
                                             targets=plan.targets)
    else:
        from s4_session import S4Session
        host = (host_cls or S4Session)(life=life, targets=plan.targets,
                                      key_point=placement.key_point, rng_seed=seed)
    return host, sampler
