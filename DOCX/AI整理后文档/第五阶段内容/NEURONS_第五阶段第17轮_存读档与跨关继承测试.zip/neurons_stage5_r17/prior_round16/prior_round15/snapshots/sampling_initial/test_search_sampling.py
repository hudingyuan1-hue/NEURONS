from collections import Counter
from copy import deepcopy
from dataclasses import fields
import json
from pathlib import Path

import pytest
from hypothesis import given, settings, strategies as st

from rules import Life
from search_sampling import AttemptSampler, PublicPlan, CONFIG, build_host, next_point, room_map


def life_at(level):
    return Life(progress=level, place=f'S{level}')


@pytest.mark.parametrize('level', range(1, 5))
def test_target_cardinality_and_unique_key(level):
    s = AttemptSampler(17)
    p = s.sync(life_at(level))
    assert len(p.candidates) == CONFIG[level][0]
    assert len(p.targets) == len(set(p.targets)) == CONFIG[level][1]
    assert s.placement(level).key_point in p.targets
    assert s.new_search(level).key_owner == 'hidden'


@pytest.mark.parametrize('level', range(1, 5))
def test_same_seed_reproduces_actual_attempt(level):
    a, b = AttemptSampler(27), AttemptSampler(27)
    l = life_at(level)
    assert a.sync(l) == b.sync(deepcopy(l))
    assert a.placement(level) == b.placement(level)
    for _ in range(5):
        l.phase = 'dead'
        assert l.revive()
        assert a.sync(l) == b.sync(deepcopy(l))
        assert a.placement(level) == b.placement(level)


@pytest.mark.parametrize('level', range(1, 5))
def test_total_cycle_jump_does_not_draw_three_attempts(level):
    s, l = AttemptSampler(31), life_at(level)
    s.sync(l)
    l.phase = 'dead'
    assert l.revive()
    p = s.sync(l)
    assert l.total == 4 and p.attempt == 2 and s.draws == 2


@pytest.mark.parametrize('level', range(1, 5))
def test_room_cancel_load_and_supplement_do_not_move_key(level):
    s, l = AttemptSampler(33), life_at(level)
    original = s.sync(l, cat_present=True)
    placement = s.placement(level)
    search = s.new_search(level)
    point = original.targets[0]
    ident = search.start(point)
    assert search.settle(ident, 'cancel')
    l.place = 'other-room'
    restored = deepcopy(s)
    for model in (s, restored):
        assert model.sync(l) == original
        assert model.placement(level) == placement
        assert model.draws == 1
    assert search.start(point) is not None
    assert s.sync(l) is original


@pytest.mark.parametrize('level', range(1, 5))
def test_real_host_receives_sampled_search(level):
    host, sampler = build_host(level, 41)
    plan = sampler.sync(host.life)
    assert tuple(host.targets) == plan.targets
    assert host.search.level == level
    assert host.search.key_point == sampler.placement(level).key_point
    assert host.search.attempt == host.life.attempts[level]


@pytest.mark.parametrize('level', range(1, 5))
def test_existing_life_identity_and_balances_preserved(level):
    l = life_at(level)
    l.hp, l.sp, l.total = 71, 62, 17
    l.attempts[level] = 6
    l.economy.n = 23
    host, sampler = build_host(level, 7, life=l)
    assert host.life is l
    assert (l.hp, l.sp, l.total, l.economy.n) == (71, 62, 17, 23)
    assert host.search.attempt == sampler.sync(l).attempt == 6


@pytest.mark.parametrize('phase', ('dead', 'transition', 'ended'))
def test_unfinished_lifecycle_cannot_draw(phase):
    s, l = AttemptSampler(1), life_at(2)
    s.sync(l)
    l.phase = phase
    with pytest.raises(ValueError): s.sync(l)
    assert s.draws == 1


@pytest.mark.parametrize('level', (5, 6))
def test_combat_levels_cannot_have_search_plan(level):
    with pytest.raises(ValueError): build_host(level, 1)
    with pytest.raises(ValueError): AttemptSampler(1).sync(life_at(level))


def test_hidden_street_cannot_have_search_plan():
    l = life_at(1)
    l.place = 'hiddenStreet'
    with pytest.raises(ValueError): AttemptSampler(1).sync(l)


@pytest.mark.parametrize('attempt', (0, -1, 1.5, True))
def test_invalid_actual_attempt_is_rejected(attempt):
    l = life_at(1)
    l.attempts[1] = attempt
    with pytest.raises(ValueError): AttemptSampler(1).sync(l)


def test_rollback_and_skipped_attempt_are_not_silent_redraws():
    l, s = life_at(2), AttemptSampler(1)
    l.attempts[2] = 2
    p = s.sync(l)
    for invalid in (1, 4):
        l.attempts[2] = invalid
        with pytest.raises(ValueError): s.sync(l)
        assert s.draws == 1 and s._plans[2] == p


@pytest.mark.parametrize('bad', ([0] * 12, list(range(31)) + [32], list(range(31)) + [-1], [True] + list(range(1, 32))))
def test_illegal_or_duplicate_candidate_rejected(bad):
    s = AttemptSampler(1)
    with pytest.raises(ValueError): s.sync(life_at(2), eligible=bad)
    assert s.draws == 0


def test_s4_requires_eight_on_each_floor_not_merely_sixteen_total():
    with pytest.raises(ValueError):
        AttemptSampler(1).sync(life_at(4), eligible=list(range(7)) + list(range(31, 62)))


def test_unavailable_points_excluded_without_shrinking_required_count():
    s = AttemptSampler(3)
    p = s.sync(life_at(2), eligible=range(6, 32))
    assert len(p.targets) == 12 and set(p.targets) <= set(range(6, 32))
    assert s.placement(2).key_point >= 6
    with pytest.raises(ValueError): AttemptSampler(3).sync(life_at(2), eligible=range(11))


def test_s4_eight_targets_each_floor_only_one_key():
    s = AttemptSampler(12)
    p = s.sync(life_at(4))
    assert sum(x < 31 for x in p.targets) == 8
    assert sum(x >= 31 for x in p.targets) == 8
    assert len(vars(s.placement(4))) == 2
    assert s.placement(4).cat_point is None


def test_s3_floor_one_and_s2_ward_have_no_candidates():
    assert set(floor for floor, room in room_map(3)) == {2}
    assert 'ward' not in room_map(2)
    assert Counter(room_map(2)) == {'waiting': 6, 'exam': 8, 'pharmacy': 7, 'office': 11}


def test_cat_position_independent_can_overlap_key_or_outside_targets():
    overlap, different, outside = False, False, False
    for seed in range(300):
        s = AttemptSampler(seed)
        p = s.sync(life_at(1), cat_present=True)
        a = s.placement(1)
        overlap |= a.cat_point == a.key_point
        different |= a.cat_point != a.key_point
        outside |= a.cat_point not in p.targets
    assert overlap and different and outside


def test_cat_presence_never_perturbs_targets_key_or_next_attempt():
    a, b, l = AttemptSampler(4), AttemptSampler(4), life_at(1)
    for _ in range(6):
        assert a.sync(l, cat_present=True) == b.sync(l, cat_present=False)
        assert a.placement(1).key_point == b.placement(1).key_point
        assert a.placement(1).cat_point is not None and b.placement(1).cat_point is None
        l.rest()


def test_public_plan_does_not_expose_key_and_same_public_state_same_choice():
    s = AttemptSampler(9)
    p = s.sync(life_at(2))
    assert 'key_point' not in {f.name for f in fields(PublicPlan)}
    distances = dict(waiting=0, exam=1, pharmacy=1, office=1)
    expected = next_point(p, room='waiting', distances=distances)
    for hypothetical_key in p.targets:
        assert next_point(p, room='waiting', distances=distances) == expected


def test_selector_prioritizes_current_room_and_observed_blockers():
    p = PublicPlan(2, 1, tuple(range(32)), (0, 1, 7, 21), room_map(2))
    assert next_point(p, room='exam', distances={'waiting': 1, 'office': 2}) == 7
    assert next_point(p, room='exam', distances={'waiting': 1, 'office': 2}, blocked={7}, completed={0}, pending={1}) == 21
    assert next_point(p, room='exam', distances={}, blocked={7}) is None
    assert next_point(p, room='exam', distances={'waiting': 1}, key_acquired=True) is None


def test_s4_supplementary_search_preserves_key_and_targets():
    s = AttemptSampler(20)
    p = s.sync(life_at(4))
    placement = s.placement(4)
    distances = dict.fromkeys(p.rooms, 1)
    candidate = next_point(p, room='atrium', distances=distances, completed=p.targets)
    assert candidate in p.candidates and candidate not in p.targets
    assert s.placement(4) == placement and s.draws == 1


def test_fixed_seed_frequency_diagnostic_is_bounded_not_uniformity_proof():
    summary = {}
    for level in range(1, 5):
        keys, ranks, floors = Counter(), Counter(), Counter()
        for seed in range(12000):
            s = AttemptSampler(seed)
            p = s.sync(life_at(level))
            key = s.placement(level).key_point
            keys[key] += 1
            ranks[p.targets.index(key)] += 1
            if level == 4: floors[int(key >= 31)] += 1
        capacity, count = CONFIG[level]
        assert len(keys) == capacity and len(ranks) == count
        assert all(abs(n - 12000/capacity) < 0.35*(12000/capacity) for n in keys.values())
        assert all(abs(n - 12000/count) < 0.20*(12000/count) for n in ranks.values())
        summary[level] = {'fixed_seed_samples': 12000, 'key_point_counts': dict(sorted(keys.items())),
                          'target_rank_counts': dict(sorted(ranks.items())), 's4_key_floor_counts': dict(floors),
                          'interpretation': 'finite regression diagnostic; not proof of statistical independence or exhaustive cycles'}
    Path('results/sampling_frequency.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))


@settings(max_examples=200, deadline=None)
@given(seed=st.integers(min_value=0, max_value=2**32-1), level=st.integers(min_value=1, max_value=4),
       actions=st.lists(st.sampled_from(('same', 'room', 'clone', 'death', 'rest')), min_size=1, max_size=25))
def test_random_attempt_sequences(seed, level, actions):
    s, l = AttemptSampler(seed), life_at(level)
    p = s.sync(l, cat_present=True)
    for action in actions:
        before = p
        placement = s.placement(level)
        draws = s.draws
        if action == 'death':
            l.phase = 'dead'
            assert l.revive()
        elif action == 'rest':
            l.rest()
        elif action == 'room':
            l.place = 'same-level-room'
        elif action == 'clone':
            s = deepcopy(s)
        p = s.sync(l, cat_present=True)
        assert len(p.targets) == len(set(p.targets)) == CONFIG[level][1]
        assert s.placement(level).key_point in p.targets
        if p.attempt == before.attempt:
            assert p == before and s.placement(level) == placement and s.draws == draws
        else:
            assert p.attempt == before.attempt + 1 and s.draws == draws + 1
        if level == 4:
            assert sum(x < 31 for x in p.targets) == 8
