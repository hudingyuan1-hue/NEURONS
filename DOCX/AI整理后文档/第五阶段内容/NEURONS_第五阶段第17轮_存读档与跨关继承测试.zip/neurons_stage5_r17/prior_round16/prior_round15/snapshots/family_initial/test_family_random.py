from collections import Counter
import pytest
from hypothesis import given,settings,strategies as st
from family_random import FamilyRandom
from family import Family


@pytest.mark.parametrize('k,expected',[
    (1,(4000,3500,1200,800,800)),(2,(4500,4000,1400,1000,1000)),
    (3,(5000,4500,1600,1200,1200)),(4,(5500,5000,1800,1400,1400)),
    (5,(6000,5500,2000,1600,1600)),(1000000,(6000,5500,2000,1600,1600))])
def test_actual_attempt_probability_source_table(k,expected):
    assert tuple(FamilyRandom.thresholds(k).values())==expected


@pytest.mark.parametrize('dog,cat,result',[(3999,3499,(True,True)),(4000,3499,(False,True)),
                                        (3999,3500,(True,False)),(4000,3500,(False,False))])
def test_opening_exact_probability_threshold_and_no_room_reroll(dog,cat,result):
    r=FamilyRandom();assert r.opening(dog_roll=dog,cat_roll=cat)==result
    before=r.family.dog,r.family.cat,tuple(r.roll_history)
    assert r.opening(dog_roll=0,cat_roll=0) is None
    assert (r.family.dog,r.family.cat,tuple(r.roll_history))==before


@pytest.mark.parametrize('k,expected',[(1,{(True,False):2600,(False,True):2100,(True,True):1400,(False,False):3900}),
                                     (5,{(True,False):2700,(False,True):2200,(True,True):3300,(False,False):1800})])
def test_pet_joint_probabilities_exact_percentage_grid(k,expected):
    counts=Counter()
    for d in range(100):
        for c in range(100):
            f=Family();f.life.attempts[1]=k
            result=FamilyRandom(f).opening(dog_roll=d*100,cat_roll=c*100)
            counts[result]+=1
    assert counts==expected


def search(r,point=0,**kw):
    ident=r.family.start_search(point);assert ident
    assert r.settle(ident,complete=False,**kw)
    return ident


def test_cancelled_avatar_actions_count_but_dog_and_duplicate_do_not():
    r=FamilyRandom(Family(dog=True))
    t=r.family.start_search(0,dog_point=1)
    dog=next(i for i,(who,_) in r.family.search.pending.items() if who=='dog')
    assert r.settle(dog,complete=False) and r.settled==0
    assert r.settle(t,complete=False) and r.settled==1
    assert not r.settle(t) and r.settled==1
    search(r,mother_roll=9999,father_roll=9999)
    assert r.settled==2 and r.draws.checked_nodes=={2}


def test_cat_block_counts_actual_avatar_settlement_and_no_reward():
    r=FamilyRandom(Family(cat='occupying',cat_point=0))
    t=r.family.start_search(0);assert t
    assert r.settle(t,complete=True)
    assert r.settled==1 and r.family.search.income==0


def test_both_selected_not_present_until_distinct_actual_legal_nodes():
    r=FamilyRandom();r.family.life.sp=80
    search(r);search(r,mother_roll=0,father_roll=0,first='mother')
    assert r.draws.queue==['mother','father'] and r.family.appeared==set()
    node=r.token()
    assert not r.enter_next(node,actual_entry=False)
    assert not r.enter_next(node,entry_free=False)
    assert r.enter_next(node)=='porridge'
    assert not r.enter_next(node) and r.family.life.phase=='alive'
    assert r.enter_next(r.token())=='collapse'
    assert r.family.life.phase=='dead' and r.family.life.hp==r.family.life.sp==0


def test_parent_event_blocks_normal_rolls_and_does_not_hold_person_waiting():
    r=FamilyRandom();r.family.life.sp=80
    search(r);search(r,mother_roll=0,father_roll=9999)
    assert r.enter_next(r.token())=='porridge'
    before=list(r.roll_history)
    assert r.family.start_search(0) is None
    assert r.extra(r.token(),'mother',node_kind='gift_done',roll=9999) is False
    assert r.draws.extra_used and len(r.roll_history)==len(before)+1
    assert not r.extra(r.token(),'mother',node_kind='before_cross',roll=0)
    assert r.draws.queue==[]


def test_extra_check_requires_actual_presence_and_legal_node():
    r=FamilyRandom();r.family.life.sp=80
    search(r);search(r,mother_roll=0,father_roll=9999)
    assert not r.extra(r.token(),'mother',node_kind='door_enter',roll=0)
    assert r.enter_next(r.token())=='porridge'
    assert not r.extra(r.token(),'mother',node_kind='dialogue',roll=0)
    assert not r.extra(r.token(),'mother',node_kind='door_enter',paused=True,roll=0)
    assert r.extra(r.token(),'mother',node_kind='door_enter',roll=799)
    assert r.draws.queue==['father'] and not r.draws.extra('mother',0)


@pytest.mark.parametrize('roll,items',[(0,('candy',)),(5999,('candy',)),(6000,('chocolate',)),
                                     (8999,('chocolate',)),(9000,('candy','chocolate')),(9999,('candy','chocolate'))])
def test_actual_placement_fixes_gift_and_pickup_is_not_food_income(roll,items):
    r=FamilyRandom(Family(dog=True));f=r.family
    assert f.appear('mother')=='door_gift'
    balance=f.life.economy.n,f.life.economy.c
    assert not r.place_gift(r.token(),actual_placed=False,roll=roll)
    assert r.place_gift(r.token(),roll=roll)
    assert f.gift_kind==items
    assert not r.place_gift(r.token(),roll=9999-roll)
    for item in tuple(f.gift_floor):assert f.pickup_gift(item)
    assert (f.life.economy.n,f.life.economy.c)==balance
    for item in tuple(f.life.food):assert f.complete_eating(item)
    expected_n=sum({'candy':5,'chocolate':3}[x] for x in items)
    assert f.life.economy.n==balance[0]+expected_n
    assert not f.life.food


def test_death_plus_three_is_only_one_probability_step_and_closes_old_nodes():
    r=FamilyRandom();r.opening(dog_roll=0,cat_roll=9999)
    old_node=r.token();r.family.verdict([('hp_damage',100)])
    assert not r.opening() and not r.enter_next(old_node)
    assert r.family.revive()
    assert r.family.life.total==4 and r.family.life.attempts[1]==2
    assert r.opening(dog_roll=4499,cat_roll=3999)==(True,True)
    assert not r.enter_next(old_node)
    assert r.draws.k==2 and not r.draws.checked_nodes


@settings(max_examples=160,deadline=None,database=None)
@given(seed=st.integers(0,2**32-1),rolls=st.lists(st.tuples(st.integers(0,9999),st.integers(0,9999)),min_size=4,max_size=4))
def test_seed_replay_parent_four_checks_and_unique_queue(seed,rolls):
    def run():
        r=FamilyRandom(seed=seed);pets=r.opening()
        for i in range(8):
            m,f=rolls[i//2]
            search(r,mother_roll=m,father_roll=f)
        assert r.draws.checked_nodes=={2,4,6,8}
        assert len(r.draws.queue)==len(set(r.draws.queue))<=2
        return pets,list(r.roll_history),list(r.draws.queue)
    assert run()==run()
