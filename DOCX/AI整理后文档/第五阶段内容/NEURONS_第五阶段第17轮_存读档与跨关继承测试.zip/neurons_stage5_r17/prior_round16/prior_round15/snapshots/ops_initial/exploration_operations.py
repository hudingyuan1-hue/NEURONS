"""R15 actual exploration operations, not navigation or animation simulation.

Sources S2:P31-35/T14R2-4/T15R5; S3:P159-160;
S4:T4/P161/P264/P273/P276. Actual endpoints are caller facts.
"""
from math import hypot, isfinite
from exploration_core import ExplorationSkills


class _HostView:
    def __init__(self, native, owner):
        object.__setattr__(self, '_native', native)
        object.__setattr__(self, '_owner', owner)

    def __getattr__(self, name):
        if name == 'action' and self._owner._react_context and self._owner.autonomous:
            return self._owner.autonomous['id']
        return getattr(self._native, name)

    def __setattr__(self, name, value):
        setattr(self._native, name, value)


class _OperationsAdapter:
    def __init__(self, native, owner):
        self.native, self.owner = native, owner
        self.host = _HostView(native.host, owner)

    def __getattr__(self, name):
        return getattr(self.native, name)

    def context(self):
        action = self.owner.autonomous
        if action:
            return (str(self.native.position), action['kind'], action['target'])
        return self.native.context()

    def advance(self, ms, **facts):
        owner = self.owner
        food = owner.food_action
        free = not self.native.blocked() and not facts.get('action_paused', False)
        result = self.native.advance(ms, **facts)
        if food and owner.food_action is food and self.native.level != 2 and free:
            food['elapsed'] += ms
        return result


class ExplorationOperations(ExplorationSkills):
    """Food IDs identify actual inventory objects; action IDs identify attempts."""
    def __init__(self, adapter):
        self.autonomous = None
        self.food_action = None
        self.auto_food_wait = False
        self.facing = (0.0, 1.0)
        self.operation_history = {}
        self._react_context = False
        self._ops_vitals = (adapter.life.hp, adapter.life.sp)
        self._ops_epoch = adapter.life.epoch
        super().__init__(_OperationsAdapter(adapter, self))

    def _end(self, kind):
        self._cancel_autonomous()
        self._cancel_food('boundary')
        super()._end(kind)

    def _sync(self):
        old_hp, old_sp = self._ops_vitals
        super()._sync()
        damaged = self.life.hp < old_hp or self.life.sp < old_sp
        if self.food_action and (damaged or self.adapter.blocked() or not self.active):
            self._cancel_food('damage' if damaged else 'blocked')
        if self.food_action and self.adapter.level == 2 and self.host.food_action != self.food_action['item']:
            self._cancel_food('native_cancel')
        if self.life.epoch != self._ops_epoch:
            self.auto_food_wait = False
            self._ops_epoch = self.life.epoch
        self._ops_vitals = (self.life.hp, self.life.sp)

    def _available_body(self):
        return (self.active and not self.paused and not self.adapter.blocked()
                and not self.effects.body_busy() and self.pending_motion is None)

    def _cancel_food(self, reason):
        record = self.food_action
        if not record:
            return False
        record['status'] = 'cancelled'
        record['reason'] = reason
        if record['automatic'] and reason in ('damage', 'blocked', 'native_cancel'):
            self.auto_food_wait = True
        if self.adapter.level == 2 and self.host.food_action == record['item']:
            self.host.food_action = None
            self.host.food_ms = 0
        self.food_action = None
        return True

    def _cancel_autonomous(self):
        action = self.autonomous
        if not action:
            return False
        self.awareness.end_action(action['id'], completed=False, autonomous=True,
                                  normal=False, kind=action['kind'])
        if self.adapter.level == 2 and getattr(self.host, 'action', None) == action['id']:
            self.host.action = None
            if hasattr(self.host, 'action_context'):
                self.host.action_context = None
        action['status'] = 'cancelled'
        self.autonomous = None
        return True

    @staticmethod
    def _direction(value):
        if not isinstance(value, (tuple, list)) or len(value) != 2:
            return None
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not isfinite(v) for v in value):
            return None
        length = hypot(*value)
        return tuple(v / length for v in value) if length else None

    def command(self, kind, action=None, **facts):
        if action == 'turn' and (kind != 'turn' or self._direction(facts.get('facing')) is None):
            return None
        if self.food_action or self.autonomous:
            return None
        return super().command(kind, action, **facts)

    def control_action(self, command_id, actual=True, **facts):
        self._sync()
        cmd = self.commands.get(command_id)
        if cmd and cmd['action'] == 'turn':
            if (not self._available_body() or not actual or cmd.get('completed')
                    or not self.book.control_active or cmd['cast_id'] != self.book.control_id
                    or self.food_action or self.autonomous):
                return False
            facing = self._direction(cmd['facts'].get('facing'))
            actual_facing = self._direction(facts.get('actual_facing', cmd['facts'].get('facing')))
            if not facing or actual_facing != facing:
                return False
            self.facing = facing
            cmd['completed'] = True
            self.book.confirm_control_body(cmd['cast_id'], actual=True)
            if hasattr(self.adapter, 'control_completed'):
                self.adapter.control_completed('turn', command_id, **facts)
            elif hasattr(self.adapter, 'control_witness'):
                self.adapter.control_witness(cmd['cast_id'], **facts)
            # S2:T5R4 requires actual movement or interaction, not facing only.
            if 'control' in self.feedback:
                self.feedback['control']['control_has_action'] = True
            return True
        if self.food_action or self.autonomous:
            return False
        return super().control_action(command_id, actual=actual, **facts)

    def react(self, cast_id, **facts):
        self._react_context = True
        try:
            result = super().react(cast_id, **facts)
        finally:
            self._react_context = False
        if result and self.book.control_active:
            self._cancel_autonomous()
            self._cancel_food('control')
        return result

    def automatic_food(self):
        """One selection only. Caller still needs a safe completed eating action."""
        if self.life.hp <= 50:
            item = next((k for k, v in self.life.food.items() if v == 'chocolate'), None)
            if item is not None:
                return item
        if self.life.sp <= 50:
            for kind in ('porridge', 'candy', 'chocolate'):
                item = next((k for k, v in self.life.food.items() if v == kind), None)
                if item is not None:
                    return item
        return None

    def begin_food(self, item_id=None, automatic=False, safe=True):
        self._sync()
        if automatic and item_id is None:
            item_id = self.automatic_food()
        if (not self._available_body() or not safe or self.food_action or self.autonomous
                or self.handoff or self.life.food.get(item_id) not in ('porridge', 'candy', 'chocolate')
                or automatic and (self.auto_food_wait or self.book.control_active or self.adapter.current_search is not None)):
            return None
        if automatic and item_id != self.automatic_food():
            return None
        identity = self.token('food')
        self.adapter.cancel_current_search()
        if self.adapter.level == 2:
            if not self.host.begin_food(identity, item_id, automatic=automatic):
                return None
        record = dict(id=identity, item=item_id, automatic=automatic,
                      elapsed=0, epoch=self.life.epoch, status='pending')
        self.food_action = self.operation_history[identity] = record
        return identity

    def complete_food(self, action_id, actual=True, hp_damage=0, sp_damage=0):
        self._sync()
        action = self.food_action
        if (not self._available_body() or not actual or not action or action_id != action['id']
                or action['epoch'] != self.life.epoch or action['item'] not in self.life.food):
            return False
        elapsed = self.host.food_ms if self.adapter.level == 2 else action['elapsed']
        if elapsed < 1500:
            return False
        item = action['item']
        if hp_damage or sp_damage:
            # A hit before swallowing interrupts food; fatal damage cannot heal.
            self.adapter.vitals(self.token('food_damage'), hp_damage=hp_damage, sp_damage=sp_damage)
            self._sync()
            return False
        if self.adapter.level == 2:
            self.host.batch(self.token('food_complete'), [('food', item)])
        else:
            self.life.frame(self.token('food_complete'), [('food', item)])
        if item in self.life.food:
            return False
        action['status'] = 'completed'
        self.food_action = None
        self._ops_vitals = (self.life.hp, self.life.sp)
        self._sync()
        return True

    def begin_autonomous(self, kind, target, probe=False, safe=True, incoming_hit=False):
        self._sync()
        if (not self._available_body() or self.book.control_active or self.autonomous
                or self.food_action or self.handoff or self.adapter.current_search is not None
                or kind not in ('move', 'interact') or getattr(self.host, 'feedback', False)):
            return None
        identity = self.token('autonomous')
        if self.adapter.level == 2:
            if not self.host.begin_autonomous(identity, kind, target, probe=False):
                return None
            identity = self.host.action
        record = dict(id=identity, kind=kind, target=target, status='pending',
                      epoch=self.life.epoch, position=self.adapter.position)
        self.autonomous = self.operation_history[identity] = record
        if probe:
            self.awareness.start_probe(identity, safe=safe, incoming_hit=incoming_hit,
                                        grabbed=self.adapter.blocked(), stunned=bool(self.life.stun))
        return identity

    def complete_autonomous(self, action_id, actual=True, action=None, normal=True, **facts):
        self._sync()
        record = self.autonomous
        if (not self._available_body() or self.book.control_active or not actual or not record
                or action_id != record['id'] or record['epoch'] != self.life.epoch):
            return False
        if record['kind'] == 'move':
            if action not in (None, 'move'):
                return False
            destination = facts.get('room') if self.adapter.level == 2 else facts.get('dest')
            if destination != record['target'] or not facts.get('actual_crossing', False) or not facts.get('route_clear', False):
                return False
            result = self.adapter.control('move', **facts)
        else:
            if action not in ('observe', 'pickup_key') or not facts.get('actual_contact', False):
                return False
            if facts.get('target') != record['target']:
                return False
            if action == 'observe':
                result = bool(facts.get('reachable', False) and facts.get('same_room', False))
            else:
                result = self.adapter.control(action, **facts)
        if not result:
            return False
        self.awareness.end_action(action_id, completed=True, autonomous=True,
                                  normal=normal, kind=record['kind'])
        if self.adapter.level == 2 and getattr(self.host, 'action', None) == action_id:
            self.host.action = None
            if hasattr(self.host, 'action_context'):
                self.host.action_context = None
        record['status'] = 'completed'
        self.autonomous = None
        self.auto_food_wait = False
        if hasattr(self.host, 'auto_food_wait'):
            self.host.auto_food_wait = False
        self._sync()
        return True

    def start_search(self, point, kind='normal', **facts):
        if self.food_action or self.autonomous:
            return None
        return super().start_search(point, kind=kind, **facts)

    def complete_search(self, *args, **kwargs):
        result = super().complete_search(*args, **kwargs)
        if result:
            self.auto_food_wait = False
        return result
