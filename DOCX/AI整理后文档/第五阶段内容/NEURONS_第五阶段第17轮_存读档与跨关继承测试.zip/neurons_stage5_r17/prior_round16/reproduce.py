"""Run selected current-round cases; preserve all delivered evidence."""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,os,json
root=Path(__file__).resolve().parent
out=root/'reproduction'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out.mkdir(parents=True)
selected=sys.argv[1:] or ['test_spawn_host.py','test_spawn_event_edges.py']
cmd=[sys.executable,'-m','pytest',*selected,'-q','--tb=short','--hypothesis-seed=2026101317','--hypothesis-show-statistics']
env=dict(os.environ,RUN_REPORT=str(out/'result.json'),PYTHONHASHSEED='0')
r=subprocess.run(cmd,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'pytest.log').write_text(r.stdout,encoding='utf8')
(out/'command.json').write_text(json.dumps({'argv':cmd,'pytest_exitstatus':r.returncode},indent=2))
print(r.stdout);print('Evidence:',out)
raise SystemExit(r.returncode)
