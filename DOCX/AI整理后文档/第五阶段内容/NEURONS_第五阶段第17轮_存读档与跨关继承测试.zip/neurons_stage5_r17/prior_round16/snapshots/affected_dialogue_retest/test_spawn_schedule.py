from copy import deepcopy
from fractions import Fraction
import random
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from spawn_schedule import SpawnSchedule, probability_bp, registry, mode


def miss(s,room,event): return s.enter(room,event,rolls=dict.fromkeys(s.groups,9999))
def hit(s,room,event): return s.enter(room,event,rolls=dict.fromkeys(s.groups,0))
def roundtrip(s, target, event, ms=20000, roll=9999):
    other=next(r for g in s.groups.values() for r in g.rooms if r!=target)
    miss(s,other,event+'out');s.tick(ms)
    return s.enter(target,event,rolls=dict.fromkeys(s.groups,roll))

@pytest.mark.parametrize('kind,expected',[('ordinary',(5000,6000,7000)),('patient',(3500,4500,5500)),('s4',(4500,5500,6500)),('s5',(5500,6500,7500))])
def test_attempt_exact_probabilities_and_cap(kind,expected):
    assert tuple(probability_bp(kind,k) for k in (1,3,5))==expected
    assert probability_bp(kind,10**9)==expected[-1]
    for k in (1,3,5,10**9):
        assert probability_bp(kind,k,1)==probability_bp(kind,k)//2==probability_bp(kind,k,2)

@pytest.mark.parametrize('level,gid,room',[(2,'s2_check','1:exam'),(2,'cross_patient','1:waiting'),(3,'s3_check','1:exam'),(4,'s4_back','1:atrium'),(5,'s5_dog','1:atrium')])
def test_exact_threshold_boundary(level,gid,room):
    for attempt in (1,3,5,10**9):
        g=registry(level)[gid];p=probability_bp(g.kind,attempt)
        for value,expected in ((p-1,True),(p,False)):
            s=SpawnSchedule(level,attempt)
            assert s.enter(room,'first',rolls={gid:value})[gid] is expected

@pytest.mark.parametrize('level,count,groups',[(2,10,6),(3,21,14),(4,11,11),(5,16,16)])
def test_complete_unique_registry(level,count,groups):
    s=SpawnSchedule(level)
    assert len(s.people)==count and len(s.groups)==groups
    assert all(len({i for i,_ in g.members})==len(g.members) for g in s.groups.values())

@pytest.mark.parametrize('gid,identities',[
 ('s2_transfer',{'S2_triage_nurse','S2_wheelchair_patient','S2_transfer_worker'}),
 ('s2_check',{'S2_check_doctor','S2_check_assistant'}),
 ('s2_records',{'S2_archivist','S2_security_guard'}),
 ('s3_drug',{'S3_treatment_pharmacist','S3_medication_nurse'}),
 ('s3_labor',{'S3_work_supervisor','S3_labor_patient'}),
 ('s3_postoperative',{'S3_postoperative_patient','S3_informer_patient'})])
def test_group_single_draw_all_members_waiting_no_story(gid,identities):
    s=SpawnSchedule(int(gid[1]));room=next(iter(s.groups[gid].rooms))
    hit(s,room,'check')
    assert s.records[gid].checks==1
    assert all(s.people[i]['status']=='waiting' for i in identities)
    assert not any(p['status']=='present' for p in s.people.values())
    assert not any(hasattr(s,k) for k in ('damage','reward','event_complete','hp'))

@pytest.mark.parametrize('elapsed,checks',[(0,1),(19999,1),(20000,2),(20001,2)])
def test_effective_reentry_exact_clock(elapsed,checks):
    s=SpawnSchedule(2);miss(s,'1:exam','a');roundtrip(s,'1:exam','b',elapsed)
    assert s.records['s2_check'].checks==checks

@pytest.mark.parametrize('pause_kind',['paused','dialogue','loading'])
def test_pause_excluded_from_away_clock(pause_kind):
    s=SpawnSchedule(2);miss(s,'1:exam','a');miss(s,'1:waiting','b')
    s.tick(19999);s.tick(900000,**{pause_kind:True})
    assert s.time_ms==19999 and s.records['s2_check'].outside==19999
    s.tick(1);miss(s,'1:exam','c')
    assert s.records['s2_check'].checks==2

@pytest.mark.parametrize('pause_kind',['paused','dialogue','loading'])
def test_frozen_callback_cannot_consume_draw(pause_kind):
    s=SpawnSchedule(2);setattr(s,pause_kind,True)
    assert hit(s,'1:exam','a')=={}
    assert not s.history
    setattr(s,pause_kind,False)
    assert hit(s,'1:exam','a')['s2_check']


def test_return_too_early_resets_required_away_period():
    s=SpawnSchedule(2);miss(s,'1:exam','a')
    roundtrip(s,'1:exam','b',15000)
    roundtrip(s,'1:exam','c',15000)
    assert s.records['s2_check'].checks==1
    roundtrip(s,'1:exam','d',20000)
    assert s.records['s2_check'].checks==2


def test_at_most_three_checks_reentries_do_not_add_attempts():
    s=SpawnSchedule(2);miss(s,'1:exam','a')
    for n in range(9):roundtrip(s,'1:exam',str(n))
    assert s.records['s2_check'].checks==3 and s.attempt==1


def test_reentry_has_half_probability_and_exclusive_threshold():
    for roll,expected in ((2499,True),(2500,False)):
        s=SpawnSchedule(2);miss(s,'1:exam','a')
        assert roundtrip(s,'1:exam','b',roll=roll)['s2_check'] is expected


def test_pending_does_not_reroll_when_entry_blocked():
    s=SpawnSchedule(2);hit(s,'1:exam','a')
    assert s.materialize('1:exam','m',eligible=s.people,entry_free=False)==()
    for n in range(4):roundtrip(s,'1:exam',str(n),roll=0)
    assert s.records['s2_check'].checks==1
    assert s.records['s2_check'].status=='waiting'


def test_distinct_member_conditions_and_batch_delay():
    s=SpawnSchedule(2);hit(s,'1:exam','a')
    assert s.materialize('1:exam','one',eligible=['S2_check_doctor'])==('S2_check_doctor',)
    assert s.people['S2_check_assistant']['status']=='waiting'
    assert not s.materialize('1:exam','two',eligible=['S2_check_assistant'])
    s.tick(9999);assert not s.materialize('1:exam','two',eligible=['S2_check_assistant'])
    s.tick(1);assert s.materialize('1:exam','two',eligible=['S2_check_assistant'])==('S2_check_assistant',)


def test_batch_gap_shared_between_independent_groups():
    s=SpawnSchedule(5);hit(s,'1:atrium','a')
    assert s.materialize('1:atrium','dog',eligible=['S1_dog'])
    assert not s.materialize('1:atrium','father',eligible=['S1_father'])
    s.tick(10000);assert s.materialize('1:atrium','father',eligible=['S1_father'])


def test_simultaneous_group_members_one_batch():
    s=SpawnSchedule(2);hit(s,'1:exam','a')
    assert set(s.materialize('1:exam','m',eligible=s.people))=={'S2_check_doctor','S2_check_assistant'}
    assert len(s.last_batch)==1


def test_room_unvisited_and_illegal_member_do_not_spawn():
    s=SpawnSchedule(2);hit(s,'1:exam','a')
    assert not s.materialize('1:office','wrong',eligible=s.people)
    assert not s.materialize('1:exam','wrongmember',eligible=['S2_security_guard'])


def test_empty_eligible_does_not_burn_batch_window_or_event():
    s=SpawnSchedule(2);hit(s,'1:exam','a')
    assert not s.materialize('1:exam','m')
    assert s.materialize('1:exam','m',eligible=['S2_check_doctor'])


def test_existing_npc_walk_bypasses_new_batch_gap():
    s=SpawnSchedule(2);hit(s,'1:exam','a');s.materialize('1:exam','m',eligible=s.people)
    assert s.move('S2_check_doctor','1:office')
    assert s.people['S2_check_doctor']['room']=='1:office'
    assert s.move('S2_check_doctor','1:exam')
    assert s.records['s2_check'].checks==1


def test_move_requires_actual_existing_route_and_does_not_clone():
    s=SpawnSchedule(2);hit(s,'1:exam','a');s.materialize('1:exam','m',eligible=s.people)
    assert not s.move('S2_check_doctor','1:office',actual=False)
    assert not s.move('S2_check_doctor','1:office',route_available=False)
    assert not s.move('S2_security_guard','1:exam')
    assert len(s.people)==10

@pytest.mark.parametrize('reason',['dead','removed','event_complete'])
def test_retired_person_not_revived_by_return(reason):
    s=SpawnSchedule(2);hit(s,'1:exam','a');s.materialize('1:exam','m',eligible=s.people)
    assert s.retire('S2_check_doctor',reason)
    roundtrip(s,'1:exam','b',roll=0)
    assert not s.materialize('1:exam','m2',eligible=['S2_check_doctor'])
    assert not s.move('S2_check_doctor','1:office')
    assert s.people['S2_check_doctor']['status']=='retired'


def test_cross_floor_same_nurse_group_keeps_remaining_checks():
    s=SpawnSchedule(3);miss(s,'1:treatment','a');miss(s,'2:stairs','b');s.tick(20000)
    assert s.enter('2:corridor','c',rolls={'s3_drug':0})['s3_drug']
    assert s.records['s3_drug'].checks==2
    assert s.materialize('2:corridor','m',eligible=['S3_medication_nurse'])
    assert s.people['S3_treatment_pharmacist']['status']=='waiting'
    miss(s,'1:treatment','d')
    assert not s.materialize('1:treatment','m2',eligible=['S3_medication_nurse'])


def test_cross_patient_is_one_identity_across_floor():
    s=SpawnSchedule(3);hit(s,'1:office','a');s.materialize('1:office','m',eligible=['cross_level_patient'])
    assert s.move('cross_level_patient','2:double')
    hit(s,'2:double','b')
    assert s.records['cross_patient'].checks==1
    assert not s.materialize('2:double','m2',eligible=['cross_level_patient'])


def test_duplicate_room_callback_never_consumes_rng_or_checks():
    s=SpawnSchedule(2,rng=random.Random(1));miss(s,'1:exam','a');state=s.rng.getstate()
    assert hit(s,'1:exam','a')=={} and hit(s,'1:exam','b')=={}
    assert s.rng.getstate()==state and s.records['s2_check'].checks==1


def test_duplicate_event_after_moving_back_is_not_replayed():
    s=SpawnSchedule(2);miss(s,'1:exam','a');miss(s,'1:waiting','b');s.tick(20000)
    assert hit(s,'1:exam','a')=={}
    assert s.room=='1:waiting' and s.records['s2_check'].checks==1


def test_snapshot_preserves_pending_timers_and_rng_without_redraw():
    s=SpawnSchedule(2,rng=random.Random(50));miss(s,'1:exam','a');miss(s,'1:waiting','b');s.tick(12345)
    t=SpawnSchedule.from_snapshot(s.snapshot())
    for obj in (s,t):obj.tick(7655);obj.enter('1:exam','c')
    assert s.history==t.history and s.rng.getstate()==t.rng.getstate()
    assert s.people==t.people


def test_restart_changes_actual_attempt_once_not_total_cycle_plus_three():
    s=SpawnSchedule(3);hit(s,'1:exam','a');s.materialize('1:exam','m',eligible=s.people)
    assert s.restart(reason='death') and s.attempt==2
    assert all(r.checks==0 for r in s.records.values())
    assert all(p['status']=='unseen' for p in s.people.values())


def test_cannot_restart_by_street_return_or_floor_change():
    s=SpawnSchedule(5);hit(s,'1:atrium','a');before=deepcopy(s.people)
    assert not s.restart(reason='street_return')
    assert not s.restart(reason='floor') and not s.restart(reason='rest')
    assert s.people==before and s.attempt==1


def test_explicit_probability_exclusions_and_required_self():
    assert mode(1)=='family_exclusive'
    assert mode(5,3)=='required_self_only'
    assert mode(6)=='street_full_roster'
    for level in (1,6):
        with pytest.raises(ValueError):SpawnSchedule(level)
    s=SpawnSchedule(5);assert hit(s,'3:relay','d')=={}
    assert 'cross_level_patient' not in s.people


def test_cannot_move_old_floor_actor_into_s5_third_floor():
    s=SpawnSchedule(5);hit(s,'1:atrium','a');s.materialize('1:atrium','m',eligible=['S1_father'])
    assert not s.move('S1_father','3:relay')


def test_s5_original_history_not_required_for_draw():
    s=SpawnSchedule(5);hit(s,'1:atrium','a')
    assert set(s.materialize('1:atrium','m',eligible=s.people))=={'S1_dog','S1_father'}
    assert not hasattr(s,'recognition_dialogue')


def test_exact_three_check_total_probability():
    assert 1-(1-Fraction(1,2))*(1-Fraction(1,4))**2==Fraction(71875,100000)
    assert 1-(1-Fraction(7,10))*(1-Fraction(35,100))**2==Fraction(87325,100000)


def test_s3_registry_uses_only_actual_rooms_no_invented_station_scene():
    from s3_session import F1,F2
    allowed={f'1:{r}' for r in F1}|{f'2:{r}' for r in F2}
    assert all(g.rooms<=allowed for g in registry(3).values())

class SpawnMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.s=SpawnSchedule(3,rng=random.Random(10));self.n=0;self.retired=set();self.maxchecks={}
    @rule(room=st.sampled_from(('1:exam','1:office','1:treatment','2:corridor','2:double','2:stairs')),roll=st.integers(0,9999))
    def enter(self,room,roll):
        self.n+=1;self.s.enter(room,self.n,rolls=dict.fromkeys(self.s.groups,roll))
    @rule(ms=st.integers(0,30000),paused=st.booleans(),dialogue=st.booleans(),loading=st.booleans())
    def tick(self,ms,paused,dialogue,loading):
        before=self.s.time_ms;self.s.tick(ms,paused=paused,dialogue=dialogue,loading=loading)
        assert self.s.time_ms==before+(0 if paused or dialogue or loading else ms)
    @rule(free=st.booleans())
    def materialize(self,free):
        before=len([p for p in self.s.people.values() if p['status']=='present']);self.n+=1
        new=self.s.materialize(self.s.room,self.n,eligible=self.s.people,entry_free=free)
        assert len([p for p in self.s.people.values() if p['status']=='present'])==before+len(new)
    @rule(index=st.integers(0,20))
    def retire(self,index):
        person=list(self.s.people)[index]
        if self.s.retire(person,'removed'):self.retired.add(person)
    @rule()
    def snapshot(self):
        self.s=SpawnSchedule.from_snapshot(self.s.snapshot())
    @invariant()
    def bounded_unique_monotonic(self):
        assert len(self.s.people)==21 and self.s.attempt==1
        for gid,rec in self.s.records.items():
            assert 0<=rec.checks<=3
            assert rec.checks>=self.maxchecks.get(gid,0)
            self.maxchecks[gid]=rec.checks
        assert all(self.s.people[p]['status']=='retired' for p in self.retired)
        assert all(r.outside>=0 for r in self.s.records.values())

TestSpawnMachine=SpawnMachine.TestCase
TestSpawnMachine.settings=settings(max_examples=200,stateful_step_count=60,deadline=None,database=None)

@pytest.mark.parametrize('level',[2,3,4,5])
def test_canonical_identities_match_existing_street_ledger(level):
    from street_people import ROSTER
    canonical={row[4] for row in ROSTER.values()}
    assert set(SpawnSchedule(level).people)<=canonical


def test_canonical_s5_matches_native_people_and_personality_ledgers():
    from s5_people import ROSTER as A
    from personalities import ROSTER as B
    assert set(SpawnSchedule(5).people)=={r[3] for r in A.values()}|{r[3] for r in B.values()}
