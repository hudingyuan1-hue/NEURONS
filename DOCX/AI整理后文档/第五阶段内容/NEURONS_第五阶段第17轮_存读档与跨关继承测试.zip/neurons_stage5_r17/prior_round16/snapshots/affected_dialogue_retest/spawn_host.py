"""R16 admission -> native S2/S3/S4/S5 event hosts.

Rules: S4:P96-120/T10/T11; S3:P420/P829-832. This is a model
adapter, not geometry. Caller supplies actual arrival, free entry, contacts and
per-member readiness. No effect is inferred from a lottery result.
Use call/move/admit/tick/actor_move; host is exposed for inspection, not a second
uncoordinated gameplay entry point. Durable save and S6 return belong to R17.
"""
import random
from spawn_schedule import SpawnSchedule, registry
from rules import Life
from evidence_session import EvidenceSession
from ward_final_session import WardFinalSession
from s4_session import S4Session, F1 as S4F1, EDGES as S4_EDGES
from s5_deep_session import S5DeepSession, F1 as S5F1, F2 as S5F2
from patient_transfer import PATIENT

ALIASES = {
 2: dict(zip(('S2_triage_nurse','S2_wheelchair_patient','S2_transfer_worker',
    'S2_check_doctor','S2_check_assistant','S2_archivist','S2_security_guard',
    'S2_junior_nurse','S2_pharmacist','cross_level_patient'),
    ('guide','wheelchair','porter','doctor','assistant','archivist','guard','nurse','pharmacist','cross_level_patient'))),
 3: dict(zip(('S3_psychiatrist','S3_check_assistant','S3_treatment_pharmacist',
    'S3_medication_nurse','S3_archivist','S3_security_guard','S3_ordinary_orderly',
    'S3_registration_nurse','cross_level_patient','S3_transfer_worker','S3_transferred_patient',
    'S3_postoperative_patient','S3_informer_patient','S3_treatment_director','S3_speaking_patient',
    'S3_work_supervisor','S3_labor_patient','S3_head_nurse','S3_isolation_orderly','S3_cleaner','S3_corner_patient'),
    ('doctor','assistant','pharmacist','nurse','archivist','guard','orderly','registrar','cross_level_patient',
     'porter','transferred','postop','informant','therapy_director','speaker','supervisor','worker','chief','isolator','cleaner','corner'))),
 4: dict(zip(('S4_back_person','S4_sewn_mouth_person','S4_blindfold_person','S4_repeater','S4_dislocated_person',
    'S4_doublehead','S4_twitch','S4_blank','S4_reverse','S4_face','S4_doubleface'),
    ('backturn','stitched','blind','mimic','clamp','doublehead','twitch','blankface','reverse','face','doubleface'))),
 5: dict(zip(('S1_dog','S1_father','S2_junior_nurse','S2_archivist','S3_corner_patient','S3_ordinary_orderly',
    'S1_mother','S1_cat','S2_check_doctor','S2_check_assistant','S4_doublehead','S4_twitch','S4_blank','S4_reverse','S4_face','S4_doubleface'),
    ('dog','father','nurse','archivist','corner','orderly','mother','cat','doctor','assistant',
     'doublehead','twitch','blank','reverse','face','doubleface'))),
}
S2_EDGES={frozenset(('waiting',r)) for r in ('ward','exam','pharmacy','office')}

class SpawnHost:
    def __init__(self, level, *, seed=2026101317, attempt=1):
        if level not in ALIASES: raise ValueError('S2 through S5 only')
        self.level=level
        self.schedule=SpawnSchedule(level,attempt,random.Random(seed))
        life=Life(progress=level,place='S5_atrium' if level==5 else f'S{level}')
        life.attempts[level]=attempt
        self.host={2:EvidenceSession,3:WardFinalSession,4:S4Session,5:S5DeepSession}[level](life=life)
        self.aliases=ALIASES[level]
        self.identities={a:i for i,a in self.aliases.items()}
        assert set(self.aliases)==set(self.schedule.people)
        self.locations=dict.fromkeys(self.aliases)  # S2 native host lacks positions.
        self.events=set();self.serial=0;self.audit=[];self.dialogue_open=None
        self.bound=(life.epoch,life.attempts[level],life.total)
        if hasattr(self.host,'search'): self.host.search.attempt=attempt
        if level==2:
            self.host.people.attempt=attempt
        if level==3:
            for name in ('medication','records','ward','isolation','transport','cleaning','corner'):
                getattr(self.host,name).new_attempt(attempt)
        self.refresh()

    def token(self,label):
        self.serial+=1
        return (self.host.life.epoch,('R16',label,self.serial))

    def _room(self, value=None):
        if value is None:
            value=self.host.room if self.level==2 else self.host.position
        if self.level==2: return '1:'+value
        if self.level==3: return f'{value[0]}:{value[1]}'
        floor=1 if value in (S4F1 if self.level==4 else S5F1) else 2
        if self.level==5 and value not in S5F1|S5F2:floor=3
        return f'{floor}:{value}'

    def _decode(self,room):
        f,r=room.split(':',1)
        return (int(f),r) if self.level==3 else r

    def active(self):
        h=self.host
        return h.life.progress==self.level and h.life.phase=='alive' and not(h.paused or getattr(h,'loading',False))

    def _fresh(self,token,*,formal=False):
        h=self.host
        allowed=self.active() or (formal and h.life.phase=='alive' and h.life.progress==self.level and not getattr(h,'loading',False))
        return allowed and isinstance(token,tuple) and len(token)==2 and token[0]==self.host.life.epoch and token not in self.events

    def native_room(self,identity):
        alias=self.aliases[identity];h=self.host
        if self.level==2:return self.locations[identity]
        if self.level in (3,4):
            p=h.actors.get(alias)
            return None if p is None else self._room(p)
        e=h.entity(alias)
        return self._room(e.room) if e.present and e.alive and e.room is not None else None

    def colocated(self,*identities,avatar=False):
        rooms=[self.native_room(i) for i in identities]
        if avatar:rooms.append(self._room())
        return bool(rooms) and rooms[0] is not None and len(set(rooms))==1

    def refresh(self):
        """Native post-action location/retirement -> one schedule, never respawn."""
        h=self.host;s=self.schedule
        for ident,p in s.people.items():
            if p['status']!='present':continue
            room=self.native_room(ident)
            reason=None
            if self.level==2:
                if ident=='cross_level_patient' and h.people.patient_removed:reason='removed'
                if ident=='S2_wheelchair_patient' and h.transfer.patient=='departed':reason='removed'
            elif self.level==5:
                e=h.entity(self.aliases[ident])
                if not e.alive:reason='dead'
                elif not e.present:reason='removed'
            elif room is None: reason='removed'
            if reason:
                p.update(status='retired',room=None,reason=reason)
                if self.level==2:self.locations[ident]=None
                self.audit.append(('native_retired',ident,reason))
            else:p['room']=room
        if self.level==2:
            here=lambda i:self.colocated(i,avatar=True)
            h.hospital.nurse_present=here('S2_junior_nurse')
            h.people.assistant_present=here('S2_check_assistant')
            h.people.patient_present=self.native_room('cross_level_patient') is not None
            h.people.guard_present=self.native_room('S2_security_guard') is not None
            t=h.transfer
            t.worker_present=self.native_room('S2_transfer_worker') is not None
            t.patient_present=self.colocated('S2_transfer_worker','S2_wheelchair_patient')
            t.guide_present=self.colocated('S2_transfer_worker','S2_triage_nurse')
        h._sync()

    def _entered(self,event,rolls=None):
        room=self._room();s=self.schedule
        # S5.3 uses its existing mandatory original; entering it still leaves F2.
        if room.startswith('3:'):
            old=s.room
            for r in s.records.values():
                if r.anchor==old and old!=room:r.away=True;r.outside=0
            s.room=room
            return {}
        return s.enter(room,event,rolls=rolls)

    def enter_current(self,token,*,actual=True,rolls=None):
        if not self._fresh(token) or not actual:return {}
        self.events.add(token)
        return self._entered(token,rolls)

    def admit(self,token,*,ready=(),entry_free=True):
        if not self._fresh(token):return ()
        self.refresh()
        batch=self.schedule.materialize(self._room(),token,eligible=ready,entry_free=entry_free)
        if not batch:return ()
        self.events.add(token);h=self.host
        for ident in batch:
            alias=self.aliases[ident];room=self._room()
            if self.level==2:self.locations[ident]=room
            elif self.level in (3,4):
                # Corridor checkpoint -> native double-ward doorway origin.
                # This is placement, not a claimed completed transport step.
                place=(2,'double') if self.level==3 and alias in ('porter','transferred') else self._decode(room)
                h.actors[alias]=place
                self.schedule.people[ident]['room']=self._room(place)
            else:
                e=h.entity(alias)
                e.present=True;e.room=h.position;e.spawn.state='present'
                if alias=='assistant':e.bed_room=h.position
        if self.level==3 and not h.transport.spawned:
            if self.native_room('S3_transfer_worker') is not None and self.native_room('S3_transferred_patient') is not None:
                order=('initial_transfer',h.life.attempts[3])
                if h.transport.spawn(h._rt('admitted_pair'),order):
                    h.ward.register_transfer(h._rt('initial_transfer'),order,
                        patient_id=PATIENT,wrist_id=PATIENT,bed_id=PATIENT)
        self.refresh()
        self.audit.append(('admit',token,batch))
        return batch

    def move(self,token,dest,*,actual=True,passable=True,rolls=None):
        if not self._fresh(token) or not actual or not passable:return False
        h=self.host
        if self.level==2:
            if frozenset((h.room,dest)) not in S2_EDGES:return False
            result=h.change_room(token,dest)
        else:result=h.move(token,dest,actual=True)
        self.events.add(token)
        if result:self._entered(token,rolls)
        self.refresh();return result

    def actor_move(self,token,identity,dest,*,actual=True,passable=True,bed_passable=True):
        if not self._fresh(token) or not actual or not passable or identity not in self.aliases:return False
        if self.schedule.people[identity]['status']!='present':return False
        alias=self.aliases[identity];h=self.host
        if self.level==2:
            old=self._decode(self.locations[identity])
            if frozenset((old,dest)) not in S2_EDGES:return False
            if alias=='porter' and h.transfer.worker_job is not None:return False
            if alias in ('guard','cross_level_patient') and h.people.guard_target is not None:return False
            if alias=='doctor' and h.hospital.exam not in ('idle','ended'):
                h._call('end_exam')
            self.locations[identity]=self._room(dest);result=True
        elif self.level==5:result=h.actor_move(token,alias,dest,actual=True,passable=True,bed_passable=bed_passable)
        else:result=h.actor_move(token,alias,dest,actual=True)
        self.events.add(token);self.refresh();return result

    def tick(self,token,ms):
        if isinstance(ms,bool) or not isinstance(ms,int) or ms<0:raise ValueError('nonnegative integer ms')
        if not self._fresh(token):return False
        self.refresh()
        result=self.host.tick(token,ms)
        self.events.add(token)
        if result:self.schedule.tick(ms)
        self.refresh();return result

    def _s2_allowed(self,method,args,kw):
        here=lambda *ids:self.colocated(*ids,avatar=True)
        h=self.host
        if method=='hospital_action':
            name=args[0]
            role={
                'give_prescription':'S2_check_doctor','begin_exam':'S2_check_doctor',
                'grip_exam':'S2_check_doctor','end_exam':'S2_check_doctor',
                'prepare':'S2_pharmacist','file_report':'S2_archivist',
                'start_bandage':'S2_junior_nurse','complete_false_label':'S2_junior_nurse',
                'approach_guard':'S2_security_guard','grip_guard':'S2_security_guard',
            }.get(name)
            if role and not here(role):return False
            if name=='receive_report' and not self.colocated('S2_archivist','S2_security_guard'):return False
            if name=='refuse':kw['nurse_witness']=kw.get('nurse_witness',False) and here('S2_junior_nurse')
        elif method=='begin_hint':return here('cross_level_patient')
        elif method=='guard_node':
            kw['receive']=kw.get('receive',False) and self.colocated('S2_archivist','S2_security_guard')
            kw['encounter']=kw.get('encounter',False) and self.colocated('cross_level_patient','S2_security_guard')
        elif method=='patient_action':return self.colocated('cross_level_patient','S2_security_guard')
        elif method=='skill':
            kw['patient_seen']=kw.get('patient_seen',False) and here('cross_level_patient')
            kw['assistant_seen']=kw.get('assistant_seen',False) and here('S2_check_assistant')
        elif method=='transfer_action':
            name=args[0]
            if name=='issue_patient_order' and not here('S2_triage_nurse','S2_wheelchair_patient'):return False
            if name in ('start_patient','patient_step') and not self.colocated('S2_transfer_worker','S2_wheelchair_patient'):return False
            if name=='patient_step':kw['seen']=kw.get('seen',False) and here('S2_wheelchair_patient')
            if name in ('start_bag','bag_step') and self.native_room('S2_transfer_worker')!='1:ward':return False
            if name=='identify_patient' and not here('S2_wheelchair_patient'):return False
            if name=='read_bag_tag' and h.room!='ward':return False
        return True

    def call(self,token,method,*args,**kw):
        """Actual native action; not an engine scheduler. No random draw here."""
        formal=kw.get('formal_dialogue',False) and (
            self.level==3 and ((method=='group_action' and args and args[0] in ('speak_transfer','say_stop','read_retraction'))
                              or (method=='corner_action' and args and args[0]=='say'))
            or self.level==4 and method=='action' and args[:2]==('records','hear_statement'))
        if not self._fresh(token,formal=formal):return False
        # A second native spawn API would draw twice / bypass member admission.
        if method in ('spawn_check','enter_pending','spawn_transfer','revive','rest','complete_rest','move','change_room','actor_move','tick'):
            raise ValueError('use the coordinator lifecycle/movement/admission entry')
        self.refresh()
        if self.level==2 and not self._s2_allowed(method,args,kw):return False
        result=getattr(self.host,method)(token,*args,**kw)
        if result and ((self.level==2 and method=='begin_hint') or (self.level==5 and method=='speak')):
            self.dialogue_open=(self.host.life.epoch,token,method)
        self.events.add(token);self.refresh();return result

    def finish_dialogue(self,token,*,dialogue_id=None,complete=True):
        # Only a dialogue actually opened by the native host may release its pause.
        if not self._fresh(token,formal=True) or self.dialogue_open is None or self.dialogue_open[0]!=self.host.life.epoch or dialogue_id!=self.dialogue_open[1]:return False
        if self.level==2:result=self.host.finish_hint(complete=complete)
        elif self.level==5:
            self.host.paused=False;result=True
        else:return False
        self.dialogue_open=None;self.events.add(token);self.refresh();return result

    def sync_attempt(self):
        """Only a committed native Life increment authorizes a fresh lottery."""
        h=self.host;old_epoch,old_attempt,old_total=self.bound
        now=(h.life.epoch,h.life.attempts[self.level],h.life.total)
        if h.life.progress!=self.level or now==self.bound:return False
        if now[1]==old_attempt:return False # room/level handoff is not restart
        delta=now[2]-old_total
        if h.life.phase!='alive' or now[1]!=old_attempt+1 or now[0]!=old_epoch+1 or delta not in (1,3) or delta==1 and self.level>=4:
            raise ValueError('not one committed native attempt')
        reason='death' if delta==3 else 'rest'
        self.schedule.restart(reason=reason)
        self.bound=now;self.locations=dict.fromkeys(self.aliases);self.dialogue_open=None
        self.refresh();self.audit.append(('attempt',reason,now))
        return True

    def revive(self):
        if self.host.paused or getattr(self.host,'loading',False):return False
        if not self.host.revive():return False
        self.sync_attempt();return True

    def rest(self,token,*,completed=True):
        if self.level not in (2,3) or not self._fresh(token):return False
        h=self.host
        result=h.rest(token,completed=completed) if self.level==2 else h.complete_rest(token,actual=completed)
        self.events.add(token)
        if result:self.sync_attempt()
        return result

    def invariant(self):
        assert self.schedule.attempt==self.host.life.attempts[self.level]
        for ident,p in self.schedule.people.items():
            room=self.native_room(ident)
            assert (p['status']=='present')==(room is not None),(ident,p,room)
            if room is not None:assert p['room']==room
        assert all(r.checks<=3 for r in self.schedule.records.values())
