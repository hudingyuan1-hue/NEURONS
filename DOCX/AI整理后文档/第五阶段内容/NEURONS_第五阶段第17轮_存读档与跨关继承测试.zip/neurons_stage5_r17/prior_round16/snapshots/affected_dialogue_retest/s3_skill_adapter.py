"""R14 S3 skill integration; sources S3 P617-622/686/708/886/T33,
S4 T15-T16/P189-207. Actual contact and hand motion remain engine facts.
"""
from fractions import Fraction
from exploration_core import NativeAdapter
from ward_final_session import WardFinalSession
from s3_session import POINT_ROOMS
from rules import search_ms


class S3SkillAdapter(NativeAdapter):
    def __init__(self, host=None):
        super().__init__(host or WardFinalSession())
        self.handoffs = {}
        self.contacts = set()
        self.chief_holding = set()

    def start(self, point, kind='normal', **facts):
        h = self.host
        if facts.get('controlled'):
            # S4:P53/P176: replace only the autonomous target/return-to-bed
            # decision. Retain native physical, budget, key and action guards.
            if (not h.node(self.token('controlled_search')) or h.feedback or h.rest_action
                    or h.blocked() or not isinstance(point, int) or not 0 <= point < 45
                    or h.position != (2, POINT_ROOMS[point])
                    or h.medication.cup_state in ('held', 'raising')):
                return None
            ident = h.search.start(point)
            if ident is not None:
                h.search_elapsed = 0
                h.search_duration = search_ms(3, kind, h.life.attempts[3], h.life.sp)
            return ident
        return h.start_search(self.token('search'), point, kind)

    def sync(self, paused=False, loading=False):
        super().sync(paused=paused, loading=loading)
        if hasattr(self, 'handoffs'):
            self._expire_handoffs()

    def finish(self, ident, actual=True, **facts):
        if not actual:
            return False
        return self.host.complete_search(self.token('search_complete'), ident)

    def limits(self):
        h = self.host
        values = [h.life.stun, h.drug_stop, h.hit_stop, h.work.clamp_remaining_ms]
        if h.holder and h.procedure:
            values.append(h.procedure['limit'] - h.hold_ms)
        if h.isolation.phase in ('closing', 'opening'):
            values.append(1000 - h.isolation.timer)
        if h.isolation.phase == 'closed':
            values.append(8000 - h.isolation.timer)
        return [x for x in values if x > 0]

    def advance(self, ms, search_factor=Fraction(1), action_paused=False):
        if ms < 0:
            raise ValueError('negative elapsed time')
        h = self.host
        self._expire_handoffs()
        before_search = h.search_elapsed
        before_pending = dict(h.search.pending)
        before_cup = h.medication.cup_id, h.medication.cup_state, h.medication.raising_ms
        result = h.tick(self.token('world_tick'), ms)
        if result:
            if before_pending and h.search.pending == before_pending:
                increment = h.search_elapsed - before_search
                h.search_elapsed = before_search + increment * (0 if action_paused else Fraction(search_factor))
            if action_paused and (h.medication.cup_id, h.medication.cup_state) == before_cup[:2]:
                h.medication.raising_ms = before_cup[2]
        self._expire_handoffs()
        return result

    def vitals(self, token, hp_damage=0, sp_damage=0, sp_heal=0):
        return self.host._apply(token, [('hp_damage', hp_damage), ('sp_damage', sp_damage),
                                        ('heal_sp', sp_heal)], physical=hp_damage > 0)

    def apply(self, proposal, **facts):
        h = self.host
        name = proposal.get('skill')
        if name == 'gut' and h.medication.cup_state in ('ready', 'held', 'raising'):
            return h.medicine_action(self.token('gut_refusal'), 'refuse',
                                     nurse_seen=facts.get('nurse_seen', False))
        # A cancelled search is not proof that the hand has left the drawer.
        if name in ('skin', 'gut', 'withdraw', 'startle', 'fear', 'control') and facts.get('hand_withdrawn') is True:
            return h.hand_position(self.token('actual_hand_withdrawal'), False, actual=True)
        return False

    def _available_contact(self, cast_id, **facts):
        return (self.host.active() and not self.host.blocked()
                and facts.get('actual', True) and cast_id not in self.contacts)

    def contact(self, name, cast_id, **facts):
        h = self.host
        if not self._available_contact(cast_id, **facts):
            return False
        target = facts.get('target')
        withdrew = name == 'withdraw' and facts.get('hand_withdrawn') is True
        retreated = name == 'startle' and facts.get('outside_range') is True
        knee = (name == 'knee' and facts.get('actual_contact') is True
                and facts.get('actual_body_contact') is True and facts.get('front') is True
                and 0 <= facts.get('distance_m', float('inf')) <= 1
                and facts.get('obstructed', False) is False)
        if not (withdrew or retreated or knee):
            return False
        if knee and (target is None or not h.present(target)):
            return False
        changed = False
        if h.work.hand_in_drawer and facts.get('hand_withdrawn') is True and (withdrew or retreated):
            changed = h.hand_position(self.token('hand_withdrawn'), False, actual=True)
        if knee and target == 'supervisor' and h.work.stage in ('approaching', 'ready', 'windup'):
            changed = h.work_action(self.token('supervisor_contact'), 'interrupt_supervisor', actual=True)
        p = h.procedure
        if p and p['state'] in ('offered', 'reaching') and h.present(p['actor']):
            if target in (None, p['actor']):
                if p['kind'] == 'wrist' and p['state'] == 'offered' and withdrew:
                    # Refusing normal wrist inspection exposes the one visible grab attempt.
                    changed = h.reach(self.token('refused_wrist'), actual=True, refused=True)
                elif p['state'] == 'reaching':
                    changed = h.finish_procedure(delivered=False)
        job = h.ordinary_job
        if job and job['target'] == 'avatar' and job['state'] == 'reaching' and target in (None, 'orderly'):
            h._close_ordinary('missed'); changed = True
        iso = h.isolation
        if iso.active and iso.active.target == 'avatar' and iso.phase == 'reaching' and target in (None, 'isolator'):
            changed = iso.abort('miss', actual=True)
            h._drain_isolation()
        if name in ('withdraw', 'startle') and h.medication.cup_state in ('held', 'raising'):
            # Physical interruption retains the same cup; it is not explicit refusal.
            if facts.get('cup_interrupted') is True:
                changed = h.medicine_action(self.token('cup_interrupt'), 'interrupt') or changed
        if changed:
            self.contacts.add(cast_id)
        h._sync()
        return changed

    def _expire_handoffs(self):
        h = self.host
        for identity, row in list(self.handoffs.items()):
            if row['state'] != 'pending':
                continue
            valid = (h.life.phase == 'alive' and h.life.progress == 3
                     and h.life.epoch == row['epoch'] and h.position == row['position'])
            if row['kind'] == 'chief_document':
                valid = valid and h.present('chief') and identity in h.records.owned
            else:
                valid = valid and h.medication.cup_id == identity and h.medication.cup_state == 'ready'
            if not valid:
                row['state'] = 'cancelled'
                if row['kind'] == 'chief_document':
                    h.chief_busy = False
        h._sync()

    def can_handoff(self, kind, identity, **facts):
        h = self.host
        self._expire_handoffs()
        if not h.active() or h.blocked():
            return False
        old = self.handoffs.get(identity)
        if old and old['state'] != 'cancelled':
            return old['kind'] == kind and old['state'] == 'pending'
        if facts.get('actual_pending') is not True:
            return False
        if kind == 'cup':
            valid = (h.medication.cup_id == identity and h.medication.cup_state == 'ready'
                     and h.position == h.cup_position and h.present('pharmacist'))
        elif kind == 'chief_document':
            valid = (h.position == (2, 'corridor') and h.present('chief') and not h.chief_busy
                     and identity in h.records.documents and identity in h.records.owned)
        else:
            return False
        if not valid:
            return False
        self.handoffs[identity] = dict(kind=kind, state='pending', epoch=h.life.epoch, position=h.position)
        if kind == 'chief_document':
            h.chief_busy = True
            h._sync()
        return True

    def handoff_valid(self, kind, identity, **facts):
        # A temporary pause/body restriction is not cancellation of a real item.
        self._expire_handoffs()
        row = self.handoffs.get(identity)
        return bool(row and row['kind'] == kind and row['state'] == 'pending')

    def cancel_handoff(self, identity):
        row = self.handoffs.get(identity)
        if not row or row['state'] != 'pending':
            return False
        row['state'] = 'cancelled'
        if row['kind'] == 'chief_document':
            self.host.chief_busy = False
            self.host._sync()
        return True

    def complete_handoff(self, kind, identity, **facts):
        if not facts.get('actual', True) or not self.can_handoff(kind, identity, **facts):
            return False
        h = self.host
        if kind == 'cup':
            result = h.medicine_action(self.token('take_cup'), 'take')
        else:
            # New adapter bridge for the explicit S3:P795/P886 physical return.
            # No testimony, order, diagnostic claim, or received report is deleted.
            h.records.owned.remove(identity)
            self.chief_holding.add(identity)
            h.chief_busy = False
            result = True
        if result:
            self.handoffs[identity]['state'] = 'completed'
        h._sync()
        return result

    def control(self, action, **facts):
        h = self.host
        if not h.active() or h.blocked() or facts.get('actual', True) is not True:
            return False
        if action == 'move':
            return h.move(self.token('control_move'), facts.get('dest'), actual=True)
        if action == 'search':
            return self.start(facts.get('point'), facts.get('kind', 'normal'), controlled=True)
        if action == 'take_cup':
            if any(row['kind'] == 'cup' and row['state'] == 'pending' for row in self.handoffs.values()):
                # An actual in-progress handoff must settle through the Core
                # delay/completion gate, not this alternate action spelling.
                return False
            return h.medicine_action(self.token('control_take'), 'take')
        if action == 'raise_cup':
            return h.medicine_action(self.token('control_raise'), 'raise_cup')
        if action == 'refuse_cup':
            return h.medicine_action(self.token('control_refuse'), 'refuse', nurse_seen=facts.get('nurse_seen', False))
        if action == 'observe':
            return h.indoor_action(self.token('control_observe'), kind='observe', reachable=facts.get('reachable', False))
        if action == 'exit':
            return h.damage_or_exit(self.token('control_exit'), exit_actual=True) == 'exit'
        return False
