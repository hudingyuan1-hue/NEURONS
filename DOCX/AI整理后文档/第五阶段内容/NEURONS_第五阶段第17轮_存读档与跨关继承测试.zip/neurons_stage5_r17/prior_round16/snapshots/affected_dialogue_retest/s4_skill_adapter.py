"""Fourth-level player-skill adapter; actual geometry remains caller evidence.

Sources: S3:P1083-85,1120-25,1144-48,1190,1203-05,1241-49;
S4:T14R5-12. No new story, rewards, enemy HP or skill prices.
"""
from fractions import Fraction
from exploration_core import NativeAdapter
from s4_session import S4Session, POINT_ROOMS


class S4SkillAdapter(NativeAdapter):
    VISIBLE = {
        'skin': 'scratch', 'gut': 'hold_abdomen', 'pores': 'look_skin',
        'thermal': 'tremble', 'tinnitus': 'turn_head', 'dry': 'press_lips',
        'knee': 'kick', 'withdraw': 'withdraw', 'startle': 'step_back',
        'fear': 'expression', 'happy': 'expression',
    }

    def __init__(self, host=None):
        super().__init__(host if host is not None else S4Session())
        self._control_visible_events = set()

    def start(self, point, kind='normal', **facts):
        return self.host.start_search(self.token('start'), point, kind=kind,
                                      reachable=facts.get('reachable', True))

    def finish(self, ident, actual=True, **facts):
        if not actual:
            return False
        return self.host.complete_search(self.token('finish'), ident)

    def next_point(self, occupied=()):
        return self.host.next_point(occupied=occupied)

    def on_cancel_search(self, ident, point):
        # Only the avatar's still-held display material returns to the table.
        self.host.archive._cancel_reading()
        self.host.records.search_cancelled = True

    def advance(self, ms, search_factor=Fraction(1), action_paused=False):
        if ms < 0:
            raise ValueError('negative time')
        factor = Fraction(search_factor)
        if not 0 <= factor <= 1:
            raise ValueError('invalid exploration rate')
        before = self.host.search_elapsed
        pending = dict(self.search.pending)
        result = self.host.tick(self.token('advance'), ms)
        # Native tick splits physical holds and advances each NPC's world clock.
        # Scale only actual avatar search progress, never the world's time.
        if result and pending and self.search.pending == pending:
            gained = self.host.search_elapsed - before
            self.host.search_elapsed = before + gained * (0 if action_paused else factor)
        return result

    def limits(self):
        return [n for n in (self.life.stun, self.host.hold_remaining,
                           self.host.hit_stop, self.host.drug_stop) if n > 0]

    def _witness(self, event_id, movement, source='player', **facts):
        if (not facts.get('visible_to_mimic', False)
                or not facts.get('actual_visible_movement', False)):
            return False
        return self.host.action(self.token('mimic'), 'cortex', 'mimic_witness',
                                event_id=event_id, movement=movement, source=source,
                                visible=True, effective=True, actual_movement=True)

    def apply(self, proposal, **facts):
        if not proposal or not self.host.active():
            return False
        name = proposal['skill']
        changed = False
        if proposal.get('cancel_search'):
            # Reading may be an observation interaction with no search pending.
            self.host.archive._cancel_reading()
            self.host.records.search_cancelled = True
            if self.host.routes.guidance:
                changed |= bool(self.host.action(self.token('guidance_cancel'),
                                                'routes', 'interrupt_guidance', actual=True))
        if name in ('skin', 'gut', 'withdraw', 'startle', 'fear', 'control'):
            if facts.get('actual_hand_clear', False):
                changed |= bool(self.host.action(self.token('hand_clear'), 'cortex',
                                                'hand_clear', actual=True))
        if name == 'startle' and facts.get('actual_out_of_face_contact', False):
            changed |= bool(self.host.action(self.token('face_avoided'), 'routes',
                                            'interrupt_face', actual=True))
        movement = self.VISIBLE.get(name)
        if movement:
            changed |= self._witness(proposal.get('cast_id', proposal.get('id')),
                                     movement, **facts)
        return changed

    def contact(self, name, cast_id, **facts):
        if name != 'knee' or not self.host.active() or self.blocked():
            return False
        if (not facts.get('actual_contact', True)
                or not facts.get('actual_body_contact', True)
                or facts.get('obstructed', False)
                or not facts.get('front', True)
                or not 0 <= facts.get('distance_m', 0) <= 1
                or facts.get('contact_kind', 'body') != 'body'):
            return False
        target = facts.get('target')
        if target not in self.host.actors or self.host.actors[target] != self.position:
            return False
        dispatch = {
            'clamp': ('cortex', 'clamp_interrupt', {'actual_hit': True}),
            'face': ('routes', 'interrupt_face', {'actual': True}),
            'stitched': ('archive', 'interrupt_paper', {'actual': True}),
            'blind': ('archive', 'interrupt_video', {'actual': True}),
            'blankface': ('records', 'interrupt_label', {'actual': True}),
        }
        if target not in dispatch:
            return False
        group, action, kw = dispatch[target]
        return self.host.action(self.token(('contact', cast_id)), group, action, **kw)

    def vitals(self, token, hp_damage=0, sp_damage=0, sp_heal=0):
        if min(hp_damage, sp_damage, sp_heal) < 0:
            raise ValueError('negative vital effect')
        if not self.host.node(token):
            return 'ignored'
        effects = self.host._effects()
        hp = hp_damage + sum(e['hp'] for _, e in effects)
        sp = sp_damage + sum(e['sp'] for _, e in effects)
        result = self.life.frame((self.life.epoch, ('S4skill', token[1])),
                                 [('hp_damage', hp), ('sp_damage', sp), ('heal_sp', sp_heal)])
        if hp or any(name == 'routes' for name, _ in effects) or self.life.stun:
            self.host.cancel_current()
        if hp and self.life.phase == 'alive':
            self.host.hit_stop = max(250, self.host.hit_stop)
        if result == 'death':
            self.host.cancel_current()
            self.host._release()
            self.host.hit_stop = self.host.drug_stop = 0
            self.awareness.transition('death')
        else:
            for name, effect in effects:
                duration = effect.get('hold_ms', effect.get('hold', 0))
                if duration and self.host.holder is None:
                    self.host.holder = 'clamp' if name == 'cortex' else 'face'
                    self.host.hold_remaining = duration
                    self.host.cancel_current()
        self.host._sync()
        return result

    def can_handoff(self, kind, identity, **facts):
        # S4 has no NPC-to-avatar reward delivery. Only the actual held paper
        # acquisition is an avatar transaction; NPC tearing/index removal isn't.
        return (self.host.active() and not self.blocked()
                and self.handoff_valid(kind, identity, **facts))

    def handoff_valid(self, kind, identity, **facts):
        """Object existence; temporary menu/physical holds don't destroy it."""
        return (kind == 'paper' and self.life.progress == 4
                and self.position == 'memory' and self.host.archive.reading
                and self.host.archive.pieces.get(identity) == 'held')

    def cancel_handoff(self, identity):
        if self.host.archive.pieces.get(identity) == 'held':
            self.host.archive.pieces[identity] = 'world'
        return True

    def complete_handoff(self, kind, identity, **facts):
        if not self.can_handoff(kind, identity, **facts):
            return False
        return self.host.action(self.token('acquire_paper'), 'archive', 'acquire_paper',
                                piece=identity, actual=True, reachable=facts.get('reachable', True))

    def control_completed(self, action, event_id, **facts):
        if event_id in self._control_visible_events or not facts.get('actual', True):
            return False
        self._control_visible_events.add(event_id)
        return self._witness(event_id, facts.get('visible_movement', 'posture'),
                             source='full_control', **facts)

    def control(self, action, **facts):
        if not self.host.active() or self.blocked() or not facts.get('actual', True):
            return False
        token = self.token(('control', action))
        if action == 'move':
            result = self.host.move(token, facts.get('dest'), actual=True)
        elif action in ('start_search', 'start'):
            result = self.host.start_search(token, facts.get('point', -1),
                                            kind=facts.get('kind', 'normal'),
                                            reachable=facts.get('reachable', True))
        elif action in ('complete_search', 'finish'):
            result = self.host.complete_search(token, facts.get('ident'))
        elif action == 'finish_feedback':
            result = self.host.finish_feedback(token)
        elif action == 'begin_open':
            result = self.host.begin_open(token, seen=facts.get('seen', True))
        elif action == 'unlock':
            result = self.host.unlock(token)
        elif action in ('push', 'push_door'):
            result = self.host.push_door(token)
        elif action in ('exit', 'cross_exit'):
            result = self.host.damage_or_exit(token, hp=facts.get('hp', 0),
                                              sp=facts.get('sp', 0), crossed=True)
            result = result == 'exit'
        elif action == 'acquire_paper':
            result = self.complete_handoff('paper', facts.get('piece'), **facts)
        else:
            return False
        if result and action not in ('exit', 'cross_exit'):
            self.control_completed(action, token, **facts)
        return result
