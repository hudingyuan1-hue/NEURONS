"""Snapshot before executing; never overwrite a previous evidence run."""
from pathlib import Path
import os, sys, shutil, subprocess, json, hashlib
name=sys.argv[1];args=sys.argv[2:]
root=Path(__file__).resolve().parent
log=root/'results'/f'{name}.log';report=root/'results'/f'{name}.json';snap=root/'snapshots'/name
if log.exists() or report.exists() or snap.exists():raise SystemExit('evidence name already used')
snap.mkdir(parents=True)
for p in root.glob('*.py'):shutil.copy2(p,snap/p.name)
(snap/'dependencies.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.py')},indent=2))
env=dict(os.environ,RUN_REPORT=str(report),PYTHONHASHSEED='0')
cmd=[sys.executable,'-m','pytest',*args,'-q','--tb=short','--hypothesis-seed=2026101317','--hypothesis-show-statistics']
r=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
log.write_text(r.stdout,encoding='utf8')
(root/'results'/f'{name}.command.json').write_text(json.dumps({'argv':cmd,'exitstatus':r.returncode},indent=2))
print(r.stdout[-14000:])
