"""Finite NPC appearance only; no story, damage, resources or Unity spawning.
S4:P94-120/T10/T11; S1 identity/home configuration. Milliseconds are game time.
"""
from dataclasses import dataclass, field
from copy import deepcopy
import random

@dataclass(frozen=True)
class Group:
    id: str
    kind: str
    members: tuple  # (canonical identity, legal appearance rooms)
    @property
    def rooms(self):
        return frozenset(room for _, rooms in self.members for room in rooms)

def g(id, kind, *members):
    return Group(id, kind, tuple((name, tuple(rooms.split('|'))) for name, rooms in members))

S2=(
 g('s2_transfer','ordinary',('S2_triage_nurse','1:waiting'),('S2_wheelchair_patient','1:waiting'),('S2_transfer_worker','1:waiting|1:ward')),
 g('s2_check','ordinary',('S2_check_doctor','1:exam'),('S2_check_assistant','1:exam')),
 g('s2_records','ordinary',('S2_archivist','1:office'),('S2_security_guard','1:office')),
 g('s2_nurse','ordinary',('S2_junior_nurse','1:ward|1:pharmacy')),
 g('s2_drug','ordinary',('S2_pharmacist','1:pharmacy')),
 g('cross_patient','patient',('cross_level_patient','1:waiting|1:office')))
S3=(
 g('s3_check','ordinary',('S3_psychiatrist','1:exam'),('S3_check_assistant','1:exam')),
 g('s3_drug','ordinary',('S3_treatment_pharmacist','1:treatment'),('S3_medication_nurse','1:treatment|2:corridor')),
 g('s3_records','ordinary',('S3_archivist','1:office'),('S3_security_guard','1:office')),
 g('s3_orderly','ordinary',('S3_ordinary_orderly','1:ward|2:corridor|2:activity|2:double')),
 g('s3_registration','ordinary',('S3_registration_nurse','1:reception')),
 g('cross_patient','patient',('cross_level_patient','1:office|2:double')),
 g('s3_transfer','ordinary',('S3_transfer_worker','2:corridor'),('S3_transferred_patient','2:corridor')),
 g('s3_postoperative','ordinary',('S3_postoperative_patient','2:activity'),('S3_informer_patient','2:activity')),
 g('s3_treatment','ordinary',('S3_treatment_director','2:group'),('S3_speaking_patient','2:group')),
 g('s3_labor','ordinary',('S3_work_supervisor','2:work'),('S3_labor_patient','2:work')),
 g('s3_chief','ordinary',('S3_head_nurse','2:corridor|2:corridor')),
 g('s3_isolation','ordinary',('S3_isolation_orderly','2:quiet')),
 g('s3_cleaner','ordinary',('S3_cleaner','2:wash')),
 g('s3_corner','ordinary',('S3_corner_patient','2:double')))
S4=tuple(g('s4_'+name,'s4',(identity,room)) for name,identity,room in (
 ('back','S4_back_person','1:atrium'),('sewn','S4_sewn_mouth_person','1:memory'),('blind','S4_blindfold_person','1:visual'),
 ('mimic','S4_repeater','1:decision'),('dislocated','S4_dislocated_person','1:body'),
 ('doublehead','S4_doublehead','2:bridge'),('twitch','S4_twitch','2:rhythm'),('blank','S4_blank','2:index'),
 ('reverse','S4_reverse','2:fork'),('face','S4_face','2:exit'),('twoface','S4_doubleface','2:identity')))
S5=tuple(g('s5_'+name,'s5',(identity,room)) for name,identity,room in (
 ('dog','S1_dog','1:atrium'),('father','S1_father','1:atrium'),('nurse','S2_junior_nurse','1:memory'),
 ('archivist','S2_archivist','1:memory'),('corner','S3_corner_patient','1:visual'),('orderly','S3_ordinary_orderly','1:visual'),
 ('mother','S1_mother','1:decision'),('cat','S1_cat','1:decision'),('doctor','S2_check_doctor','1:body'),
 ('assistant','S2_check_assistant','1:body'),('doublehead','S4_doublehead','2:bridge'),('twitch','S4_twitch','2:rhythm'),
 ('blank','S4_blank','2:index'),('reverse','S4_reverse','2:fork'),('face','S4_face','2:exit'),('twoface','S4_doubleface','2:identity')))

def mode(level, floor=1):
    if level == 1: return 'family_exclusive'
    if level in (2,3,4) or level == 5 and floor in (1,2): return 'finite_probability'
    if level == 5 and floor == 3: return 'required_self_only'
    if level == 6: return 'street_full_roster'
    raise ValueError('unsupported level/floor')

def registry(level):
    if level not in (2,3,4,5): raise ValueError('ordinary spawn rules apply only to S2-S5.2')
    return {group.id:group for group in {2:S2,3:S3,4:S4,5:S5}[level]}

def probability_bp(kind, attempt, check=0):
    if isinstance(attempt,bool) or not isinstance(attempt,int) or attempt < 1: raise ValueError('attempt >= 1 integer')
    if check not in (0,1,2): raise ValueError('check index 0..2')
    base={'ordinary':5000,'patient':3500,'s4':4500,'s5':5500}[kind]
    first=base+500*min(attempt-1,4)
    return first if check == 0 else first//2

@dataclass
class Record:
    checks: int = 0
    status: str = 'unseen'
    anchor: str | None = None
    outside: int = 0
    away: bool = False

class SpawnSchedule:
    def __init__(self, level, attempt=1, rng=None):
        probability_bp('ordinary',attempt)
        self.level=level; self.attempt=attempt; self.groups=registry(level)
        self.rng=rng if rng is not None else random.Random()
        self.records={gid:Record() for gid in self.groups}
        self.people={identity:{'status':'unseen','room':None,'group':gid,'reason':None}
                     for gid,group in self.groups.items() for identity,_ in group.members}
        assert len(self.people)==sum(len(g.members) for g in self.groups.values()), 'identity in multiple groups'
        self.room=None; self.time_ms=0; self.last_batch={}; self.events=set(); self.history=[]
        self.paused=self.dialogue=self.loading=False
    @property
    def frozen(self): return self.paused or self.dialogue or self.loading
    def tick(self, ms, *, paused=False, dialogue=False, loading=False):
        if isinstance(ms,bool) or not isinstance(ms,int) or ms<0: raise ValueError('nonnegative integer ms')
        if self.frozen or paused or dialogue or loading: return
        self.time_ms+=ms
        for rec in self.records.values():
            if rec.away: rec.outside+=ms
    def enter(self, room, event_id, *, rolls=None):
        """Actual room-entry callback. Duplicate callbacks do not consume RNG/checks.
        A shared group's latest checked room anchors its away timer. Any configured
        member room can spend a remaining check after >=20 s away from that anchor.
        """
        key=('enter',self.attempt,event_id)
        if self.frozen or key in self.events: return {}
        # Deep S5 and unavailable rooms cannot invoke a probability check.
        allowed={r for g in self.groups.values() for r in g.rooms}
        if self.level==3: allowed.add('2:stairs')
        if room not in allowed: return {}
        if room==self.room: return {}  # a repeated stay is not a new entrance
        self.events.add(key)
        old=self.room; self.room=room
        for rec in self.records.values():
            if old==rec.anchor and old!=room:
                rec.away=True; rec.outside=0
        results={}
        for gid,group in self.groups.items():
            rec=self.records[gid]
            if rec.status=='unseen' and rec.checks<3 and room in group.rooms:
                first=rec.checks==0
                valid=first or rec.away and rec.outside>=20000
                if valid:
                    roll=rolls[gid] if rolls is not None and gid in rolls else self.rng.randrange(10000)
                    if isinstance(roll,bool) or not isinstance(roll,int) or not 0<=roll<10000:
                        raise ValueError('roll integer 0..9999')
                    threshold=probability_bp(group.kind,self.attempt,rec.checks)
                    rec.checks+=1; hit=roll<threshold
                    rec.anchor=room; rec.away=False; rec.outside=0
                    if hit:
                        rec.status='waiting'
                        for identity,_ in group.members: self.people[identity]['status']='waiting'
                    results[gid]=hit
                    self.history.append({'event':event_id,'group':gid,'roll':roll,'threshold':threshold,'hit':hit,'check':rec.checks,'room':room})
            if room==rec.anchor:
                rec.away=False; rec.outside=0
        return results
    def materialize(self, room, event_id, *, eligible=(), entry_free=True):
        """Caller supplies actual member action conditions and free entry facts.
        One callback creates one batch; it cannot grant events, damage or resources.
        """
        key=('materialize',self.attempt,event_id)
        if self.frozen or key in self.events or not entry_free or room!=self.room: return ()
        if room in self.last_batch and self.time_ms-self.last_batch[room]<10000: return ()
        eligible=set(eligible)
        batch=[]
        for gid,group in self.groups.items():
            if self.records[gid].status!='waiting': continue
            for identity,rooms in group.members:
                person=self.people[identity]
                if identity in eligible and room in rooms and person['status']=='waiting':
                    person.update(status='present',room=room)
                    batch.append(identity)
        if not batch: return ()
        self.events.add(key); self.last_batch[room]=self.time_ms
        for gid in {self.people[i]['group'] for i in batch}:
            if all(self.people[i]['status']!='waiting' for i,_ in self.groups[gid].members):
                self.records[gid].status='resolved'
        return tuple(batch)
    def move(self, identity, room, *, actual=True, route_available=True):
        person=self.people.get(identity)
        if self.frozen or not actual or not route_available or person is None or person['status']!='present': return False
        if self.level==5 and str(room).startswith('3:'): return False
        person['room']=room
        return True
    def retire(self, identity, reason, *, actual=True):
        person=self.people.get(identity)
        if self.frozen or not actual or person is None or person['status']!='present': return False
        if reason not in ('dead','removed','event_complete'): raise ValueError('unknown retirement')
        person.update(status='retired',room=None,reason=reason)
        return True
    def snapshot(self):
        """In-memory exact continuation; not a durable save-format test."""
        return deepcopy(self)
    @classmethod
    def from_snapshot(cls, snapshot):
        if not isinstance(snapshot,cls): raise TypeError('SpawnSchedule snapshot required')
        return deepcopy(snapshot)
    def restart(self, *, reason, actual=True):
        if self.frozen or not actual or reason not in ('rest','death') or reason=='rest' and self.level>=4: return False
        self.__init__(self.level,self.attempt+1,self.rng)
        return True
