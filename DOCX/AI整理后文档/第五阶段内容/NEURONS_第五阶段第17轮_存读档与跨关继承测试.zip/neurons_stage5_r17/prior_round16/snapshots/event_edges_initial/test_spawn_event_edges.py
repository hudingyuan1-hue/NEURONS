"""New integration boundaries; expectations from source event prerequisites."""
import pytest
from hypothesis import given, settings, strategies as st
from spawn_host import SpawnHost
from test_spawn_host import call,enter,admit,tick,walk,spawn_at,die,resources


def test_s2_doctor_actual_departure_releases_hold_and_rejects_stale_needle():
    w=SpawnHost(2);spawn_at(w,['S2_check_doctor'])
    assert call(w,'hospital_action','begin_exam')
    assert call(w,'hospital_action','grip_exam')
    assert w.host.hospital.holder=='doctor'
    assert w.actor_move(w.token('doctor_leaves'),'S2_check_doctor','waiting')
    assert w.host.hospital.holder is None
    call(w,'batch',[('needle',True)])
    assert w.host.life.hp==100 and w.host.hospital.needle_count==0


def test_s3_formal_dialogue_can_finish_while_game_clock_frozen():
    w=SpawnHost(3);walk(w,(2,'group'))
    admit(w,['S3_treatment_director','S3_speaking_patient'])
    assert call(w,'group_action','start_recording')
    assert call(w,'group_action','sit_speaker')
    w.host.paused=True;t=w.schedule.time_ms
    assert not tick(w,20000) and not admit(w)
    assert call(w,'group_action','speak_transfer',formal_dialogue=True)
    assert w.host.group.original_spoken and w.schedule.time_ms==t
    assert not call(w,'group_action','stop_recording')


def test_s3_corner_formal_line_not_blocked_by_pause_or_replayed():
    w=SpawnHost(3);walk(w,(2,'double'));admit(w,['S3_corner_patient'])
    assert call(w,'corner_action','begin_talk')
    w.host.paused=True
    assert call(w,'corner_action','say',speaker='corner',line_key='remember_number',formal_dialogue=True)
    assert not call(w,'corner_action','say',speaker='corner',line_key='remember_number',formal_dialogue=True)
    assert w.host.corner.knowledge=={'remember_number'}


def test_s4_formal_contradiction_requires_both_lines_one_effect():
    w=SpawnHost(4);walk(w,'bridge');admit(w,['S4_doublehead'])
    e={'event_id':'old_event','patient_id':'old_patient',
       'truth':{'event_id':'old_event','patient_id':'old_patient','verified':True,'result':'dead'},
       'left':{'event_id':'old_event','patient_id':'old_patient','doc_id':'d1','result':'dead'},
       'right':{'event_id':'old_event','patient_id':'old_patient','doc_id':'d2','result':'discharged'}}
    w.host.records.event=e
    assert call(w,'action','records','start_contradiction')
    w.host.paused=True
    assert call(w,'action','records','hear_statement',side='left',formal_dialogue=True)
    assert w.host.life.sp==100
    assert call(w,'action','records','hear_statement',side='right',formal_dialogue=True)
    assert w.host.life.sp==90
    call(w,'action','records','hear_statement',side='right',formal_dialogue=True)
    assert w.host.life.sp==90


def test_s3_delayed_informer_actual_witness_needed_before_chief_receipt():
    w=SpawnHost(3);walk(w,(2,'activity'));admit(w,['S3_postoperative_patient'])
    event=call(w,'report_action','begin_wound',event='wound')
    assert event
    assert not call(w,'report_action','see_wound',event_key=event)
    tick(w,10000);admit(w,['S3_informer_patient'])
    assert not w.host.ward.testimonies
    assert call(w,'report_action','see_wound',event_key=event)
    assert w.actor_move(w.token('informer_walk'),'S3_informer_patient',(2,'corridor'))
    walk(w,(2,'corridor'))
    assert not call(w,'report_action','receive_testimony',event_key=event,target='postop',statement='source statement')
    admit(w,['S3_head_nurse'])
    assert call(w,'report_action','receive_testimony',event_key=event,target='postop',statement='source statement')
    report=call(w,'report_action','write_report',event_key=event,target='postop')
    assert report
    order=call(w,'report_action','sign_isolation',report_id=report,target='postop')
    assert order
    assert not call(w,'isolation_take',order,target='postop')
    walk(w,(2,'quiet'));admit(w,['S3_isolation_orderly'])
    assert call(w,'isolation_take',order,target='postop')
    assert w.host.isolation.phase=='locating'
    assert w.native_room('S3_postoperative_patient')=='2:activity'
    assert not w.host.ward.reports[report]['handled']
    w.invariant()


def test_s3_head_report_waits_for_actual_ordinary_orderly_acceptance():
    w=SpawnHost(3);walk(w,(2,'corridor'));admit(w,['S3_head_nurse'])
    ev=call(w,'report_action','chief_observe_internal',event='internal')
    rid=call(w,'report_action','write_report',event_key=ev,target='avatar')
    assert rid
    assert not call(w,'ordinary_accept',rid,'avatar')
    tick(w,10000);admit(w,['S3_ordinary_orderly'])
    assert call(w,'ordinary_accept',rid,'avatar')
    assert w.host.holder is None
    assert call(w,'ordinary_find')
    assert call(w,'ordinary_grip')
    assert w.host.holder=='orderly'
    assert w.host.life.hp==95 and w.host.life.sp==95


def test_s3_cleaner_and_relics_independent_of_missing_live_characters():
    w=SpawnHost(3);walk(w,(2,'wash'))
    assert not call(w,'cleanup_action','cover')
    assert call(w,'cleanup_action','observe_body')
    admit(w,['S3_cleaner'])
    assert not w.host.cleaning.body_covered
    assert call(w,'cleanup_action','cover')
    assert call(w,'cleanup_action','load_board')
    assert call(w,'cleanup_action','move_body',dest='corridor')
    assert w.native_room('S3_cleaner')=='2:corridor'
    assert all(w.native_room(i) is None for i in ('cross_level_patient','S3_corner_patient','S3_transferred_patient'))
    w.invariant()


def test_s3_registrar_not_required_for_doctor_to_issue_order():
    w=SpawnHost(3);walk(w,(1,'exam'))
    assert not call(w,'records_action','issue_order',order_id='o',subject='avatar')
    admit(w,['S3_psychiatrist'])
    assert call(w,'records_action','issue_order',order_id='o',subject='avatar')
    assert w.native_room('S3_registration_nurse') is None
    walk(w,(1,'treatment'))
    assert not call(w,'medicine_action','prepare',order_id='o',patient_id='avatar')
    admit(w,['S3_treatment_pharmacist'])
    assert call(w,'medicine_action','prepare',order_id='o',patient_id='avatar')
    assert w.native_room('S3_medication_nurse') is None
    assert not w.host.medication.records
    w.invariant()


def test_s3_nurse_cross_floor_one_identity_no_remote_false_record():
    w=SpawnHost(3);walk(w,(1,'exam'));admit(w,['S3_psychiatrist'])
    assert call(w,'records_action','issue_order',order_id='o',subject='avatar')
    walk(w,(1,'treatment'));admit(w,['S3_treatment_pharmacist','S3_medication_nurse'])
    assert call(w,'medicine_action','prepare',order_id='o',patient_id='avatar')
    for dest in ((1,'reception'),(2,'stairs'),(2,'corridor')):
        assert w.actor_move(w.token('nurse_step'),'S3_medication_nurse',dest)
    assert call(w,'medicine_action','refuse',nurse_seen=True)
    assert not w.host.medication.records
    assert w.native_room('S3_medication_nurse')=='2:corridor'
    walk(w,(2,'corridor'));tick(w,20000)
    assert not admit(w,['S3_medication_nurse'])
    assert w.schedule.records['s3_drug'].checks==1
    w.invariant()


def test_s3_archivist_without_guard_can_write_but_cannot_deliver_report():
    w=SpawnHost(3);walk(w,(1,'office'));admit(w,['S3_archivist'])
    assert call(w,'records_action','archive_spotted')
    assert call(w,'records_action','archive_continue')
    assert call(w,'records_action','archive_write')
    assert not call(w,'records_action','archive_deliver')
    assert not w.host.records.report_received
    tick(w,10000);admit(w,['S3_security_guard'])
    assert call(w,'records_action','archive_deliver')
    assert not w.host.holder


@settings(max_examples=160,deadline=None,database=None)
@given(guide=st.booleans(),patient=st.booleans(),porter=st.booleans(),order=st.booleans(),busy=st.booleans(),actual=st.booleans())
def test_random_s2_link_group_presence_not_event_completion(guide,patient,porter,order,busy,actual):
    w=SpawnHost(2);enter(w)
    ids=[i for i,b in zip(('S2_triage_nurse','S2_wheelchair_patient','S2_transfer_worker'),(guide,patient,porter)) if b]
    admit(w,ids)
    if order:call(w,'transfer_action','issue_patient_order',actual=actual)
    w.host.transfer.nurse_busy=busy
    before=resources(w)
    result=call(w,'transfer_action','start_patient')
    assert bool(result)==(guide and patient and porter and order and actual and not busy)
    assert resources(w)==before
    assert w.host.transfer.patient in ('waiting','queued')
    assert not w.host.transfer.departure_record and not w.host.transfer.knowledge
