from collections import deque
from copy import deepcopy
import pytest
from hypothesis import given, settings, strategies as st, note
from hypothesis.stateful import RuleBasedStateMachine, initialize, rule, invariant
from spawn_host import SpawnHost, ALIASES, S2_EDGES
from s3_session import EDGES as S3_EDGES
from s4_session import EDGES as S4_EDGES
from s5_deep_session import EDGES as S5_EDGES


def call(w,method,*args,**kw):return w.call(w.token(method),method,*args,**kw)
def enter(w,hit=True):return w.enter_current(w.token('entry'),rolls=dict.fromkeys(w.schedule.groups,0 if hit else 9999))
def admit(w,identities=None):return w.admit(w.token('admit'),ready=w.aliases if identities is None else identities)
def tick(w,ms):return w.tick(w.token('time'),ms)
def pos(w):return w.host.room if w.level==2 else w.host.position

def walk(w,dest,hit=True):
    edges={2:S2_EDGES,3:S3_EDGES,4:S4_EDGES,5:S5_EDGES}[w.level]
    q=deque([(pos(w),[])]);seen={pos(w)}
    while q:
        r,path=q.popleft()
        if r==dest:
            for v in path:
                assert w.move(w.token('walk'),v,rolls=dict.fromkeys(w.schedule.groups,0 if hit else 9999)),(r,v)
            if not path:enter(w,hit)
            return
        for e in sorted(edges,key=repr):
            if r in e:
                n=next(iter(e-{r}))
                if n not in seen:seen.add(n);q.append((n,path+[n]))
    raise AssertionError(dest)

def spawn_at(w,identities):
    ident=identities[0]
    g=w.schedule.groups[w.schedule.people[ident]['group']]
    room=next(rooms[0] for i,rooms in g.members if i==ident)
    walk(w,w._decode(room));return admit(w,identities)

def resources(w):return (w.host.life.hp,w.host.life.sp,w.host.life.economy.n,w.host.life.economy.c)

def die(w):
    if w.level==2:return call(w,'batch',[('damage',(100,0))])
    if w.level in (3,4):return call(w,'damage_or_exit',hp=100)
    return call(w,'frame',hp_damage=100)

CASES=[(level,ident) for level,m in ALIASES.items() for ident in m]
@pytest.mark.parametrize('level,identity',CASES)
def test_each_canonical_identity_waits_then_populates_native_host_only(level,identity):
    w=SpawnHost(level);h=w.host
    assert w.native_room(identity) is None
    g=w.schedule.groups[w.schedule.people[identity]['group']]
    room=next(rooms[0] for i,rooms in g.members if i==identity)
    walk(w,w._decode(room))
    assert w.schedule.people[identity]['status']=='waiting'
    assert w.native_room(identity) is None
    state=resources(w)
    assert not w.admit(w.token('blocked_entry'),ready=[identity],entry_free=False)
    assert resources(w)==state
    assert admit(w,[identity])==(identity,)
    assert w.native_room(identity) is not None
    assert resources(w)==state
    assert not admit(w,[identity])
    w.invariant()

@pytest.mark.parametrize('level',[2,3,4,5])
@pytest.mark.parametrize('attempt',[1,2,4,5,6,10**9])
def test_actual_death_and_repeat_callbacks_refresh_once_at_key_attempts(level,attempt):
    w=SpawnHost(level,attempt=attempt);enter(w);admit(w)
    old=w.token('old_callback');oldtotal=w.host.life.total
    assert die(w)=='death'
    assert not w.admit(old,ready=w.aliases)
    assert w.revive()
    assert w.schedule.attempt==attempt+1
    assert w.host.life.total==oldtotal+3
    assert not w.revive() and not w.sync_attempt()
    assert not w.admit(old,ready=w.aliases)
    assert not any(p['status']=='present' for p in w.schedule.people.values())
    w.invariant()

@pytest.mark.parametrize('level',[2,3,4,5])
def test_freeze_duplicate_and_blocked_entry_do_not_advance_two_clocks(level):
    w=SpawnHost(level);enter(w)
    t=w.token('time');assert w.tick(t,9999)
    assert not w.tick(t,9999)
    for flag in ('paused','loading'):
        setattr(w.host,flag,True)
        assert not w.tick(w.token('frozen'),999999)
        assert not admit(w)
        assert w.schedule.time_ms==9999
        setattr(w.host,flag,False)
    assert w.tick(w.token('time'),1)
    assert w.schedule.time_ms==10000
    admit(w);w.invariant()

@pytest.mark.parametrize('level,room,actor',[(2,'exam','S2_check_doctor'),(3,(1,'exam'),'S3_psychiatrist'),(4,'memory','S4_sewn_mouth_person'),(5,'memory','S2_junior_nurse')])
@pytest.mark.parametrize('elapsed,checks',[(19999,1),(20000,2),(20001,2)])
def test_native_movement_drives_exact_reentry_clock(level,room,actor,elapsed,checks):
    w=SpawnHost(level);origin=pos(w)
    walk(w,room,False);walk(w,origin,False);tick(w,elapsed)
    walk(w,room,False)
    gid=w.schedule.people[actor]['group']
    assert w.schedule.records[gid].checks==checks
    assert w.schedule.attempt==1

@pytest.mark.parametrize('level',[2,3])
def test_rest_only_native_completed_bed_event_can_refresh(level):
    w=SpawnHost(level);h=w.host
    enter(w);admit(w)
    assert not w.sync_attempt()
    walk(w,'ward' if level==2 else (1,'ward'))
    if level==3:assert call(w,'begin_rest')
    assert not w.rest(w.token('incomplete'),completed=False)
    assert w.schedule.attempt==1
    assert w.rest(w.token('rest'),completed=True)
    assert w.schedule.attempt==2 and h.life.total==2
    assert not w.sync_attempt()
    w.invariant()

@pytest.mark.parametrize('level',[4,5])
def test_battle_and_cortex_cannot_rest_refresh(level):
    w=SpawnHost(level);assert not w.rest(w.token('rest'));assert w.schedule.attempt==1


def test_s2_doctor_absent_then_admitted_does_not_need_assistant_or_generate_damage():
    w=SpawnHost(2);walk(w,'exam')
    assert not call(w,'hospital_action','begin_exam')
    assert admit(w,['S2_check_doctor'])
    assert call(w,'hospital_action','begin_exam')
    assert w.host.hospital.exam=='offered'
    assert w.host.life.hp==100
    assert not w.host.people.assistant_present
    assert not w.host.people.labels


def test_s2_nurse_delayed_batch_heals_once_and_room_return_cannot_refresh():
    w=SpawnHost(2);walk(w,'ward');w.host.life.hp=70
    assert not call(w,'hospital_action','start_bandage')
    assert admit(w,['S2_junior_nurse'])
    assert call(w,'hospital_action','start_bandage')
    tick(w,2999);assert w.host.life.hp==70
    w.host.paused=True;assert not tick(w,50000);w.host.paused=False
    tick(w,1);assert w.host.life.hp==80
    walk(w,'waiting');walk(w,'ward')
    assert not call(w,'hospital_action','start_bandage')
    assert w.host.hospital.healing_count==1


def test_s2_partial_linked_transfer_no_automatic_order_damage_or_departure():
    w=SpawnHost(2);enter(w)
    assert set(admit(w,['S2_triage_nurse','S2_wheelchair_patient']))=={'S2_triage_nurse','S2_wheelchair_patient'}
    t=w.host.transfer
    assert not t.patient_order and t.patient=='waiting' and not t.facts
    assert call(w,'transfer_action','issue_patient_order')
    assert not call(w,'transfer_action','start_patient')
    tick(w,9999);assert not admit(w,['S2_transfer_worker'])
    tick(w,1);assert admit(w,['S2_transfer_worker'])
    assert call(w,'transfer_action','start_patient')
    for step in ('handover','grab_frame','release_fingers','depart'):
        assert call(w,'transfer_action','patient_step',step=step,seen=True)
    assert w.host.life.sp==90
    assert w.schedule.people['S2_wheelchair_patient']['status']=='retired'
    assert not admit(w,['S2_wheelchair_patient'])
    assert not call(w,'transfer_action','patient_step',step='depart',seen=True)
    assert w.host.life.sp==90
    w.invariant()


def test_s2_patient_guard_single_owner_and_actual_retirement():
    w=SpawnHost(2);walk(w,'office')
    assert admit(w,['S2_security_guard','cross_level_patient'])
    assert call(w,'guard_node',encounter=True)=='patient'
    for name in ('approach_patient','reach_patient','grip_patient'):
        assert call(w,'patient_action',name)
    assert not call(w,'hospital_action','grip_guard')
    assert call(w,'patient_action','drag_patient',crossed_exit=True)
    assert w.schedule.people['cross_level_patient']['status']=='retired'
    assert not call(w,'begin_hint',kind='number')
    walk(w,'waiting');tick(w,20000);walk(w,'office');assert not admit(w,['cross_level_patient'])
    w.invariant()


def test_s2_absent_pharmacist_cannot_prepare_but_prepared_cup_survives_departure():
    w=SpawnHost(2);spawn_at(w,['S2_check_doctor'])
    assert call(w,'hospital_action','give_prescription',ident='avatar')
    walk(w,'pharmacy');assert not call(w,'hospital_action','prepare')
    admit(w,['S2_pharmacist']);assert call(w,'hospital_action','prepare')
    assert w.actor_move(w.token('pharm_leave'),'S2_pharmacist','waiting')
    assert call(w,'hospital_action','take_cup')
    assert w.host.hospital.cup=='held'


def test_s3_linked_doctor_assistant_wait_for_both_and_actual_signal():
    w=SpawnHost(3);walk(w,(1,'exam'))
    assert admit(w,['S3_psychiatrist'])
    assert not call(w,'begin_procedure','assistant',doctor_signal=True)
    tick(w,10000);admit(w,['S3_check_assistant'])
    assert not call(w,'begin_procedure','assistant',doctor_signal=False)
    assert call(w,'begin_procedure','assistant',doctor_signal=True)
    assert call(w,'reach');assert call(w,'grip')
    assert w.host.holder=='assistant' and w.host.life.hp==100
    assert call(w,'tighten') and w.host.life.hp==95


def test_s3_cross_patient_escort_updates_same_native_entities_across_layers():
    w=SpawnHost(3);walk(w,(1,'office'))
    admit(w,['S3_security_guard','cross_level_patient'])
    assert call(w,'start_patient_escort');assert call(w,'patient_grip')
    for dest in ((1,'reception'),(2,'stairs'),(2,'corridor'),(2,'double')):
        assert call(w,'escort_step',dest)
        w.invariant()
        assert w.schedule.people['cross_level_patient']['room']==w._room(dest)
    assert w.host.patient_delivered
    walk(w,(2,'double'));tick(w,20000)
    assert not admit(w,['cross_level_patient'])
    assert w.schedule.records['cross_patient'].checks==1


def test_s3_transported_patient_requires_pair_paperwork_and_actual_motion():
    w=SpawnHost(3);walk(w,(2,'corridor'))
    admit(w,['S3_transferred_patient'])
    assert not w.host.transport.spawned
    assert not call(w,'transfer_action','release_brake')
    tick(w,10000);admit(w,['S3_transfer_worker'])
    t=w.host.transport
    assert t.spawned and not t.verified and not t.delivered
    assert t.positions['bed']=='double' and not t.knowledge
    assert call(w,'transfer_action','take_order');assert call(w,'transfer_action','verify')
    assert call(w,'transfer_action','release_brake')
    assert not call(w,'transfer_action','move',dest='quiet')
    assert call(w,'transfer_action','move',dest='corridor')
    assert call(w,'transfer_action','move',dest='quiet')
    assert not t.delivered
    assert call(w,'transfer_action','park') and t.delivered
    assert not w.host.isolation.active
    w.invariant()


def test_s3_therapy_pair_does_not_play_original_or_record_until_actions():
    w=SpawnHost(3);walk(w,(2,'group'))
    admit(w,['S3_treatment_director'])
    assert not call(w,'group_action','start_recording')
    tick(w,10000);admit(w,['S3_speaking_patient'])
    assert not w.host.group.started and not w.host.group.original_spoken
    assert call(w,'group_action','start_recording')
    assert not w.host.group.original_spoken
    assert call(w,'group_action','sit_speaker')
    assert call(w,'group_action','speak_transfer')
    assert w.host.group.original_spoken
    assert not w.host.group.knowledge


def test_s3_worker_can_work_without_supervisor_no_phantom_clamp():
    w=SpawnHost(3);walk(w,(2,'work'));admit(w,['S3_labor_patient'])
    assert call(w,'work_action','labor_action',action='take_paper')
    assert w.host.work.worker_phase=='paper'
    assert not call(w,'work_action','windup')
    assert w.host.holder is None
    tick(w,10000);admit(w,['S3_work_supervisor'])
    assert w.host.work.worker_phase=='paper'
    assert not w.host.work.effects


def test_s4_backturn_needs_native_presence_and_actual_completion():
    w=SpawnHost(4);enter(w)
    assert not call(w,'action','cortex','back_approach')
    admit(w,['S4_back_person'])
    assert call(w,'action','cortex','back_approach')
    assert w.host.cortex.back_phase=='approach'
    assert not call(w,'action','cortex','back_turn',part='head',actual_completed=False)
    assert call(w,'action','cortex','back_turn',part='head')
    assert w.actor_move(w.token('away'),'S4_back_person','memory')
    assert not call(w,'action','cortex','back_turn',part='torso')
    w.invariant()

@pytest.mark.parametrize('identity',['S1_father','S1_mother','S1_cat','S2_archivist','S3_ordinary_orderly','S2_check_doctor','S2_check_assistant','S4_twitch','S4_reverse','S4_face'])
def test_s5_admission_not_attack_or_prior_recognition(identity):
    w=SpawnHost(5);spawn_at(w,[identity]);a=w.aliases[identity];e=w.host.entity(a)
    assert e.hp==e.max_hp and not e.target
    assert not w.host.combat.attacks
    assert not w.host._module(a).recognizes_previous_identity(a)
    assert call(w,'observe',a,actual_visible=True)
    assert call(w,'start_attack',a)
    assert w.host.life.hp==100
    w.invariant()


def test_s5_real_death_retired_without_respawn_same_attempt():
    w=SpawnHost(5);enter(w);admit(w,['S1_dog','S1_father'])
    p=w.host.people
    assert p.damage(p.token('actual_father_hit'),'dog',1,source='father',actual=True)
    w.refresh()
    assert w.schedule.people['S1_dog']['status']=='retired'
    walk(w,'memory');tick(w,20000);walk(w,'atrium')
    assert not admit(w,['S1_dog'])
    assert w.host.people.entities['dog'].hp==0
    assert not w.host.people.street_boost
    w.invariant()


def test_s5_real_movement_preserves_entity_hp_and_attack_generation():
    w=SpawnHost(5);enter(w);admit(w,['S1_father']);e=w.host.entity('father')
    call(w,'observe','father');aid=call(w,'start_attack','father')
    attack=w.host.combat.attacks[aid];phase=attack['phase'];tick(w,1)
    assert w.actor_move(w.token('walk'),'S1_father','decision')
    assert e is w.host.entity('father')
    assert w.host.combat.attacks[aid] is attack and attack['phase']==phase
    assert w.schedule.people['S1_father']['room']=='1:decision'
    w.invariant()


def test_s5_third_floor_required_person_not_in_probability_pool():
    w=SpawnHost(5);walk(w,'hippocampus',False)
    assert w.host.deep.original.present
    assert not admit(w)
    assert all(not i.endswith('original') for i in w.aliases)
    count=len(w.schedule.history)
    walk(w,'thalamus',False);assert len(w.schedule.history)==count
    w.invariant()

class HostMachine(RuleBasedStateMachine):
    @initialize(level=st.sampled_from([2,3,4,5]),attempt=st.sampled_from([1,4,5,6,10**9]))
    def begin(self,level,attempt):
        self.w=SpawnHost(level,attempt=attempt);enter(self.w)
    @rule()
    def admit_all(self):
        w=self.w;before=resources(w);rng=w.schedule.rng.getstate()
        batch=admit(w)
        assert resources(w)==before
        assert rng==w.schedule.rng.getstate()
        note(('admit',batch))
    @rule(index=st.integers(0,57))
    def admit_one(self,index):
        w=self.w;i=list(w.aliases)[index%len(w.aliases)]
        admit(w,[i]);note(('admit_one',i))
    @rule(index=st.integers(0,7))
    def walk_neighbor(self,index):
        w=self.w;edges={2:S2_EDGES,3:S3_EDGES,4:S4_EDGES,5:S5_EDGES}[w.level]
        ns=sorted((next(iter(e-{pos(w)})) for e in edges if pos(w) in e),key=repr)
        if ns:
            n=ns[index%len(ns)];w.move(w.token('walk'),n);note(('walk',n))
    @rule(ms=st.sampled_from([0,1,9999,10000,19999,20000,20001]))
    def time(self,ms):tick(self.w,ms)
    @rule()
    def pause_then_resume(self):
        w=self.w;before=deepcopy(w.schedule.__dict__)
        w.host.paused=True;assert not tick(w,20000);assert not admit(w)
        w.host.paused=False
        assert w.schedule.__dict__==before
    @rule()
    def death_revive_duplicate(self):
        w=self.w;before=w.schedule.attempt
        if w.host.life.phase=='alive':die(w)
        if w.host.life.phase=='dead':
            assert w.revive();assert not w.revive();assert not w.sync_attempt()
            assert w.schedule.attempt==before+1
            enter(w)
    @invariant()
    def shared_identity_truth(self):self.w.invariant()

TestHostMachine=HostMachine.TestCase
TestHostMachine.settings=settings(max_examples=220,stateful_step_count=70,deadline=None,database=None)
