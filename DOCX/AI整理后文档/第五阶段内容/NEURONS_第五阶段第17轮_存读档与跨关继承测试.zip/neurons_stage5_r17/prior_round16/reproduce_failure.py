"""Replay historical snapshot in an isolated temporary folder. Expected to fail."""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,os,json,shutil,tempfile
root=Path(__file__).resolve().parent
if len(sys.argv)<3:raise SystemExit('usage: python reproduce_failure.py SNAPSHOT NODEID [NODEID...]')
name=sys.argv[1]
if name!=Path(name).name or not(root/'snapshots'/name).is_dir():raise SystemExit('unknown snapshot')
out=root/'reproduction'/('failure_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
out.mkdir(parents=True)
with tempfile.TemporaryDirectory(prefix='neurons_failure_') as tmp:
 work=Path(tmp)
 for f in (root/'snapshots'/name).glob('*.py'):shutil.copy2(f,work/f.name)
 cmd=[sys.executable,'-m','pytest',*sys.argv[2:],'-q','--tb=short','--hypothesis-seed=2026101317','--hypothesis-show-statistics']
 r=subprocess.run(cmd,cwd=work,env=dict(os.environ,RUN_REPORT=str(out/'result.json'),PYTHONHASHSEED='0'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/'pytest.log').write_text(r.stdout,encoding='utf8')
 (out/'command.json').write_text(json.dumps({'argv':cmd,'snapshot':name,'expected_failure':True,'pytest_exitstatus':r.returncode},indent=2))
 print(r.stdout);print('Evidence:',out)
 raise SystemExit(r.returncode)
