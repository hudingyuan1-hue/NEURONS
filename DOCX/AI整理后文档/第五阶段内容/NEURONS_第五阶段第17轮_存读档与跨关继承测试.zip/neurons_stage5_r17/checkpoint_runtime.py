"""Ephemeral callback generation around a durable model; no time passes on load.

Saved unfinished actions survive. External callbacks from a discarded runtime
must be reissued against their saved action identity in the newly loaded one.
Use this boundary instead of calling the exposed model with stale native tokens.
"""
from dataclasses import dataclass, field
from uuid import uuid4
import checkpoint_store as store


@dataclass
class RuntimeState:
    model: object
    receipts: set = field(default_factory=set)


@dataclass(frozen=True)
class Ticket:
    generation: str
    epoch: int
    event_id: object


class CallbackRuntime:
    def __init__(self, model, *, _state=None):
        self.state = _state if _state is not None else RuntimeState(model)
        self.generation = uuid4().hex

    @property
    def model(self):
        return self.state.model

    @property
    def life(self):
        return self.model.life if hasattr(self.model, 'life') else self.model.host.life

    def issue(self, event_id):
        hash(event_id)
        return Ticket(self.generation, self.life.epoch, event_id)

    def dispatch(self, ticket, method, *args, **kwargs):
        if (not isinstance(ticket, Ticket) or ticket.generation != self.generation
                or ticket.epoch != self.life.epoch):
            return False
        identity = (ticket.epoch, ticket.event_id)
        if identity in self.state.receipts:
            return False
        if method.startswith('_') or method in {'sync_attempt', 'refresh', 'token', 'invariant'}:
            raise ValueError('not a callback entry')
        result = getattr(self.model, method)((ticket.epoch, ('R17', ticket.event_id)), *args, **kwargs)
        self.state.receipts.add(identity)
        return result

    def save(self, path, **kwargs):
        return store.save(self.state, path, **kwargs)

    @classmethod
    def restore(cls, path):
        state = store.load(path)
        if not isinstance(state, RuntimeState):
            raise store.CheckpointError('callback runtime checkpoint required')
        return cls(state.model, _state=state)
