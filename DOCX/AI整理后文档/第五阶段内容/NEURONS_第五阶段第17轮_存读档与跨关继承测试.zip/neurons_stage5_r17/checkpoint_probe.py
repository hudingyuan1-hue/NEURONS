"""Fresh-process reload probe. Only explicitly listed verification actions."""
from pathlib import Path
import json
import sys
import checkpoint_store as store

source, destination = sys.argv[1:3]
model = store.load(source)
if len(sys.argv) > 3 and sys.argv[3] == 'spawn_tick':
    model.tick(model.token('fresh_process_tick'), int(sys.argv[4]))
store.save(model, destination)
Path(destination + '.probe.json').write_text(json.dumps({
    'pid': __import__('os').getpid(), 'python': sys.version,
    'loaded_class': type(model).__module__ + ':' + type(model).__name__
}, indent=2))
