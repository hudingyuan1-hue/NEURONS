"""R17 versioned JSON object graph and atomic disk checkpoint, not engine saves.

S4:P57/P93/P118/T27/T28R11. Constructors are not called while restoring:
they can issue rewards, draw randomness or rebuild a roster. Shared references,
dictionary order, typed keys, frozen tokens and RNG state are retained.
Only the explicitly named local model classes below can be reconstructed.
"""
from collections import Counter, deque
from fractions import Fraction
from pathlib import Path
import hashlib
import importlib
import json
import math
import os
import random
import sys
import tempfile

SCHEMA = 'NEURONS-rule-checkpoint-v1'
MODEL_MODULES = '''archive_events awareness cleanup combat_flow corner_patient
cortex_events deep_combat deep_environment deep_world event_session evidence_session
exploration_core exploration_operations family family_random family_skill_bridge
group_therapy hidden_street hospital hospital_people hospital_session isolation
patient_transfer personalities player_session player_skills rules s2_skill_adapter
s3_medication s3_records s3_session s3_skill_adapter s4_session s4_skill_adapter
s5_deep_session s5_people s5_session s5_support search_sampling skill_effects
spawn_host spawn_schedule street_combat street_people street_session street_special
street_support transfer ward_final_session ward_reports ward_session white_records
white_routes workroom return_journey checkpoint_runtime'''.split()
ROOT = Path(__file__).resolve().parent


class CheckpointError(ValueError):
    pass


def registry():
    classes = {}
    for name in MODEL_MODULES:
        if not (ROOT / (name + '.py')).exists():
            continue
        module = importlib.import_module(name)
        for key, value in vars(module).items():
            if isinstance(value, type) and value.__module__ == name:
                classes[name + ':' + key] = value
    return classes


def code_fingerprint():
    entries = [(name, hashlib.sha256((ROOT / (name + '.py')).read_bytes()).hexdigest())
               for name in sorted(MODEL_MODULES + ['checkpoint_store'])
               if (ROOT / (name + '.py')).exists()]
    return hashlib.sha256(canonical(entries)).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf8')


def encode(root):
    allowed = {cls: name for name, cls in registry().items()}
    memo, nodes, retained = {}, [], []

    def ref(value):
        kind = type(value)
        if value is None or kind in (str, bool, int):
            return value
        if kind is float:
            if not math.isfinite(value):
                raise CheckpointError('nonfinite number')
            return value
        identity = id(value)
        if identity in memo:
            return {'ref': memo[identity]}
        index = len(nodes)
        memo[identity] = index
        retained.append(value)  # also retain temporary Random.getstate() tuples
        nodes.append(None)
        if kind in (list, tuple, set, frozenset, deque):
            items = list(value)
            # No gameplay ordering is implied by a set; keep bytes reproducible.
            if kind in (set, frozenset):
                items.sort(key=lambda x: (type(x).__name__, repr(x)))
            node = {'kind': kind.__name__, 'items': [ref(x) for x in items]}
            if kind is deque:
                node['maxlen'] = value.maxlen
        elif kind in (dict, Counter):
            node = {'kind': kind.__name__, 'items': [[ref(k), ref(v)] for k, v in value.items()]}
        elif kind is Fraction:
            node = {'kind': 'Fraction', 'numerator': value.numerator, 'denominator': value.denominator}
        elif kind is random.Random:
            node = {'kind': 'Random', 'state': ref(value.getstate())}
        elif kind in allowed:
            attrs = object.__getattribute__(value, '__dict__')
            node = {'kind': 'object', 'class': allowed[kind],
                    'attrs': {k: ref(attrs[k]) for k in sorted(attrs)}}
        else:
            raise CheckpointError('unsupported type: ' + kind.__module__ + '.' + kind.__name__)
        nodes[index] = node
        return {'ref': index}

    top = ref(root)
    return {'root': top, 'nodes': nodes}


def decode(graph):
    allowed = registry()
    if not isinstance(graph, dict) or set(graph) != {'root', 'nodes'} or not isinstance(graph['nodes'], list):
        raise CheckpointError('invalid graph')
    nodes = graph['nodes']
    objects, states = {}, {}
    for i, node in enumerate(nodes):
        if not isinstance(node, dict):
            raise CheckpointError('invalid node')
        kind = node.get('kind')
        if kind == 'object':
            cls = allowed.get(node.get('class'))
            if cls is None:
                raise CheckpointError('unknown model class')
            objects[i] = object.__new__(cls)
        elif kind in ('list', 'dict', 'Counter', 'set'):
            objects[i] = {'list': list, 'dict': dict, 'Counter': Counter, 'set': set}[kind]()
        elif kind == 'deque':
            objects[i] = deque(maxlen=node.get('maxlen'))
        elif kind == 'Random':
            objects[i] = random.Random(0)
        elif kind not in ('tuple', 'frozenset', 'Fraction'):
            raise CheckpointError('unknown node kind')

    def value(encoded):
        if encoded is None or type(encoded) in (str, bool, int):
            return encoded
        if type(encoded) is float and math.isfinite(encoded):
            return encoded
        if not isinstance(encoded, dict) or set(encoded) != {'ref'}:
            raise CheckpointError('invalid reference')
        i = encoded['ref']
        if type(i) is not int or not 0 <= i < len(nodes):
            raise CheckpointError('reference outside graph')
        if states.get(i) == 'done':
            return objects[i]
        if states.get(i) == 'building':
            if i not in objects:
                raise CheckpointError('immutable-only cycle')
            return objects[i]
        states[i] = 'building'
        node, kind = nodes[i], nodes[i]['kind']
        if kind == 'object':
            attrs = node['attrs']
            if not isinstance(attrs, dict) or any(type(k) is not str for k in attrs):
                raise CheckpointError('invalid attributes')
            object.__getattribute__(objects[i], '__dict__').update({k: value(v) for k, v in attrs.items()})
        elif kind in ('dict', 'Counter'):
            for k, v in node['items']:
                objects[i][value(k)] = value(v)
        elif kind in ('list', 'deque'):
            objects[i].extend(value(x) for x in node['items'])
        elif kind == 'set':
            objects[i].update(value(x) for x in node['items'])
        elif kind == 'tuple':
            objects[i] = tuple(value(x) for x in node['items'])
        elif kind == 'frozenset':
            objects[i] = frozenset(value(x) for x in node['items'])
        elif kind == 'Fraction':
            objects[i] = Fraction(node['numerator'], node['denominator'])
        elif kind == 'Random':
            objects[i].setstate(value(node['state']))
        states[i] = 'done'
        return objects[i]

    try:
        result = value(graph['root'])
        if len(states) != len(nodes):
            raise CheckpointError('unreachable graph node')
        return result
    except (KeyError, TypeError, IndexError, OverflowError, RecursionError) as exc:
        raise CheckpointError('malformed graph: ' + type(exc).__name__) from exc


def state_bytes(model):
    """Canonical comparison only; never an in-memory substitute for disk tests."""
    return canonical(encode(model))


def save(model, path, *, fault=None):
    """Atomic old-or-new checkpoint. Fault hook models bounded write interruptions."""
    path = Path(path)
    graph = encode(model)
    body = {'schema': SCHEMA, 'python': list(sys.version_info[:2]),
            'code': code_fingerprint(), 'graph': graph}
    blob = canonical({'body': body, 'sha256': hashlib.sha256(canonical(body)).hexdigest()})
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.' + path.name + '-', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            if fault:
                fault('before_write')
            stream.write(blob)
            stream.flush()
            os.fsync(stream.fileno())
        if fault:
            fault('before_replace')
        os.replace(temp, path)
        if fault:
            fault('after_replace')
        if hasattr(os, 'O_DIRECTORY'):
            folder = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(folder)
            finally:
                os.close(folder)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()}


def load(path):
    try:
        envelope = json.loads(Path(path).read_bytes())
        if not isinstance(envelope, dict) or set(envelope) != {'body', 'sha256'}:
            raise CheckpointError('invalid envelope')
        body = envelope['body']
        if hashlib.sha256(canonical(body)).hexdigest() != envelope['sha256']:
            raise CheckpointError('checkpoint checksum mismatch')
        if body.get('schema') != SCHEMA:
            raise CheckpointError('unsupported checkpoint schema')
        if body.get('python') != list(sys.version_info[:2]):
            raise CheckpointError('Python runtime version mismatch')
        if body.get('code') != code_fingerprint():
            raise CheckpointError('model code version mismatch; migration required')
        return decode(body['graph'])
    except CheckpointError:
        raise
    except (ValueError, KeyError, TypeError, UnicodeError, RecursionError) as exc:
        raise CheckpointError('invalid checkpoint: ' + type(exc).__name__) from exc
