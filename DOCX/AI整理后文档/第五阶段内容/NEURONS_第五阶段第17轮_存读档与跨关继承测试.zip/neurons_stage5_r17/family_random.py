"""R15 actual S1 probability callbacks. Source S4:P121-141.

Family owns outcomes. Independent RNG domain owns only random selections;
queued parents do not count as present. This does not simulate animations.
"""
from fractions import Fraction
from hashlib import sha256
from random import Random
from family import Family, ParentDraws


class FamilyRandom:
    EXTRA_NODES={'door_enter','gift_done','before_grab','before_cross'}

    def __init__(self,family=None,seed=2026101316):
        self.family=family or Family();self.seed=seed;self.serial=0
        self.attempt=None;self.opened=False;self.draws=None
        self.roll_history=[];self.entry_nodes=set();self.extra_nodes=set()
        self.settled=0;self._sync()

    def _sync(self):
        f=self.family;k=f.life.attempts[1]
        if k!=self.attempt:
            self.attempt=k;self.draws=ParentDraws(k=k);self.opened=False
            self.settled=0;self.entry_nodes.clear();self.extra_nodes.clear()
            self.rng=Random(int.from_bytes(sha256(f'{self.seed}|S1-NPC|{k}'.encode()).digest(),'big'))

    def token(self):
        self.serial+=1
        return (self.family.life.epoch,self.serial)

    def _active(self,paused=False):
        self._sync()
        return self.family.alive_home() and not paused

    def _roll(self,label,provided=None):
        value=self.rng.randrange(10000) if provided is None else provided
        if type(value) is not int or not 0<=value<10000:raise ValueError('basis point roll 0..9999')
        self.roll_history.append((self.attempt,label,value))
        return value

    @staticmethod
    def thresholds(k):
        if type(k) is not int or k<1:raise ValueError('positive actual attempt')
        step=min(k-1,4)
        return {'dog':(40+5*step)*100,'cat':(35+5*step)*100,
                'mother':(12+2*step)*100,'father':(8+2*step)*100,
                'extra':(8+2*step)*100}

    def opening(self,*,actual=True,paused=False,dog_roll=None,cat_roll=None):
        if not self._active(paused) or not actual or self.opened:return None
        limits=self.thresholds(self.attempt)
        dog=self._roll('dog',dog_roll)<limits['dog']
        cat=self._roll('cat',cat_roll)<limits['cat']
        self.opened=True;f=self.family
        f.dog=dog;f.cat='fighting' if dog and cat else 'occupying' if cat else 'absent'
        return dog,cat

    def settle(self,search_id,*,complete=True,paused=False,mother_roll=None,father_roll=None,first=None):
        if not self._active(paused) or search_id not in self.family.search.pending:return False
        actor,_=self.family.search.pending[search_id]
        if not self.family.settle(search_id,complete=complete):return False
        if actor!='avatar':return True
        self.settled+=1
        if self.settled not in (2,4,6,8) or self.family.event_busy():return True
        mr=self._roll('mother',mother_roll);fr=self._roll('father',father_roll)
        if first is None:first='mother' if self.rng.randrange(2)==0 else 'father'
        if first not in ('mother','father'):raise ValueError('parent order')
        self.draws.normal(self.settled,Fraction(mr,100),Fraction(fr,100),first=first)
        return True

    def enter_next(self,node,*,actual_entry=True,entry_free=True,legal_node=True,paused=False):
        f=self.family
        if (not self._active(paused) or node[0]!=f.life.epoch or node in self.entry_nodes
                or not actual_entry or not entry_free or not legal_node or not self.draws.queue):return False
        parent=self.draws.queue.pop(0)
        result=f.appear(parent)
        if result:self.entry_nodes.add(node)
        return result

    def extra(self,node,present,*,node_kind,paused=False,roll=None):
        f=self.family
        if (not self._active(paused) or node[0]!=f.life.epoch or node in self.extra_nodes
                or present not in ('mother','father') or node_kind not in self.EXTRA_NODES):return False
        if getattr(f,present) in ('absent','gone','saved'):return False
        other='father' if present=='mother' else 'mother'
        if self.draws.extra_used or other in self.draws.selected:return False
        value=self._roll('extra',roll);self.extra_nodes.add(node)
        return self.draws.extra(present,Fraction(value,100))

    def place_gift(self,node,*,actual_placed=True,paused=False,roll=None):
        f=self.family
        if (not self._active(paused) or node[0]!=f.life.epoch or not actual_placed
                or f.gifted or f.mother not in ('porridge','chocolate','door_gift')):return False
        value=Fraction(self._roll('gift',roll),100) if f.mother=='door_gift' else 0
        return f.complete_gift(value)
