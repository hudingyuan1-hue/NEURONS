"""S3 floor 2: facts, testimony, reports and physical document handoffs.

No health, movement of targets, restraint or isolation timer is implemented here.
Positions are rooms within floor 2. `place` is an explicit test fixture input;
`move` validates the documented star corridor graph.
"""
from copy import deepcopy


ROOMS = {'stairs', 'corridor', 'activity', 'group', 'quiet', 'wash', 'double', 'work'}
EDGES = {frozenset(('corridor', r)) for r in ROOMS - {'corridor'}}
ENTITIES = ('chief', 'informant', 'orderly', 'isolator', 'avatar', 'postop', 'transferred')


class WardReports:
    def __init__(self, attempt=1):
        self.attempt = attempt
        self.paused = self.dead = False
        self.positions = {actor: None for actor in ENTITIES}
        self.busy = set()
        self.tokens = set()
        self.events = {}
        self.reports = {}
        self.isolation_orders = {}
        self.transfers = {}
        self.knowledge = {}
        self.testimonies = {}
        self.permits = set()
        self.jobs = {'orderly': None, 'isolator': None}
        self.exposures = set()
        self.history = []

    def _node(self, token, actual=True):
        if self.paused or self.dead or not actual or token[0] != self.attempt or token in self.tokens:
            return False
        self.tokens.add(token)
        return True

    def place(self, actor, room):
        if actor not in self.positions or (room is not None and room not in ROOMS):
            return False
        self.positions[actor] = room
        return True

    def move(self, token, actor, dest, actual=True):
        if not self._node(token, actual) or actor not in self.positions:
            return False
        if frozenset((self.positions[actor], dest)) not in EDGES:
            return False
        self.positions[actor] = dest
        return True

    def _together(self, *actors, room=None):
        places = [self.positions.get(a) for a in actors]
        return bool(places) and places[0] is not None and len(set(places)) == 1 and (room is None or places[0] == room)

    def _current(self, row):
        return bool(row and row['attempt'] == self.attempt)

    def _event_key(self, event):
        return (self.attempt, event)

    def chief_observe_internal(self, token, event, target='avatar', internal=True, actual=True):
        if not self._node(token, actual) or not internal or target != 'avatar' or not self._together('chief', target, room='corridor'):
            return False
        key = self._event_key(event)
        if key in self.events:
            return False
        self.events[key] = {'id': key, 'attempt': self.attempt, 'kind': 'internal_read', 'target': target, 'room': 'corridor', 'witnesses': {'chief'}}
        self.knowledge[('chief', key)] = {'target': target, 'last_location': 'corridor', 'kind': 'eyewitness'}
        return key

    def begin_wound(self, token, event, target='postop', actual=True, visible=True):
        if not self._node(token, actual) or not visible or target != 'postop' or not self._together(target, 'avatar', room='activity'):
            return False
        if any(self.positions[a] == 'activity' for a in ('chief', 'informant', 'orderly', 'isolator', 'transferred')):
            return False
        key = self._event_key(event)
        if key in self.events or any(x['attempt'] == self.attempt and x['target'] == target and x['kind'] == 'wound' for x in self.events.values()):
            return False
        self.events[key] = {'id': key, 'attempt': self.attempt, 'kind': 'wound', 'target': target, 'room': 'activity', 'witnesses': {'avatar'}}
        self.knowledge[('avatar', key)] = {'target': target, 'last_location': 'activity', 'kind': 'eyewitness'}
        self.exposures.add(key)
        return key

    def end_wound(self, token, event_key, actual=True):
        if not self._node(token, actual) or event_key not in self.exposures:
            return False
        self.exposures.remove(event_key)
        return True

    def see_wound(self, token, event_key, observer='informant', actual=True, unobstructed=True):
        row = self.events.get(event_key)
        if not self._node(token, actual) or not self._current(row) or row['kind'] != 'wound' or event_key not in self.exposures or not unobstructed or observer != 'informant':
            return False
        if not self._together(observer, row['target'], room='activity'):
            return False
        row['witnesses'].add(observer)
        self.knowledge[(observer, event_key)] = {'target': row['target'], 'last_location': 'activity', 'kind': 'eyewitness'}
        return True

    def receive_testimony(self, token, event_key, target, statement, actual=True):
        row = self.events.get(event_key)
        if not self._node(token, actual) or not self._current(row) or row['kind'] != 'wound' or row['target'] != target or ('informant', event_key) not in self.knowledge:
            return False
        if 'chief' in self.busy or not self._together('chief', 'informant', room='corridor') or event_key in self.testimonies:
            return False
        self.testimonies[event_key] = {'attempt': self.attempt, 'reporter': 'informant', 'target': target, 'statement': statement, 'received_by': 'chief'}
        self.knowledge[('chief', event_key)] = {'target': target, 'last_location': self.knowledge[('informant', event_key)]['last_location'], 'kind': 'testimony'}
        return True

    def write_report(self, token, event_key, target, complete=True, actual=True):
        event = self.events.get(event_key)
        if not self._node(token, actual) or not complete or not self._current(event) or event['target'] != target or self.positions['chief'] != 'corridor' or 'chief' in self.busy:
            return False
        known = self.knowledge.get(('chief', event_key))
        if known is None or (event['kind'] == 'wound' and event_key not in self.testimonies):
            return False
        if any(r['event'] == event_key for r in self.reports.values()):
            return False
        rid = ('report', *event_key)
        self.reports[rid] = {'id': rid, 'event': event_key, 'attempt': self.attempt, 'target': target, 'issuer': 'chief', 'last_location': known['last_location'], 'source': known['kind'], 'written': True, 'at_station': True, 'signed_isolation': False, 'report_taken': False, 'handled': False, 'outcome': None, 'state': 'waiting'}
        return rid

    def give_permit(self, token, event_key, recipient='informant', actual=True):
        if not self._node(token, actual) or recipient != 'informant' or event_key not in self.testimonies or event_key[0] != self.attempt or event_key in self.permits or 'chief' in self.busy or not self._together('chief', 'informant', room='corridor'):
            return False
        self.permits.add(event_key)
        return True

    def sign_isolation(self, token, report_id, target, issuer='chief', actual=True):
        row = self.reports.get(report_id)
        if not self._node(token, actual) or not self._current(row) or row['target'] != target or issuer != 'chief' or self.positions['chief'] != 'corridor' or 'chief' in self.busy or row['signed_isolation']:
            return False
        oid = ('isolation', *row['event'])
        self.isolation_orders[oid] = {'id': oid, 'attempt': self.attempt, 'event': row['event'], 'target': target, 'issuer': 'chief', 'report_id': report_id, 'source': 'report', 'last_location': row['last_location'], 'taken': False, 'handled': False, 'outcome': None}
        row['signed_isolation'] = True
        return oid

    def accept_ordinary(self, token, report_id, target, actor='orderly', actual=True):
        row = self.reports.get(report_id)
        if not self._node(token, actual) or not self._current(row) or actor != 'orderly' or row['target'] != target or row['report_taken'] or row['handled'] or self.positions['orderly'] != 'corridor' or self.jobs['orderly'] is not None or 'orderly' in self.busy:
            return False
        row['report_taken'] = True
        row['state'] = 'accepted'
        self.jobs['orderly'] = report_id
        return True

    def confirm_target(self, token, document_id, target, actor='orderly', actual=True):
        rows = self.reports if actor == 'orderly' else self.isolation_orders if actor == 'isolator' else {}
        row = rows.get(document_id)
        if not self._node(token, actual) or not self._current(row) or row['target'] != target or self.jobs.get(actor) != document_id or not self._together(actor, target):
            return False
        return True

    def finish_ordinary(self, token, report_id, outcome, actual=True):
        row = self.reports.get(report_id)
        if not self._node(token, actual) or not self._current(row) or self.jobs['orderly'] != report_id or outcome not in {'delivered', 'not_found', 'missed', 'cancelled', 'death', 'timeout'}:
            return False
        row.update(handled=True, outcome=outcome, state='closed')
        self.jobs['orderly'] = None
        self.history.append(('ordinary', report_id, outcome))
        return True

    def register_transfer(self, token, transfer_id, target='transferred', patient_id='transfer-patient', wrist_id='transfer-patient', bed_id='transfer-patient', signed=True, actual=True):
        if not self._node(token, actual) or target != 'transferred' or not signed or patient_id != wrist_id or patient_id != bed_id:
            return False
        tid = ('transfer', self.attempt, transfer_id)
        if tid in self.transfers:
            return False
        self.transfers[tid] = {'id': tid, 'attempt': self.attempt, 'target': target, 'patient_id': patient_id, 'signed_transfer': True, 'chief_verified': False, 'isolation_signed': False}
        return tid

    def verify_transfer(self, token, transfer_id, observed_patient_id, actual=True):
        row = self.transfers.get(transfer_id)
        if not self._node(token, actual) or not self._current(row) or row['patient_id'] != observed_patient_id or 'chief' in self.busy or not self._together('chief', row['target'], room='corridor'):
            return False
        row['chief_verified'] = True
        return True

    def sign_transfer_isolation(self, token, transfer_id, target='transferred', issuer='chief', actual=True):
        row = self.transfers.get(transfer_id)
        if not self._node(token, actual) or not self._current(row) or not row['chief_verified'] or row['target'] != target or row['isolation_signed'] or issuer != 'chief' or self.positions['chief'] != 'corridor' or 'chief' in self.busy:
            return False
        oid = ('isolation', *transfer_id)
        self.isolation_orders[oid] = {'id': oid, 'attempt': self.attempt, 'event': transfer_id, 'target': target, 'issuer': 'chief', 'report_id': None, 'source': 'transfer', 'last_location': 'corridor', 'taken': False, 'handled': False, 'outcome': None}
        row['isolation_signed'] = True
        return oid

    def isolation_authorization(self, order_id, target):
        row = self.isolation_orders.get(order_id)
        if not self._current(row) or row['target'] != target or row['taken'] or row['handled']:
            return None
        if row['source'] == 'report' and not self.reports[row['report_id']]['handled']:
            return None
        return deepcopy(row)

    def accept_isolation(self, token, order_id, target, actor='isolator', actual=True):
        if not self._node(token, actual) or actor != 'isolator' or self.positions['isolator'] != 'corridor' or 'isolator' in self.busy or self.jobs['isolator'] is not None or self.isolation_authorization(order_id, target) is None:
            return False
        self.isolation_orders[order_id]['taken'] = True
        self.jobs['isolator'] = order_id
        return True

    def finish_isolation(self, token, order_id, outcome, actual=True):
        row = self.isolation_orders.get(order_id)
        if not self._node(token, actual) or not self._current(row) or self.jobs['isolator'] != order_id or outcome not in {'delivered', 'not_found', 'missed', 'cancelled', 'death', 'timeout'}:
            return False
        row.update(handled=True, outcome=outcome)
        self.jobs['isolator'] = None
        self.history.append(('isolation', order_id, outcome))
        return True

    def new_attempt(self, number):
        if number <= self.attempt:
            return False
        for actor, doc in self.jobs.items():
            if doc is not None:
                rows = self.reports if actor == 'orderly' else self.isolation_orders
                rows[doc].update(handled=True, outcome='attempt_ended')
                if actor == 'orderly':
                    rows[doc]['state'] = 'closed'
        self.history.append(('new_attempt', self.attempt, number))
        self.attempt = number
        self.tokens.clear()
        self.jobs = {'orderly': None, 'isolator': None}
        self.exposures.clear()
        self.positions = {actor: None for actor in ENTITIES}
        self.busy.clear()
        self.paused = self.dead = False
        return True

    def reload(self):
        return deepcopy(self)
