from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from ward_reports import WardReports, ENTITIES, ROOMS


def token(m, n):
    return (m.attempt, n)


def direct(m=None):
    m = m or WardReports()
    m.place('chief', 'corridor')
    m.place('avatar', 'corridor')
    e = m.chief_observe_internal(token(m, 'seen'), 'private-page')
    r = m.write_report(token(m, 'write'), e, 'avatar')
    return m, e, r


def wound(m=None):
    m = m or WardReports()
    m.place('avatar', 'activity')
    m.place('postop', 'activity')
    e = m.begin_wound(token(m, 'expose'), 'wound-1')
    return m, e


def report_wound():
    m, e = wound()
    m.place('informant', 'corridor')
    assert m.move(token(m, 'enter'), 'informant', 'activity')
    assert m.see_wound(token(m, 'see'), e)
    assert m.move(token(m, 'leave'), 'informant', 'corridor')
    m.place('chief', 'corridor')
    assert m.receive_testimony(token(m, 'tell'), e, 'postop', 'He displayed the wound.')
    r = m.write_report(token(m, 'write'), e, 'postop')
    return m, e, r


@pytest.mark.parametrize('internal,actual', [(False, True), (True, False), (False, False)])
def test_public_roster_and_unobserved_read_are_not_events(internal, actual):
    m = WardReports()
    m.place('chief', 'corridor'); m.place('avatar', 'corridor')
    assert not m.chief_observe_internal(token(m, 1), 'x', internal=internal, actual=actual)
    assert not m.events and not m.reports


@pytest.mark.parametrize('absent', ['chief', 'avatar'])
def test_internal_read_requires_actual_same_room(absent):
    m = WardReports(); m.place('chief', 'corridor'); m.place('avatar', 'corridor')
    m.place(absent, 'activity')
    assert not m.chief_observe_internal(token(m, 1), 'x')


@pytest.mark.parametrize('spectator', ['chief', 'informant', 'orderly', 'isolator', 'transferred'])
def test_wound_cannot_start_with_another_observer(spectator):
    m = WardReports(); m.place('avatar', 'activity'); m.place('postop', 'activity'); m.place(spectator, 'activity')
    assert not m.begin_wound(token(m, 1), 'w')


def test_late_arrival_while_exposed_is_valid_but_after_cover_is_not():
    m, e = wound(); m.place('informant', 'corridor')
    assert not m.see_wound(token(m, 1), e)
    m.move(token(m, 2), 'informant', 'activity')
    assert not m.see_wound(token(m, 3), e, unobstructed=False)
    assert m.see_wound(token(m, 4), e)
    m.end_wound(token(m, 5), e)
    assert not m.see_wound(token(m, 6), e)
    assert m.events[e]['witnesses'] == {'avatar', 'informant'}


def test_conversation_only_cannot_be_reported_as_wound():
    m = WardReports(); m.place('chief', 'corridor'); m.place('informant', 'corridor')
    assert not m.receive_testimony(token(m, 1), (1, 'unseen'), 'postop', 'wound')
    assert not m.reports and not m.testimonies


def test_wound_once_per_attempt_and_reload():
    m, e = wound(); m.end_wound(token(m, 1), e); m = m.reload()
    assert not m.begin_wound(token(m, 2), 'wound-2')
    m.new_attempt(2); m.place('avatar', 'activity'); m.place('postop', 'activity')
    assert m.begin_wound(token(m, 2), 'wound-2')


@pytest.mark.parametrize('missing', ['chief', 'informant'])
def test_report_reception_requires_physical_arrival(missing):
    m, e = wound(); m.place('informant', 'activity'); m.see_wound(token(m, 1), e)
    m.place('chief', 'corridor'); m.place('informant', 'corridor'); m.place(missing, 'activity')
    assert not m.receive_testimony(token(m, 2), e, 'postop', 'wound')
    assert not m.give_permit(token(m, 3), e)


def test_busy_chief_waits_then_receives_without_replaying_fact():
    m, e = wound(); m.place('informant', 'activity'); m.see_wound(token(m, 1), e)
    m.place('chief', 'corridor'); m.place('informant', 'corridor'); m.busy.add('chief')
    assert not m.receive_testimony(token(m, 2), e, 'postop', 'wound')
    m.busy.clear()
    assert m.receive_testimony(token(m, 3), e, 'postop', 'wound')
    assert m.knowledge[('chief', e)]['kind'] == 'testimony'
    assert 'chief' not in m.events[e]['witnesses']


def test_statement_does_not_overwrite_actual_fact_or_grant_avatar_knowledge():
    m, e, r = report_wound()
    assert m.events[e]['kind'] == 'wound'
    assert m.reports[r]['source'] == 'testimony'
    assert m.knowledge[('avatar', e)]['kind'] == 'eyewitness'
    assert ('avatar', ('testimony', e)) not in m.knowledge
    assert m.testimonies[e]['target'] == 'postop'


@pytest.mark.parametrize('recipient', ['avatar', 'chief', 'postop', 'orderly'])
def test_leave_permit_only_belongs_to_informant(recipient):
    m, e, r = report_wound()
    assert not m.give_permit(token(m, 1), e, recipient=recipient)
    assert not m.permits


def test_permit_requires_actual_handoff_and_is_not_disappearance():
    m, e, r = report_wound()
    assert not m.give_permit(token(m, 1), e, actual=False)
    assert m.give_permit(token(m, 2), e)
    assert m.positions['informant'] == 'corridor'
    assert not m.give_permit(token(m, 3), e)


@pytest.mark.parametrize('blocked', ['incomplete', 'absent', 'busy', 'wrong_target', 'not_actual'])
def test_unwritten_report_does_not_dispatch(blocked):
    m = WardReports(); m.place('chief', 'corridor'); m.place('avatar', 'corridor')
    e = m.chief_observe_internal(token(m, 1), 'e')
    if blocked == 'absent': m.place('chief', None)
    if blocked == 'busy': m.busy.add('chief')
    r = m.write_report(token(m, 2), e, 'postop' if blocked == 'wrong_target' else 'avatar', complete=blocked != 'incomplete', actual=blocked != 'not_actual')
    assert not r and not m.reports and m.jobs['orderly'] is None


def test_same_event_produces_one_report_and_isolation_order():
    m, e, r = direct()
    assert not m.write_report(token(m, 1), e, 'avatar')
    o = m.sign_isolation(token(m, 2), r, 'avatar')
    assert o
    assert not m.sign_isolation(token(m, 3), r, 'avatar')
    assert len(m.reports) == len(m.isolation_orders) == 1


@pytest.mark.parametrize('blocked', ['absent', 'busy', 'wrong_target', 'wrong_actor', 'not_actual'])
def test_pending_report_waits_for_actual_available_orderly(blocked):
    m, e, r = direct(); m.place('orderly', 'corridor')
    if blocked == 'absent': m.place('orderly', None)
    if blocked == 'busy': m.busy.add('orderly')
    assert not m.accept_ordinary(token(m, 1), r, 'postop' if blocked == 'wrong_target' else 'avatar', actor='isolator' if blocked == 'wrong_actor' else 'orderly', actual=blocked != 'not_actual')
    assert m.reports[r]['state'] == 'waiting'
    assert not m.reports[r]['report_taken'] and m.jobs['orderly'] is None


def test_accept_is_not_grip_and_report_cannot_be_replayed():
    m, e, r = direct(); m.place('orderly', 'corridor')
    assert m.accept_ordinary(token(m, 1), r, 'avatar')
    assert m.positions['avatar'] == 'corridor'
    assert not m.reports[r]['handled']
    assert not m.accept_ordinary(token(m, 2), r, 'avatar')
    assert m.finish_ordinary(token(m, 3), r, 'missed')
    assert not m.accept_ordinary(token(m, 4), r, 'avatar')
    assert not m.finish_ordinary(token(m, 5), r, 'delivered')


@pytest.mark.parametrize('outcome', ['delivered', 'not_found', 'missed', 'cancelled', 'death', 'timeout'])
def test_completed_ordinary_attempt_allows_separate_isolation_handoff(outcome):
    m, e, r = direct(); m.place('orderly', 'corridor'); m.place('isolator', 'corridor')
    o = m.sign_isolation(token(m, 1), r, 'avatar')
    assert not m.accept_isolation(token(m, 2), o, 'avatar')
    assert m.accept_ordinary(token(m, 3), r, 'avatar')
    assert not m.accept_isolation(token(m, 4), o, 'avatar')
    assert m.finish_ordinary(token(m, 5), r, outcome)
    assert m.accept_isolation(token(m, 6), o, 'avatar')
    assert not m.accept_ordinary(token(m, 7), r, 'avatar')


def test_report_uses_last_witnessed_location_not_remote_target_position():
    m, e, r = report_wound(); m.place('postop', 'double')
    assert m.reports[r]['last_location'] == 'activity'
    m.place('orderly', 'corridor'); m.accept_ordinary(token(m, 1), r, 'postop')
    assert not m.confirm_target(token(m, 2), r, 'postop')
    m.place('orderly', 'activity')
    assert not m.confirm_target(token(m, 3), r, 'postop')
    m.place('orderly', 'double')
    assert m.confirm_target(token(m, 4), r, 'postop')
    assert not m.confirm_target(token(m, 5), r, 'avatar')


@pytest.mark.parametrize('issuer', ['orderly', 'isolator', 'informant', 'pharmacist'])
def test_only_chief_can_sign_isolation(issuer):
    m, e, r = direct()
    assert not m.sign_isolation(token(m, 1), r, 'avatar', issuer=issuer)
    assert not m.isolation_orders


def test_transfer_order_is_not_isolation_or_eyewitness():
    m = WardReports()
    t = m.register_transfer(token(m, 1), 't')
    assert t and not m.knowledge and not m.isolation_orders
    assert not m.sign_transfer_isolation(token(m, 2), t)
    assert not m.accept_isolation(token(m, 3), t, 'transferred')


@pytest.mark.parametrize('wrong', ['wrist_id', 'bed_id'])
def test_transfer_requires_same_patient_identity(wrong):
    m = WardReports()
    assert not m.register_transfer(token(m, 1), 't', **{wrong: 'somebody-else'})


def test_transfer_actual_chief_identity_check_and_separate_signature():
    m = WardReports(); t = m.register_transfer(token(m, 1), 't')
    m.place('transferred', 'corridor')
    assert not m.verify_transfer(token(m, 2), t, 'transfer-patient')
    m.place('chief', 'corridor')
    assert not m.verify_transfer(token(m, 3), t, 'avatar')
    assert m.verify_transfer(token(m, 4), t, 'transfer-patient')
    assert not m.isolation_orders
    o = m.sign_transfer_isolation(token(m, 5), t)
    assert o and not m.reports
    m.place('isolator', 'corridor')
    assert m.accept_isolation(token(m, 6), o, 'transferred')
    assert not m.confirm_target(token(m, 7), o, 'avatar', actor='isolator')
    assert m.confirm_target(token(m, 8), o, 'transferred', actor='isolator')


@pytest.mark.parametrize('method', ['accept_ordinary', 'sign_isolation', 'finish_ordinary'])
def test_old_attempt_callbacks_cannot_execute(method):
    m, e, r = direct(); m.place('orderly', 'corridor'); m.accept_ordinary(token(m, 1), r, 'avatar')
    m.new_attempt(2); m.place('chief', 'corridor'); m.place('orderly', 'corridor')
    assert not getattr(m, method)((1, 'late'), r, 'cancelled' if method == 'finish_ordinary' else 'avatar')
    assert not getattr(m, method)((2, 'late-new-token'), r, 'cancelled' if method == 'finish_ordinary' else 'avatar')
    assert r in m.reports and m.reports[r]['outcome'] == 'attempt_ended'
    assert m.jobs == {'orderly': None, 'isolator': None}


@pytest.mark.parametrize('flag', ['paused', 'dead'])
def test_paused_dead_has_no_new_handoff(flag):
    m, e, r = direct(); m.place('orderly', 'corridor'); setattr(m, flag, True)
    before = deepcopy(m.__dict__)
    assert not m.accept_ordinary(token(m, 1), r, 'avatar')
    assert m.__dict__ == before


def test_same_token_repeat_and_reload_are_idempotent():
    m, e, r = direct(); m.place('orderly', 'corridor')
    assert m.accept_ordinary(token(m, 1), r, 'avatar')
    m = m.reload()
    assert not m.accept_ordinary(token(m, 1), r, 'avatar')
    assert len(m.reports) == 1


class ReportMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__(); self.m = WardReports(); self.seq = 0

    def tok(self):
        self.seq += 1
        return (self.m.attempt, self.seq)

    @rule(actor=st.sampled_from(ENTITIES), room=st.one_of(st.none(), st.sampled_from(sorted(ROOMS))))
    def presence(self, actor, room):
        self.m.place(actor, room)

    @rule(actor=st.sampled_from(ENTITIES), dest=st.sampled_from(sorted(ROOMS)))
    def walk(self, actor, dest):
        self.m.move(self.tok(), actor, dest)

    @rule(kind=st.sampled_from(['private', 'wound']), event=st.integers(0, 4))
    def start(self, kind, event):
        if kind == 'private': self.m.chief_observe_internal(self.tok(), event)
        else: self.m.begin_wound(self.tok(), event)

    @rule(op=st.sampled_from(['see', 'cover', 'tell', 'write', 'permit']), event=st.integers(0, 4), subject=st.sampled_from(['avatar', 'postop', 'transferred']))
    def event_action(self, op, event, subject):
        target = subject
        key = (self.m.attempt, event)
        if op == 'see': self.m.see_wound(self.tok(), key)
        if op == 'cover': self.m.end_wound(self.tok(), key)
        if op == 'tell': self.m.receive_testimony(self.tok(), key, target, 'claim')
        if op == 'write': self.m.write_report(self.tok(), key, target)
        if op == 'permit': self.m.give_permit(self.tok(), key)

    @rule(op=st.sampled_from(['take', 'sign', 'finish', 'find']), index=st.integers(0, 5), subject=st.sampled_from(['avatar', 'postop', 'transferred']))
    def report_action(self, op, index, subject):
        target = subject
        rows = list(self.m.reports)
        r = rows[index % len(rows)] if rows else ('report', self.m.attempt, -1)
        if op == 'take': self.m.accept_ordinary(self.tok(), r, target)
        if op == 'sign': self.m.sign_isolation(self.tok(), r, target)
        if op == 'finish': self.m.finish_ordinary(self.tok(), r, 'not_found')
        if op == 'find': self.m.confirm_target(self.tok(), r, target)

    @rule(op=st.sampled_from(['take', 'finish']), index=st.integers(0, 5), subject=st.sampled_from(['avatar', 'postop', 'transferred']))
    def isolation(self, op, index, subject):
        target = subject
        rows = list(self.m.isolation_orders)
        r = rows[index % len(rows)] if rows else ('isolation', self.m.attempt, -1)
        if op == 'take': self.m.accept_isolation(self.tok(), r, target)
        else: self.m.finish_isolation(self.tok(), r, 'not_found')

    @rule(op=st.sampled_from(['create', 'verify', 'sign']), index=st.integers(0, 3))
    def transfer(self, op, index):
        t = ('transfer', self.m.attempt, index)
        if op == 'create': self.m.register_transfer(self.tok(), index)
        if op == 'verify': self.m.verify_transfer(self.tok(), t, 'transfer-patient')
        if op == 'sign': self.m.sign_transfer_isolation(self.tok(), t)

    @rule(flag=st.sampled_from(['paused', 'dead']), value=st.booleans())
    def flags(self, flag, value):
        setattr(self.m, flag, value)

    @rule(actor=st.sampled_from(['chief', 'orderly', 'isolator']), value=st.booleans())
    def busy(self, actor, value):
        if value: self.m.busy.add(actor)
        else: self.m.busy.discard(actor)

    @rule()
    def reload(self):
        self.m = self.m.reload()

    @rule()
    def new_attempt(self):
        self.m.new_attempt(self.m.attempt + 1)

    @rule(kind=st.sampled_from(['direct', 'wound']))
    def complete_valid_chain(self, kind):
        if self.m.paused or self.m.dead: return
        event = ('chain', self.seq)
        if kind == 'direct':
            self.m.place('chief', 'corridor'); self.m.place('avatar', 'corridor')
            e = self.m.chief_observe_internal(self.tok(), event)
            target = 'avatar'
        else:
            for actor in ENTITIES: self.m.place(actor, None)
            self.m.place('avatar', 'activity'); self.m.place('postop', 'activity')
            e = self.m.begin_wound(self.tok(), event)
            if not e: return
            self.m.place('informant', 'activity'); self.m.see_wound(self.tok(), e)
            self.m.place('informant', 'corridor'); self.m.place('chief', 'corridor')
            self.m.receive_testimony(self.tok(), e, 'postop', 'actual displayed wound')
            target = 'postop'
        if not e: return
        r = self.m.write_report(self.tok(), e, target)
        if not r: return
        o = self.m.sign_isolation(self.tok(), r, target)
        self.m.place('orderly', 'corridor'); self.m.place('isolator', 'corridor')
        if self.m.accept_ordinary(self.tok(), r, target):
            self.m.finish_ordinary(self.tok(), r, 'not_found')
        if o and self.m.accept_isolation(self.tok(), o, target):
            self.m.finish_isolation(self.tok(), o, 'not_found')

    @invariant()
    def provenance_and_execution(self):
        m = self.m
        assert len({r['event'] for r in m.reports.values()}) == len(m.reports)
        for r in m.reports.values():
            e = m.events[r['event']]
            assert e['target'] == r['target'] and e['attempt'] == r['attempt']
            assert r['issuer'] == 'chief'
            if r['source'] == 'testimony':
                assert e['id'] in m.testimonies and 'informant' in e['witnesses'] and 'chief' not in e['witnesses']
        for o in m.isolation_orders.values():
            assert o['issuer'] == 'chief'
            if o['source'] == 'report':
                r = m.reports[o['report_id']]
                assert r['target'] == o['target'] and r['signed_isolation']
                if o['taken']: assert r['handled']
            else:
                t = m.transfers[o['event']]
                assert t['chief_verified'] and t['isolation_signed']
        for actor, job in m.jobs.items():
            if job is not None:
                row = (m.reports if actor == 'orderly' else m.isolation_orders)[job]
                assert row['attempt'] == m.attempt and not row['handled']
                assert row['report_taken'] if actor == 'orderly' else row['taken']
        for key in m.permits:
            assert key in m.testimonies


TestReportMachine = ReportMachine.TestCase
TestReportMachine.settings = settings(max_examples=225, stateful_step_count=65, deadline=None, database=None)
