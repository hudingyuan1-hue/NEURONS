import copy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from isolation import Isolation


def signed(target='avatar', attempt=1):
    m = Isolation(attempt=attempt)
    assert m.sign('O', 'R', target, report_target=target, chief_present=True,
                  actual=True, report_received=True, target_verified=True)
    return m


def started(target='avatar', position='corridor'):
    m = signed(target)
    assert m.take_order('O', actual=True, orderly_present=True, idle=True,
                        previous_holder_released=True)
    assert m.locate(position, actual=True, found=True)
    return m


def held(target='avatar', position='corridor'):
    m = started(target, position)
    assert m.approach(actual=True, visible=True)
    assert m.grip(actual=True)
    return m


def closing(target='avatar'):
    m = held(target)
    assert m.step('quiet', actual=True, route_valid=True, at_observation=True)
    assert not m.holding
    assert m.begin_close(actual=True)
    return m


def closed(target='avatar'):
    m = closing(target)
    assert m.close_actual(actual=True)
    return m


@pytest.mark.parametrize('missing', ['actual', 'chief_present', 'report_received', 'target_verified'])
def test_sign_requires_each_real_authority_fact(missing):
    m = Isolation()
    kw = dict(actual=True, chief_present=True, report_received=True, target_verified=True)
    kw[missing] = False
    assert not m.sign('O', 'R', 'avatar', report_target='avatar', **kw)
    assert not m.orders


@pytest.mark.parametrize('other', [None, '', 'postop', 'transport_patient'])
def test_report_subject_never_converted_to_avatar(other):
    m = Isolation()
    assert not m.sign('O', 'R', 'avatar', report_target=other, chief_present=True,
                      actual=True, report_received=True, target_verified=True)


@pytest.mark.parametrize('source', ['transfer', 'report'])
def test_both_sources_require_separate_chief_signature(source):
    m = Isolation()
    assert not m.take_order('transfer-slip', actual=True, orderly_present=True,
                            idle=True, previous_holder_released=True)
    assert m.sign('O', 'R', 'postop', report_target='postop', chief_present=True,
                  actual=True, report_received=True, target_verified=True, source=source)
    assert m.orders['O'].source == source


def test_one_report_cannot_create_new_target_or_duplicate_authorization():
    m = signed()
    assert not m.sign('O2', 'R', 'postop', report_target='postop', chief_present=True,
                      actual=True, report_received=True, target_verified=True)
    assert len(m.orders) == 1


@pytest.mark.parametrize('missing', ['actual', 'orderly_present', 'idle', 'previous_holder_released'])
def test_delivery_no_remote_takeover_and_does_not_consume_if_blocked(missing):
    m = signed()
    kw = dict(actual=True, orderly_present=True, idle=True, previous_holder_released=True)
    kw[missing] = False
    assert not m.take_order('O', **kw)
    assert not m.avatar_attempts and not m.consumed and not m.active


def test_not_found_after_last_known_ends_without_remote_grip():
    m = signed()
    m.take_order('O', actual=True, orderly_present=True, idle=True, previous_holder_released=True)
    assert not m.locate(actual=True, found=False)
    assert m.locate(actual=True, found=False, last_known_checked=True)
    assert m.phase == 'idle' and not m.holding and not m.facts
    assert m.outcomes[-1]['reason'] == 'not_found'
    assert not m.take_order('O', actual=True, orderly_present=True, idle=True,
                            previous_holder_released=True)


@pytest.mark.parametrize('clear,space', [(False, True), (True, False), (False, False)])
def test_capacity_bystanders_prevent_grip_and_close(clear, space):
    m = started()
    m.configure_room(clear=clear, space=space)
    assert not m.approach(actual=True, visible=True)
    assert not m.holding and m.can_move_inside()
    m.configure_room(clear=True, space=True)
    assert m.approach(actual=True, visible=True)
    m.configure_room(clear=clear, space=space)
    assert not m.grip(actual=True)
    assert not m.holding
    m = held()
    m.step('quiet', actual=True, route_valid=True, at_observation=True)
    m.configure_room(clear=clear, space=space)
    assert not m.begin_close(actual=True)
    assert not m.facts and m.can_leave()


def test_reach_must_be_visible_before_grip():
    m = started()
    assert not m.approach(actual=True, visible=False)
    assert not m.grip(actual=True)
    assert m.phase == 'located'


def test_missed_grip_ends_once_even_with_new_report():
    m = started()
    m.approach(actual=True, visible=True)
    assert m.grip(actual=False)
    assert m.outcomes[-1]['reason'] == 'miss'
    assert m.sign('O2', 'R2', 'avatar', report_target='avatar', chief_present=True,
                  actual=True, report_received=True, target_verified=True)
    assert not m.take_order('O2', actual=True, orderly_present=True, idle=True,
                            previous_holder_released=True)
    assert m.hp_effect == m.sp_effect == 0


@pytest.mark.parametrize('elapsed', [0, 1, 5999, 6000, 6001, 10000])
def test_avatar_transport_cap_local_release_no_teleport(elapsed):
    m = held()
    m.tick(elapsed)
    assert m.position == 'corridor' and not m.facts
    assert m.holding == (elapsed < 6000)
    if elapsed >= 6000:
        assert m.outcomes[-1]['reason'] == 'transport_timeout'


@pytest.mark.parametrize('target', ['postop', 'transport_patient'])
def test_npc_transport_not_subject_to_avatar_six_second_cap(target):
    m = held(target)
    m.tick(60000)
    assert m.holding and m.active.target == target
    assert m.position == 'corridor' and not m.facts
    m.abort(actual=True)
    assert m.position == 'corridor' and m.outcomes[-1]['target'] == target


def test_already_inside_moves_to_observation_without_dragging_out():
    m = held(position='quiet')
    assert m.step('quiet', actual=True, route_valid=True, at_observation=True)
    assert not m.holding and m.phase == 'arrived'
    assert [x['location'] for x in m.history if x['action'] == 'transport_step'] == ['quiet']


@pytest.mark.parametrize('actual,valid,location', [(False, True, 'quiet'),
                                                 (True, False, 'quiet'),
                                                 (True, True, 'corridor')])
def test_impossible_or_remote_arrival_does_not_complete_transport(actual, valid, location):
    m = held()
    assert not m.step(location, actual=actual, route_valid=valid, at_observation=True)
    assert m.holding and m.phase == 'held' and not m.facts


@pytest.mark.parametrize('elapsed,phase,timer', [
    (0, 'closing', 0), (999, 'closing', 999), (1000, 'closed', 0),
    (1001, 'closed', 1), (8999, 'closed', 7999), (9000, 'opening', 0),
    (9999, 'opening', 999), (10000, 'idle', 0), (30000, 'idle', 0)])
def test_continuous_tick_splits_close_isolation_and_open_deadlines(elapsed, phase, timer):
    m = closing()
    m.tick(elapsed)
    assert m.phase == phase and m.timer == timer and m.elapsed_ms == elapsed
    assert len(m.facts) == (0 if elapsed < 1000 else 1)
    if m.facts:
        assert m.facts[0]['at_ms'] == 1000
    if elapsed >= 10000:
        assert m.outcomes[-1]['at_ms'] == 10000 and m.can_leave()


@pytest.mark.parametrize('pause_kind', ['paused', 'loading'])
@pytest.mark.parametrize('factory', [held, closing, closed])
def test_menu_dialogue_and_loading_freeze_all_physical_timers(pause_kind, factory):
    m = factory()
    before = (m.phase, m.timer, m.transport_ms, m.elapsed_ms, copy.deepcopy(m.facts))
    m.tick(50000, **{pause_kind: True})
    assert (m.phase, m.timer, m.transport_ms, m.elapsed_ms, m.facts) == before
    m.tick(1, **{pause_kind: False})
    assert m.elapsed_ms == before[3] + 1


def test_time_starts_at_actual_close_not_grip_or_arrival():
    m = held()
    m.tick(5000)
    m.step('quiet', actual=True, route_valid=True, at_observation=True)
    m.tick(40000)
    assert not m.facts
    m.begin_close(actual=True)
    m.tick(500)
    m.close_actual(actual=True)
    m.tick(7999)
    assert m.phase == 'closed'
    m.tick(1)
    assert m.phase == 'opening'
    assert m.facts[0]['at_ms'] == 45500


def test_isolated_avatar_can_move_observe_but_not_leave_no_added_damage():
    m = closed()
    assert m.can_move_inside() and not m.can_leave()
    assert m.target_moved('quiet', actual=True)
    assert not m.target_moved('corridor', actual=True)
    assert m.can_leave('bystander') and m.can_move_inside('bystander')
    assert m.hp_effect == m.sp_effect == 0


def test_avatar_can_leave_before_actual_close_without_isolation_fact():
    m = closing()
    m.tick(500)
    assert m.can_leave()
    assert m.target_moved('corridor', actual=True)
    m.tick(10000)
    assert m.position == 'corridor' and not m.facts and m.phase == 'idle'


def test_bystander_enters_during_closing_aborts_before_fact():
    m = closing()
    m.tick(999)
    m.configure_room(clear=False, space=True)
    m.tick(1000)
    assert m.phase == 'idle' and not m.facts


@pytest.mark.parametrize('reason', ['cancel', 'route_unavailable', 'orderly_departed'])
def test_abort_opens_within_one_second(reason):
    m = closed()
    assert m.abort(reason, actual=True)
    assert m.phase == 'opening'
    m.tick(999)
    assert not m.can_leave()
    m.tick(1)
    assert m.can_leave() and m.phase == 'idle'


def test_observer_at_door_is_not_departure():
    m = closed()
    assert not m.orderly_departed(actual=True, doorway_observer=True)
    assert m.phase == 'closed'
    assert m.orderly_departed(actual=True, doorway_observer=False)
    assert m.phase == 'opening'


@pytest.mark.parametrize('factory', [held, closing, closed])
def test_death_releases_grip_and_bounded_open_without_revive(factory):
    m = factory()
    m.target_died()
    assert not m.holding
    m.tick(1000)
    assert m.phase == 'idle' and m.door == 'open'


@pytest.mark.parametrize('target', ['postop', 'transport_patient'])
def test_npc_release_preserves_identity_position_and_living_state(target):
    m = closing(target)
    m.tick(10000)
    assert m.position == 'quiet' and not m.dead
    assert m.outcomes[-1]['target'] == target
    assert m.facts[-1]['target'] == target
    assert m.can_leave(target)


def test_new_attempt_keeps_history_but_does_not_execute_old_authorization():
    m = closed()
    old = copy.deepcopy(m.facts)
    assert m.new_attempt(2)
    assert m.facts == old and m.phase == 'idle' and m.can_leave()
    assert not m.take_order('O', actual=True, orderly_present=True, idle=True,
                            previous_holder_released=True)
    assert m.sign('O2', 'R', 'avatar', report_target='avatar', chief_present=True,
                  actual=True, report_received=True, target_verified=True)
    assert m.take_order('O2', actual=True, orderly_present=True, idle=True,
                        previous_holder_released=True)


def test_reload_and_reentry_do_not_reset_once_or_timer():
    m = closed()
    m.tick(2400)
    n = copy.deepcopy(m)
    assert n.timer == 2400 and n.avatar_attempts == {1}
    assert not n.new_attempt(1)
    n.tick(5600)
    assert n.phase == 'opening'


class IsolationMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.m = Isolation()
        self.serial = 0

    @rule(target=st.sampled_from(['avatar', 'postop', 'transport_patient']),
          valid=st.booleans())
    def sign_and_take(self, target, valid):
        self.serial += 1
        order, report = f'O{self.serial}', f'R{self.serial}'
        self.m.sign(order, report, target, report_target=target,
                    chief_present=valid, actual=valid, report_received=valid,
                    target_verified=valid)
        self.m.take_order(order, actual=valid, orderly_present=valid, idle=valid,
                          previous_holder_released=valid)

    @rule(found=st.booleans(), actual=st.booleans(),
          location=st.sampled_from(['quiet', 'corridor', 'activity']))
    def locate(self, found, actual, location):
        self.m.locate(location, actual=actual, found=found, last_known_checked=not found)

    @rule(actual=st.booleans())
    def approach(self, actual):
        self.m.approach(actual=actual, visible=actual)

    @rule(actual=st.booleans())
    def grip(self, actual):
        self.m.grip(actual=actual)

    @rule(actual=st.booleans(), valid=st.booleans())
    def arrive(self, actual, valid):
        self.m.step('quiet', actual=actual, route_valid=valid, at_observation=True)

    @rule(clear=st.booleans(), space=st.booleans())
    def room(self, clear, space):
        self.m.configure_room(clear=clear, space=space)

    @rule()
    def close(self):
        self.m.begin_close(actual=True)
        self.m.close_actual(actual=True)

    @rule(ms=st.sampled_from([0, 1, 999, 1000, 1001, 5999, 6000, 7999, 8000, 10000]),
          paused=st.booleans(), loading=st.booleans())
    def time(self, ms, paused, loading):
        self.m.tick(ms, paused=paused, loading=loading)

    @rule()
    def abort(self):
        self.m.abort(actual=True)

    @rule()
    def die(self):
        self.m.target_died()

    @rule()
    def restart(self):
        self.m.new_attempt(self.m.attempt + 1)

    @rule()
    def reload(self):
        self.m = copy.deepcopy(self.m)

    @rule(location=st.sampled_from(['quiet', 'corridor']))
    def move(self, location):
        self.m.target_moved(location, actual=True)

    @invariant()
    def physical_and_identity_invariants(self):
        m = self.m
        assert m.hp_effect == m.sp_effect == 0
        assert not m.holding or (m.active is not None and m.phase == 'held')
        assert m.phase != 'closed' or (m.position == 'quiet' and m.door == 'closed'
                                       and not m.holding and m.room_clear and m.room_space)
        assert not (m.phase == 'held' and m.active.target == m.avatar_id
                    and m.transport_ms >= 6000)
        keys = [(f['attempt'], f['report_id']) for f in m.facts]
        assert len(keys) == len(set(keys))
        avatar_facts = [f['attempt'] for f in m.facts if f['target'] == m.avatar_id]
        assert len(avatar_facts) == len(set(avatar_facts))
        assert all(f['target'] == m.orders[f['order_id']].target for f in m.facts)
        assert m.phase != 'closed' or m.can_move_inside(m.active.target)


TestIsolationMachine = IsolationMachine.TestCase
TestIsolationMachine.settings = settings(max_examples=220, stateful_step_count=65,
                                         deadline=None, database=None)
