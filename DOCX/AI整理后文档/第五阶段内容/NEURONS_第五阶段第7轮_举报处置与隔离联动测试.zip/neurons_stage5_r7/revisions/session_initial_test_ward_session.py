from copy import deepcopy
from collections import deque
import pytest
from hypothesis import settings,strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant
from ward_session import WardSession
from s3_session import EDGES

class Driver:
    def __init__(self,s=None):self.s=s or WardSession();self.seq=0
    def n(self):self.seq+=1;return(self.s.life.epoch,self.seq)
    def tick(self,ms):return self.s.tick(self.n(),ms)
    def rep(self,name,**kw):return self.s.report_action(self.n(),name,**kw)
    def move(self,dest):return self.s.move(self.n(),dest)
    def amove(self,a,dest):return self.s.actor_move(self.n(),a,dest)
    def go(self,dest):
        q=deque([(self.s.position,[])]);seen={self.s.position}
        while q:
            p,path=q.popleft()
            if p==dest:
                for n in path:assert self.move(n)
                return
            for edge in EDGES:
                if p in edge:
                    n=next(iter(edge-{p}))
                    if n not in seen:seen.add(n);q.append((n,path+[n]))
        raise AssertionError('unreachable')
    def make_report(self,event='read'):
        self.go((2,'corridor'));self.s.actors.update(chief=(2,'corridor'),orderly=(2,'corridor'),isolator=(2,'corridor'))
        key=self.rep('chief_observe_internal',event=event)
        assert key
        rid=self.rep('write_report',event_key=key,target='avatar');assert rid
        oid=self.rep('sign_isolation',report_id=rid,target='avatar');assert oid
        return rid,oid
    def ordinary(self,rid,grip=True):
        assert self.s.ordinary_accept(self.n(),rid,'avatar')
        assert self.s.ordinary_find(self.n())
        assert self.s.ordinary_grip(self.n(),actual=grip)
    def release(self):assert self.s.ordinary_arrive(self.n())
    def take_iso(self,oid):
        assert self.s.isolation_take(self.n(),oid,'avatar')
        assert self.s.isolation_find(self.n())
        assert self.s.isolation_reach(self.n())
        assert self.s.isolation_grip(self.n())
    def closed(self):
        rid,oid=self.make_report();self.ordinary(rid);self.release();self.tick(1050)
        self.take_iso(oid)
        assert self.s.isolation_step(self.n(),(2,'quiet'),at_observation=True)
        assert self.s.isolation_action(self.n(),'begin_close',actual=True)
        self.tick(1000);assert self.s.isolation.phase=='closed'
        return rid,oid

@pytest.mark.parametrize('sp',[0,1,9,10,19,20,49,100])
def test_actual_report_grip_once_and_timeout_local(sp):
    d=Driver();r,o=d.make_report();s=d.s;s.life.sp=sp;s.life.emptied=sp==0
    n=s.life.economy.n;d.ordinary(r)
    assert (s.life.hp,s.life.sp)==(95,max(0,sp-10))
    assert not s.ordinary_grip(d.n())
    d.tick(6000)
    assert not s.holder and not s.ordinary_job and s.position==(2,'corridor')
    assert s.ward.reports[r]['outcome']=='timeout' and s.life.economy.n==n
    assert not s.ordinary_accept(d.n(),r,'avatar')

@pytest.mark.parametrize('hp',[1,5,6,100])
def test_lethal_grip_ends_actions_immediately(hp):
    d=Driver();r,o=d.make_report();s=d.s;s.life.hp=hp;d.ordinary(r)
    if hp<=5:
        assert s.life.phase=='dead' and not s.holder and not s.ordinary_job
        assert not s.isolation_take(d.n(),o,'avatar')
    else:assert s.life.hp==hp-5 and s.holder=='orderly'

@pytest.mark.parametrize('part',['unwritten','unreceived','absent','busy','wrong_target'])
def test_report_alone_never_damage_or_remote_grip(part):
    d=Driver();r,o=d.make_report();s=d.s
    if part=='unwritten':r='missing'
    if part=='absent':s.actors['orderly']=None
    if part=='busy':s.procedure={'kind':'wrist','actor':'orderly','state':'offered','limit':2000,'hp':5,'sp':5,'paid':False}
    if part=='unreceived':assert not s.ordinary_find(d.n())
    else:assert not s.ordinary_accept(d.n(),r,'postop' if part=='wrong_target' else 'avatar')
    assert (s.life.hp,s.life.sp,s.holder)==(100,100,None)

@pytest.mark.parametrize('actual',[False,True])
def test_missed_grip_no_damage_no_duplicate(actual):
    d=Driver();r,o=d.make_report();d.ordinary(r,grip=actual);s=d.s
    assert (s.life.hp,s.life.sp)==((95,90) if actual else (100,100))
    if not actual:
        assert not s.ordinary_job and not s.ordinary_accept(d.n(),r,'avatar')

@pytest.mark.parametrize('remaining',[0,799,800,1000])
def test_recovery_begins_after_hitstop_not_on_release(remaining):
    d=Driver();r,o=d.make_report();d.ordinary(r);d.release();s=d.s
    assert s.isolation_take(d.n(),o,'avatar') and s.isolation_find(d.n())
    d.tick(250+remaining)
    assert s.isolation_reach(d.n()) is (remaining>=800)

@pytest.mark.parametrize('reason',['paused','loading'])
def test_pause_freezes_body_and_door(reason):
    d=Driver();d.closed();s=d.s
    setattr(s,reason,True);before=(s.isolation.timer,s.life.hp,s.life.sp,s.gap)
    assert not d.tick(100000)
    assert (s.isolation.timer,s.life.hp,s.life.sp,s.gap)==before
    setattr(s,reason,False);d.tick(8000);assert s.isolation.phase=='opening'
    d.tick(1000);assert s.isolation.door=='open'

@pytest.mark.parametrize('sp',[0,1,19,20,49,100])
def test_isolation_zero_resources_low_sp_can_move_observe_and_leave(sp):
    d=Driver();d.closed();s=d.s;s.life.sp=sp;s.life.emptied=sp==0
    s.life.economy.n=s.life.economy.c=0;s.life.economy.global_r=100
    before=(s.life.hp,s.life.sp,s.life.economy.n,s.life.economy.c)
    assert not s.blocked()
    assert s.indoor_action(d.n(),'move') and s.indoor_action(d.n(),'observe')
    assert not d.move((2,'corridor'))
    d.tick(7999);assert s.isolation.phase=='closed'
    d.tick(1);assert s.isolation.phase=='opening' and not d.move((2,'corridor'))
    d.tick(1000);assert d.move((2,'corridor'))
    assert before==(s.life.hp,s.life.sp,s.life.economy.n,s.life.economy.c)
    d.go((1,'ward'));assert s.begin_rest(d.n());assert s.complete_rest(d.n())
    assert s.life.attempts[3]==2 and not s.isolation.active

@pytest.mark.parametrize('kind',['ordinary','isolator'])
def test_bound_transport_no_teleport(kind):
    d=Driver();r,o=d.make_report();d.ordinary(r);s=d.s
    if kind=='isolator':
        d.release();d.tick(1050);d.take_iso(o)
        assert not s.isolation_step(d.n(),(2,'quiet'),route_clear=False)
    else:assert not s.ordinary_step(d.n(),(2,'quiet'),route_clear=False)
    d.tick(6000)
    assert s.position==(2,'corridor') and not s.holder and not s.isolation.facts
    assert not s.isolation.active

@pytest.mark.parametrize('phase',['arrived','closing'])
def test_can_leave_before_actual_close_not_captured_remotely(phase):
    d=Driver();r,o=d.make_report();d.ordinary(r);d.release();d.tick(1050);d.take_iso(o);s=d.s
    assert s.isolation_step(d.n(),(2,'quiet'),at_observation=True)
    if phase=='closing':assert s.isolation_action(d.n(),'begin_close',actual=True)
    assert d.move((2,'corridor'));d.tick(10000)
    assert not s.isolation.facts and s.position==(2,'corridor') and not s.isolation.active

@pytest.mark.parametrize('occupied_by',['postop','nurse','cross_level_patient'])
def test_bystanders_block_isolation_without_freezing_them(occupied_by):
    d=Driver();r,o=d.make_report();d.ordinary(r);d.release();d.tick(1050);s=d.s
    s.actors[occupied_by]=(2,'quiet')
    assert s.isolation_take(d.n(),o,'avatar') and s.isolation_find(d.n())
    assert not s.isolation_reach(d.n()) and not s.holder
    assert d.move((2,'activity'))
    assert not s.isolation.facts

@pytest.mark.parametrize('k',[1,2,5,6,1000000])
def test_old_orders_cannot_execute_after_real_attempt(k):
    d=Driver();s=d.s;s.life.attempts[3]=s.ward.attempt=s.isolation.attempt=k
    r,o=d.make_report();old=d.n();d.ordinary(r);d.release();d.tick(1050)
    d.go((1,'ward'));assert s.begin_rest(d.n());assert s.complete_rest(d.n())
    s.actors.update(orderly=(2,'corridor'),isolator=(2,'corridor'))
    assert not s.ordinary_accept(old,r,'avatar')
    assert not s.isolation_take(d.n(),o,'avatar')
    assert s.life.attempts[3]==k+1 and r in s.ward.reports


def test_distinct_wrist_and_report_counts_same_entity():
    d=Driver();s=d.s;s.position=(1,'ward');s.actors['orderly']=s.position
    assert s.begin_procedure(d.n(),'wrist');assert s.normal_check(d.n())
    for p in ((1,'reception'),(2,'stairs'),(2,'corridor')):assert d.amove('orderly',p)
    r,o=d.make_report();d.ordinary(r)
    assert s.life.hp==95 and len([a for a in s.actors if a=='orderly'])==1


def test_report_grip_interrupts_search_without_erasing_key_or_awareness():
    d=Driver();r,o=d.make_report();s=d.s
    ident=s.start_search(d.n(),1);assert ident is not None
    assert s.ordinary_accept(d.n(),r,'avatar');assert s.ordinary_find(d.n());assert s.ordinary_grip(d.n())
    assert not s.search.pending and s.search.income==0 and s.search.used==1
    assert s.awareness.stage==0 and not s.awareness.evidence
    d.release();d.tick(1050);s.search.key_owner='avatar'
    d.go((2,'stairs'));assert s.damage_or_exit(d.n(),exit_actual=True)=='exit' and s.life.progress==4


def test_isolation_does_not_remove_key_exit_after_release():
    d=Driver();d.closed();s=d.s;s.search.key_owner='avatar';s.life.economy.n=0;s.life.sp=1
    d.tick(9000);d.go((2,'stairs'))
    assert s.damage_or_exit(d.n(),exit_actual=True)=='exit' and s.life.progress==4


def test_isolator_actual_departure_opens_but_doorway_observation_does_not():
    d=Driver();d.closed();s=d.s
    assert not s.isolation_action(d.n(),'orderly_departed',actual=True,doorway_observer=True)
    assert s.isolation.phase=='closed'
    assert d.amove('isolator',(2,'corridor'))
    assert s.isolation.phase=='opening';d.tick(1000);assert d.move((2,'corridor'))


def test_full_informant_patient_transport_then_isolation():
    d=Driver();s=d.s;d.go((2,'activity'))
    s.actors.update(postop=(2,'activity'),informant=(2,'corridor'),chief=(2,'corridor'),orderly=(2,'corridor'),isolator=(2,'corridor'))
    key=d.rep('begin_wound',event='wound');assert key
    assert d.amove('informant',(2,'activity'))
    assert d.rep('see_wound',event_key=key)
    assert d.amove('informant',(2,'corridor'))
    assert d.rep('receive_testimony',event_key=key,target='postop',statement='他把伤口给别人看了。')
    assert d.rep('give_permit',event_key=key)
    r=d.rep('write_report',event_key=key,target='postop');o=d.rep('sign_isolation',report_id=r,target='postop')
    assert s.ordinary_accept(d.n(),r,'postop')
    assert d.amove('orderly',(2,'activity')) and s.ordinary_find(d.n()) and s.ordinary_grip(d.n())
    d.tick(60000) # NPC is not teleported by the avatar's six-second cap.
    assert s.actors['postop']==(2,'activity') and s.ordinary_job
    for dest in ((2,'corridor'),(2,'quiet')):assert s.ordinary_step(d.n(),dest)
    assert s.ordinary_arrive(d.n())
    assert d.amove('orderly',(2,'corridor'))
    assert s.isolation_take(d.n(),o,'postop');assert d.amove('isolator',(2,'quiet'))
    assert s.isolation_find(d.n()) and s.isolation_reach(d.n()) and s.isolation_grip(d.n())
    assert s.isolation_step(d.n(),(2,'quiet'),at_observation=True)
    assert s.isolation_action(d.n(),'begin_close',actual=True);d.tick(10000)
    assert s.actors['postop']==(2,'quiet') and not s.isolation.active
    assert (s.life.hp,s.life.sp)==(100,100) and s.awareness.stage==0
    assert s.ward.knowledge[('chief',key)]['kind']=='testimony'
    assert 'chief' not in s.ward.events[key]['witnesses']


def test_reload_preserves_exact_door_timer_no_replay():
    d=Driver();r,o=d.closed();d.tick(3210);s=d.s;before=deepcopy((s.ward,s.isolation))
    d.s=s.reload();d.tick(4790);assert d.s.isolation.phase=='opening'
    assert d.s.ward.reports==before[0].reports and len(d.s.isolation.facts)==1

class WardMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.r,self.o=self.d.make_report();self.start_attempt=1
    @rule()
    def accept(self):self.d.s.ordinary_accept(self.d.n(),self.r,'avatar')
    @rule(found=st.booleans(),checked=st.booleans())
    def find(self,found,checked):self.d.s.ordinary_find(self.d.n(),found=found,last_checked=checked)
    @rule(actual=st.booleans())
    def grip(self,actual):self.d.s.ordinary_grip(self.d.n(),actual=actual)
    @rule()
    def arrive(self):self.d.s.ordinary_arrive(self.d.n())
    @rule()
    def take_iso(self):self.d.s.isolation_take(self.d.n(),self.o,'avatar')
    @rule()
    def find_iso(self):self.d.s.isolation_find(self.d.n())
    @rule()
    def reach_iso(self):self.d.s.isolation_reach(self.d.n())
    @rule(actual=st.booleans())
    def grip_iso(self,actual):self.d.s.isolation_grip(self.d.n(),actual=actual)
    @rule()
    def transport_iso(self):self.d.s.isolation_step(self.d.n(),(2,'quiet'),at_observation=True)
    @rule()
    def close(self):self.d.s.isolation_action(self.d.n(),'begin_close',actual=True)
    @rule(ms=st.sampled_from([0,1,249,250,799,800,1000,5999,6000,8000,9000,10000]))
    def tick(self,ms):self.d.tick(ms)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused
    @rule(room=st.sampled_from(['quiet','corridor','activity','stairs']))
    def move(self,room):self.d.move((2,room))
    @rule()
    def reload(self):self.d.s=self.d.s.reload()
    @rule()
    def death(self):self.d.s.damage_or_exit(self.d.n(),hp=100)
    @rule()
    def revive(self):self.d.s.revive()
    @invariant()
    def body_limits_and_unique_effects(self):
        s=self.d.s
        assert 0<=s.life.hp<=100 and 0<=s.life.sp<=100
        assert s.holder in (None,'orderly','isolator')
        assert not (s.holder=='orderly' and s.isolation.holding)
        assert s.isolation.hp_effect==s.isolation.sp_effect==0
        assert len([f for f in s.isolation.facts if f['target']=='avatar' and f['attempt']==s.life.attempts[3]])<=1
        if s.life.phase=='dead':assert not s.holder
        if s.life.attempts[3]>self.start_attempt:assert not s.isolation.active and not s.ordinary_job
        assert s.awareness.stage==0

TestWardMachine=WardMachine.TestCase
TestWardMachine.settings=settings(max_examples=250,stateful_step_count=70,deadline=None)
