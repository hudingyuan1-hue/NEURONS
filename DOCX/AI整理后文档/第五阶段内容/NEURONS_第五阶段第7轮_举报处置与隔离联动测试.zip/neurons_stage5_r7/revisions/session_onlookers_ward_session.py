"""R7 S3F2 report/contact/isolation adapter. Source: S3:P781-886/T30;
S4:T15/P181-207. R6 inherited modules remain byte-for-byte unchanged.
Physical perception/contact/room capacity are explicit engine inputs, not 3D calculations.
"""
from dataclasses import dataclass,field
from s3_session import S3Session,EDGES
from ward_reports import WardReports,ENTITIES
from isolation import Isolation

NEW_ACTORS=('chief','informant','isolator','postop','transferred')
REPORT_ACTIONS={'chief_observe_internal','begin_wound','end_wound','see_wound',
 'receive_testimony','write_report','give_permit','sign_isolation',
 'register_transfer','verify_transfer','sign_transfer_isolation'}

@dataclass
class WardSession(S3Session):
    ward: WardReports=field(default_factory=WardReports)
    isolation: Isolation=field(default_factory=Isolation)
    ordinary_job: dict|None=None
    chief_busy: bool=False
    room_space: bool=True
    serial: int=0

    def __post_init__(self):
        self.actors.update({a:None for a in NEW_ACTORS if a not in self.actors})
        super().__post_init__()

    def _rt(self,label):
        self.serial+=1
        return (self.life.attempts[3],('internal',self.serial,label))

    def target_pos(self,target):
        return self.position if target=='avatar' else self.actors.get(target)

    def _sync(self):
        super()._sync()
        if not hasattr(self,'ward'):return
        self.ward.paused=self.paused or self.loading
        self.ward.dead=self.life.phase=='dead'
        for name in ENTITIES:
            p=self.target_pos(name)
            self.ward.positions[name]=p[1] if p and p[0]==2 else None
        self.ward.busy={'chief'} if self.chief_busy else set()
        if self.procedure and self.procedure['actor']=='orderly':self.ward.busy.add('orderly')
        self.isolation.paused=self.paused;self.isolation.loading=self.loading
        # Only the assigned observer is excluded. All other occupants must leave.
        target=self.isolation.active.target if self.isolation.active else None
        clear=all(p!=(2,'quiet') for a,p in self.actors.items() if a not in (target,'isolator'))
        if target!='avatar' and self.position==(2,'quiet'):clear=False
        self.isolation.configure_room(clear=clear,space=self.room_space)

    def report_action(self,token,name,**kwargs):
        if not self.node(token) or name not in REPORT_ACTIONS:return False
        result=getattr(self.ward,name)(self._rt(name),**kwargs)
        if result and name in ('sign_isolation','sign_transfer_isolation'):
            row=self.ward.isolation_orders[result]
            self.isolation.sign(result,row['report_id'] or row['event'],row['target'],
                report_target=row['target'],chief_present=row['issuer']=='chief',
                actual=True,report_received=True,target_verified=True,source=row['source'])
        return result

    def ordinary_accept(self,token,report_id,target,actual=True):
        if not self.node(token) or self.ordinary_job or (self.procedure and self.procedure['actor']=='orderly'):return False
        if not self.ward.accept_ordinary(self._rt('accept'),report_id,target,actual=actual):return False
        self.ordinary_job={'report':report_id,'target':target,'state':'locating'}
        return True

    def ordinary_find(self,token,found=True,last_checked=False,visible=True,actual=True):
        if not self.node(token) or not actual or not self.ordinary_job:return False
        job=self.ordinary_job
        if job['state']!='locating':return False
        if not found:
            if last_checked:self._close_ordinary('not_found');return True
            return False
        if job['target']=='avatar' and (self.blocked() or self.procedure or self.need_gap and self.gap<800):return False
        if not visible or not self.ward.confirm_target(self._rt('find'),job['report'],job['target']):return False
        job['state']='reaching';return True

    def ordinary_grip(self,token,actual=True):
        if not self.node(token) or not self.ordinary_job or self.ordinary_job['state']!='reaching':return False
        job=self.ordinary_job;target=job['target']
        if not actual:self._close_ordinary('missed');return True
        if self.actors.get('orderly')!=self.target_pos(target):return False
        if target=='avatar':
            if self.blocked() or self.procedure:return False
            self.procedure={'kind':('ward_report',job['report']),'actor':'orderly','state':'held',
                            'limit':6000,'hp':5,'sp':10,'paid':False}
            self.holder='orderly';self.hold_ms=0;self.cancel_action()
            job['state']='held';self._pressure(token)
        else:
            job['state']='held'
            for event in list(self.ward.exposures):
                if self.ward.events[event]['target']==target:self.ward.exposures.remove(event)
        return True

    def _close_ordinary(self,outcome):
        if not self.ordinary_job:return False
        job=self.ordinary_job
        # Lifecycle closure is bookkeeping even when the avatar has just died.
        dead=self.ward.dead;self.ward.dead=False
        self.ward.finish_ordinary(self._rt('finish'),job['report'],outcome)
        self.ward.dead=dead;self.ordinary_job=None
        return True

    def finish_procedure(self,delivered=False):
        if self.procedure and isinstance(self.procedure['kind'],tuple) and self.procedure['kind'][0]=='ward_report':
            self._close_ordinary('death' if self.life.phase=='dead' else 'delivered' if delivered else 'timeout')
        return super().finish_procedure(delivered)

    def ordinary_step(self,token,dest,actual=True,route_clear=True):
        if not self.node(token) or not actual or not route_clear or not self.ordinary_job or self.ordinary_job['state']!='held':return False
        target=self.ordinary_job['target'];origin=self.target_pos(target)
        if dest[0]!=2 or origin[0]!=2 or frozenset((origin,dest)) not in EDGES:return False
        self.actors['orderly']=dest
        if target=='avatar':self.position=dest;self.awareness.transition('room')
        else:self.actors[target]=dest
        self._sync();return True

    def ordinary_arrive(self,token,actual=True):
        if not self.node(token) or not actual or not self.ordinary_job or self.ordinary_job['state']!='held':return False
        target=self.ordinary_job['target'];goal=(2,'corridor' if target=='avatar' else 'quiet')
        if self.target_pos(target)!=goal:return False
        if target=='avatar':self.finish_procedure(delivered=True)
        else:self._close_ordinary('delivered')
        self._sync();return True

    def isolation_take(self,token,order_id,target,actual=True):
        if not self.node(token) or not actual:return False
        auth=self.ward.isolation_authorization(order_id,target)
        if not auth or self.isolation.active or (target=='avatar' and self.life.attempts[3] in self.isolation.avatar_attempts):return False
        if self.ordinary_job and self.ordinary_job['target']==target:return False
        if target=='avatar' and self.holder:return False
        if not self.ward.accept_isolation(self._rt('iso_take'),order_id,target):return False
        result=self.isolation.take_order(order_id,actual=True,orderly_present=True,idle=True,previous_holder_released=True)
        return result

    def isolation_find(self,token,found=True,last_checked=False,actual=True):
        if not self.node(token) or not actual or not self.isolation.active:return False
        target=self.isolation.active.target;p=self.target_pos(target)
        if found and (not p or p[0]!=2 or self.actors.get('isolator')!=p):return False
        result=self.isolation.locate(p[1] if p else None,actual=True,found=found,last_known_checked=last_checked)
        self._drain_isolation();return result

    def isolation_reach(self,token,actual=True,visible=True):
        if not self.node(token) or not self.isolation.active:return False
        target=self.isolation.active.target
        if self.actors.get('isolator')!=self.target_pos(target):return False
        if target=='avatar' and (self.blocked() or self.procedure or self.need_gap and self.gap<800):return False
        return self.isolation.approach(actual=actual,visible=visible)

    def isolation_grip(self,token,actual=True):
        if not self.node(token) or not self.isolation.active:return False
        target=self.isolation.active.target
        if self.actors.get('isolator')!=self.target_pos(target):return False
        if target=='avatar' and (self.blocked() or self.procedure):return False
        result=self.isolation.grip(actual=actual)
        if result and self.isolation.holding and target=='avatar':
            self.procedure={'kind':'isolation','actor':'isolator','state':'held','limit':6000,'hp':0,'sp':0,'paid':True}
            self.holder='isolator';self.hold_ms=0;self.cancel_action()
        self._drain_isolation();return result

    def isolation_step(self,token,dest,actual=True,route_clear=True,at_observation=False):
        if not self.node(token) or not actual or not route_clear or not self.isolation.active:return False
        target=self.isolation.active.target;origin=self.target_pos(target)
        if not origin or origin[0]!=2 or dest[0]!=2:return False
        if dest!=origin and frozenset((origin,dest)) not in EDGES:return False
        if not self.isolation.step(dest[1],actual=True,route_valid=True,at_observation=at_observation):return False
        self.actors['isolator']=dest
        if target=='avatar':self.position=dest
        else:self.actors[target]=dest
        if not self.isolation.holding and self.holder=='isolator':self.finish_procedure(delivered=True)
        self._sync();return True

    def isolation_action(self,token,name,**kwargs):
        if not self.node(token) or name not in ('begin_close','close_actual','open_actual','abort','orderly_departed'):return False
        if name in ('begin_close','close_actual') and self.actors.get('isolator')!=(2,'quiet'):return False
        result=getattr(self.isolation,name)(**kwargs)
        self._drain_isolation();return result

    def _drain_isolation(self):
        if not self.isolation.holding and self.holder=='isolator':self.finish_procedure(delivered=False)
        oid=self.ward.jobs['isolator']
        if oid is not None and not self.isolation.active:
            reason=self.isolation.outcomes[-1]['reason'] if self.isolation.outcomes else 'cancel'
            outcome={'released':'delivered','not_found':'not_found','miss':'missed','transport_timeout':'timeout','death':'death'}.get(reason,'cancelled')
            dead=self.ward.dead;self.ward.dead=False
            self.ward.finish_isolation(self._rt('iso_end'),oid,outcome)
            self.ward.dead=dead

    def move(self,token,dest,actual=True):
        if not self.isolation.can_leave('avatar') and dest!=self.position:return False
        result=super().move(token,dest,actual)
        if result and self.isolation.active and self.isolation.active.target=='avatar':
            self.isolation.target_moved(dest[1] if dest[0]==2 else 'floor1',actual=True)
            self._drain_isolation()
        return result

    def indoor_action(self,token,kind='observe',reachable=True):
        return bool(self.node(token) and reachable and kind in ('observe','move') and not self.blocked() and self.isolation.can_move_inside('avatar'))

    def actor_move(self,token,actor,dest,actual=True):
        if self.ordinary_job and self.ordinary_job['state']=='held' and actor in ('orderly',self.ordinary_job['target']):return False
        if self.isolation.active and actor==self.isolation.active.target and (self.isolation.holding or not self.isolation.can_leave(actor)):return False
        was_iso=actor=='isolator' and self.isolation.active is not None and self.isolation.phase in ('held','arrived','closing','closed','opening')
        result=super().actor_move(token,actor,dest,actual)
        if result and was_iso:self.isolation.orderly_departed(actual=True);self._drain_isolation()
        return result

    def begin_procedure(self,token,kind,**kwargs):
        if kind=='wrist' and self.ordinary_job:return False
        return super().begin_procedure(token,kind,**kwargs)

    def _apply(self,token,events,physical=False):
        result=super()._apply(token,events,physical)
        if self.life.phase=='dead':
            self._close_ordinary('death');self.isolation.target_died();self._drain_isolation()
        return result

    def release(self,token,reason='complete',actual=True):
        was_isolation=self.holder=='isolator'
        result=super().release(token,reason,actual)
        if result and was_isolation:
            self.isolation.abort('body_released',actual=True)
            self._drain_isolation()
        return result

    def damage_or_exit(self,token,hp=0,sp=0,exit_actual=False):
        result=super().damage_or_exit(token,hp,sp,exit_actual)
        if result=='exit':
            self._close_ordinary('cancelled')
            # Dispose old scene commands. This is not an actual door animation
            # and adds no isolation, release, injury or delivery fact.
            if self.isolation.active:self.isolation._finish('level_left')
            self._drain_isolation()
        return result

    def tick(self,token,ms):
        if ms<0:raise ValueError('negative elapsed time')
        if not self.node(token):return False
        remaining=ms
        while remaining and self.active():
            # Split at every body/door boundary, so leftover time is truly actionable.
            bounds=[x for x in (self.life.stun,self.drug_stop,self.hit_stop) if x>0]
            if self.holder:bounds.append(self.procedure['limit']-self.hold_ms)
            iso=self.isolation
            if iso.phase in ('closing','opening'):bounds.append(1000-iso.timer)
            if iso.phase=='closed':bounds.append(8000-iso.timer)
            if iso.phase=='held' and iso.active.target=='avatar':bounds.append(6000-iso.transport_ms)
            dt=min([remaining,*bounds]);free=not self.blocked()
            if free:
                if self.need_gap:self.gap=min(800,self.gap+dt)
                if self.search.pending:self.search_elapsed+=dt
                self.medication.tick(dt)
            self.life.tick(dt);self.drug_stop=max(0,self.drug_stop-dt);self.hit_stop=max(0,self.hit_stop-dt)
            if self.holder:
                self.hold_ms+=dt
                if self.hold_ms>=self.procedure['limit']:self.finish_procedure(delivered=False)
            iso.tick(dt);self._drain_isolation();remaining-=dt
        self._sync();return True

    def _restart(self):
        super()._restart()
        self.actors.update(dict.fromkeys(NEW_ACTORS));self.ordinary_job=None
        self.ward.new_attempt(self.life.attempts[3]);self.isolation.new_attempt(self.life.attempts[3])
        self._sync()
