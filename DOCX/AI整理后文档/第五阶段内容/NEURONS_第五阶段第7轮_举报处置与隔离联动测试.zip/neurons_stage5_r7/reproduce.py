"""R7 replay; original result files are never overwritten."""
import json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def nodes(file,failed=False):
    rows=json.loads((ROOT/'results'/file).read_text())['tests']
    return [r['test'] for r in rows if not failed or r['outcome']=='failed']

def run(selected,cwd,label):
    env=os.environ.copy();env['RUN_REPORT']=str(ROOT/'results'/('reproduced_'+label+'.json'))
    return subprocess.run([sys.executable,'-m','pytest','-q',*selected,
        '--hypothesis-seed=2026101207','--hypothesis-show-statistics'],cwd=cwd,env=env).returncode

def main(mode):
    if mode=='current':
        return run(['test_ward_reports.py','test_isolation.py','test_ward_session.py'],ROOT,'current')
    if mode=='affected':
        selected=set()
        for name in ('reports_affected.json','session_affected.json','session_onlookers_affected.json'):
            selected.update(nodes(name))
        return run(sorted(selected),ROOT,'affected')
    if mode!='failures':raise SystemExit('Usage: python reproduce.py affected|current|failures')
    cases=[('reports',{'ward_reports.py':'reports_copy_boundary_ward_reports.py',
             'test_ward_reports.py':'reports_copy_boundary_test_ward_reports.py'},'reports_boundary_initial.json'),
           ('session',{'ward_session.py':'session_boundaries_ward_session.py',
             'test_ward_session.py':'session_boundaries_test_ward_session.py'},'session_boundaries.json'),
           ('onlookers',{'ward_session.py':'session_onlookers_ward_session.py',
             'test_ward_session.py':'session_onlookers_test_ward_session.py'},'session_onlookers.json')]
    codes=[]
    for label,restore,report in cases:
        with tempfile.TemporaryDirectory(prefix='neurons_r7_') as tmp:
            dest=Path(tmp)
            for p in ROOT.glob('*.py'):shutil.copy2(p,dest/p.name)
            for target,source in restore.items():shutil.copy2(ROOT/'revisions'/source,dest/target)
            codes.append(run(nodes(report,True),dest,label+'_failure'))
    print('Expected pytest failure exits:',codes)
    return 0 if codes==[1,1,1] else 1

if __name__=='__main__':raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else 'affected'))
