from copy import deepcopy
import pytest
from hypothesis import settings,strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant
from patient_transfer import PatientTransfer,PATIENT

class Driver:
    def __init__(self):self.m=PatientTransfer();self.seq=0
    def n(self):self.seq+=1;return (self.m.attempt,self.seq)
    def setup(self):
        assert self.m.spawn(self.n(),'T1');assert self.m.take_order(self.n());assert self.m.verify(self.n());assert self.m.release_brake(self.n())
    def go(self):assert self.m.move(self.n(),'corridor');assert self.m.move(self.n(),'quiet');assert self.m.park(self.n())

@pytest.mark.parametrize('bad',['avatar','s2_wheelchair','cross_level_patient','dead_patient'])
def test_transfer_patient_not_other_identity(bad):
    d=Driver();assert not d.m.spawn(d.n(),'bad',subject=bad);assert not d.m.spawned

@pytest.mark.parametrize('field',['band_subject','bed_subject'])
def test_mismatched_source_ids_rejected(field):
    d=Driver();assert not d.m.spawn(d.n(),'bad',**{field:'other'});assert not d.m.spawned

@pytest.mark.parametrize('missing',['spawn','order','verify','brake'])
def test_no_transport_before_physical_preconditions(missing):
    d=Driver();m=d.m
    if missing!='spawn':assert m.spawn(d.n(),'T1')
    if missing in ('verify','brake'):assert m.take_order(d.n())
    if missing=='brake':assert m.verify(d.n())
    assert not m.move(d.n(),'corridor');assert not m.delivered

@pytest.mark.parametrize('dest',['stairs','floor1','quiet','work'])
def test_bed_cannot_skip_corridor_or_use_stairs(dest):
    d=Driver();d.setup();before=deepcopy(d.m.positions)
    assert not d.m.move(d.n(),dest);assert d.m.positions==before

@pytest.mark.parametrize('constraint',['blocked','full','paused','interrupted','hand'])
def test_blocked_route_and_interruption_preserve_entities(constraint):
    d=Driver();d.setup();m=d.m
    if constraint=='paused':m.paused=True
    if constraint=='interrupted':assert m.interrupt(d.n())
    if constraint=='hand':assert m.grab_rail(d.n())
    assert not m.move(d.n(),'corridor',route_clear=constraint!='blocked',space=constraint!='full')
    assert set(m.positions.values())=={'double'} and not m.delivered


def test_hand_out_stops_transport_until_actual_return():
    d=Driver();d.setup();m=d.m
    assert m.grab_rail(d.n());assert not m.return_hand(d.n(),actual=False)
    assert not m.move(d.n(),'corridor');assert m.return_hand(d.n());assert m.move(d.n(),'corridor')


def test_arrival_without_actual_parking_not_delivery_or_death():
    d=Driver();d.setup();m=d.m
    assert m.move(d.n(),'corridor');assert m.move(d.n(),'quiet')
    assert not m.delivered and not m.park(d.n(),actual=False)
    assert m.park(d.n()) and m.delivered
    assert not m.dead and not m.park(d.n())
    assert [f['kind'] for f in m.facts].count('delivered')==1

@pytest.mark.parametrize('drop_room',['double','corridor'])
def test_detached_band_stays_at_original_location(drop_room):
    d=Driver();d.setup();m=d.m
    if drop_room=='corridor':assert m.move(d.n(),'corridor')
    assert m.detach_band(d.n());assert not m.detach_band(d.n())
    if drop_room=='double':assert m.move(d.n(),'corridor')
    assert m.move(d.n(),'quiet');assert m.park(d.n())
    assert m.band_room==drop_room and m.band_owner=='floor'
    m.avatar_room='quiet';assert not m.pickup(d.n())
    m.avatar_room=drop_room;assert m.pickup(d.n()) and m.band_owner=='avatar'
    assert not m.pickup(d.n(),actor='porter')

@pytest.mark.parametrize('item',['order','band'])
def test_remote_or_unreadable_documents_grant_no_id(item):
    d=Driver();d.setup();m=d.m;m.avatar_room='wash'
    assert not m.read(d.n(),item)
    m.avatar_room='double';assert not m.read(d.n(),item,readable=False)
    assert not m.linked() and not m.knowledge


def test_read_not_ownership_and_matching_both_required():
    d=Driver();d.setup();m=d.m;m.avatar_room='double'
    assert m.read(d.n(),'order');assert not m.linked()
    assert m.read(d.n(),'band');assert m.linked() and m.band_owner=='patient'
    assert m.detach_band(d.n());assert m.pickup(d.n(),actor='porter')
    assert m.linked() and not m.pickup(d.n())


def test_observer_leaving_does_not_stop_transport_or_receive_future_facts():
    d=Driver();d.setup();m=d.m;m.avatar_room='double'
    assert m.grab_rail(d.n()) and m.observe(d.n(),'alive')
    assert m.return_hand(d.n());m.avatar_room='work';before=m.knowledge.copy();d.go()
    assert m.delivered and not m.observe(d.n(),'delivered') and m.knowledge==before
    assert m.hp_effect==m.sp_effect==m.resource_effect==0


def test_resume_uses_actual_progress_no_restart():
    d=Driver();d.setup();m=d.m;assert m.move(d.n(),'corridor');assert m.detach_band(d.n())
    assert m.interrupt(d.n());m=d.m=m.reload();assert m.resume(d.n());assert m.move(d.n(),'quiet');assert m.park(d.n())
    assert m.band_room=='corridor' and [f['kind'] for f in m.facts].count('transport_step')==2

@pytest.mark.parametrize('attempt',[1,2,5,6,1000000])
def test_true_attempt_resets_execution_not_knowledge(attempt):
    d=Driver();d.m.attempt=attempt;d.setup();m=d.m;m.avatar_room='double';assert m.read(d.n(),'order');old=d.n()
    assert m.new_attempt(attempt+1);assert not m.spawned and not m.move(old,'corridor')
    assert (PATIENT,'read_order') in m.knowledge and m.spawn(d.n(),'next')


def test_reentry_cannot_duplicate_bed_patient_or_band():
    d=Driver();d.setup();m=d.m;assert m.detach_band(d.n());d.go()
    for _ in range(3):
        m.avatar_room='double';m=d.m=m.reload();assert not m.spawn(d.n(),'new')
    assert m.delivered and set(m.positions.values())=={'quiet'} and m.band_room=='double'

class TransferMachine(RuleBasedStateMachine):
    def __init__(self):super().__init__();self.d=Driver();self.d.setup()
    @rule(action=st.sampled_from(['take_order','verify','release_brake','grab_rail','return_hand','detach_band','park','interrupt','resume']),actual=st.booleans())
    def action(self,action,actual):getattr(self.d.m,action)(self.d.n(),actual=actual)
    @rule(room=st.sampled_from(['double','corridor','quiet','stairs']),clear=st.booleans(),space=st.booleans())
    def move(self,room,clear,space):self.d.m.move(self.d.n(),room,route_clear=clear,space=space)
    @rule(room=st.sampled_from(['double','corridor','quiet','wash']))
    def observer(self,room):self.d.m.avatar_room=room
    @rule(item=st.sampled_from(['order','band']),visible=st.booleans())
    def read(self,item,visible):self.d.m.read(self.d.n(),item,visible=visible)
    @rule(actor=st.sampled_from(['avatar','porter']))
    def pickup(self,actor):self.d.m.pickup(self.d.n(),actor)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.m.paused=paused
    @rule()
    def reload(self):self.d.m=self.d.m.reload()
    @rule()
    def restart(self):
        m=self.d.m;m.new_attempt(m.attempt+1);m.spawn(self.d.n(),'next')
    @invariant()
    def physical_truth(self):
        m=self.d.m
        assert len(set(m.positions.values()))==1
        assert m.band_owner in ('patient','floor','avatar','porter')
        if m.delivered:assert m.positions['patient']=='quiet' and m.brake_on
        assert not m.dead and m.hp_effect==m.sp_effect==m.resource_effect==0
        assert len([f for f in m.facts if f['attempt']==m.attempt and f['kind']=='delivered'])<=1

TestTransferMachine=TransferMachine.TestCase
TestTransferMachine.settings=settings(max_examples=225,stateful_step_count=65,deadline=None)
