from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from group_therapy import GroupTherapy, GROUP, RETRACTION


def new(attempt=1, epoch=0):
    return GroupTherapy(attempt, epoch, 'speaker-17', 'TR-017',
                        {'avatar': GROUP, 'director': GROUP, 'speaker': GROUP})


def original(m, heard=True):
    assert m.start_recording((m.epoch, 'start'))
    assert m.sit_speaker((m.epoch, 'sit'))
    assert m.speak_transfer((m.epoch, 'speech'), heard_text='转运编号是TR-017，那天——' if heard else None)


def paper(m, heard=True):
    original(m, heard)
    assert m.say_stop((m.epoch, 'command'))
    assert m.stop_recording((m.epoch, 'stop'))
    assert m.delete_segment((m.epoch, 'delete'), seen_by_avatar=True)
    assert m.hand_statement((m.epoch, 'paper'))


def test_full_actual_sequence_does_not_require_avatar_participation():
    m = new(); m.positions['avatar'] = (2, 'corridor')
    paper(m)
    assert m.read_retraction((0, 'retract'))
    assert m.write_minutes((0, 'minutes'))
    assert m.sign((0, 'signature'))
    assert m.release_seat((0, 'release'))
    assert not m.finished
    assert m.stand_up((0, 'stand'))
    assert m.finished and not m.seat_requested and not m.speaker_seated
    assert not m.knowledge
    assert (1, 'speaker-17', 'actual_signature') in m.facts


def test_stop_command_is_not_device_stop():
    m=new();original(m)
    assert m.say_stop((0,'command'))
    assert m.recording and not m.stopped
    assert m.segments[(1,'original')]=='转运编号是TR-017，那天——'


def test_stop_not_delete_and_delete_not_erase_heard():
    m=new();original(m)
    m.say_stop((0,'command'));m.stop_recording((0,'stop'))
    assert m.replay((0,'play'))=='转运编号是TR-017，那天——'
    before=deepcopy(m.knowledge)
    m.delete_segment((0,'delete'),seen_by_avatar=True)
    assert m.replay((0,'replay_after_delete')) is None
    assert before <= m.knowledge
    assert m.can_question_deletion()


@pytest.mark.parametrize('method,prior', [('start_recording',0),('stop_recording',1),('delete_segment',2),('hand_statement',3)])
def test_formal_dialogue_pauses_device_and_handover(method,prior):
    m=new()
    if prior>=1: original(m); m.say_stop((0,'command'))
    if prior>=2: m.stop_recording((0,'stop'))
    if prior>=3: m.delete_segment((0,'delete'))
    m.paused=True
    state=deepcopy(m.__dict__)
    assert not getattr(m,method)((0,'paused'))
    assert m.__dict__==state


def test_actual_dialogue_during_pause_is_recorded_and_not_replayed_on_skip():
    m=new();m.start_recording((0,'start'));m.paused=True
    assert not m.speak_transfer((0,'blocked'),heard_text='TR-017')
    assert m.speak_transfer((0,'speech'),formal_dialogue=True,heard_text='TR-017')
    assert m.segments[(1,'original')]=='转运编号是TR-017，那天——'
    assert (1,'speaker-17','heard','TR-017') in m.knowledge
    assert not m.speak_transfer((0,'speech'),formal_dialogue=True,heard_text='TR-017')
    assert len([f for f in m.facts if f[2]=='said'])==1


@pytest.mark.parametrize('transfer', [None,''])
def test_unbound_number_cannot_borrow_another_patients_identity(transfer):
    m=new();m.transfer_number=transfer;m.start_recording((0,'start'))
    assert not m.speak_transfer((0,'speech'))
    assert not m.original_spoken and not m.segments


@pytest.mark.parametrize('heard', [None,'TR-999','whole invented statement'])
def test_unheard_or_other_person_information_not_learned(heard):
    m=new();m.start_recording((0,'start'))
    assert m.speak_transfer((0,'speech'),heard_text=heard)
    assert not m.knowledge


def test_only_retraction_heard_does_not_allow_original_deletion_challenge():
    m=new();paper(m,heard=False)
    assert m.read_retraction((0,'retract'),heard_text=RETRACTION)
    assert not m.can_question_deletion()


def test_prefilled_minutes_do_not_create_actual_retraction():
    m=new()
    assert m.write_minutes((0,'prefill'),prefilled=True)
    assert not m.retraction_spoken and not m.minutes_written and not m.facts
    assert not m.release_seat((0,'release'))
    assert m.documents==[(1,'speaker-17','prefilled',RETRACTION)]


@pytest.mark.parametrize('mode', ['read','search'])
def test_reading_paper_and_searching_chair_do_not_sign_or_speak(mode):
    m=new();paper(m)
    before=deepcopy(m.facts)
    fn=m.read_statement if mode=='read' else m.search_chair
    assert fn((0,mode))
    assert m.facts==before and not m.signed and not m.retraction_spoken


@pytest.mark.parametrize('kind', ['prefilled','proxy','actual'])
def test_signature_provenance(kind):
    m=new();paper(m)
    assert m.sign((0,'sign'),prefilled=kind=='prefilled',proxy=kind=='proxy')
    assert ((1,'speaker-17','actual_signature') in m.facts)==(kind=='actual')
    assert not m.retraction_spoken


@pytest.mark.parametrize('step', [0,1,2,3,4,5,6])
def test_director_departure_closes_only_pending_actions(step):
    m=new();original(m)
    actions=[('say_stop',{}),('stop_recording',{}),('delete_segment',{}),('hand_statement',{}),
             ('read_retraction',{}),('write_minutes',{})]
    for i,(name,kwargs) in enumerate(actions[:step]):
        assert getattr(m,name)((0,('prior',i)),**kwargs)
    facts=deepcopy(m.facts);documents=deepcopy(m.documents)
    positions=dict(m.positions);positions['director']=(2,'corridor')
    m.sync_context(attempt=1,epoch=0,positions=positions)
    assert m.closed and not m.seat_requested
    positions['director']=GROUP
    m.sync_context(attempt=1,epoch=0,positions=positions)
    for i,(name,kwargs) in enumerate(actions):
        assert not getattr(m,name)((0,('late',i)),**kwargs)
    assert m.facts==facts and m.documents==documents


def test_avatar_can_leave_without_permission_or_ending_other_persons_event():
    m=new();original(m)
    positions=dict(m.positions);positions['avatar']=(2,'corridor')
    m.sync_context(attempt=1,epoch=0,positions=positions)
    assert not m.closed and m.seat_requested
    assert m.say_stop((0,'command'))
    assert m.stop_recording((0,'stop'))


@pytest.mark.parametrize('method', ['start_recording','speak_transfer','say_stop','stop_recording','delete_segment','hand_statement','read_retraction','write_minutes','release_seat','stand_up','sign'])
def test_actual_false_has_no_effect(method):
    m=new();before=deepcopy(m.__dict__)
    assert not getattr(m,method)((0,method),actual=False)
    assert m.__dict__==before


@pytest.mark.parametrize('person', ['director','speaker'])
def test_absent_people_do_not_start_remote_group(person):
    m=new();m.positions[person]=None
    assert not m.start_recording((0,'start'))


@pytest.mark.parametrize('attempt', [1,2,5,6,99999])
def test_new_attempt_preserves_knowledge_but_invalidates_old_completion(attempt):
    m=new(attempt=attempt,epoch=4);paper(m)
    known=deepcopy(m.knowledge)
    m.sync_context(attempt=attempt+1,epoch=5,positions=dict(m.positions))
    assert m.knowledge==known and not m.started and not m.closed and not m.paper_handed
    assert not m.read_retraction((4,'stale'),formal_dialogue=True)
    assert m.start_recording((5,'newstart'))
    assert not m.can_question_deletion()


def test_reload_does_not_rearm_sequence():
    m=new();paper(m)
    m=m.reload()
    assert not m.start_recording((0,'restart'))
    assert not m.delete_segment((0,'repeatdelete'))


@pytest.mark.parametrize('end', ['death','epoch','interrupt'])
def test_end_invalidates_outstanding_completion(end):
    m=new();paper(m)
    if end=='interrupt': assert m.interrupt((0,'interrupt'))
    else: m.sync_context(attempt=1,epoch=1 if end=='epoch' else 0,positions=m.positions,dead=end=='death')
    assert m.closed and not m.seat_requested
    assert not m.read_retraction((m.epoch,'late'),formal_dialogue=True)


class TherapyMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.m=new();self.serial=0;self.old_knowledge=set()

    def token(self):
        self.serial+=1;return self.m.epoch,self.serial

    @rule(action=st.sampled_from(['start_recording','sit_speaker','speak_transfer','say_stop',
                                  'stop_recording','delete_segment','hand_statement','read_retraction',
                                  'write_minutes','release_seat','stand_up','sign','read_statement',
                                  'search_chair','replay','interrupt']),actual=st.booleans(),formal=st.booleans())
    def operate(self,action,actual,formal):
        before=deepcopy(self.m.__dict__)
        kwargs={'actual':actual}
        if action in ('speak_transfer','read_retraction','say_stop'):
            kwargs['formal_dialogue']=formal
        if action=='speak_transfer': kwargs['heard_text']='TR-017'
        if action=='read_retraction': kwargs['heard_text']=RETRACTION
        if action=='delete_segment': kwargs['seen_by_avatar']=True
        result=getattr(self.m,action)(self.token(),**kwargs)
        if not actual: assert self.m.__dict__==before

    @rule(who=st.sampled_from(['avatar','director','speaker']),where=st.sampled_from([None,GROUP,(2,'corridor'),(1,'ward')]))
    def move(self,who,where):
        positions=dict(self.m.positions);positions[who]=where
        self.m.sync_context(attempt=self.m.attempt,epoch=self.m.epoch,positions=positions,
                            paused=self.m.paused,dead=self.m.dead)

    @rule(paused=st.booleans())
    def pause(self,paused):
        self.m.paused=paused

    @rule(kind=st.sampled_from(['reload','death','attempt','epoch']))
    def lifecycle(self,kind):
        if kind=='reload': self.m=self.m.reload();return
        self.m.sync_context(attempt=self.m.attempt+(kind=='attempt'),
                            epoch=self.m.epoch+(kind in ('attempt','epoch')),
                            positions=self.m.positions,dead=kind=='death')

    @invariant()
    def facts_and_provenance(self):
        assert self.old_knowledge <= self.m.knowledge
        self.old_knowledge=set(self.m.knowledge)
        if self.m.deleted: assert (self.m.attempt,'original') not in self.m.segments
        if self.m.retraction_spoken:
            assert (self.m.attempt,self.m.speaker_id,'said',RETRACTION) in self.m.facts
        if self.m.minutes_written: assert self.m.retraction_spoken
        if self.m.paper_handed: assert self.m.deleted
        if self.m.closed: assert not self.m.seat_requested
        assert all('TR-999' not in str(x) for x in self.m.facts)
        assert len(self.m.events)==len({(a,t) for a,_,t in self.m.events})


TestTherapyMachine=TherapyMachine.TestCase
TestTherapyMachine.settings=settings(max_examples=220,stateful_step_count=65,deadline=None)
