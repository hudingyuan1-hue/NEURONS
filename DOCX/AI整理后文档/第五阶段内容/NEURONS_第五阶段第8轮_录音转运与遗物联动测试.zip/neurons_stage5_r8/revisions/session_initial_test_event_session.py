from copy import deepcopy
from collections import deque
import pytest
from hypothesis import settings,strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant
from event_session import EventSession
from patient_transfer import PATIENT
from group_therapy import RETRACTION
from s3_session import EDGES

class Driver:
    def __init__(self):self.s=EventSession();self.seq=0
    def n(self):self.seq+=1;return(self.s.life.epoch,self.seq)
    def g(self,name,**kw):return self.s.group_action(self.n(),name,**kw)
    def t(self,name,**kw):return self.s.transfer_action(self.n(),name,**kw)
    def c(self,name,**kw):return self.s.cleanup_action(self.n(),name,**kw)
    def go(self,dest):
        q=deque([(self.s.position,[])]);seen={self.s.position}
        while q:
            p,path=q.popleft()
            if p==dest:
                for step in path:assert self.s.move(self.n(),step)
                return
            for e in EDGES:
                if p in e:
                    n=next(iter(e-{p}))
                    if n not in seen:seen.add(n);q.append((n,path+[n]))
        assert False,'route not found'
    def setup_group(self):
        self.go((2,'group'));self.s.actors.update(therapy_director=(2,'group'),speaker=(2,'group'))
        assert self.g('start_recording')
    def setup_transfer(self):
        assert self.s.spawn_transfer(self.n(),'T1');assert self.t('take_order');assert self.t('verify');assert self.t('release_brake')
    def setup_cleaner(self):
        self.go((2,'wash'));self.s.actors['cleaner']=(2,'wash')


def test_formal_speech_records_during_dialogue_but_physical_operations_wait():
    d=Driver();d.setup_group();s=d.s;s.paused=True
    text='转运编号是speaker-transfer-01，那天——'
    assert d.g('speak_transfer',formal_dialogue=True,heard_text=text)
    assert d.g('say_stop',formal_dialogue=True)
    assert s.group.recording and not d.g('stop_recording')
    assert not s.tick(d.n(),999999)
    s.paused=False;assert d.g('stop_recording');assert d.g('delete_segment',seen_by_avatar=True)
    assert s.group.can_question_deletion() and d.g('replay') is None
    assert (s.life.hp,s.life.sp,s.awareness.stage)==(100,100,0)

@pytest.mark.parametrize('reason',['loading','dead','wrong_epoch'])
def test_formal_speech_cannot_bypass_invalid_context(reason):
    d=Driver();d.setup_group();s=d.s
    if reason=='loading':s.loading=True
    if reason=='dead':s.damage_or_exit(d.n(),hp=100)
    n=d.n() if reason!='wrong_epoch' else(-1,999)
    assert not s.group_action(n,'speak_transfer',formal_dialogue=True)
    assert not s.group.original_spoken


def test_avatar_departure_does_not_end_npc_scene_or_reveal_remote_words():
    d=Driver();d.setup_group();s=d.s;d.go((2,'corridor'))
    assert d.g('speak_transfer',heard_text='转运编号')
    assert d.g('say_stop') and d.g('stop_recording') and d.g('delete_segment',seen_by_avatar=True)
    assert not s.group.knowledge and not s.group.can_question_deletion()
    assert not s.blocked() and not s.group.closed


def test_director_leaves_pending_signature_or_delete_never_finishes():
    d=Driver();d.setup_group();s=d.s;assert d.g('speak_transfer')
    assert s.actor_move(d.n(),'therapy_director',(2,'corridor'))
    assert not s.group.seat_requested and s.group.closed
    assert not d.g('say_stop') and not d.g('delete_segment') and not d.g('read_retraction')
    assert not s.group.deleted and not s.group.retraction_spoken


def test_searching_chairs_and_low_sp_key_do_not_force_group_join():
    d=Driver();d.go((2,'group'));s=d.s
    assert d.g('search_chair') and not s.group.started and not s.group.speaker_seated
    s.search.key_owner='avatar';s.life.sp=1;s.life.economy.n=s.life.economy.c=0
    d.go((2,'stairs'));assert s.damage_or_exit(d.n(),exit_actual=True)=='exit'

@pytest.mark.parametrize('step',['transport','cleaner','therapy'])
def test_avatar_drug_stop_does_not_freeze_npc_actions(step):
    d=Driver();s=d.s
    if step=='transport':d.setup_transfer()
    elif step=='cleaner':d.setup_cleaner()
    else:d.setup_group()
    s.drug_stop=1500
    if step=='transport':assert d.t('move',dest='corridor')
    elif step=='cleaner':assert d.c('cover')
    else:assert d.g('write_minutes',prefilled=True)
    assert not s.indoor_action(d.n(),'move') and s.drug_stop==1500

@pytest.mark.parametrize('step',['transport','cleaner','therapy'])
def test_formal_pause_freezes_npc_physical_work(step):
    d=Driver();s=d.s
    if step=='transport':d.setup_transfer()
    elif step=='cleaner':d.setup_cleaner()
    else:d.setup_group()
    s.paused=True
    result=d.t('move',dest='corridor') if step=='transport' else d.c('cover') if step=='cleaner' else d.g('write_minutes',prefilled=True)
    assert not result


def test_actual_transport_to_isolation_one_patient_no_transfer_slip_shortcut():
    d=Driver();d.setup_transfer();s=d.s
    s.actors.update(chief=(2,'corridor'),isolator=(2,'corridor'))
    tid=next(iter(s.ward.transfers))
    assert d.t('move',dest='corridor')
    assert s.report_action(d.n(),'verify_transfer',transfer_id=tid,observed_patient_id=PATIENT)
    oid=s.report_action(d.n(),'sign_transfer_isolation',transfer_id=tid);assert oid
    assert not s.isolation_take(d.n(),oid,'transferred')
    assert d.t('move',dest='quiet')
    assert not s.isolation_take(d.n(),oid,'transferred') # not parked
    assert d.t('park')
    assert s.actor_move(d.n(),'porter',(2,'corridor'))
    assert s.isolation_take(d.n(),oid,'transferred')
    assert s.actor_move(d.n(),'isolator',(2,'quiet'))
    assert s.isolation_find(d.n()) and s.isolation_reach(d.n()) and s.isolation_grip(d.n())
    assert s.isolation_step(d.n(),(2,'quiet'),at_observation=True)
    assert s.isolation_action(d.n(),'begin_close',actual=True);assert s.tick(d.n(),10000)
    assert s.actors['transferred']==(2,'quiet') and s.transport.delivered and not s.isolation.active
    assert len([f for f in s.isolation.facts if f['target']=='transferred'])==1
    assert (s.life.hp,s.life.sp,s.awareness.stage)==(100,100,0)


def test_nurse_missing_does_not_block_transport_or_create_isolation():
    d=Driver();d.setup_transfer();s=d.s
    tid=next(iter(s.ward.transfers));assert d.t('move',dest='corridor')
    assert not s.report_action(d.n(),'verify_transfer',transfer_id=tid,observed_patient_id=PATIENT)
    assert not s.report_action(d.n(),'sign_transfer_isolation',transfer_id=tid)
    assert d.t('move',dest='quiet') and d.t('park')
    assert not s.isolation.facts and not s.transport.dead


def test_old_s2_patient_and_live_corpse_ids_never_merged():
    d=Driver();d.setup_transfer();s=d.s
    assert s.transport.patient_id!=s.group.speaker_id!=s.cleaning.deceased_id
    s.actors['cross_level_patient']=(2,'double')
    assert d.t('move',dest='corridor')
    assert s.actors['cross_level_patient']==(2,'double')
    assert s.actors['transferred']==(2,'corridor')


def test_corpse_move_retains_player_knowledge_and_separate_loot():
    d=Driver();d.setup_cleaner();s=d.s
    assert d.c('observe_body') and d.c('read_item',item='anklet')
    assert d.c('read_item',item='band') and d.c('take_item',item='band')
    before=deepcopy(s.cleaning.knowledge)
    assert d.c('cover') and d.c('load_board') and d.c('move_body',dest='corridor')
    assert s.actors['cleaner']==(2,'corridor') and s.cleaning.board_location=='corridor'
    assert s.cleaning.body_location=='corridor' and s.cleaning.items['band']=='avatar'
    assert not d.c('collect',item='band') and s.cleaning.knowledge==before
    assert (s.life.hp,s.life.sp,s.awareness.stage)==(100,100,0)


def test_scenes_do_not_recreate_moved_body_bed_or_band():
    d=Driver();d.setup_transfer();d.setup_cleaner();s=d.s
    assert d.c('cover') and d.c('load_board') and d.c('move_body',dest='corridor')
    assert d.t('move',dest='corridor');assert d.t('detach_band');assert d.t('move',dest='quiet');assert d.t('park')
    d.go((2,'double'));d.go((2,'wash'));d.s=s.reload();s=d.s
    assert s.cleaning.body_location=='corridor' and s.transport.band_room=='corridor'
    assert s.transport.positions['bed']=='quiet' and not s.spawn_transfer(d.n(),'duplicate')

@pytest.mark.parametrize('attempt',[1,2,5,6,1000000])
def test_owned_relics_and_knowledge_survive_bed_restart(attempt):
    d=Driver();s=d.s;s.life.attempts[3]=s.ward.attempt=s.isolation.attempt=s.transport.attempt=s.cleaning.attempt=attempt
    d.setup_transfer();d.go((2,'double'))
    assert d.t('detach_band') and d.t('pickup') and d.t('read',item='band')
    d.setup_cleaner();assert d.c('read_item',item='band') and d.c('take_item',item='band')
    old=d.n();d.go((1,'ward'));assert s.begin_rest(d.n()) and s.complete_rest(d.n())
    assert s.life.attempts[3]==attempt+1
    assert s.transport.band_owner=='avatar' and s.cleaning.items['band']=='avatar'
    assert s.transport.knowledge and s.cleaning.knowledge
    assert not s.cleanup_action(old,'collect',item='band')

@pytest.mark.parametrize('hp',[0,100])
def test_death_and_level_exit_invalidate_all_old_scene_callbacks(hp):
    d=Driver();d.setup_transfer();d.setup_group();s=d.s;old=d.n()
    if hp:
        assert s.damage_or_exit(d.n(),hp=hp)=='death'
    else:
        s.search.key_owner='avatar';d.go((2,'stairs'));assert s.damage_or_exit(d.n(),exit_actual=True)=='exit'
    assert not s.transfer_action(old,'move',dest='corridor')
    assert not s.group_action(old,'speak_transfer',formal_dialogue=True)
    assert not s.cleanup_action(old,'cover')

class EventMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.d.setup_transfer();self.d.setup_group();self.d.s.actors['cleaner']=(2,'wash')
    @rule(name=st.sampled_from(['start_recording','speak_transfer','say_stop','stop_recording','delete_segment','hand_statement','read_retraction','write_minutes','release_seat','stand_up']))
    def therapy(self,name):self.d.g(name)
    @rule(name=st.sampled_from(['grab_rail','return_hand','detach_band','park','interrupt','resume']))
    def transport(self,name):self.d.t(name)
    @rule(dest=st.sampled_from(['corridor','quiet','stairs']),clear=st.booleans())
    def bed_move(self,dest,clear):self.d.t('move',dest=dest,route_clear=clear)
    @rule(name=st.sampled_from(['notice','cover','load_board','observe_body','unfold_meal']))
    def cleaner(self,name):self.d.c(name)
    @rule(room=st.sampled_from(['corridor','group','double','wash','stairs']))
    def move(self,room):self.d.s.move(self.d.n(),(2,room))
    @rule(item=st.sampled_from(['band','meal']))
    def loot(self,item):self.d.c('take_item',item=item)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused
    @rule(ms=st.sampled_from([0,1,250,1000,6000,10000]))
    def tick(self,ms):self.d.s.tick(self.d.n(),ms)
    @rule()
    def reload(self):self.d.s=self.d.s.reload()
    @rule()
    def death(self):self.d.s.damage_or_exit(self.d.n(),hp=100)
    @rule()
    def revive(self):self.d.s.revive()
    @invariant()
    def consequences(self):
        s=self.d.s
        assert s.awareness.stage==0 and not s.awareness.evidence
        assert s.life.sp==100 and s.life.hp in (0,100)
        assert s.transport.positions['patient']==s.transport.positions['bed']
        if s.group.deleted:assert (s.group.attempt,'original') not in s.group.segments
        if s.cleaning.body_on_board:assert s.cleaning.body_location==s.cleaning.board_location

TestEventMachine=EventMachine.TestCase
TestEventMachine.settings=settings(max_examples=225,stateful_step_count=70,deadline=None)
