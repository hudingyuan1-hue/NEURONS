from copy import deepcopy
import itertools
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from cleanup import Cleanup


def token(m, name):
    return m.attempt, name


@pytest.mark.parametrize('living', ['cross_level_patient', 'corner_patient', 'bed_patient'])
def test_corpse_never_uses_live_identity(living):
    with pytest.raises(ValueError):
        Cleanup(deceased_id=living)


def test_three_identifiers_belong_to_one_separate_dead_person():
    m = Cleanup()
    assert set(m.item_ids.values()) == {m.deceased_id}
    assert m.deceased_id not in m.living_ids
    with pytest.raises(ValueError):
        Cleanup(item_ids={'anklet': m.deceased_id, 'band': 'other', 'meal': m.deceased_id})


@pytest.mark.parametrize('actual,visible', [(False, True), (True, False), (False, False)])
def test_curtain_requires_real_notice(actual, visible):
    m = Cleanup()
    assert not m.notice((1, 1), actual=actual, visible=visible)
    assert not m.curtain_closed


def test_curtain_hides_only_body_not_drain_page_or_owned_information():
    m = Cleanup()
    assert m.read_item((1, 1), 'band')
    assert m.notice((1, 2))
    assert not m.observe_body((1, 3))
    assert not m.read_item((1, 4), 'anklet')
    assert m.unfold_meal((1, 5))
    assert m.read_item((1, 6), 'meal')
    assert m.take_item((1, 7), 'band')
    assert m.matched_identity == m.deceased_id
    assert 'saw_body' not in m.knowledge


@pytest.mark.parametrize('order', list(itertools.permutations(['cover', 'load', 'move'])))
def test_contact_load_and_departure_are_distinct_real_nodes(order):
    m = Cleanup()
    funcs = {'cover': m.cover, 'load': m.load_board, 'move': lambda t: m.move_body(t, 'corridor')}
    for i, action in enumerate(order):
        funcs[action]((1, i))
    assert (m.body_location == 'corridor') == (order == ('cover', 'load', 'move'))
    assert m.board_location == 'wash' or m.body_on_board
    assert m.body_location == m.board_location


@pytest.mark.parametrize('actual,clear', [(False, True), (True, False), (False, False)])
def test_cart_stops_if_no_actual_move_or_passable_door(actual, clear):
    m = Cleanup()
    m.cover((1, 1)); m.load_board((1, 2))
    assert not m.move_body((1, 3), 'corridor', actual=actual, route_clear=clear)
    assert m.body_location == m.board_location == m.cleaner_location == 'wash'


@pytest.mark.parametrize('dest', ['stairs', 'double', 'wash', 'S4'])
def test_body_is_not_teleported_outside_its_defined_route(dest):
    m = Cleanup()
    m.cover((1, 1)); m.load_board((1, 2))
    assert not m.move_body((1, 3), dest)


def test_body_and_attached_anklet_leave_together_without_duplicate():
    m = Cleanup()
    m.cover((1, 1)); m.load_board((1, 2))
    assert m.move_body((1, 3), 'corridor')
    assert m.body_location == m.board_location == 'corridor'
    assert 'anklet' not in m.items
    assert not m.take_item((1, 4), 'anklet')
    assert not m.read_item((1, 5), 'anklet')
    assert not m.move_body((1, 6), 'corridor')


@pytest.mark.parametrize('item', ['band', 'meal'])
def test_avatar_wins_item_race_no_copy_and_no_auto_read(item):
    m = Cleanup()
    assert m.take_item((1, 1), item)
    assert not m.collect((1, 2), item)
    assert not m.take_item((1, 3), item)
    assert m.items[item] == 'avatar' and item not in m.reads


@pytest.mark.parametrize('visible,reachable', list(itertools.product([False, True], repeat=2)))
def test_band_in_bucket_requires_actual_visibility_and_reach(visible, reachable):
    m = Cleanup()
    assert m.collect((1, 1), 'band')
    assert m.take_item((1, 2), 'band', visible=visible, reachable=reachable) == (visible and reachable)
    assert m.items['band'] == ('avatar' if visible and reachable else 'bucket')


def test_reading_does_not_secure_relic_but_collection_cannot_erase_memory():
    m = Cleanup()
    assert m.read_item((1, 1), 'band')
    known = deepcopy(m.knowledge)
    assert m.collect((1, 2), 'band')
    assert m.items['band'] == 'bucket' and m.knowledge == known
    assert not m.read_item((1, 3), 'band', reachable=False)


def test_closed_meal_page_cannot_prove_identity_or_liveness():
    m = Cleanup()
    assert not m.read_item((1, 1), 'meal')
    assert m.unfold_meal((1, 2))
    assert not m.read_item((1, 3), 'meal', legible=False)
    assert m.read_item((1, 4), 'meal')
    assert m.matched_identity is None
    assert m.read_item((1, 5), 'band')
    assert m.matched_identity == m.deceased_id
    assert 'saw_body' not in m.knowledge and 'patient_alive' not in m.knowledge


@pytest.mark.parametrize('covered,curtain', [(True, False), (False, True), (True, True)])
def test_cloth_or_closed_curtain_never_establishes_corpse_knowledge(covered, curtain):
    m = Cleanup(body_covered=covered, curtain_closed=curtain)
    assert not m.observe_body((1, 1))
    assert not m.knowledge


@pytest.mark.parametrize('region', ['shower', 'drain', 'floor'])
def test_wiping_is_local_and_does_not_destroy_items_or_knowledge(region):
    m = Cleanup()
    m.observe_body((1, 1)); m.read_item((1, 2), 'band')
    known, items = deepcopy(m.knowledge), deepcopy(m.items)
    assert m.clean((1, 3), region)
    assert m.traces == {r: r != region for r in ('shower', 'drain', 'floor')}
    assert m.knowledge == known and m.items == items
    assert not m.clean((1, 4), region)


def test_interrupt_preserves_completed_progress_and_resume_finishes_remaining_work():
    m = Cleanup()
    m.cover((1, 1)); m.clean((1, 2), 'drain'); m.collect((1, 3), 'band')
    assert m.interrupt((1, 4))
    assert not m.load_board((1, 5)) and not m.clean((1, 6), 'floor')
    assert m.body_covered and not m.traces['drain'] and m.items['band'] == 'bucket'
    assert m.resume((1, 7))
    assert m.load_board((1, 8)) and m.move_body((1, 9), 'corridor')
    assert len([h for h in m.history if h[0] == 'covered']) == 1


def test_avatar_abnormality_does_not_stop_npc_but_formal_pause_does():
    m = Cleanup(avatar_blocked=True)
    assert not m.take_item((1, 1), 'band')
    assert m.cover((1, 2))
    assert m.collect((1, 3), 'band')
    m.paused = True
    before = deepcopy(m.__dict__)
    assert not m.load_board((1, 4))
    assert not m.clean((1, 5), 'drain')
    assert m.__dict__ == before
    m.paused = False
    assert m.load_board((1, 6))


@pytest.mark.parametrize('attempt', [2, 5, 6, 100, 1000000])
def test_attempts_keep_owned_relics_and_knowledge_without_old_callbacks(attempt):
    m = Cleanup()
    m.take_item((1, 1), 'band'); m.read_item((1, 2), 'band')
    m.cover((1, 3))
    before = deepcopy(m.knowledge)
    assert m.new_attempt(attempt)
    assert m.items['band'] == 'avatar' and m.knowledge == before
    assert not m.collect((attempt, 4), 'band')
    assert not m.cover((1, 5)) and not m.body_covered


def test_reload_retains_owned_items_and_work_and_depart_closes_callbacks():
    m = Cleanup()
    m.take_item((1, 1), 'band'); m.cover((1, 2)); m.load_board((1, 3))
    r = m.reload()
    assert r.__dict__ == m.__dict__
    r.depart()
    assert not r.move_body((1, 4), 'corridor')
    assert r.items['band'] == 'avatar'


def test_duplicate_callback_does_not_move_or_collect_twice():
    m = Cleanup()
    assert m.collect((1, 1), 'band')
    before = deepcopy(m.__dict__)
    assert not m.collect((1, 1), 'band')
    assert m.__dict__ == before


@pytest.mark.parametrize('position', ['corridor', None])
def test_absent_cleaner_cannot_notice_or_collect_remotely(position):
    m = Cleanup(cleaner_location=position)
    assert not m.notice((1, 1))
    assert not m.collect((1, 2), 'band')
    assert not m.cover((1, 3))


class CleanupMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.m = Cleanup()
        self.i = 0
        self.known = set()
        self.owned = set()

    def t(self):
        self.i += 1
        return self.m.attempt, self.i

    @rule(action=st.sampled_from(['notice', 'cover', 'load', 'move', 'collect_band', 'collect_meal',
                                'clean_shower', 'clean_drain', 'clean_floor', 'interrupt', 'resume']),
          actual=st.booleans(), clear=st.booleans())
    def npc_work(self, action, actual, clear):
        m, t = self.m, self.t()
        paused_before = deepcopy(m.__dict__) if m.paused else None
        if action == 'notice': m.notice(t, actual=actual, visible=clear)
        elif action == 'cover': m.cover(t, actual=actual, reachable=clear)
        elif action == 'load': m.load_board(t, actual=actual, space_clear=clear)
        elif action == 'move': m.move_body(t, 'corridor', actual=actual, route_clear=clear)
        elif action.startswith('collect_'): m.collect(t, action[8:], actual=actual, reachable=clear)
        elif action.startswith('clean_'): m.clean(t, action[6:], actual=actual, reachable=clear)
        elif action == 'interrupt': m.interrupt(t, actual=actual)
        else: m.resume(t, actual=actual)
        if paused_before is not None: assert m.__dict__ == paused_before

    @rule(action=st.sampled_from(['observe', 'unfold', 'read', 'take']),
          item=st.sampled_from(['band', 'meal', 'anklet']), actual=st.booleans(),
          visible=st.booleans(), reachable=st.booleans())
    def avatar(self, action, item, actual, visible, reachable):
        m, t = self.m, self.t()
        if action == 'observe': m.observe_body(t, actual=actual, visible=visible)
        elif action == 'unfold': m.unfold_meal(t, actual=actual, visible=visible, reachable=reachable)
        elif action == 'read': m.read_item(t, item, actual=actual, visible=visible, reachable=reachable)
        else: m.take_item(t, item, actual=actual, visible=visible, reachable=reachable)

    @rule(paused=st.booleans(), blocked=st.booleans(), room=st.sampled_from(['wash', 'corridor', None]))
    def environment(self, paused, blocked, room):
        self.m.paused, self.m.avatar_blocked, self.m.avatar_location = paused, blocked, room

    @rule(dest=st.sampled_from(['wash', 'corridor']), actual=st.booleans(), clear=st.booleans())
    def cleaner_walks(self, dest, actual, clear):
        self.m.move_cleaner(self.t(), dest, actual=actual, route_clear=clear)

    @rule(increase=st.sampled_from([1, 4, 999]))
    def restart(self, increase):
        old_attempt = self.m.attempt
        self.m.new_attempt(old_attempt + increase)
        assert not self.m.cover((old_attempt, self.i + 999999))

    @rule()
    def save_reload(self):
        before = deepcopy(self.m.__dict__)
        self.m = self.m.reload()
        assert before == self.m.__dict__

    @invariant()
    def identities_ownership_physics_knowledge(self):
        m = self.m
        assert self.known <= m.knowledge
        self.known = set(m.knowledge)
        now_owned = {item for item, owner in m.items.items() if owner == 'avatar'}
        assert self.owned <= now_owned
        self.owned = now_owned
        assert set(m.items) == {'band', 'meal'}
        assert all(v in {'wash', 'bucket', 'avatar'} for v in m.items.values())
        assert m.body_location == m.board_location
        assert m.body_location != 'corridor' or m.body_on_board
        assert not m.body_on_board or m.body_covered
        assert m.deceased_id not in m.living_ids
        assert set(m.item_ids.values()) == {m.deceased_id}
        assert not m.matched_identity or len(m.reads) >= 2
        for attempt in {h[-1] for h in m.history if isinstance(h[-1], int)}:
            assert sum(h == ('covered', attempt) for h in m.history) <= 1
            assert sum(h == ('loaded', attempt) for h in m.history) <= 1


TestCleanupMachine = CleanupMachine.TestCase
TestCleanupMachine.settings = settings(max_examples=225, stateful_step_count=65, deadline=None)
