"""R8 current/affected checks and isolated replay of actual pre-fix failures."""
import json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def nodes(name,failed=False):
    rows=json.loads((ROOT/'results'/name).read_text())['tests']
    return [r['test'] for r in rows if not failed or r['outcome']=='failed']

def run(args,cwd,label):
    env=os.environ.copy();env['RUN_REPORT']=str(ROOT/'results'/('reproduced_'+label+'.json'))
    return subprocess.run([sys.executable,'-m','pytest','-q',*args,'--hypothesis-seed=2026101208','--hypothesis-show-statistics'],cwd=cwd,env=env).returncode

def main(mode):
    if mode=='affected':return run(sorted(set(nodes('therapy_affected.json')+nodes('transfer_carry_affected.json'))),ROOT,'affected')
    if mode=='current':return run(['test_group_therapy.py','test_cleanup.py','test_patient_transfer.py','test_event_session.py'],ROOT,'current')
    if mode!='failures':raise SystemExit('Use: python reproduce.py affected|current|failures')
    cases=[('therapy',{'group_therapy.py':'therapy_initial/group_therapy.py','test_group_therapy.py':'therapy_initial/test_group_therapy.py'},'therapy_initial.json'),
           ('transfer',{'patient_transfer.py':'transfer_carry_patient_transfer.py','test_patient_transfer.py':'transfer_carry_test_patient_transfer.py'},'transfer_carry_initial.json')]
    codes=[]
    for label,restore,report in cases:
        with tempfile.TemporaryDirectory(prefix='neurons_r8_') as tmp:
            dest=Path(tmp)
            for p in ROOT.glob('*.py'):shutil.copy2(p,dest/p.name)
            for target,source in restore.items():shutil.copy2(ROOT/'revisions'/source,dest/target)
            codes.append(run(nodes(report,True),dest,label+'_failures'))
    print('Expected pytest failure exit codes:',codes)
    return 0 if codes==[1,1] else 1

if __name__=='__main__':raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else 'affected'))
