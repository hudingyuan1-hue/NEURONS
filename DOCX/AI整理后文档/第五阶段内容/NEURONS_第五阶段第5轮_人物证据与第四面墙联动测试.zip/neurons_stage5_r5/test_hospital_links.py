from copy import deepcopy
from itertools import product
import pytest
from hypothesis import given,settings,strategies as st
from test_hospital_session import Driver,cup,equip,grip_doctor,offer_guard

def transfer(d,name,**kw):return d.s.transfer_action(d.n(),name,**kw)
def patient(d,seen=(True,True,True)):
    assert transfer(d,'issue_patient_order') and transfer(d,'start_patient')
    assert transfer(d,'patient_step',step='handover')
    for step,visible in zip(['grab_frame','release_fingers','depart'],seen):
        assert transfer(d,'patient_step',step=step,seen=visible)

@pytest.mark.parametrize('seen',list(product([False,True],repeat=3)))
def test_complete_witness_commits_actual_sp_once_and_no_resource(seen):
    d=Driver();s=d.s;patient(d,seen)
    assert s.life.sp==s.hospital.sp==(90 if all(seen) else 100)
    assert (s.life.economy.n,s.life.economy.c)==(5,3)
    before=s.life.sp
    assert not transfer(d,'patient_step',step='depart',seen=True)
    ev={'id':('S2-transfer',1,'S2-wheelchair'),'attempt':1,'kind':'full_witness','sp_damage':10}
    if all(seen):d.batch(('transfer',ev));assert s.life.sp==before

@pytest.mark.parametrize('sp,expected',[(49,39),(50,40),(59,49),(60,50),(10,0)])
def test_transfer_witness_rejudges_bed_without_counting_search(sp,expected):
    d=Driver();s=d.s;s.life.sp=sp;s._pull();patient(d)
    assert s.life.sp==expected and s.search.used==0 and s.search.income==0
    if sp==10:
        assert s.life.stun==1000;d.tick(1000)
    assert s.decision()==('bed' if expected<50 else 'search')
    s.search.key_owner='avatar';assert s.decision()=='exit'

def test_witness_empty_cancels_search_but_reentry_does_not_redamage():
    d=Driver();s=d.s;t=s.start_search(d.n(),0)
    s.life.sp=10;s._pull();patient(d)
    assert not s.search.pending and s.search.used==1 and s.search.income==0
    d.tick(1000);s.change_room(d.n(),'ward');s.change_room(d.n(),'waiting')
    assert s.life.sp==0 and s.transfer.patient=='departed'
    d.batch(('search_done',t));assert s.search.income==0

def test_gripped_character_can_witness_without_releasing_grip():
    d=Driver();grip_doctor(d);patient(d)
    assert d.s.hospital.holder=='doctor' and d.s.life.sp==90
    d.tick(4000);assert not d.s.hospital.holder and d.s.grip_gap==0

def test_turn_pause_preserves_transfer_and_no_replay_reward():
    d=Driver();s=d.s;transfer(d,'issue_patient_order');transfer(d,'start_patient')
    before=deepcopy(s.transfer);s.paused=True
    assert not transfer(d,'patient_step',step='handover')
    assert s.transfer==before and s.life.sp==100
    s.paused=False
    token=d.n();assert s.transfer_action(token,'patient_step',step='handover')
    before=deepcopy(s.transfer)
    assert not s.transfer_action(token,'patient_step',step='grab_frame',seen=True)
    assert s.transfer==before

def test_true_new_attempt_resets_local_transfer_not_prior_knowledge():
    d=Driver();s=d.s;patient(d);known=set(s.transfer.knowledge)
    s.change_room(d.n(),'ward');assert s.rest(d.n());assert s.transfer.attempt==2
    assert s.transfer.patient=='waiting' and known<=s.transfer.knowledge
    assert s.life.sp==100
    old={'id':('S2-transfer',1,'S2-wheelchair'),'attempt':1,'kind':'full_witness','sp_damage':10}
    d.batch(('transfer',old));assert s.life.sp==100
    patient(d);assert s.life.sp==90 and len(s.witness_paid)==2

def test_bag_and_patient_share_one_porter_without_gate():
    d=Driver();s=d.s
    transfer(d,'issue_bag_order');transfer(d,'issue_patient_order');assert transfer(d,'start_bag')
    assert not transfer(d,'start_patient')
    transfer(d,'bag_step',step='check_tag');transfer(d,'bag_step',step='lift')
    assert not transfer(d,'bag_step',step='depart',route_clear=False)
    d.tick(100000);assert s.transfer.bag=='carried'
    assert s.decision()=='search'
    assert transfer(d,'bag_step',step='depart') and transfer(d,'start_patient')

@pytest.mark.parametrize('missing',['nurse','patient','worker'])
def test_missing_transfer_participant_never_locks_key_exit(missing):
    d=Driver();s=d.s;s.transfer.set_presence(**{missing:False})
    transfer(d,'issue_patient_order');assert not transfer(d,'start_patient')
    s.search.key_owner='avatar';assert d.batch(('exit',True))=='exit'

def test_report_waiting_does_not_block_low_sp_or_reset_on_room_change():
    d=Driver();s=d.s;d.action('file_report');s.life.sp=49;s._pull()
    assert not d.action('receive_report') and s.decision()=='bed'
    s.change_room(d.n(),'ward');s.change_room(d.n(),'office')
    assert s.hospital.report=='desk' and s.life.attempts[2]==1
    s.hospital.guard_present=True;assert d.action('receive_report')
    assert d.action('approach_guard') and d.action('grip_guard')
    d.tick(6000);assert s.decision()=='bed' and s.hospital.guard_damage_count==1

def test_drug_and_empty_are_parallel_and_search_restarts_only_after_real_rest():
    d=Driver();s=d.s;cup(d);d.tick(1000);s.life.sp=15;s._pull()
    d.batch(('swallow',True));assert (s.hospital.drug_stop,s.life.stun)==(1000,1000)
    d.tick(999);assert s.decision()=='wait_effect'
    d.tick(1);assert s.decision()=='bed' and s.life.sp==0
    s.change_room(d.n(),'ward');s.rest(d.n());s.change_room(d.n(),'waiting')
    assert s.hospital.drug_history and s.hospital.medication_count==0
    d.action('give_prescription');d.action('prepare');assert d.action('take_cup')
    assert s.hospital.cup=='refused' and s.life.sp==100

def test_auto_food_retry_waits_for_other_action_but_manual_remains_possible():
    d=Driver();s=d.s;s.life.sp=40;s.life.food['p']='porridge';s._pull()
    assert s.begin_food(d.n(),'p',automatic=True);d.tick(1000)
    d.batch(('damage',(1,0)));d.tick(250)
    assert s.auto_food_wait and s.decision()=='bed'
    assert not s.begin_food(d.n(),'p',automatic=True)
    assert s.begin_food(d.n(),'p',automatic=False)

def test_actual_room_move_unlocks_automatic_food_retry():
    d=Driver();s=d.s;s.life.sp=40;s.life.food['p']='porridge';s._pull()
    s.begin_food(d.n(),'p',automatic=True);d.batch(('damage',(1,0)));d.tick(250)
    assert s.change_room(d.n(),'ward') and not s.auto_food_wait
    assert s.decision()=='eat' and s.begin_food(d.n(),'p',automatic=True)

@settings(max_examples=200,deadline=None)
@given(seen=st.tuples(st.booleans(),st.booleans(),st.booleans()),
       sp=st.integers(1,100),replays=st.integers(0,20))
def test_witness_replay_and_reload_never_multiply_damage(seen,sp,replays):
    d=Driver();s=d.s;s.life.sp=sp;s._pull();patient(d,seen)
    expected=max(0,sp-10) if all(seen) else sp
    for _ in range(replays):
        d.s=d.s.reload();transfer(d,'patient_step',step='depart',seen=True)
        assert d.s.life.sp==expected
