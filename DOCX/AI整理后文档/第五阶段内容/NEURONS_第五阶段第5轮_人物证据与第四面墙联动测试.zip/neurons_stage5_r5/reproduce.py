"""Reproduce current / affected tests or archived real model failures."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BASE=Path(__file__).resolve().parent
SEED='2026101205'

def run(args, cwd, name):
    env=os.environ.copy()
    env['RUN_REPORT']=str(BASE/'results'/('reproduced_'+name+'.json'))
    return subprocess.run([sys.executable,'-m','pytest','-q',*args,
                           '--hypothesis-seed='+SEED,'--hypothesis-show-statistics'],
                          cwd=cwd,env=env).returncode

def nodes(report, failed=False):
    rows=json.loads((BASE/'results'/report).read_text())['tests']
    return [r['test'] for r in rows if not failed or r['outcome']=='failed']

def main(mode):
    if mode=='current':
        return run(['test_awareness.py','test_hospital_people.py','test_evidence_session.py'],BASE,'current')
    if mode=='affected':
        reports=['awareness_affected_retest.json','people_retest.json','people_guard_retest.json',
                 'evidence_affected_retest.json','evidence_actions_retest.json']
        return run(sorted({n for r in reports for n in nodes(r)}),BASE,'affected')
    if mode!='failures':
        raise SystemExit('Use: python reproduce.py affected|current|failures')
    cases=[
        ('awareness',{'awareness.py':'awareness_control_boundary_awareness.py',
                      'test_awareness.py':'awareness_control_boundary_test_awareness.py'},
                     'awareness_control_boundary_initial.json'),
        ('people',{'hospital_people.py':'people_initial.py'},'people_initial.json'),
        ('evidence',{'evidence_session.py':'evidence_initial_evidence_session.py',
                     'test_evidence_session.py':'evidence_initial_test_evidence_session.py'},
                    'evidence_initial.json'),
        ('actions',{'evidence_session.py':'evidence_actions_initial_evidence_session.py',
                    'test_evidence_session.py':'evidence_actions_initial_test_evidence_session.py'},
                   'evidence_actions_initial.json')]
    codes=[]
    for name,restore,report in cases:
        with tempfile.TemporaryDirectory(prefix='neurons_r5_failure_') as td:
            folder=Path(td)
            for file in BASE.glob('*.py'):shutil.copy2(file,folder/file.name)
            for dest,source in restore.items():shutil.copy2(BASE/'revisions'/source,folder/dest)
            selected=nodes(report,failed=True)
            # This was a fixture error, not a model failure.
            selected=[n for n in selected if 'complete_search_releases' not in n]
            codes.append(run(selected,folder,name+'_failure'))
    print('Expected pytest failure exit codes:',codes)
    return 0 if codes==[1,1,1,1] else 1

if __name__=='__main__':
    raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else 'affected'))
