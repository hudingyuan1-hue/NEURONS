"""R5: actual S2 commits -> perceived proof, witnessed records, one guard.

Fixture spawning, geometry/perception, contact and action completion are inputs.
No all-skills, S3 gameplay, real save IO or Unity acceptance is implied.
"""
from dataclasses import dataclass, field
from hospital_session import HospitalSession
from awareness import Awareness
from hospital_people import HospitalPeople


@dataclass
class EvidenceSession(HospitalSession):
    awareness: Awareness = field(default_factory=Awareness)
    people: HospitalPeople = field(default_factory=HospitalPeople)
    action: object = None
    action_context: object = None
    committed: dict = field(default_factory=dict)

    def _sync(self):
        p, a, h = self.people, self.awareness, self.hospital
        p.paused = a.paused = self.paused
        p.dead = self.life.phase == 'dead'
        if p.dead and a.alive:
            a.transition('death')
        h.guard_present = p.guard_present
        h.guard_busy = p.guard_target == 'patient'
        if p.guard_target == 'avatar' and h.guard == 'ended':
            p.finish_guard('avatar')

    def _pull(self):
        super()._pull()
        self._sync()

    def _push(self, before_holder=None, physical_hit=False):
        super()._push(before_holder, physical_hit)
        self._sync()
        if self.action is not None and (self.blocked() or self.life.phase == 'dead'):
            self.awareness.end_action(self.action, completed=False)
            self.action = self.action_context = None

    def _search_ended(self):
        if self.action is not None and self.action[0] == 'search' and self.action[2] not in self.search.pending:
            completed = self.action_context[2] in self.search.complete
            self.awareness.end_action(self.action, completed=completed, kind='search')
            self.action = self.action_context = None

    def context(self):
        if self.action_context is not None:
            return self.action_context
        if self.search.pending:
            _, point = next(iter(self.search.pending.values()))
            return ('S2:' + self.room, 'search', point)
        return ('S2:' + self.room, 'idle', 'avatar')

    def start_search(self, token, point):
        result = super().start_search(token, point)
        if result is not None:
            self.action = ('search', self.life.epoch, result)
            self.action_context = ('S2:' + self.room, 'search', point)
        return result

    def begin_autonomous(self, token, kind, target, probe=False, safe=True):
        if not self.node(token) or self.blocked() or self.search.pending or self.action is not None:
            return False
        if kind not in ('move', 'interact') or self.awareness.control is not None:
            return False
        self.action = ('action', token)
        self.action_context = ('S2:' + self.room, kind, target)
        if probe:
            self.awareness.start_probe(self.action, safe=safe,
                                       grabbed=bool(self.hospital.holder),
                                       stunned=bool(self.life.stun or self.hit_stop or self.hospital.drug_stop))
        return True

    def end_autonomous(self, token, action_id, completed=True, normal=True):
        if not self.node(token) or self.blocked() or action_id != self.action:
            return False
        kind = self.action_context[1]
        self.awareness.end_action(action_id, completed=completed, normal=normal, kind=kind)
        self.action = self.action_context = None
        return True

    def skill(self, token, name, actual=True, hit=False, *, perceived=True,
              visible=True, patient_seen=False, assistant_seen=False, changes_intent=False):
        self._sync()
        if not self.awareness.allowed_intervention():
            return 'restricted'
        ctx, action_id = self.context(), self.action
        stunned = bool(self.life.stun or self.hit_stop or self.hospital.drug_stop)
        exam_before = self.hospital.exam
        result = super().skill(token, name, actual=actual, hit=hit)
        if result in ('reacted', 'resisted', 'interrupted'):
            self.committed[token] = (name, result, ctx)
        if result not in ('reacted', 'resisted'):
            return result
        self.awareness.observe(token, name, ctx, perceived=perceived,
                               reaction=result == 'reacted', resisted=result == 'resisted',
                               conscious=True, stunned=stunned, action_id=action_id,
                               changes_intent=changes_intent)
        if result == 'reacted':
            self.people.patient_witness(token, visible=visible, witnessed=patient_seen)
            if self.room == 'exam' and name == 'withdraw' and exam_before in ('offered', 'refused'):
                self.people.observe_exam(token, 'withdraw', witnessed=assistant_seen)
            if self.room == 'exam' and name == 'knee':
                self.people.observe_exam(token, 'knee', witnessed=assistant_seen, hit=hit)
        self._sync()
        self._search_ended()
        return result

    def hospital_action(self, token, name, *, assistant_seen=False, **kw):
        self._sync()
        if name in ('receive_report', 'approach_guard', 'grip_guard', 'release_guard'):
            if self.people.guard_target == 'patient' or not self.people.guard_present:
                return False
        result = super().hospital_action(token, name, **kw)
        if result and name == 'receive_report':
            self.people.dispatch_guard(report_received=True)
        if result and name == 'begin_exam' and self.hospital.exam == 'refused':
            self.people.observe_exam(token, 'refused', witnessed=assistant_seen)
        self._sync()
        return result

    def record_sample(self, token, sample_id, subject_id, actual=True, matched=True):
        if not self.node(token):
            return False
        return self.people.sample_complete(sample_id, subject_id,
                                           completed=actual and self.hospital.sample_valid,
                                           matched=matched)

    def guard_node(self, token, receive=False, encounter=False):
        """Same-node facts; actual receipt has priority only for an idle guard."""
        if not self.node(token):
            return None
        self._sync()
        if receive and self.people.guard_target is None:
            self._call('receive_report', actual=True)
        owner = self.people.dispatch_guard(
            report_received=self.hospital.guard in ('received', 'approach', 'dragging'),
            patient_encounter=encounter)
        self._sync()
        return owner

    def patient_action(self, token, name, **kw):
        if not self.node(token):
            return False
        if name not in ('approach_patient', 'reach_patient', 'grip_patient', 'drag_patient'):
            return False
        result = getattr(self.people, name)(**kw)
        self._sync()
        return result

    def begin_hint(self, token, kind='fourth_wall', **kw):
        if not self.node(token) or self.search.pending or self.feedback or self.blocked():
            return False
        result = self.people.begin_hint(kind, **kw)
        if result:
            self.paused = True
            self._pull()
        return result

    def finish_hint(self, complete=True):
        # Dialogue completion is intentionally permitted while the world is paused.
        kind = self.people.dialogue
        if kind is None:
            return False
        result = self.people.finish_hint(complete)
        self.paused = False
        self._pull()
        if result:
            self.awareness.npc_hint((self.people.patient_id, kind))
        return result

    def batch(self, token, events):
        ev = list(events)
        before = self.action
        result = super().batch(token, ev)
        self._sync()
        if result == 'exit':
            self.awareness.transition('level')
            self.people.move_level(3)
            self.action = self.action_context = None
        elif result == 'death':
            self.action = self.action_context = None
            self.people.dialogue = None
        elif result == 'alive':
            self._search_ended()
        return result

    def tick(self, token, ms, **kw):
        result = super().tick(token, ms, **kw)
        self._sync()
        return result

    def change_room(self, token, room):
        result = super().change_room(token, room)
        if result:
            self.awareness.transition('room')
            self._search_ended()
        return result

    def _reset_attempt(self):
        super()._reset_attempt()
        self.awareness.new_attempt()
        self.people.new_attempt()
        self.action = self.action_context = None
        self._sync()
