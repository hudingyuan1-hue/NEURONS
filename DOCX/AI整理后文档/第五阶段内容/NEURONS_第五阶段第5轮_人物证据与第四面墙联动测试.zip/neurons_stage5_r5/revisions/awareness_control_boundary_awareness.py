"""S2 P25-36 fourth-wall model; observation is an actual callback, never a UI click.

This module does not mutate HP, SP, resource balances, resistance, truth, or awakening.
"""
from dataclasses import dataclass, field
from collections import Counter


@dataclass(frozen=True)
class Evidence:
    cast_id: object
    skill: str
    context: tuple
    action_id: object
    resisted: bool


@dataclass
class Awareness:
    stage: int = 0  # unaware / suspicious / aware / identified
    attempt: int = 1
    mode: str = "explore"
    alive: bool = True
    paused: bool = False
    evidence: dict = field(default_factory=dict)
    hints: set = field(default_factory=set)
    successful_probes: set = field(default_factory=set)
    probe_used: bool = False
    probe: object = None
    failed_at_count: object = None
    restriction: bool = False
    identified_once: bool = False
    control: object = None
    control_eligible: bool = False
    control_actions: set = field(default_factory=set)
    changes: list = field(default_factory=list)

    def _identify(self, reason):
        if self.stage != 2:
            return False
        self.stage = 3
        self.changes.append((3, reason))
        self.restriction = self.mode == "explore" and not self.identified_once
        self.identified_once = True
        return True

    def observe(self, event_id, skill, context, *, perceived=True, reaction=True,
                resisted=False, source="skill", conscious=True, stunned=False,
                action_id=None, changes_intent=False, valid_cast=True):
        if (not self.alive or self.paused or not conscious or stunned or
                not valid_cast or source != "skill" or not perceived or
                not (reaction or resisted) or event_id in self.evidence):
            return False
        if len(context) != 3:
            raise ValueError("context must be (scene, behavior, actual object/threat)")
        old = self.stage
        self.evidence[event_id] = Evidence(event_id, skill, tuple(context), action_id, resisted)
        if old == 0:
            self.stage = 1
        elif old == 1:
            skills = Counter(e.skill for e in self.evidence.values())
            contexts = {e.context for e in self.evidence.values()}
            if len(self.evidence) >= 3 and len(contexts) >= 2 and max(skills.values()) >= 2:
                self.stage = 2
        if self.stage != old:
            self.changes.append((self.stage, event_id))
        if (old == 2 and self.probe is not None and action_id == self.probe["action_id"]
                and changes_intent and reaction and not resisted):
            self.probe["evidence"].add(event_id)
        return True

    def npc_hint(self, hint_id):
        """A clue cannot become bodily evidence or promote a recognition stage."""
        self.hints.add(hint_id)

    def start_probe(self, action_id, *, safe=True, chasing=False, grabbed=False,
                    incoming_hit=False, conscious=True, stunned=False):
        if (self.stage != 2 or not self.alive or self.paused or self.probe_used or
                not safe or grabbed or incoming_hit or not conscious or stunned or
                (self.mode == "battle" and chasing) or
                (self.failed_at_count is not None and len(self.evidence) <= self.failed_at_count)):
            return False
        self.probe_used = True
        self.probe = {"action_id": action_id, "evidence": set()}
        return True

    def end_action(self, action_id, *, completed=True, autonomous=True, normal=True,
                   kind="move"):
        if not self.alive or self.paused:
            return False
        was_restricted = self.restriction
        if self.probe is not None and action_id == self.probe["action_id"]:
            if completed and self.probe["evidence"]:
                self.successful_probes.add((self.attempt, action_id))
                self._identify("probe")
            else:
                self.failed_at_count = len(self.evidence)
            self.probe = None
        # A newly identified probe is not also the subsequent normal action.
        if was_restricted and completed and autonomous and normal and kind in {"move", "interact", "search"}:
            self.restriction = False
        return True

    def start_control(self, cast_id, *, conscious=True, stunned=False, grabbed=False):
        if not self.alive or self.paused or not conscious or stunned or grabbed or self.control is not None:
            return False
        self.control = cast_id
        self.control_eligible = self.stage == 2
        return True

    def control_action(self, cast_id, event_id, context, *, actual=True,
                       against_intent=True, kind="move", conscious=True, stunned=False):
        if (not self.alive or self.paused or not conscious or stunned or
                cast_id != self.control or not actual or kind not in {"move", "interact"}
                or event_id in self.control_actions):
            return False
        self.control_actions.add(event_id)
        before = self.stage
        # One cast can execute many commands but creates at most one evidence.
        self.observe(cast_id, "control", context, conscious=conscious,
                     stunned=stunned, action_id=event_id)
        if self.control_eligible and before == 2 and against_intent:
            self._identify("control")
        return True

    def end_control(self):
        self.control = None
        self.control_eligible = False

    def allowed_intervention(self, *, rescue=False):
        # The explicit S1 father rescue exception still requires external cost/CD/R checks.
        return self.alive and (not self.restriction or rescue)

    def allowed_item(self):
        return self.alive

    def _close_window(self):
        if self.probe is not None:
            self.failed_at_count = len(self.evidence)
        self.probe = None
        self.restriction = False
        self.end_control()

    def new_attempt(self):
        self._close_window()
        self.attempt += 1
        self.probe_used = False
        self.alive = True

    def transition(self, kind="room"):
        if kind in {"room", "floor", "street_segment"}:
            return  # ordinary crossing preserves the actual action and attempt state
        if kind not in {"level", "death", "battle"}:
            raise ValueError(kind)
        self._close_window()
        if kind == "death":
            self.alive = False
        elif kind == "battle":
            self.mode = "battle"

