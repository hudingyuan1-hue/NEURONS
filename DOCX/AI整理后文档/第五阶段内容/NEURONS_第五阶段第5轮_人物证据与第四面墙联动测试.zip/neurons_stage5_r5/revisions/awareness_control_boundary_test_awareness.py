from copy import deepcopy
import itertools
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from awareness import Awareness

A=("S2", "search", "cabinet")
B=("S2", "search", "desk")

def aware():
    a=Awareness()
    for i, c in enumerate((A,A,B)):
        assert a.observe(i,"skin",c)
    assert a.stage==2
    return a

@pytest.mark.parametrize("kwargs", [
    {"perceived":False}, {"valid_cast":False}, {"conscious":False},
    {"stunned":True}, {"reaction":False}, {"source":"npc"},
    {"source":"enemy"}, {"source":"tutorial"}, {"source":"preview"},
    {"source":"menu"}, {"source":"story_fear"}])
def test_non_evidence_rejected(kwargs):
    a=Awareness(); assert not a.observe(1,"skin",A,**kwargs)
    assert a.stage==0 and not a.evidence

def test_resisted_but_perceived_counts_without_resistance_mutation():
    a=Awareness(); assert a.observe(1,"skin",A,resisted=True,reaction=False)
    assert a.stage==1 and len(a.evidence)==1
    assert not hasattr(a,"resistance")

def test_cast_id_deduplicates_animation_sound_subtitle_and_reloads():
    a=Awareness();a.observe("cast1","skin",A)
    for ctx in (A,B,("S3","move","guard")):
        a=deepcopy(a);assert not a.observe("cast1","skin",ctx)
    assert len(a.evidence)==1 and a.stage==1

@pytest.mark.parametrize("skills,contexts,expected",[
    (["skin"]*3,[A]*3,1),
    (["skin","knee","ear"],[A,B,A],1),
    (["skin"]*2,[A,B],1),
    (["skin"]*3,[A,A,B],2),
    (["skin","knee","skin"],[A,B,A],2),
    (["skin"]*3,[A,A,("S2","move","cabinet")],2),
    (["skin"]*3,[A,A,("S3","search","cabinet")],2),
])
def test_thresholds(skills,contexts,expected):
    a=Awareness()
    for i,(s,c) in enumerate(zip(skills,contexts)):
        before=a.stage;a.observe(i,s,c);assert a.stage<=before+1
    assert a.stage==expected

@pytest.mark.parametrize("changed,resisted,reaction,complete",list(itertools.product([False,True],repeat=4)))
def test_probe_requires_new_actual_change_and_completion(changed,resisted,reaction,complete):
    a=aware();assert a.start_probe("next")
    a.observe(9,"skin",B,action_id="next",changes_intent=changed,resisted=resisted,reaction=reaction)
    assert a.stage==2
    a.end_action("next",completed=complete)
    assert (a.stage==3)==(changed and not resisted and reaction and complete)

@pytest.mark.parametrize("kwargs",[{"safe":False},{"grabbed":True},{"incoming_hit":True},{"stunned":True},{"conscious":False}])
def test_unsafe_probe_denied_without_spending_attempt(kwargs):
    a=aware();assert not a.start_probe(1,**kwargs);assert not a.probe_used

def test_battle_only_after_chase_and_never_locks():
    a=aware();a.mode="battle"
    assert not a.start_probe(1,chasing=True)
    assert a.start_probe(2)
    a.observe(9,"skin",B,action_id=2,changes_intent=True)
    a.end_action(2)
    assert a.stage==3 and not a.restriction and a.allowed_intervention()

def test_probe_once_per_attempt_and_failed_needs_new_evidence():
    a=aware();assert a.start_probe(1);a.end_action(1)
    assert not a.start_probe(2)
    a.new_attempt();assert not a.start_probe(2)
    a.observe(9,"skin",A)
    assert a.start_probe(2)

def test_probe_old_evidence_wrong_action_and_npc_cannot_identify():
    a=aware();a.start_probe(1)
    a.observe(0,"skin",B,action_id=1,changes_intent=True)
    a.observe(9,"skin",B,action_id=2,changes_intent=True)
    a.npc_hint("you_are_controlled");a.end_action(1)
    assert a.stage==2

@pytest.mark.parametrize("kind",["room","floor","street_segment"])
def test_ordinary_crossings_preserve_probe(kind):
    a=aware();a.start_probe(1);a.transition(kind)
    assert a.probe is not None and a.probe_used and a.attempt==1

@pytest.mark.parametrize("kind",["level","death","battle"])
def test_major_boundary_closes_probe_preserves_long_term(kind):
    a=aware();a.start_probe(1);a.observe(9,"skin",B,action_id=1,changes_intent=True)
    a.transition(kind);a.end_action(1)
    assert a.stage==2 and a.probe is None and len(a.evidence)==4

def test_death_and_pause_block_evidence_and_action_commits():
    a=aware();a.start_probe(1);a.paused=True
    assert not a.observe(9,"skin",B,action_id=1,changes_intent=True)
    assert not a.end_action(1)
    assert a.probe is not None
    a.paused=False;a.transition("death")
    assert not a.observe(9,"skin",B);assert not a.allowed_intervention(rescue=True)
    a.new_attempt();assert len(a.evidence)==3 and a.stage==2

@pytest.mark.parametrize("actual,against,kind",itertools.product([False,True],[False,True],["move","interact","turn","attack"]))
def test_control_actual_defiance_only(actual,against,kind):
    a=aware();assert a.start_control("cast")
    a.control_action("cast","cmd",B,actual=actual,against_intent=against,kind=kind)
    assert (a.stage==3)==(actual and against and kind in {"move","interact"})

def test_control_started_before_awareness_cannot_skip_a_stage():
    a=Awareness();a.observe(0,"skin",A);a.observe(1,"skin",B)
    a.start_control("cast")
    a.control_action("cast","cmd",B)
    assert a.stage==2
    a.control_action("cast","cmd2",A)
    assert a.stage==2 and len(a.evidence)==3
    a.end_control();a.start_control("newcast")
    a.control_action("newcast","cmd3",A)
    assert a.stage==3 and len(a.evidence)==4

def test_without_active_control_no_actual_control_callback():
    a=aware();before=deepcopy(a)
    assert not a.control_action(None,"stray",B)
    assert a==before

def test_autonomous_probe_cannot_begin_during_control():
    a=aware();a.start_control("cast")
    assert not a.start_probe("autonomous")
    assert not a.probe_used and a.probe is None

def identified():
    a=aware();a.start_probe(1);a.observe(9,"skin",B,action_id=1,changes_intent=True);a.end_action(1)
    assert a.stage==3 and a.restriction
    return a

@pytest.mark.parametrize("kwargs",[{"completed":False},{"autonomous":False},{"normal":False},{"kind":"dialogue"},{"kind":"animation"},{"kind":"menu"}])
def test_only_normal_autonomous_completion_unlocks(kwargs):
    a=identified();a.end_action(2,**kwargs)
    assert not a.allowed_intervention() and a.allowed_item()
    assert a.allowed_intervention(rescue=True)
    a.end_action(3)
    assert a.allowed_intervention()

def test_lock_never_repeats_and_does_not_gate_keys_or_departure():
    a=identified();a.transition("level")
    assert a.allowed_intervention()
    a.new_attempt();a.observe(99,"skin",A)
    assert a.stage==3 and not a.restriction
    assert not hasattr(a,"key_requirement")


class AwarenessMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.a=Awareness();self.serial=0;self.previous=0
        self.probe_attempts=set();self.all_evidence=set();self.previous_stage=0

    @rule(skill=st.sampled_from(["skin","knee","ear"]),object_id=st.integers(0,2),
          valid=st.booleans(),feel=st.booleans(),reaction=st.booleans(),resisted=st.booleans(),
          source=st.sampled_from(["skill","enemy","npc","tutorial"]))
    def observation(self,skill,object_id,valid,feel,reaction,resisted,source):
        self.serial+=1
        action=self.a.probe["action_id"] if self.a.probe else None
        before=self.a.stage
        self.a.observe(self.serial,skill,("S2","search",object_id),valid_cast=valid,
                       perceived=feel,reaction=reaction,resisted=resisted,source=source,
                       action_id=action,changes_intent=True)
        assert self.a.stage<=before+1

    @rule(safe=st.booleans(),chasing=st.booleans())
    def probe(self,safe,chasing):
        self.serial+=1
        if self.a.start_probe(self.serial,safe=safe,chasing=chasing):
            assert self.a.attempt not in self.probe_attempts
            self.probe_attempts.add(self.a.attempt)

    @rule(completed=st.booleans(),autonomous=st.booleans())
    def end(self,completed,autonomous):
        action=self.a.probe["action_id"] if self.a.probe else self.serial
        self.a.end_action(action,completed=completed,autonomous=autonomous)

    @rule(kind=st.sampled_from(["room","level","death","battle"]))
    def boundary(self,kind): self.a.transition(kind)

    @rule()
    def restart(self):self.a.new_attempt()

    @rule()
    def load(self):
        old=deepcopy(self.a);self.a=deepcopy(self.a)
        assert self.a==old

    @rule()
    def duplicate(self):
        if self.a.evidence:
            e=next(iter(self.a.evidence.values()));before=deepcopy(self.a)
            assert not self.a.observe(e.cast_id,e.skill,B)
            assert self.a==before

    @rule()
    def hint(self):
        before=(self.a.stage,len(self.a.evidence));self.a.npc_hint("patient")
        assert before==(self.a.stage,len(self.a.evidence))

    @rule(paused=st.booleans())
    def pause(self,paused):self.a.paused=paused

    @rule(actual=st.booleans(),against=st.booleans())
    def control(self,actual,against):
        self.serial+=1;self.a.start_control(("control",self.serial))
        self.a.control_action(self.a.control,self.serial,B,actual=actual,against_intent=against)
        self.a.end_control()

    @invariant()
    def preserved_and_bounded(self):
        assert self.a.stage>=self.previous_stage and 0<=self.a.stage<=3
        assert self.all_evidence<=set(self.a.evidence)
        self.previous_stage=self.a.stage;self.all_evidence=set(self.a.evidence)
        if self.a.mode=="battle":assert not self.a.restriction
        if not self.a.alive:assert self.a.probe is None and not self.a.restriction
        if self.a.stage>=2:
            counts={e.skill for e in self.a.evidence.values()}
            assert len(self.a.evidence)>=3 and len({e.context for e in self.a.evidence.values()})>=2
            assert len(counts)<len(self.a.evidence)

TestAwarenessMachine=AwarenessMachine.TestCase
TestAwarenessMachine.settings=settings(max_examples=250,stateful_step_count=50,deadline=None)
