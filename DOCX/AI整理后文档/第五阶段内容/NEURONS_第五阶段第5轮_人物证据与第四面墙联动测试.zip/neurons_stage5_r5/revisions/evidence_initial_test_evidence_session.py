from copy import deepcopy
from itertools import product
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from evidence_session import EvidenceSession
from rules import Skill


class Driver:
    def __init__(self):
        self.s = EvidenceSession()
        self.seq = 0
        for name, cost, power, cd in [('skin',1,1,2000), ('gut',1,1,2000),
                                     ('withdraw',2,2,4000), ('knee',2,2,4000),
                                     ('fear',3,3,8000), ('joy',3,3,8000)]:
            self.s.life.economy.skills[name] = Skill(cost,power,cd)
        self.s.life.economy.n = 500  # test fixture; never gameplay income
    def n(self):
        self.seq += 1
        return (self.s.life.epoch, self.seq)
    def cast(self, name='skin', **kw): return self.s.skill(self.n(), name, **kw)
    def ha(self, name, **kw): return self.s.hospital_action(self.n(), name, **kw)
    def pa(self, name, **kw): return self.s.patient_action(self.n(), name, **kw)
    def tick(self, ms): return self.s.tick(self.n(), ms)
    def batch(self, *events): return self.s.batch(self.n(), events)
    def move(self, target, probe=False):
        assert self.s.begin_autonomous(self.n(), 'move', target, probe=probe)
        return self.s.action
    def end(self, aid, **kw): return self.s.end_autonomous(self.n(), aid, **kw)


def get_aware(d):
    for dest in ('desk', 'desk', 'door'):
        a = d.move(dest)
        assert d.cast() == 'reacted'
        assert d.end(a)
        d.tick(2000)
    assert d.s.awareness.stage == 2


def identify(d):
    get_aware(d)
    a = d.move('exit', probe=True)
    assert d.cast(changes_intent=True) == 'reacted'
    assert d.end(a)
    assert d.s.awareness.stage == 3 and d.s.awareness.restriction


def complete_sample(d):
    d.s.room = 'exam'
    assert d.ha('begin_exam') and d.ha('grip_exam')
    d.batch(('needle', True))
    d.tick(2000)
    assert d.s.hospital.sample_valid


@pytest.mark.parametrize('actual,perceived,visible,witnessed', product([False, True], repeat=4))
def test_cast_proof_adaptation_and_npc_witness_are_separate(actual,perceived,visible,witnessed):
    d=Driver(); s=d.s; n=s.life.economy.n
    result=d.cast(actual=actual,perceived=perceived,visible=visible,patient_seen=witnessed)
    assert result == ('reacted' if actual else 'interrupted')
    assert s.life.economy.n == n-1
    assert len(s.awareness.evidence) == int(actual and perceived)
    assert s.life.economy.skills['skin'].successes == int(actual)
    assert s.people.hint_pending == (actual and visible and witnessed)
    assert not s.life.economy.awakening


@pytest.mark.parametrize('reason', ['funds','cooldown','pause','stun','missing_skill'])
def test_invalid_cast_never_creates_proof_label_or_charge(reason):
    d=Driver(); s=d.s
    if reason=='funds': s.life.economy.n=0
    if reason=='cooldown': s.life.economy.skills['skin'].remaining=1
    if reason=='pause': s.paused=True
    if reason=='stun': s.life.stun=1
    if reason=='missing_skill': del s.life.economy.skills['skin']
    n=s.life.economy.n
    assert d.cast(patient_seen=True,assistant_seen=True) == 'invalid'
    assert s.life.economy.n==n and not s.awareness.evidence and not s.people.witnesses and not s.people.labels


@pytest.mark.parametrize('felt', [False,True])
def test_resisted_but_felt_is_proof_without_reaction_or_npc_hint(felt):
    d=Driver(); s=d.s; search=s.start_search(d.n(),0)
    s.life.economy.skills['skin'].resistance=1
    assert d.cast(perceived=felt,patient_seen=True,changes_intent=True) == 'resisted'
    assert len(s.awareness.evidence)==int(felt) and not s.people.hint_pending
    assert search in s.search.pending and s.life.economy.skills['skin'].successes==0


def test_duplicate_cast_and_reload_do_not_duplicate_proof_or_cost():
    d=Driver(); token=d.n(); n=d.s.life.economy.n
    assert d.s.skill(token,'skin',patient_seen=True)=='reacted'
    d.s=d.s.reload()
    assert d.s.skill(token,'skin',patient_seen=True)=='invalid'
    assert len(d.s.awareness.evidence)==len(d.s.people.witnesses)==1
    assert d.s.life.economy.n==n-1


@pytest.mark.parametrize('hit,present,seen',product([False,True],repeat=3))
def test_assistant_actual_knee_contact_distinct_from_reaction(hit,present,seen):
    d=Driver(); s=d.s; s.room='exam'; s.people.assistant_present=present
    assert d.cast('knee',hit=hit,assistant_seen=seen)=='reacted'
    assert len(s.people.labels)==int(hit and present and seen)
    assert s.life.hp==100 and s.life.sp==100 and len(s.awareness.evidence)==1
    assert s.life.economy.skills['knee'].successes==1


def test_doctor_actual_grip_escape_records_only_real_hit():
    d=Driver(); d.s.room='exam'; d.ha('begin_exam'); d.ha('grip_exam')
    assert d.cast('knee',hit=True,assistant_seen=True)=='reacted'
    assert not d.s.hospital.holder and '攻击行为' in d.s.people.labels.values()
    assert d.s.life.hp==100 and d.s.life.sp==100


@pytest.mark.parametrize('seen',[False,True])
def test_actual_withdraw_records_noncooperation_only_when_witnessed(seen):
    d=Driver(); d.s.room='exam'; d.ha('begin_exam')
    assert d.cast('withdraw',assistant_seen=seen)=='reacted'
    assert len(d.s.people.labels)==int(seen) and d.s.hospital.exam_closed


def test_harm_then_refusal_label_does_not_add_damage():
    d=Driver(); d.s.room='exam'; d.s.doctor_harm_known=True
    assert d.ha('begin_exam',assistant_seen=True)
    assert '不配合检查' in d.s.people.labels.values()
    assert (d.s.life.hp,d.s.life.sp)==(100,100)


@pytest.mark.parametrize('ms', [1999,2000,2001])
def test_sample_requires_real_completion(ms):
    d=Driver(); d.ha('begin_exam'); d.ha('grip_exam'); d.batch(('needle',True));d.tick(ms)
    sid=('S2',1,'avatar')
    assert d.s.record_sample(d.n(),sid,'avatar') == (ms>=2000)


def test_sample_cannot_be_renamed_to_manufacture_a_second_tube():
    d=Driver(); complete_sample(d)
    assert d.s.record_sample(d.n(),('S2',1,'avatar'),'avatar')
    assert not d.s.record_sample(d.n(),'another-tube','avatar')
    assert len(d.s.people.samples)==1


def test_sample_cannot_be_reassigned_to_another_subject():
    d=Driver(); complete_sample(d)
    assert not d.s.record_sample(d.n(),('S2',1,'avatar'),'other-patient',matched=True)
    assert not d.s.people.samples


def test_npc_hint_pauses_world_but_does_not_promote_stage_or_awaken():
    d=Driver(); s=d.s; d.cast(patient_seen=True)
    s.guard_node(d.n(),encounter=True)
    assert s.begin_hint(d.n())
    before=deepcopy((s.life,s.hospital,s.people.guard_state))
    assert not d.pa('approach_patient') and not d.tick(10000)
    assert d.batch(('damage',(100,100)))=='ignored'
    assert (s.life,s.hospital,s.people.guard_state)==before
    assert s.finish_hint() and s.awareness.stage==1 and len(s.awareness.evidence)==1
    assert not s.life.economy.awakening and s.people.hint_said
    assert d.pa('approach_patient')


def test_hint_interruption_not_known_and_not_consumed():
    d=Driver();d.cast(patient_seen=True);assert d.s.begin_hint(d.n())
    assert not d.s.finish_hint(complete=False)
    assert not d.s.people.hint_said and not d.s.awareness.hints
    assert d.s.begin_hint(d.n()) and d.s.finish_hint()


def test_real_approach_blocks_unsaid_hint_but_no_awakening():
    d=Driver();d.cast(patient_seen=True);d.s.guard_node(d.n(),encounter=True)
    assert d.pa('approach_patient')
    assert not d.s.begin_hint(d.n()) and not d.s.people.hint_said
    assert not d.s.life.economy.awakening and d.s.awareness.stage==1


@pytest.mark.parametrize('receive,encounter,present',product([False,True],repeat=3))
def test_same_node_guard_arbitration_requires_actual_receipt(receive,encounter,present):
    d=Driver();s=d.s;s.people.guard_present=present;d.ha('file_report')
    owner=s.guard_node(d.n(),receive=receive,encounter=encounter)
    expected=None if not present else ('avatar' if receive else 'patient' if encounter else None)
    assert owner==expected and (s.life.hp,s.life.sp)==(100,100)


def test_existing_patient_escort_retains_target_report_waits_and_avatar_cannot_free_patient():
    d=Driver();s=d.s;s.guard_node(d.n(),encounter=True)
    for name in ('approach_patient','reach_patient','grip_patient'):assert d.pa(name)
    d.ha('file_report');assert not d.ha('receive_report')
    assert s.guard_node(d.n(),receive=True,encounter=True)=='patient'
    assert s.hospital.report=='desk' and not s.hospital.holder
    d.cast('withdraw')
    assert s.people.guard_target=='patient' and s.people.guard_state=='dragging'
    assert d.pa('drag_patient',crossed_exit=True)
    assert s.people.patient_removed and not s.people.patient_present
    assert d.ha('receive_report') and s.people.guard_target=='avatar'
    assert s.hospital.guard_damage_count==0


def test_existing_avatar_procedure_cannot_grab_patient_and_only_hurts_on_contact():
    d=Driver();s=d.s;d.ha('file_report');d.ha('receive_report')
    assert s.guard_node(d.n(),encounter=True)=='avatar'
    assert not d.pa('approach_patient')
    d.ha('approach_guard');assert (s.life.hp,s.life.sp)==(100,100)
    assert d.ha('grip_guard') and (s.life.hp,s.life.sp)==(95,90)
    d.tick(6000)
    assert s.people.guard_target is None and s.hospital.guard_closed
    assert s.guard_node(d.n(),encounter=True)=='patient'


def test_no_patient_teleport_through_a_blocked_route():
    d=Driver();s=d.s;s.guard_node(d.n(),encounter=True)
    for name in ('approach_patient','reach_patient','grip_patient'):d.pa(name)
    assert not d.pa('drag_patient',route_available=False,crossed_exit=True)
    d.tick(999999)
    assert not s.people.patient_removed and s.people.guard_target=='patient'


def test_probe_identification_lock_uses_next_normal_action_and_allows_items():
    d=Driver();identify(d);s=d.s;n=s.life.economy.n
    assert d.cast()=='restricted' and s.life.economy.n==n
    s.life.food['c']='candy'
    assert s.begin_food(d.n(),'c') and s.awareness.restriction
    d.tick(1500);d.batch(('food','c'))
    assert 'c' not in s.life.food and s.awareness.restriction
    a=d.move('door');assert d.end(a) and not s.awareness.restriction


def test_complete_search_releases_one_action_lock_cancel_does_not():
    d=Driver();identify(d);s=d.s
    t=s.start_search(d.n(),0);d.batch(('search_cancel',t))
    assert s.awareness.restriction and s.action is None
    t=s.start_search(d.n(),1);d.batch(('search_done',t))
    assert not s.awareness.restriction and s.action is None


def test_probe_interrupted_by_damage_cannot_be_finished_by_late_callback():
    d=Driver();get_aware(d);a=d.move('exit',probe=True)
    d.cast(changes_intent=True);d.batch(('damage',(1,0)));d.tick(250)
    assert not d.end(a) and d.s.awareness.stage==2 and d.s.awareness.probe is None


@pytest.mark.parametrize('boundary',['room','rest','death','exit'])
def test_evidence_persistence_and_unfinished_probe_boundaries(boundary):
    d=Driver();get_aware(d);s=d.s;a=d.move('door',probe=True)
    count=len(s.awareness.evidence);epoch=s.life.epoch
    if boundary=='room': assert s.change_room(d.n(),'office')
    if boundary=='rest': s.room='ward';assert s.rest(d.n())
    if boundary=='death': d.batch(('damage',(100,0)));assert s.revive()
    if boundary=='exit': s.search.key_owner='avatar';assert d.batch(('exit',True))=='exit'
    assert len(s.awareness.evidence)==count and s.awareness.stage==2
    assert (s.awareness.probe is not None)==(boundary=='room')
    if boundary!='room':assert not s.end_autonomous((epoch,999),'old')


@pytest.mark.parametrize('damage,expected',[(0,'exit'),(99,'exit'),(100,'death')])
def test_wall_lock_no_resources_high_resistance_absent_npcs_does_not_gate_exit(damage,expected):
    d=Driver();identify(d);s=d.s;s.search.key_owner='avatar';s.life.sp=0;s.life.emptied=True
    s.life.economy.n=s.life.economy.c=0;s.life.economy.global_r=100
    s.people.patient_present=s.people.guard_present=s.people.assistant_present=False
    assert d.batch(('damage',(damage,0)),('exit',True))==expected
    assert s.life.progress==(3 if expected=='exit' else 2)
    assert not s.awareness.restriction


def test_cross_level_identity_labels_and_actual_scars_survive_without_added_injury():
    d=Driver();s=d.s;identity=s.people.patient_id
    s.room='exam';d.cast('knee',hit=True,assistant_seen=True)
    s.guard_node(d.n(),encounter=True)
    for name in ('approach_patient','reach_patient','grip_patient'):d.pa(name)
    d.pa('drag_patient',crossed_exit=True)
    before=s.people.inherited_record();s.search.key_owner='avatar'
    assert d.batch(('exit',True))=='exit'
    assert s.people.patient_id==identity and s.people.level==3
    assert s.people.inherited_record()==before and (s.life.hp,s.life.sp)==(100,100)
    assert not d.ha('grip_guard') and not d.pa('grip_patient')
    assert not s.life.economy.awakening


def test_absent_patient_and_assistant_do_not_block_entire_search_exit():
    d=Driver();s=d.s;s.people.patient_present=s.people.assistant_present=s.people.guard_present=False
    for point in range(12):
        t=s.start_search(d.n(),point);assert t is not None
        d.batch(('search_done',t));s.finish_feedback(d.n())
    assert s.search.key_owner=='avatar' and d.batch(('exit',True))=='exit'
    assert not s.people.labels and not s.awareness.evidence


class EvidenceSessionMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.previous_known=set();self.previous_evidence=set()

    @rule(name=st.sampled_from(['skin','gut','withdraw','knee','fear','joy']),
          actual=st.booleans(),perceived=st.booleans(),visible=st.booleans(),seen=st.booleans())
    def cast(self,name,actual,perceived,visible,seen):
        s=self.d.s;n=s.life.economy.n;before=len(s.awareness.evidence)
        result=self.d.cast(name,actual=actual,perceived=perceived,visible=visible,patient_seen=seen)
        assert len(s.awareness.evidence)-before in (0,1)
        if result in ('invalid','restricted'):assert s.life.economy.n==n and len(s.awareness.evidence)==before

    @rule(ms=st.sampled_from([0,1,249,250,799,800,1999,2000,6000,8000]))
    def time(self,ms):self.d.tick(ms)

    @rule(which=st.sampled_from(['file_report','receive_report','approach_guard','grip_guard','release_guard',
                               'begin_exam','grip_exam','end_exam','withdraw']))
    def hospital(self,which):self.d.ha(which)

    @rule(which=st.sampled_from(['approach_patient','reach_patient','grip_patient','drag_patient']),actual=st.booleans())
    def patient(self,which,actual):
        kw={'actual_motion':actual,'crossed_exit':actual} if which=='drag_patient' else {'actual':actual}
        self.d.pa(which,**kw)

    @rule(receive=st.booleans(),encounter=st.booleans())
    def guard(self,receive,encounter):self.d.s.guard_node(self.d.n(),receive,encounter)

    @rule(begin=st.booleans(),complete=st.booleans())
    def hint(self,begin,complete):
        if begin:self.d.s.begin_hint(self.d.n())
        else:self.d.s.finish_hint(complete)

    @rule(point=st.integers(0,11),complete=st.booleans())
    def search(self,point,complete):
        s=self.d.s;t=s.start_search(self.d.n(),point)
        if t is not None:self.d.batch(('search_done' if complete else 'search_cancel',t))
        s.finish_feedback(self.d.n())

    @rule(room=st.sampled_from(['ward','waiting','exam','office','pharmacy']))
    def room(self,room):self.d.s.change_room(self.d.n(),room)

    @rule(probe=st.booleans(),complete=st.booleans())
    def autonomous(self,probe,complete):
        s=self.d.s
        if s.action is None:s.begin_autonomous(self.d.n(),'move','door',probe=probe)
        elif s.action[0]=='action':s.end_autonomous(self.d.n(),s.action,completed=complete)

    @rule(hp=st.sampled_from([0,1,99,100]),sp=st.sampled_from([0,1,100]))
    def damage(self,hp,sp):self.d.batch(('damage',(hp,sp)))

    @rule()
    def restart(self):
        s=self.d.s
        if s.life.phase=='dead':s.revive()
        elif s.room=='ward':s.rest(self.d.n())

    @rule()
    def reload(self):self.d.s=self.d.s.reload()

    @rule()
    def exit(self):self.d.batch(('exit',True))

    @invariant()
    def independent_ledgers_and_shared_actor(self):
        s=self.d.s;p=s.people
        assert not s.life.economy.awakening and not s.life.economy.pending_g
        assert 0<=s.life.hp<=100 and 0<=s.life.sp<=100 and s.life.economy.n>=0
        assert self.previous_evidence<=set(s.awareness.evidence)
        assert self.previous_known<=p.known
        self.previous_evidence=set(s.awareness.evidence);self.previous_known=set(p.known)
        assert set(s.awareness.evidence)<=set(s.committed)
        assert not (p.guard_target=='patient' and s.hospital.holder=='guard')
        if p.patient_removed:assert not p.patient_present
        if p.hint_said:assert 'fourth_wall_hint' in p.known
        if p.dialogue is not None:assert s.paused


TestEvidenceSessionMachine=EvidenceSessionMachine.TestCase
TestEvidenceSessionMachine.settings=settings(max_examples=250,stateful_step_count=65,deadline=None)
