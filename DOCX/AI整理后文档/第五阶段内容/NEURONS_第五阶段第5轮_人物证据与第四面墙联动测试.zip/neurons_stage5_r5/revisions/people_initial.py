"""S2 assistant, cross-level patient and shared-guard arbitration.

Source S3:P437-460/T10/P516/P591-598/P617-619. Geometry, observed
contact, UI dialogue completion and NPC availability are caller facts.
No damage, awakening, fourth-wall counters, artificial speed or timeout.
"""
from dataclasses import dataclass, field


@dataclass
class HospitalPeople:
    attempt: int = 1
    level: int = 2
    paused: bool = False
    dead: bool = False
    patient_id: str = 'cross_level_patient'
    patient_present: bool = True
    assistant_present: bool = True
    guard_present: bool = True
    guard_target: str | None = None
    guard_state: str = 'idle'
    patient_removed: bool = False
    hint_pending: bool = False
    hint_said: bool = False
    dialogue: str | None = None
    known: set = field(default_factory=set)
    facts: dict = field(default_factory=dict)
    labels: dict = field(default_factory=dict)
    samples: dict = field(default_factory=dict)
    witnesses: set = field(default_factory=set)
    scars: set = field(default_factory=set)
    events: list = field(default_factory=list)

    def active(self):
        return not self.paused and not self.dead

    def available_patient(self):
        return self.patient_present and not self.patient_removed

    def observe_exam(self, event_id, kind, actual=True, witnessed=True, hit=False):
        """actual = a real action, never a queued click or unsatisfied cast.

        Facts are independent from the assistant's selective allegations.
        """
        if not self.active() or not actual or event_id in self.facts:
            return False
        if kind not in ('refused', 'withdraw', 'knee', 'struggle'):
            return False
        self.facts[event_id] = (kind, bool(hit) if kind == 'knee' else None)
        if not self.assistant_present or not witnessed:
            return True
        if kind in ('refused', 'withdraw'):
            self.labels[event_id] = '不配合检查'
        elif kind == 'knee' and hit:
            self.labels[event_id] = '攻击行为'
        return True

    def sample_complete(self, sample_id, subject_id, completed=True, matched=True):
        if not (self.active() and self.assistant_present and completed and matched):
            return False
        if sample_id in self.samples:
            return False
        self.samples[sample_id] = subject_id
        return True

    def patient_witness(self, cast_id, success=True, visible=True, witnessed=True):
        if not (self.active() and self.available_patient() and success and visible and witnessed):
            return False
        if cast_id in self.witnesses:
            return False
        self.witnesses.add(cast_id)
        if not self.hint_said:
            self.hint_pending = True
        return True

    def begin_hint(self, kind='fourth_wall', close=True, medics_listening=False):
        if not (self.active() and self.available_patient() and close and not medics_listening):
            return False
        if self.dialogue is not None or (self.guard_target == 'patient' and self.guard_state != 'idle'):
            return False
        if kind == 'fourth_wall' and (not self.hint_pending or self.hint_said):
            return False
        if kind not in ('fourth_wall', 'number'):
            return False
        self.dialogue = kind
        return True

    def finish_hint(self, complete=True):
        # Formal dialogue freezes world movement, not its own close callback.
        if self.dead or self.dialogue is None:
            return False
        kind = self.dialogue
        self.dialogue = None
        if not complete or not self.available_patient():
            return False
        if self.guard_target == 'patient' and self.guard_state != 'idle':
            return False
        self.known.add(kind + '_hint')
        if kind == 'fourth_wall':
            self.hint_said = True
            self.hint_pending = False
        return True

    def read_number(self, number, actual=True, clear=True):
        if not (self.active() and actual and clear):
            return False
        self.known.add(('number', number))
        return True

    def dispatch_guard(self, report_received=False, patient_encounter=False):
        """Caller batches same-node report receipt and actual encounter.

        Existing work retains its owner; received report wins only on idle.
        A report merely on the desk is NOT report_received.
        """
        if not (self.active() and self.guard_present) or self.guard_target is not None:
            return self.guard_target
        if report_received:
            self.guard_target, self.guard_state = 'avatar', 'assigned'
        elif patient_encounter and self.available_patient():
            self.guard_target, self.guard_state = 'patient', 'assigned'
        return self.guard_target

    def approach_patient(self, actual=True):
        if not (self.active() and self.guard_present and actual and self.available_patient()
                and self.guard_target == 'patient' and self.guard_state == 'assigned'
                and self.dialogue is None):
            return False
        self.guard_state = 'approaching'
        return True

    def reach_patient(self, actual=True):
        if not (self.active() and self.guard_present and actual and self.available_patient()
                and self.guard_target == 'patient' and self.guard_state == 'approaching'
                and self.dialogue is None):
            return False
        self.guard_state = 'reaching'
        return True

    def grip_patient(self, actual=True):
        if not (self.active() and self.guard_present and self.guard_target == 'patient'
                and self.guard_state == 'reaching' and self.dialogue is None):
            return False
        if not actual:
            self.finish_guard('patient')
            return False
        self.guard_state = 'dragging'
        self.scars.add((self.level, self.attempt, 'actual_grip'))
        return True

    def drag_patient(self, actual_motion=True, route_available=True, crossed_exit=False):
        if not (self.active() and self.guard_present and self.guard_target == 'patient'
                and self.guard_state == 'dragging' and self.dialogue is None):
            return False
        if not actual_motion or not route_available:
            return False
        self.scars.add((self.level, self.attempt, 'actual_drag'))
        if crossed_exit:
            self.patient_removed = True
            self.patient_present = False
            self.finish_guard('patient')
        return True

    def finish_guard(self, owner):
        if self.guard_target != owner:
            return False
        self.guard_target, self.guard_state = None, 'idle'
        return True

    def visit_room(self):
        # Returning does not respawn a patient who was actually taken out.
        return self.available_patient()

    def new_attempt(self):
        self.attempt += 1
        self.patient_removed = False
        self.patient_present = True  # Caller applies this attempt's spawn roll.
        self.guard_target, self.guard_state = None, 'idle'
        self.dialogue = None
        self.paused = self.dead = False

    def move_level(self, level):
        if level not in (2, 3, 5):
            return False
        if level != self.level:
            self.level, self.attempt = level, 1
            self.patient_removed = False
            self.patient_present = True
            self.guard_target, self.guard_state = None, 'idle'
            self.dialogue = None
        return True

    def inherited_record(self):
        return {'patient_id': self.patient_id, 'facts': dict(self.facts),
                'labels': dict(self.labels), 'samples': dict(self.samples),
                'known': set(self.known), 'scars': set(self.scars),
                'hint_said': self.hint_said}
