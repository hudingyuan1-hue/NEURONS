from copy import deepcopy
import itertools
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from hospital_people import HospitalPeople


@pytest.mark.parametrize('kind,hit,expected', [
    ('refused', False, '不配合检查'), ('withdraw', False, '不配合检查'),
    ('knee', True, '攻击行为'), ('knee', False, None), ('struggle', False, None)])
@pytest.mark.parametrize('present,witness', [(True, True), (True, False), (False, True)])
def test_assistant_actual_facts_not_label_inference(kind,hit,expected,present,witness):
    p=HospitalPeople(assistant_present=present)
    assert p.observe_exam('real',kind,hit=hit,witnessed=witness)
    assert len(p.facts)==1
    assert p.labels.get('real')==(expected if present and witness else None)
    p.assistant_present=True
    assert not p.observe_exam('real',kind,hit=hit,witnessed=True)
    assert len(p.facts)==1


@pytest.mark.parametrize('kind',['refused','withdraw','knee','struggle'])
def test_click_or_unexecuted_action_no_fact(kind):
    p=HospitalPeople()
    assert not p.observe_exam(1,kind,actual=False,hit=True)
    assert not p.facts and not p.labels


@pytest.mark.parametrize('completed,matched,present',list(itertools.product((False,True),repeat=3)))
def test_only_actual_matching_sample_is_checked(completed,matched,present):
    p=HospitalPeople(assistant_present=present)
    assert p.sample_complete('tube-A','old-patient',completed,matched)==(completed and matched and present)
    assert p.samples==({'tube-A':'old-patient'} if completed and matched and present else {})
    if p.samples:
        assert not p.sample_complete('tube-A','avatar')
        assert p.samples['tube-A']=='old-patient'


@pytest.mark.parametrize('success,visible,witness,present',list(itertools.product((False,True),repeat=4)))
def test_hint_requires_actual_success_visible_and_person_witness(success,visible,witness,present):
    p=HospitalPeople(patient_present=present)
    eligible=success and visible and witness and present
    assert p.patient_witness(1,success,visible,witness)==eligible
    assert p.begin_hint()==eligible
    if eligible:
        assert p.finish_hint()
    assert p.hint_said==eligible
    assert ('fourth_wall_hint' in p.known)==eligible


def test_interrupted_hint_not_consumed_then_says_once_across_attempts_levels():
    p=HospitalPeople()
    p.patient_witness(1)
    assert p.begin_hint()
    assert not p.finish_hint(complete=False)
    assert not p.hint_said and not p.known
    assert p.begin_hint() and p.finish_hint()
    ident=p.patient_id
    for level in (3,5):
        assert p.move_level(level)
        p.new_attempt()
        assert p.patient_id==ident and p.hint_said
        p.patient_witness(level)
        assert not p.begin_hint()


def test_number_hint_is_not_read_content_or_other_archive():
    p=HospitalPeople()
    assert p.begin_hint('number') and p.finish_hint()
    assert p.known=={'number_hint'}
    assert not p.read_number('B42',clear=False)
    assert p.read_number('B42')
    assert p.known=={'number_hint',('number','B42')}


@pytest.mark.parametrize('medics,close',[(True,True),(False,False),(True,False)])
def test_no_unsafe_or_distant_hint(medics,close):
    p=HospitalPeople(); p.patient_witness(1)
    assert not p.begin_hint(close=close,medics_listening=medics)
    assert not p.hint_said


def test_formal_dialogue_close_works_under_world_pause():
    p=HospitalPeople();p.patient_witness(1);p.begin_hint();p.paused=True
    assert p.finish_hint()
    assert p.hint_said


def test_assigned_guard_does_not_silence_patient_before_actual_approach():
    p=HospitalPeople();p.patient_witness(1)
    p.dispatch_guard(patient_encounter=True)
    # Assignment is not yet physical approach; truthful completed speech stays.
    assert p.begin_hint()
    assert p.finish_hint()
    assert p.hint_said


def test_guard_approach_stops_new_disclosure_but_not_known():
    p=HospitalPeople();p.begin_hint('number');p.finish_hint()
    p.patient_witness(1);p.dispatch_guard(patient_encounter=True)
    assert p.approach_patient()
    assert not p.begin_hint()
    assert p.known=={'number_hint'} and not p.hint_said


@pytest.mark.parametrize('report,patient,expected',[(False,False,None),(True,False,'avatar'),(False,True,'patient'),(True,True,'avatar')])
def test_idle_guard_same_node_priority(report,patient,expected):
    p=HospitalPeople()
    assert p.dispatch_guard(report,patient)==expected
    assert p.guard_target==expected


def test_busy_guard_not_preempted_report_stays_outside_component():
    p=HospitalPeople();p.dispatch_guard(patient_encounter=True);p.approach_patient()
    assert p.dispatch_guard(report_received=True)=='patient'
    assert not p.finish_guard('avatar')
    assert p.guard_target=='patient'
    p.finish_guard('patient')
    assert p.dispatch_guard(report_received=True)=='avatar'
    assert p.dispatch_guard(patient_encounter=True)=='avatar'


@pytest.mark.parametrize('present,encounter',[(False,True),(True,False),(False,False)])
def test_patient_takeaway_not_remote(present,encounter):
    p=HospitalPeople(guard_present=present)
    assert p.dispatch_guard(patient_encounter=encounter) is None
    assert not p.grip_patient() and not p.drag_patient(crossed_exit=True)
    assert not p.patient_removed and not p.scars


def _takeaway():
    p=HospitalPeople();p.dispatch_guard(patient_encounter=True)
    assert p.approach_patient() and p.reach_patient() and p.grip_patient()
    return p


@pytest.mark.parametrize('motion,route,crossed',list(itertools.product((False,True),repeat=3)))
def test_removed_only_after_real_drag_crosses_existing_exit(motion,route,crossed):
    p=_takeaway();p.drag_patient(motion,route,crossed)
    removed=motion and route and crossed
    assert p.patient_removed==removed
    assert ((2,1,'actual_drag') in p.scars)==(motion and route)
    assert p.visit_room()==(not removed)


def test_paused_or_dead_stops_physical_interaction():
    for state in ('paused','dead'):
        p=_takeaway();setattr(p,state,True);before=deepcopy(p.__dict__)
        assert not p.drag_patient(crossed_exit=True)
        assert not p.patient_witness(5)
        assert not p.observe_exam(6,'refused')
        assert p.__dict__==before


def test_real_scar_does_not_invent_death_or_hurt_from_false_label():
    p=HospitalPeople();p.observe_exam(1,'refused');p.observe_exam(2,'knee',hit=False)
    old=p.inherited_record()
    assert p.move_level(3) and p.inherited_record()==old
    assert not p.scars and not p.dead
    assert p.labels=={1:'不配合检查'}


def test_removed_scope_and_identity_saved_through_load_and_transition():
    p=_takeaway();p.drag_patient(crossed_exit=True);q=deepcopy(p)
    assert not q.visit_room()
    assert q.patient_id==p.patient_id and q.scars==p.scars
    assert q.move_level(3) and q.visit_room()
    assert q.patient_id==p.patient_id and q.scars==p.scars


class PeopleMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.p=HospitalPeople();self.serial=0;self.witness_valid=set();self.report_truth={}

    @rule(kind=st.sampled_from(['refused','withdraw','knee','struggle']),actual=st.booleans(),hit=st.booleans(),seen=st.booleans())
    def exam(self,kind,actual,hit,seen):
        self.serial+=1
        self.p.observe_exam(self.serial,kind,actual,seen,hit)
        self.report_truth[self.serial]=(actual,seen,self.p.assistant_present,kind,hit)

    @rule(success=st.booleans(),visible=st.booleans(),witness=st.booleans())
    def witness(self,success,visible,witness):
        self.serial+=1
        if self.p.active() and self.p.available_patient() and success and visible and witness:self.witness_valid.add(self.serial)
        self.p.patient_witness(self.serial,success,visible,witness)

    @rule(begin=st.booleans(),complete=st.booleans())
    def speech(self,begin,complete):
        if begin:self.p.begin_hint()
        else:self.p.finish_hint(complete)

    @rule(op=st.sampled_from(['dispatch','approach','reach','grip','drag','release']),actual=st.booleans(),route=st.booleans(),cross=st.booleans(),report=st.booleans())
    def guard(self,op,actual,route,cross,report):
        if op=='dispatch':self.p.dispatch_guard(report,actual)
        elif op=='approach':self.p.approach_patient(actual)
        elif op=='reach':self.p.reach_patient(actual)
        elif op=='grip':self.p.grip_patient(actual)
        elif op=='drag':self.p.drag_patient(actual,route,cross)
        else:self.p.finish_guard('avatar' if report else 'patient')

    @rule(paused=st.booleans(),assistant=st.booleans(),guard=st.booleans())
    def availability(self,paused,assistant,guard):
        self.p.paused=paused;self.p.assistant_present=assistant;self.p.guard_present=guard

    @rule(level=st.sampled_from([2,3,5]),new=st.booleans())
    def transition(self,level,new):
        if new:self.p.new_attempt()
        else:self.p.move_level(level)

    @invariant()
    def truthful_limits(self):
        assert self.p.patient_id=='cross_level_patient'
        assert self.p.witnesses<=self.witness_valid
        assert not self.p.hint_said or self.p.witnesses
        for event,label in self.p.labels.items():
            actual,seen,present,kind,hit=self.report_truth[event]
            assert actual and seen and present
            assert (label=='不配合检查' and kind in ('refused','withdraw')) or (label=='攻击行为' and kind=='knee' and hit)
        if self.p.patient_removed:
            assert (self.p.level,self.p.attempt,'actual_grip') in self.p.scars
            assert (self.p.level,self.p.attempt,'actual_drag') in self.p.scars
            assert not self.p.patient_present
        assert self.p.guard_target in (None,'avatar','patient')
        if self.p.guard_state in ('approaching','reaching','dragging'):
            assert self.p.guard_target=='patient'


TestPeopleMachine=PeopleMachine.TestCase
TestPeopleMachine.settings=settings(max_examples=225,stateful_step_count=55,deadline=None)
