"""Reproduce R9; original evidence is never overwritten.
pip install -r requirements.txt
python reproduce.py current|affected|failures
"""
import json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SEED='2026101209'

def nodes(name):
    return [x['test'] for x in json.loads((ROOT/'results'/f'{name}.json').read_text())['tests']]

def run(label,where,selected,expect_failure=False):
    env=os.environ.copy()
    deps=Path('/tmp/neurons_stage5_deps')
    if deps.exists():env['PYTHONPATH']=str(deps)+os.pathsep+env.get('PYTHONPATH','')
    report=ROOT/'results'/f'reproduced_{label}.json'
    env['RUN_REPORT']=str(report)
    cmd=[sys.executable,'-m','pytest',*selected,'-q',f'--hypothesis-seed={SEED}','--hypothesis-show-statistics']
    with (ROOT/'results'/f'reproduced_{label}.log').open('w') as log:
        p=subprocess.run(cmd,cwd=where,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(label,'exit',p.returncode,'report',report.name)
    return p.returncode==(1 if expect_failure else 0)

def main(mode):
    if mode=='current':
        return run('current',ROOT,['test_corner_patient.py','test_workroom.py','test_ward_final_session.py'])
    if mode=='affected':
        return run('affected',ROOT,nodes('corner_impacted')+nodes('session_takeover_affected'))
    if mode=='failures':
        ok=True
        for label,replacements,selection in (
            ('corner',{'corner_patient.py':'corner_patient_prefix.py','test_corner_patient.py':'corner_tests_prefix.py'},'corner_boundary_failure'),
            ('takeover',{'ward_final_session.py':'session_takeover_ward_final_session.py','test_ward_final_session.py':'session_takeover_test_ward_final_session.py'},'session_takeover_initial')):
            with tempfile.TemporaryDirectory(prefix='neurons_r9_') as tmp:
                d=Path(tmp)
                for p in ROOT.glob('*.py'):shutil.copy2(p,d/p.name)
                for dest,src in replacements.items():shutil.copy2(ROOT/'revisions'/src,d/dest)
                ok=run(label+'_failure',d,nodes(selection),True) and ok
        return ok
    raise SystemExit('Choose current, affected, or failures')

if __name__=='__main__':sys.exit(0 if main(sys.argv[1] if len(sys.argv)>1 else 'affected') else 1)
