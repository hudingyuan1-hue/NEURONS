from collections import deque
from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant
from ward_final_session import WardFinalSession,DRAWER_POINT
from s3_session import EDGES
from rules import Search

class Driver:
    def __init__(self,attempt=1,key=44):
        self.s=WardFinalSession(search=Search(level=3,key_point=key),targets=tuple(range(31,45)))
        self.s.life.attempts[3]=attempt;self.s.search.attempt=attempt;self.seq=0;self.s._sync()
    def n(self):self.seq+=1;return (self.s.life.epoch,self.seq)
    def c(self,name,**kw):return self.s.corner_action(self.n(),name,**kw)
    def w(self,name,**kw):return self.s.work_action(self.n(),name,**kw)
    def go(self,dest):
        q=deque([(self.s.position,[])]);seen={self.s.position}
        while q:
            p,path=q.popleft()
            if p==dest:
                for step in path:assert self.s.move(self.n(),step)
                return
            for e in EDGES:
                if p in e:
                    n=next(iter(e-{p}))
                    if n not in seen:seen.add(n);q.append((n,path+[n]))
        assert False,'no route'
    def corner(self):
        self.go((2,'double'));self.s.actors.update(corner=(2,'double'),cross_level_patient=(2,'double'),orderly=(2,'corridor'))
        assert self.c('begin_talk');assert self.c('show')
    def escort(self):
        self.corner();assert self.s.medical_at_door(self.n(),'orderly')
        assert self.c('observe_receipt');assert self.c('approach');assert self.c('grip')
    def work(self):
        self.go((2,'work'));self.s.actors.update(supervisor=(2,'work'),worker=(2,'work'))
    def drawer(self):
        self.work();ident=self.s.start_search(self.n(),DRAWER_POINT);assert ident
        assert self.s.hand_position(self.n(),True)
        assert self.w('notice');assert self.w('reach');assert self.w('windup')
        return ident

def test_same_patient_from_guard_delivery_and_own_bed_is_not_respawned():
    d=Driver();s=d.s;s.actors.update(guard=(1,'office'),cross_level_patient=(1,'office'))
    assert s.start_patient_escort(d.n()) and s.patient_grip(d.n())
    for dest in ((1,'reception'),(2,'stairs'),(2,'corridor'),(2,'double')):assert s.escort_step(d.n(),dest)
    s.actors['corner']=(2,'double');d.go((2,'double'))
    assert not d.c('begin_talk') # guard is still present
    for dest in ((2,'corridor'),(2,'stairs'),(1,'reception'),(1,'office')):assert s.guard_return_step(d.n(),dest)
    assert d.c('begin_talk') and d.c('say',speaker='cross',line_key='same_vehicle')
    assert s.actors['cross_level_patient']==(2,'double') and s.patient_delivered
    assert s.actors['transferred'] is None

@pytest.mark.parametrize('medical',['orderly','nurse','chief','doctor'])
def test_actual_door_arrival_stops_unsaid_words_but_does_not_invent_stowing(medical):
    d=Driver();d.corner();s=d.s;s.actors[medical]=(2,'corridor')
    assert s.medical_at_door(d.n(),medical)
    assert not d.c('say',speaker='cross',line_key='same_vehicle')
    assert 'same_vehicle' not in s.corner.knowledge and 'corner' in s.corner.showing
    assert not s.corner.held

def test_dialogue_pauses_movement_not_actual_spoken_line_callback():
    d=Driver();d.corner();s=d.s;s.paused=True
    assert d.c('say',speaker='cross',line_key='same_vehicle',formal_dialogue=True)
    assert not s.medical_at_door(d.n(),'orderly') and not s.actor_move(d.n(),'orderly',(2,'double'))
    assert not s.tick(d.n(),9999)
    s.paused=False;assert s.medical_at_door(d.n(),'orderly')
    assert not d.c('say',speaker='corner',line_key='remember_number',formal_dialogue=True)

def test_patient_escort_retains_real_position_and_no_avatar_six_second_cap():
    d=Driver();d.escort();s=d.s
    assert s.holder is None and not s.blocked()
    assert not s.actor_move(d.n(),'corner',(2,'corridor'))
    assert not d.c('step',dest='corridor')
    assert s.tick(d.n(),60001) and s.corner.held
    assert d.c('step',dest='doorway') and not s.corner.completed
    assert not d.c('release')
    assert d.c('step',dest='corridor') and d.c('release')
    assert s.actors['corner']==s.actors['orderly']==(2,'corridor')
    assert not s.actor_move(d.n(),'corner',(2,'double'))
    assert (s.life.hp,s.life.sp,s.life.economy.n)==(100,100,5)

@pytest.mark.parametrize('after_door',[False,True])
def test_interrupted_escort_no_fake_arrival(after_door):
    d=Driver();d.escort();s=d.s
    if after_door:assert d.c('step',dest='doorway')
    before=deepcopy(s.corner.positions);assert d.c('interrupt')
    assert s.corner.positions==before and not s.corner.completed and not s.corner.held
    assert not d.c('release')

def test_corner_job_blocks_report_accept_and_reverse_busy_blocks_observation():
    d=Driver();d.escort();s=d.s
    assert not s.ordinary_accept(d.n(),'fixture_report','avatar')
    assert 'orderly' in s.ward.busy
    assert d.c('interrupt');s.ordinary_job={'report':'another','target':'postop','state':'locating'}
    s.actors['corner']=(2,'double');s.actors['orderly']=(2,'double');s.corner.showing.add('corner')
    assert not d.c('observe_receipt') and not s.corner.held

def test_receipt_read_and_give_independent_and_follow_real_inventory_across_rest():
    d=Driver();d.corner();s=d.s
    assert d.c('say',speaker='cross',line_key='same_vehicle') and d.c('show',person='cross')
    for person in ('corner','cross'):assert d.c('read',person=person,fields={'date','trip','person'})
    assert s.corner.same_vehicle_verified and s.corner.owners['corner']=='corner'
    assert d.c('give',person='corner')
    d.go((1,'ward'));assert s.begin_rest(d.n()) and s.complete_rest(d.n())
    assert s.corner.owners=={'corner':'avatar','cross':'cross'} and s.corner.same_vehicle_verified
    assert not s.corner.showing

@pytest.mark.parametrize('attempt',[1,2,5,6,1000000])
def test_clamp_exact_damage_pending_reward_and_one_attempt(attempt):
    d=Driver(attempt);ident=d.drawer();s=d.s;balance=s.life.economy.n
    assert (s.life.hp,s.life.sp)==(100,100)
    assert d.w('close');assert (s.life.hp,s.life.sp)==(90,100)
    assert ident not in s.search.pending and s.search.used==1 and s.life.economy.n==balance
    assert not s.complete_search(d.n(),ident)
    assert not d.w('close') and s.life.hp==90
    assert s.tick(d.n(),999) and s.holder=='supervisor'
    assert s.tick(d.n(),1) and s.holder is None and s.work.clamp_remaining_ms==0
    assert not d.w('notice')

@pytest.mark.parametrize('actual_withdraw',[False,True])
def test_search_cancel_only_dodges_if_hand_has_really_left(actual_withdraw):
    d=Driver();d.drawer();s=d.s
    assert s.cancel_search_action(d.n(),hand_withdrawn=actual_withdraw)
    assert d.w('close');assert s.life.hp==(100 if actual_withdraw else 90)
    assert s.work.attempt_used and not s.search.pending and s.life.economy.n==5

def test_canceled_search_then_animation_withdrawal_before_close_misses():
    d=Driver();d.drawer();s=d.s
    assert s.cancel_search_action(d.n()) and s.work.hand_in_drawer
    assert s.hand_position(d.n(),False)
    assert d.w('close') and s.life.hp==100

def test_key_and_completed_income_remain_after_actual_late_clamp():
    d=Driver(key=DRAWER_POINT);ident=d.drawer();s=d.s
    assert s.tick(d.n(),s.search_duration) and s.complete_search(d.n(),ident)
    assert s.search.key_owner=='avatar';balance=s.life.economy.n
    assert d.w('close');assert s.search.key_owner=='avatar' and s.life.economy.n==balance
    assert s.tick(d.n(),1000);d.go((2,'stairs'))
    assert s.damage_or_exit(d.n(),exit_actual=True)=='exit'

@pytest.mark.parametrize('hp',[1,10])
def test_lethal_clamp_death_first_clears_controls_and_stale_actions(hp):
    d=Driver();d.drawer();s=d.s;s.life.hp=hp;old=d.n()
    assert d.w('close') and s.life.phase=='dead'
    assert s.holder is None and not s.search.pending and s.work.clamp_remaining_ms==0
    assert not s.work_action(old,'release')
    assert s.revive() and s.life.attempts[3]==2 and s.work.attempt==2
    assert not s.work_action(old,'close') and s.life.hp==100

def test_pause_and_loading_freeze_release_cap():
    d=Driver();d.drawer();s=d.s;assert d.w('close')
    for flag in ('paused','loading'):
        setattr(s,flag,True);assert not s.tick(d.n(),10000)
        assert s.holder=='supervisor' and s.work.clamp_remaining_ms==1000
        setattr(s,flag,False)
    assert s.tick(d.n(),1000) and not s.blocked()

def test_other_holder_not_replaced_by_clamp_but_real_damage_still_occurs():
    d=Driver();d.drawer();s=d.s
    # Actual existing contact supplied by physics after supervisor windup.
    s.procedure={'kind':'fixture_hold','actor':'orderly','state':'held','limit':2000,'hp':0,'sp':0,'paid':True}
    s.holder='orderly';s.hold_ms=0
    assert d.w('close') and s.life.hp==90 and s.holder=='orderly'
    assert s.tick(d.n(),1000) and s.holder=='orderly'
    assert s.tick(d.n(),1000) and s.holder is None

def test_post_release_actionable_gap_excludes_overlapping_drug_time():
    d=Driver();d.drawer();s=d.s;assert d.w('close');s.drug_stop=1500
    assert s.tick(d.n(),1000) and s.holder is None and s.drug_stop==500
    assert s.gap==0;assert s.tick(d.n(),500) and s.gap==0
    assert s.tick(d.n(),799) and s.gap==799
    assert s.tick(d.n(),1) and s.gap==800

@pytest.mark.parametrize('elapsed',[0,799,800])
def test_old_clamp_cannot_take_over_after_another_holder_releases(elapsed):
    d=Driver();d.drawer();s=d.s
    s.procedure={'kind':'fixture_hold','actor':'orderly','state':'held','limit':2000,'hp':0,'sp':0,'paid':True}
    s.holder='orderly';s.hold_ms=0
    assert s.release(d.n(),actual=True)
    assert s.tick(d.n(),elapsed)
    # A still-real collision may hurt, but a stale takeover cannot create a hold.
    assert d.w('close') and s.life.hp==90
    assert s.holder is None and s.work.stage=='reopening'

def test_supervisor_actual_departure_releases_but_no_completed_search():
    d=Driver();ident=d.drawer();s=d.s;assert d.w('close')
    assert s.actor_move(d.n(),'supervisor',(2,'corridor'))
    assert s.holder is None and s.work.clamp_remaining_ms==0
    assert s.search.income==0 and ident not in s.search.pending

def test_partial_labor_and_inventory_no_reward_or_free_material_refill():
    d=Driver();d.work();s=d.s
    assert d.w('labor_action',action='take_paper') and d.w('labor_action',action='fold')
    assert d.w('remove_material',kind='label',count=3)
    assert d.w('labor_action',action='flatten')
    assert not d.w('labor_action',action='take_label') and not s.work.boxes
    d.go((2,'corridor'));d.s=s.reload();s=d.s;d.go((2,'work'))
    assert s.work.current_box['folded'] and s.work.label_count==0
    assert not d.w('labor_action',action='paste')
    assert (s.life.economy.n,s.life.economy.c,s.search.used)==(5,3,0)
    d.go((1,'ward'));assert s.begin_rest(d.n()) and s.complete_rest(d.n())
    assert s.work.avatar_materials['label']==3 and s.work.label_count==0

def test_removed_materials_do_not_delete_search_point_or_key():
    d=Driver(key=44);d.work();s=d.s
    assert d.w('remove_material',kind='paper',count=3) and d.w('remove_material',kind='label',count=3)
    ident=s.start_search(d.n(),44);assert ident
    assert s.tick(d.n(),s.search_duration) and s.complete_search(d.n(),ident)
    assert s.search.key_owner=='avatar'

def test_worker_continues_during_avatar_stop_but_not_world_pause():
    d=Driver();d.work();s=d.s;s.drug_stop=1500
    assert d.w('labor_action',action='take_paper')
    assert not d.w('remove_material',kind='label') and not d.w('observe_label')
    s.paused=True;assert not d.w('labor_action',action='fold')
    s.paused=False;assert d.w('labor_action',action='fold')

def test_backside_actual_read_and_s2_known_batch_required_for_link():
    d=Driver();d.work();s=d.s
    assert not d.w('view_board',back=True)
    assert d.w('steady_board') and not d.w('view_board',back=False)
    assert d.w('view_board',back=True) and not s.work.cross_linked()
    assert s.work.record_cold_label(s.work.batch,actual_read=True)
    assert s.work.cross_linked() and s.awareness.stage==0

@pytest.mark.parametrize('reason',['death','exit','rest'])
def test_old_callbacks_cannot_complete_scene_after_lifecycle_change(reason):
    d=Driver();d.work();s=d.s
    assert d.w('labor_action',action='take_paper');old=d.n()
    if reason=='death':assert s.damage_or_exit(d.n(),hp=100)=='death'
    elif reason=='exit':
        s.search.key_owner='avatar';d.go((2,'stairs'));assert s.damage_or_exit(d.n(),exit_actual=True)=='exit'
    else:
        d.go((1,'ward'));assert s.begin_rest(d.n()) and s.complete_rest(d.n())
    assert not s.work_action(old,'labor_action',action='fold')
    assert not s.corner_action(old,'say',speaker='cross',line_key='same_vehicle',formal_dialogue=True)

class FinalWardMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.d.work();s=self.d.s
        s.actors.update(corner=(2,'double'),cross_level_patient=(2,'double'),orderly=(2,'corridor'))
    @rule(room=st.sampled_from(['work','corridor','double','stairs','quiet']))
    def walk(self,room):self.d.s.move(self.d.n(),(2,room))
    @rule(point=st.sampled_from([37,38,42,43,44]))
    def search(self,point):self.d.s.start_search(self.d.n(),point)
    @rule(inside=st.booleans())
    def hand(self,inside):self.d.s.hand_position(self.d.n(),inside)
    @rule(name=st.sampled_from(['notice','reach','windup','close','release','interrupt_supervisor']))
    def supervisor(self,name):self.d.w(name)
    @rule(action=st.sampled_from(['take_paper','fold','flatten','take_label','paste','place']))
    def worker(self,action):self.d.w('labor_action',action=action)
    @rule(name=st.sampled_from(['begin_talk','show','stow','observe_receipt','approach','grip','release','interrupt']))
    def corner(self,name):self.d.c(name)
    @rule(dest=st.sampled_from(['doorway','corridor']))
    def escort(self,dest):self.d.c('step',dest=dest)
    @rule()
    def doorway(self):self.d.s.medical_at_door(self.d.n(),'orderly')
    @rule(ms=st.sampled_from([0,1,250,799,800,999,1000,1500,6000]))
    def tick(self,ms):self.d.s.tick(self.d.n(),ms)
    @rule(withdraw=st.booleans())
    def cancel(self,withdraw):self.d.s.cancel_search_action(self.d.n(),withdraw)
    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused
    @rule()
    def complete(self):
        for ident in list(self.d.s.search.pending):self.d.s.complete_search(self.d.n(),ident)
    @rule()
    def reload(self):self.d.s=self.d.s.reload()
    @rule()
    def death(self):self.d.s.damage_or_exit(self.d.n(),hp=100)
    @rule()
    def revive(self):self.d.s.revive()
    @invariant()
    def no_wrong_side_effects(self):
        s=self.d.s
        assert 0<=s.life.hp<=100 and s.life.sp==100
        assert s.awareness.stage==0 and not s.awareness.evidence
        assert not (s.corner.held and s.holder=='orderly')
        assert s.search.used<=14
        assert s.work.paper_count>=0 and s.work.label_count>=0
        assert 0<=s.work.clamp_remaining_ms<=1000
        if s.life.phase=='dead':assert not s.holder and not s.corner.held
        assert s.work.paper_count+s.work.avatar_materials['paper']+len(s.work.boxes)+int(s.work.current_box is not None)==3

TestFinalWardMachine=FinalWardMachine.TestCase
TestFinalWardMachine.settings=settings(max_examples=240,stateful_step_count=80,deadline=None)
