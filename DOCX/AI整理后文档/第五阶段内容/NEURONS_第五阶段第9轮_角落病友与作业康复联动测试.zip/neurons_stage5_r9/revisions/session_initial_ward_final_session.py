"""R9 S3F2 corner/work scene adapter; preserves R8 modules unchanged.
S3:P970-1059; S4:T15/P181-207. Inputs actual/visible/contact are engine
facts, not a visibility, animation, spawn, skill-price or geometry simulator.
"""
from dataclasses import dataclass, field
from event_session import EventSession
from corner_patient import CornerPatient
from workroom import Workroom

CORNER_ACTIONS={'begin_talk','say','show','read','give','stow','complete_talk',
 'observe_receipt','approach','grip','step','release','interrupt','witness_escort'}
WORK_ACTIONS={'notice','reach','windup','close','release','interrupt_supervisor',
 'remove_material','labor_action','interrupt_worker','resume_worker',
 'steady_board','view_board','observe_label'}
MEDICS={'orderly','registrar','doctor','assistant','pharmacist','nurse',
 'archivist','guard','chief','isolator','therapy_director','porter','supervisor'}
DRAWER_POINT=43

@dataclass
class WardFinalSession(EventSession):
    corner: CornerPatient=field(default_factory=CornerPatient)
    work: Workroom=field(default_factory=Workroom)
    doorway: set=field(default_factory=set)
    work_effects: set=field(default_factory=set)

    def __post_init__(self):
        self.actors.update(dict.fromkeys(('corner','supervisor','worker')))
        super().__post_init__()

    def _room(self,actor):
        p=self.position if actor=='avatar' else self.actors.get(actor)
        if actor in self.doorway:return 'doorway'
        return p[1] if p and p[0]==2 else None

    def corner_busy(self):
        return self.corner.state in ('observed','approaching','held','doorway','corridor')

    def _sync(self):
        super()._sync()
        if not hasattr(self,'corner'):return
        a=self.life.attempts[3]
        self.corner.new_attempt(a)
        c=self.corner
        c.positions.update(avatar=self._room('avatar'),corner=self._room('corner'),
                           cross=self._room('cross_level_patient'),orderly=self._room('orderly'))
        c.paused=self.paused or self.loading
        c.avatar_blocked=self.blocked()
        c.orderly_busy=bool(self.ordinary_job or self.procedure and self.procedure['actor']=='orderly')
        near={m for m in MEDICS if self._room(m) in ('double','doorway')}
        c.medical_near=near
        if near or c.positions['avatar']!='double':c.talking=False
        invalid=self.life.phase!='alive' or self.life.progress!=3
        if invalid and self.corner_busy():
            c.held=False;c.state='interrupted';c.history.append((a,'scene_closed'));c.talking=False
        c.dead=invalid
        self.work.sync_context(positions={r:self._room(k) for r,k in
            (('avatar','avatar'),('supervisor','supervisor'),('worker','worker'))},
            paused=self.paused or self.loading,dead=invalid,epoch=self.life.epoch,
            attempt=a,avatar_blocked=self.blocked())
        if self.corner_busy():self.ward.busy.add('orderly')

    def corner_action(self,token,name,**kw):
        formal=name=='say' and kw.get('formal_dialogue',False)
        if not (self._dialogue_node(token) if formal else self.node(token)) or name not in CORNER_ACTIONS:return False
        result=getattr(self.corner,name)(self._rt(name),**kw)
        if result and name in ('approach','step'):
            for role in ('orderly','corner'):
                room=self.corner.positions[role]
                if room=='doorway':self.doorway.add(role)
                else:self.doorway.discard(role)
                if room in ('double','doorway','corridor'):
                    self.actors[role]=(2,'double' if room=='doorway' else room)
        self._sync();return result

    def medical_at_door(self,token,actor,actual=True):
        if not self.node(token) or not actual or actor not in MEDICS:return False
        if self.actors.get(actor) not in ((2,'corridor'),(2,'double')):return False
        if actor=='orderly' and self.corner.held:return False
        self.doorway.add(actor)
        return self.corner.medical_arrive(self._rt('medical_door'),actor)

    def leave_door(self,token,actor,actual=True):
        if not self.node(token) or not actual or actor not in self.doorway:return False
        if actor in ('orderly','corner') and self.corner.held:return False
        self.doorway.remove(actor);self._sync();return True

    def ordinary_accept(self,token,report_id,target,actual=True):
        if self.corner_busy():return False
        return super().ordinary_accept(token,report_id,target,actual)

    def begin_procedure(self,token,kind,**kw):
        if kind=='wrist' and self.corner_busy():return False
        return super().begin_procedure(token,kind,**kw)

    def actor_move(self,token,actor,dest,actual=True):
        if self.corner.held and actor in ('orderly','corner'):return False
        if actor=='corner' and self.corner.completed and dest==(2,'double'):return False
        was_busy=actor=='orderly' and self.corner_busy()
        result=super().actor_move(token,actor,dest,actual)
        if result:
            self.doorway.discard(actor)
            if was_busy:self.corner.interrupt(self._rt('orderly_left'),reason='orderly_left')
            self._sync();self._drain_work()
        return result

    def hand_position(self,token,inside,actual=True):
        if not self.node(token) or not actual:return False
        if inside and not any(p==DRAWER_POINT for _,p in self.search.pending.values()):return False
        return self.work.set_hand(self._rt('hand'),inside,actual=True)

    def cancel_search_action(self,token,hand_withdrawn=False,actual=True):
        if not self.node(token) or not actual or self.blocked():return False
        self.cancel_action()
        if hand_withdrawn:self.work.set_hand(self._rt('withdrawn'),False)
        return True

    def work_action(self,token,name,**kw):
        if not self.node(token) or name not in WORK_ACTIONS:return False
        if name=='windup':
            kw['body_available']=not self.blocked() and not self.procedure and (not self.need_gap or self.gap>=800)
        elif name=='close':kw['body_available']=self.holder is None
        result=getattr(self.work,name)(self._rt(name),**kw)
        self._drain_work();self._sync();return result

    def _drain_work(self):
        for effect in self.work.effects:
            if effect['id'] in self.work_effects or effect['id'][0]!=self.life.attempts[3]:continue
            self.work_effects.add(effect['id'])
            if not self.active():continue
            if effect.get('hold',True) and not self.holder:
                self.procedure={'kind':'work_clamp','actor':'supervisor','state':'held',
                    'limit':1000,'hp':10,'sp':0,'paid':True}
                self.holder='supervisor';self.hold_ms=0
            self._apply((self.life.epoch,('work_effect',effect['id'])),
                        [('hp_damage',effect['hp']),('sp_damage',effect['sp'])],physical=True)
        if self.holder=='supervisor' and self.work.stage!='clamped':
            self.finish_procedure(delivered=True)

    def finish_procedure(self,delivered=False):
        was_work=self.procedure and self.procedure['kind']=='work_clamp'
        result=super().finish_procedure(delivered)
        if was_work:self.work.abort('body_released')
        return result

    def move(self,token,dest,actual=True):
        result=super().move(token,dest,actual)
        if result:self._sync()
        return result

    def tick(self,token,ms):
        if ms<0:raise ValueError('negative time')
        if not self.node(token):return False
        remaining=ms
        while remaining and self.active():
            limit=self.work.clamp_remaining_ms
            dt=min(remaining,limit) if limit else remaining
            self.serial+=1
            super().tick((self.life.epoch,('R9tick',self.serial)),dt)
            self.work.tick(dt);self.corner.tick(dt);self._drain_work()
            remaining-=dt
        self._sync();return True

    def _restart(self):
        super()._restart()
        self.actors.update(dict.fromkeys(('corner','supervisor','worker')))
        self.doorway.clear();self.corner.new_attempt(self.life.attempts[3])
        self.work.new_attempt(self.life.attempts[3],epoch=self.life.epoch);self._sync()
