from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant, initialize
from workroom import Workroom


class Driver:
    def __init__(self, **kwargs):
        self.w = Workroom(**kwargs)
        self.n = 0
    def token(self):
        self.n += 1
        return self.w.attempt, self.n
    def call(self, name, *args, **kwargs):
        return getattr(self.w, name)(self.token(), *args, **kwargs)
    def windup(self):
        assert self.call('set_hand', True)
        assert self.call('notice')
        assert self.call('reach')
        assert self.call('windup')
    def box(self):
        for action in ('take_paper', 'fold', 'flatten', 'take_label', 'paste', 'place'):
            assert self.call('labor_action', action)


def test_notice_requires_distinct_actual_animation_phases():
    d = Driver()
    assert d.call('set_hand', True)
    assert d.call('notice')
    assert d.w.effects == []
    assert not d.call('close')
    assert d.call('reach')
    assert d.w.effects == []
    assert not d.call('close')
    assert d.call('windup')
    assert d.w.effects == []
    assert d.call('close')
    assert d.w.effects == [{'id': (1, 'work_drawer'), 'hp': 10, 'sp': 0, 'cancel_search': True, 'hold': True}]


@pytest.mark.parametrize('change', ['hidden', 'no_hand', 'wrong_drawer', 'locked_store', 'avatar_absent', 'supervisor_absent'])
def test_notice_false_facts_no_damage_or_attempt(change):
    d = Driver()
    d.w.hand_in_drawer = True
    kwargs = {}
    if change == 'hidden': kwargs['visible'] = False
    if change == 'no_hand': d.w.hand_in_drawer = False
    if change in {'wrong_drawer', 'locked_store'}: kwargs['drawer'] = change
    if change == 'avatar_absent': d.w.positions['avatar'] = 'corridor'
    if change == 'supervisor_absent': d.w.positions['supervisor'] = 'corridor'
    assert not d.call('notice', **kwargs)
    assert not d.w.attempt_used
    assert not d.w.effects


@pytest.mark.parametrize('withdraw_mode', ['actual_withdraw', 'failed_contact'])
def test_miss_consumes_attempt_and_no_retarget(withdraw_mode):
    d = Driver()
    d.windup()
    if withdraw_mode == 'actual_withdraw': assert d.call('set_hand', False)
    assert d.call('close', contact=withdraw_mode != 'failed_contact')
    d.w.tick(1000)
    assert d.call('set_hand', True)
    assert not d.call('notice')
    assert d.w.attempt_used and not d.w.effects


def test_skill_success_without_actual_withdraw_does_not_prevent_hit():
    d = Driver()
    d.windup()
    # Successful pore or joy effect is not a hand-position callback.
    d.w.tick(10)
    assert d.call('close')
    assert d.w.effects[0]['hp'] == 10


@pytest.mark.parametrize('ms,held', [(0, True), (999, True), (1000, False), (1001, False), (6000, False)])
def test_release_deadline(ms, held):
    d = Driver()
    d.windup()
    assert d.call('close')
    d.w.tick(ms)
    assert (d.w.stage == 'clamped') == held
    assert len(d.w.effects) == 1


def test_pause_freezes_release_and_actions():
    d = Driver()
    d.windup()
    assert d.call('close')
    d.w.tick(999)
    d.w.paused = True
    d.w.tick(100000)
    assert d.w.clamp_remaining_ms == 1
    assert not d.call('release')
    d.w.paused = False
    d.w.tick(1)
    assert d.w.stage == 'finished'


def test_competing_holder_keeps_actual_damage_without_second_holder():
    d = Driver()
    d.windup()
    assert d.call('close', body_available=False)
    assert d.w.effects[0]['hp'] == 10 and not d.w.effects[0]['hold']
    assert d.w.stage == 'reopening'


def test_occupied_body_blocks_new_windup_but_not_rewrite_attempt():
    d = Driver()
    assert d.call('set_hand', True)
    assert d.call('notice')
    assert d.call('reach')
    assert not d.call('windup', body_available=False)
    assert not d.w.attempt_used


@pytest.mark.parametrize('interrupt_at', ['approaching', 'ready', 'windup', 'clamped'])
def test_real_interrupt_preserves_one_attempt_rule(interrupt_at):
    d = Driver()
    d.call('set_hand', True)
    d.call('notice')
    if interrupt_at != 'approaching': d.call('reach')
    if interrupt_at in {'windup', 'clamped'}: d.call('windup')
    if interrupt_at == 'clamped': d.call('close')
    assert d.call('interrupt_supervisor')
    assert d.w.stage == ('finished' if interrupt_at in {'windup', 'clamped'} else 'idle')
    assert not d.call('close')
    assert len(d.w.effects) == (interrupt_at == 'clamped')


@pytest.mark.parametrize('stop', ['death', 'epoch', 'avatar_left', 'supervisor_left'])
def test_invalidated_callbacks_no_survival_or_second_damage(stop):
    d = Driver()
    d.windup()
    if stop == 'death': d.w.sync_context(dead=True)
    if stop == 'epoch': d.w.sync_context(epoch=1)
    if stop == 'avatar_left': d.w.sync_context(positions={'avatar': 'corridor'})
    if stop == 'supervisor_left': d.w.sync_context(positions={'supervisor': 'corridor'})
    assert not d.call('close')
    assert not d.w.effects


def test_duplicate_hit_callback_idempotent_and_owned_things_untouched():
    d = Driver()
    inventory = {'key': True, 'receipt': 'owned'}
    before = deepcopy(inventory)
    d.windup()
    tok = d.token()
    assert d.w.close(tok)
    assert not d.w.close(tok)
    assert len(d.w.effects) == 1 and inventory == before


@pytest.mark.parametrize('attempt', [2, 5, 1000000])
def test_actual_restart_not_reentry_resets_attempt_and_stale_token_denied(attempt):
    d = Driver()
    d.windup(); d.call('close'); d.w.tick(1000)
    old = (1, 100)
    d.w.sync_context(positions={'avatar': 'corridor'})
    d.w.sync_context(positions={'avatar': 'work'})
    assert not d.call('notice')
    d.w.new_attempt(attempt, epoch=1)
    assert not d.w.close(old)
    d.windup(); assert d.call('close')
    assert len(d.w.effects) == 2


def test_labor_step_order_and_no_early_complete():
    d = Driver(paper_count=1, label_count=1)
    assert not d.call('labor_action', 'place')
    for action in ('take_paper', 'fold', 'flatten', 'take_label'):
        assert d.call('labor_action', action)
        assert not d.w.boxes
        assert not d.call('observe_label', item='current_box')
    assert d.call('labor_action', 'paste')
    assert d.call('observe_label', item='current_box')
    assert not d.w.boxes
    assert d.call('labor_action', 'place')
    assert len(d.w.boxes) == 1
    assert not d.call('labor_action', 'take_paper')
    assert not d.w.effects


@pytest.mark.parametrize('action', ['take_paper', 'fold', 'flatten', 'take_label', 'paste', 'place'])
def test_work_table_one_not_box_production(action):
    d = Driver()
    assert not d.call('labor_action', action, table='table1')
    assert d.w.paper_count == 3 and d.w.label_count == 3 and not d.w.boxes


def test_remove_all_paper_patient_waits_without_refill():
    d = Driver()
    assert d.call('remove_material', 'paper', 3)
    for _ in range(5): assert not d.call('labor_action', 'take_paper')
    assert d.w.paper_count == 0 and d.w.avatar_materials['paper'] == 3
    assert not d.w.effects


def test_remove_labels_keeps_half_folded_box():
    d = Driver(paper_count=1, label_count=1)
    for a in ('take_paper', 'fold', 'flatten'): assert d.call('labor_action', a)
    assert d.call('remove_material', 'label')
    assert not d.call('labor_action', 'take_label')
    assert d.w.current_box['folded'] and d.w.current_box['batch'] is None
    assert not d.w.boxes


@pytest.mark.parametrize('phase_actions', [1, 2, 3, 4, 5])
def test_interrupt_retains_exact_work_progress(phase_actions):
    d = Driver(paper_count=1, label_count=1)
    actions = ('take_paper', 'fold', 'flatten', 'take_label', 'paste', 'place')
    for a in actions[:phase_actions]: assert d.call('labor_action', a)
    snapshot = deepcopy((d.w.current_box, d.w.paper_count, d.w.label_count))
    assert d.call('interrupt_worker')
    for a in actions: assert not d.call('labor_action', a)
    assert snapshot == (d.w.current_box, d.w.paper_count, d.w.label_count)
    assert d.call('resume_worker')
    for a in actions[phase_actions:]: assert d.call('labor_action', a)
    assert len(d.w.boxes) == 1 and not d.w.effects


def test_body_block_stops_avatar_reads_but_not_workers_own_work():
    d = Driver()
    d.w.avatar_blocked = True
    assert not d.call('observe_label')
    assert not d.call('remove_material', 'paper')
    d.box()
    assert len(d.w.boxes) == 1


@pytest.mark.parametrize('case', ['front', 'unsteady', 'illegible', 'occluded'])
def test_backboard_requires_actual_stability_and_readable_back(case):
    d = Driver()
    if case != 'unsteady': assert d.call('steady_board')
    assert not d.call('view_board', back=case != 'front', visible=case != 'occluded', legible=case != 'illegible')
    assert not d.w.knowledge


def test_cross_level_match_needs_both_actual_reads_and_correct_batch():
    d = Driver()
    assert not d.w.record_cold_label(d.w.batch)
    assert d.w.record_cold_label('other', actual_read=True)
    assert d.call('steady_board') and d.call('view_board')
    assert not d.w.cross_linked()
    assert d.w.record_cold_label(d.w.batch, actual_read=True)
    assert d.w.cross_linked()
    assert not any('patient' in str(fact) for fact in d.w.knowledge)


def test_actual_knowledge_and_owned_material_survive_restart():
    d = Driver()
    assert d.call('remove_material', 'paper')
    assert d.call('observe_label')
    d.w.record_cold_label(d.w.batch, actual_read=True)
    d.w.new_attempt(2)
    assert d.w.avatar_materials['paper'] == 1 and d.w.paper_count == 2
    assert d.w.cross_linked()
    assert not d.w.board_steady


def test_reload_does_not_clone_material_rewards_or_restart_work():
    d = Driver()
    d.box(); d.call('remove_material', 'paper')
    before = deepcopy(d.w.__dict__)
    d.w = d.w.reload()
    assert d.w.__dict__ == before


class WorkroomMachine(RuleBasedStateMachine):
    @initialize()
    def setup(self):
        self.d = Driver()
        self.last_effects = []

    @rule(action=st.sampled_from(['notice', 'reach', 'windup', 'close', 'release', 'steady_board', 'view_board',
                                 'interrupt_supervisor', 'interrupt_worker', 'resume_worker', 'observe_label']),
          actual=st.booleans())
    def action(self, action, actual):
        if action == 'observe_label': self.d.call(action, actual=actual)
        else: self.d.call(action, actual=actual)

    @rule(inside=st.booleans())
    def hand(self, inside): self.d.call('set_hand', inside)

    @rule(action=st.sampled_from(['take_paper','fold','flatten','take_label','paste','place']),
          table=st.sampled_from(['table1', 'table2']))
    def labor(self, action, table): self.d.call('labor_action', action, table=table)

    @rule(kind=st.sampled_from(['paper', 'label']), count=st.integers(0, 4))
    def take(self, kind, count): self.d.call('remove_material', kind, count)

    @rule(ms=st.sampled_from([0,1,799,999,1000,6000]), pause=st.booleans())
    def time(self, ms, pause):
        self.d.w.paused = pause
        before = self.d.w.clamp_remaining_ms
        self.d.w.tick(ms)
        if pause: assert self.d.w.clamp_remaining_ms == before

    @rule(step=st.sampled_from([1,4,1000000]))
    def restart(self, step): self.d.w.new_attempt(self.d.w.attempt + step, epoch=self.d.w.epoch+1)

    @rule()
    def reload(self): self.d.w = self.d.w.reload()

    @rule(actor=st.sampled_from(['avatar','worker','supervisor']), room=st.sampled_from(['work','corridor',None]))
    def move(self, actor, room): self.d.w.sync_context(positions={actor: room})

    @invariant()
    def conservation_and_effects(self):
        w = self.d.w
        used_paper = len(w.boxes) + (w.current_box is not None)
        used_labels = sum(box['batch'] is not None for box in w.boxes)
        if w.current_box is not None and w.current_box['label_taken']: used_labels += 1
        assert w.paper_count + w.avatar_materials['paper'] + used_paper == 3
        assert w.label_count + w.avatar_materials['label'] + used_labels == 3
        assert 0 <= w.clamp_remaining_ms <= 1000
        assert len({e['id'] for e in w.effects}) == len(w.effects)
        assert all(e['hp'] == 10 and e['sp'] == 0 for e in w.effects)
        assert all(box['folded'] and box['flat'] and box['batch'] is not None for box in w.boxes)
        if w.worker_phase != 'idle': assert w.current_box is not None


TestWorkroomMachine = WorkroomMachine.TestCase
TestWorkroomMachine.settings = settings(max_examples=225, stateful_step_count=65, deadline=None,
                                       database=None, derandomize=False)
