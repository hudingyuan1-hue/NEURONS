from copy import deepcopy
from dataclasses import replace
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from corner_patient import CornerPatient, Receipt

class Driver:
    def __init__(self):
        self.m=CornerPatient();self.i=0
        self.m.positions.update(avatar='double',corner='double',cross='double',orderly='corridor')
    def n(self):self.i+=1;return self.m.attempt,self.i
    def show_both(self):
        assert self.m.begin_talk(self.n());assert self.m.show(self.n(),'corner');assert self.m.show(self.n(),'cross')
    def known(self):
        self.show_both();assert self.m.say(self.n(),'cross','same_vehicle')
        for who in ('corner','cross'):assert self.m.read(self.n(),who,{'person','date','trip'})
    def held(self):
        self.show_both();assert self.m.medical_arrive(self.n(),'orderly')
        assert self.m.observe_receipt(self.n());assert self.m.approach(self.n());assert self.m.grip(self.n())


def test_independent_receipts_not_shared_patient():
    d=Driver();m=d.m;assert m.receipts['corner'].person!=m.receipts['cross'].person
    assert m.receipts['corner'].bed=='2' and m.receipts['cross'].bed=='1'
    assert set(m.owners.values())=={'corner','cross'}


def test_same_id_cannot_construct_different_patients():
    with pytest.raises(ValueError):CornerPatient(receipts=dict.fromkeys(('corner','cross'),Receipt('same','D','T')))

@pytest.mark.parametrize('field',['date','trip','person'])
def test_both_receipts_must_actually_read_all_matching_fields(field):
    d=Driver();d.show_both();m=d.m;assert m.say(d.n(),'cross','same_vehicle')
    assert m.read(d.n(),'corner',{'person','date','trip'})
    assert m.read(d.n(),'cross',{'person','date','trip'}-{field});assert not m.same_vehicle_verified
    assert m.read(d.n(),'cross',{field});assert m.same_vehicle_verified

@pytest.mark.parametrize('field,value',[('date','another-date'),('trip','another-trip'),('date',''),('trip','')])
def test_same_batch_and_testimony_do_not_override_date_trip_mismatch(field,value):
    d=Driver();d.m.receipts['cross']=replace(d.m.receipts['cross'],**{field:value});d.known()
    assert not d.m.same_vehicle_verified


def test_matching_documents_without_actual_statement_not_verified():
    d=Driver();d.show_both();m=d.m
    for who in ('corner','cross'):assert m.read(d.n(),who,{'person','date','trip','batch'})
    assert not m.same_vehicle_verified
    assert m.say(d.n(),'cross','same_vehicle',heard=False);assert not m.same_vehicle_verified
    assert 'same_vehicle' not in m.knowledge


def test_full_matching_documents_plus_heard_statement_verified():
    d=Driver();d.known();assert d.m.same_vehicle_verified

@pytest.mark.parametrize('constraint',['not-shown','not-visible','illegible','remote','blocked'])
def test_read_requires_actual_visible_accessible_receipt(constraint):
    d=Driver();m=d.m;assert m.begin_talk(d.n())
    if constraint!='not-shown':assert m.show(d.n(),'corner')
    if constraint=='remote':m.positions['avatar']='corridor'
    if constraint=='blocked':m.avatar_blocked=True
    assert not m.read(d.n(),'corner',{'person','date','trip'},visible=constraint!='not-visible',legible=constraint!='illegible')
    assert not m.read_fields['corner']


def test_erased_name_does_not_assert_shared_name_identity():
    d=Driver();d.show_both();m=d.m
    assert m.read(d.n(),'corner',{'erased_name','bed'})
    assert m.read_fields['corner']=={'erased_name','bed'}
    assert not m.same_vehicle_verified and 'same_name' not in m.knowledge

@pytest.mark.parametrize('constraint',['medical','far','blocked','no-corner','finished'])
def test_talk_requires_private_actual_conditions(constraint):
    d=Driver();m=d.m
    if constraint=='medical':m.medical_near.add('nurse')
    if constraint=='blocked':m.avatar_blocked=True
    if constraint=='no-corner':m.positions['corner']=None
    if constraint=='finished':m.talk_completed=True
    assert not m.begin_talk(d.n(),near=constraint!='far');assert not m.talking


def test_actual_medical_arrival_stops_new_lines_without_hiding_receipt():
    d=Driver();d.show_both();m=d.m
    assert m.medical_arrive(d.n(),'nurse');assert not m.talking
    assert 'corner' in m.showing
    assert not m.say(d.n(),'cross','same_vehicle');assert not m.knowledge
    assert not m.completed and not m.held


def test_formal_pause_stops_arrival_while_actual_formal_line_can_complete():
    d=Driver();d.show_both();m=d.m;m.paused=True
    before=deepcopy(m.positions)
    assert not m.medical_arrive(d.n(),'orderly');assert m.positions==before and m.talking
    assert m.say(d.n(),'cross','same_vehicle',formal_dialogue=True)
    assert 'same_vehicle' in m.knowledge
    assert not m.say(d.n(),'corner','remember_number')

@pytest.mark.parametrize('constraint',['not-shown','invisible','busy','passer','absent'])
def test_no_orderly_escort_without_witness_and_availability(constraint):
    d=Driver();m=d.m
    if constraint!='not-shown':d.show_both()
    m.positions['orderly']='doorway'
    if constraint=='busy':m.orderly_busy=True
    if constraint=='passer':m.positions['orderly']='corridor'
    if constraint=='absent':m.positions['corner']=None
    assert not m.observe_receipt(d.n(),visible=constraint!='invisible');assert not m.observed and not m.held


def test_stowed_before_orderly_observation_never_triggers():
    d=Driver();d.show_both();m=d.m;assert m.stow(d.n(),'corner');assert m.medical_arrive(d.n(),'orderly')
    assert not m.observe_receipt(d.n());assert not m.completed


def test_witness_then_stow_does_not_erase_actual_witness():
    d=Driver();d.show_both();m=d.m;assert m.medical_arrive(d.n(),'orderly');assert m.observe_receipt(d.n())
    assert m.stow(d.n());assert m.approach(d.n());assert m.grip(d.n());assert m.held


def test_grip_miss_is_not_completed_and_patient_stays_put():
    d=Driver();d.show_both();m=d.m;assert m.medical_arrive(d.n(),'orderly');assert m.observe_receipt(d.n());assert m.approach(d.n())
    assert m.grip(d.n(),contact=False);assert not m.completed and not m.held and m.positions['corner']=='double'
    assert not m.step(d.n(),'doorway')


def test_busy_after_observation_cannot_start_second_orderly_job():
    d=Driver();d.show_both();m=d.m;assert m.medical_arrive(d.n(),'orderly');assert m.observe_receipt(d.n());m.orderly_busy=True
    assert not m.approach(d.n());assert m.positions['orderly']=='doorway'


def test_departed_orderly_cannot_use_old_approach_from_remote_room():
    d=Driver();d.show_both();m=d.m;assert m.medical_arrive(d.n(),'orderly');assert m.observe_receipt(d.n());m.positions['orderly']='quiet'
    assert not m.approach(d.n());assert m.positions['orderly']=='quiet'

@pytest.mark.parametrize('stop',['held','doorway','corridor'])
def test_interruption_retains_actual_position_and_never_marks_delivery(stop):
    d=Driver();d.held();m=d.m
    if stop in ('doorway','corridor'):assert m.step(d.n(),'doorway')
    if stop=='corridor':assert m.step(d.n(),'corridor')
    before=deepcopy(m.positions);assert m.interrupt(d.n())
    assert m.positions==before and not m.held and not m.completed
    assert not m.release(d.n())

@pytest.mark.parametrize('invalid',['corridor','quiet','stairs',None])
def test_gripped_patient_cannot_skip_doorway(invalid):
    d=Driver();d.held();m=d.m;before=deepcopy(m.positions)
    assert not m.step(d.n(),invalid);assert m.positions==before

@pytest.mark.parametrize('constraint',['blocked-route','no-space','paused'])
def test_transport_conditions_keep_position(constraint):
    d=Driver();d.held();m=d.m;m.paused=constraint=='paused'
    assert not m.step(d.n(),'doorway',route_clear=constraint!='blocked-route',space=constraint!='no-space')
    assert m.positions['corner']=='double' and m.held


def test_actual_corridor_release_only_completes_once_and_prevents_replay():
    d=Driver();d.held();m=d.m
    assert not m.release(d.n());assert m.step(d.n(),'doorway');assert not m.release(d.n())
    assert m.step(d.n(),'corridor');assert not m.completed
    assert m.release(d.n()) and m.completed and not m.held
    assert not m.release(d.n());assert not m.begin_talk(d.n())
    assert m.history.count((1,'completed'))==1


def test_no_six_second_timeout_or_teleport_for_corner_patient():
    d=Driver();d.held();m=d.m;m.tick(6001);m.tick(30000)
    assert m.held and m.positions['corner']=='double' and not m.completed and m.elapsed_ms==36001


def test_passive_npc_escort_and_witness_continue_while_avatar_controlled():
    d=Driver();d.held();m=d.m;m.avatar_blocked=True
    assert m.witness_escort(d.n());assert 'escort_witnessed' in m.knowledge
    assert m.step(d.n(),'doorway');assert m.held


def test_remote_avatar_does_not_gain_escort_knowledge():
    d=Driver();d.held();m=d.m;m.positions['avatar']='work'
    assert not m.witness_escort(d.n());assert 'escort_witnessed' not in m.knowledge

@pytest.mark.parametrize('owned',[False,True])
def test_receipt_ownership_and_read_knowledge_survive_escort_and_attempt(owned):
    d=Driver();d.show_both();m=d.m;assert m.read(d.n(),'corner',{'person','date','trip'})
    if owned:assert m.give(d.n(),'corner')
    old=d.n();assert m.new_attempt(2);assert m.owners['corner']==('avatar' if owned else 'corner')
    assert m.read_fields['corner']=={'person','date','trip'} and not m.showing and not m.talking
    assert not m.show(old,'corner')
    m.positions.update(avatar='double',corner='double',cross='double');assert m.begin_talk(d.n())
    assert m.show(d.n(),'corner') is (not owned)

@pytest.mark.parametrize('attempt',[2,5,1_000_000])
def test_carried_receipt_no_world_copy_after_actual_attempt(attempt):
    d=Driver();m=d.m;assert m.give(d.n());assert m.new_attempt(attempt)
    m.positions.update(avatar='double',corner='double');assert m.begin_talk(d.n())
    assert not m.show(d.n());assert m.owners['corner']=='avatar'
    assert m.read(d.n(),'corner',{'person'});assert not m.give(d.n())


def test_duplicate_or_old_token_cannot_double_transition():
    d=Driver();n=d.n();assert d.m.begin_talk(n);assert not d.m.show(n)
    assert d.m.new_attempt(2);assert not d.m.begin_talk(n)


def test_no_hp_sp_resources_awarded_for_corner_event():
    d=Driver();d.known();m=d.m;assert m.medical_arrive(d.n(),'orderly');assert m.observe_receipt(d.n());assert m.approach(d.n());assert m.grip(d.n())
    assert m.step(d.n(),'doorway');assert m.step(d.n(),'corridor');assert m.release(d.n())
    assert (m.hp_effect,m.sp_effect,m.resource_effect)==(0,0,0)


def test_reload_preserves_physical_and_knowledge_without_extra_callback():
    d=Driver();d.held();m=d.m;assert m.step(d.n(),'doorway');clone=m.reload()
    assert clone.__dict__==m.__dict__;assert clone.positions is not m.positions
    assert len(clone.facts)==len(m.facts)

class CornerMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver()
    @rule(op=st.sampled_from(['begin','show','say','read','give','stow','complete','arrive','leave','observe','approach','grip','step','release','interrupt','witness','tick']),
          who=st.sampled_from(['corner','cross']),flag=st.booleans(),dest=st.sampled_from(['doorway','corridor','double','quiet']))
    def event(self,op,who,flag,dest):
        m=self.d.m;n=self.d.n();before=deepcopy(m.__dict__)
        if op=='begin':m.begin_talk(n,near=flag)
        elif op=='show':m.show(n,who)
        elif op=='say':m.say(n,who,'same_vehicle' if who=='cross' else 'remember_number',heard=flag)
        elif op=='read':m.read(n,who,{'person','date','trip'} if flag else {'batch'})
        elif op=='give':m.give(n,who)
        elif op=='stow':m.stow(n,who)
        elif op=='complete':m.complete_talk(n)
        elif op=='arrive':m.medical_arrive(n,'orderly')
        elif op=='leave':m.medical_leave(n,'orderly')
        elif op=='observe':m.observe_receipt(n,visible=flag)
        elif op=='approach':m.approach(n,route_clear=flag)
        elif op=='grip':m.grip(n,contact=flag)
        elif op=='step':m.step(n,dest,route_clear=flag)
        elif op=='release':m.release(n)
        elif op=='interrupt':m.interrupt(n)
        elif op=='witness':m.witness_escort(n,visible=flag)
        elif op=='tick':m.tick(7000)
        if before['paused'] or before['dead']:assert m.__dict__==before
    @rule(paused=st.booleans(),blocked=st.booleans(),busy=st.booleans())
    def flags(self,paused,blocked,busy):
        m=self.d.m;m.paused=paused;m.avatar_blocked=blocked;m.orderly_busy=busy
    @rule(dest=st.sampled_from(['double','corridor','quiet',None]))
    def avatar_move(self,dest):
        if not self.d.m.paused and not self.d.m.dead and not self.d.m.avatar_blocked:self.d.m.positions['avatar']=dest
    @rule(jump=st.sampled_from([1,4,999999]))
    def restart(self,jump):
        m=self.d.m;owners=deepcopy(m.owners);read=deepcopy(m.read_fields);knowledge=deepcopy(m.knowledge)
        old=self.d.n();assert m.new_attempt(m.attempt+jump)
        m.positions.update(avatar='double',corner='double',cross='double',orderly='corridor')
        assert owners==m.owners and read==m.read_fields and knowledge==m.knowledge
        assert not m.begin_talk(old)
    @rule()
    def reload(self):
        before=deepcopy(self.d.m.__dict__);self.d.m=self.d.m.reload();assert before==self.d.m.__dict__
    @invariant()
    def valid_state(self):
        m=self.d.m
        assert m.owners['corner'] in ('corner','avatar') and m.owners['cross'] in ('cross','avatar')
        assert all(m.owners[p]==p for p in m.showing)
        assert not m.completed or (not m.held and m.positions['corner']=='corridor')
        assert not m.held or (m.observed and m.positions['corner']==m.positions['orderly'])
        assert (m.hp_effect,m.sp_effect,m.resource_effect)==(0,0,0)
        if m.same_vehicle_verified:
            assert 'same_vehicle' in m.knowledge
            assert all({'person','date','trip'}<=m.read_fields[p] for p in ('corner','cross'))
        attempts=[a for a,outcome in m.history if outcome=='completed'];assert len(attempts)==len(set(attempts))

TestCornerMachine=CornerMachine.TestCase
TestCornerMachine.settings=settings(max_examples=220,stateful_step_count=65,deadline=None,database=None)

@pytest.mark.parametrize('at_room',['double','doorway','corridor'])
def test_reentrant_orderly_arrival_cannot_split_active_escort(at_room):
    d=Driver();d.held();m=d.m
    if at_room in ('doorway','corridor'):assert m.step(d.n(),'doorway')
    if at_room=='corridor':assert m.step(d.n(),'corridor')
    before=deepcopy(m.positions)
    assert not m.medical_arrive(d.n(),'orderly')
    assert m.positions==before and m.held and not m.completed
