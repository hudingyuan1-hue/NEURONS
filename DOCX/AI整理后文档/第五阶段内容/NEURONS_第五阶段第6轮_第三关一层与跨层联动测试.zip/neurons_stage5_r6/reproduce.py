"""Run R6 current tests, affected tests, or archived real failures."""
import json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def nodes(file,failed=False):
    ts=json.loads((ROOT/'results'/file).read_text())['tests']
    return [r['test'] for r in ts if not failed or r['outcome']=='failed']

def run(args,cwd,name):
    env=os.environ.copy();env['RUN_REPORT']=str(ROOT/'results'/('reproduced_'+name+'.json'))
    return subprocess.run([sys.executable,'-m','pytest','-q',*args,
        '--hypothesis-seed=2026101206','--hypothesis-show-statistics'],cwd=cwd,env=env).returncode

def main(mode):
    if mode=='current':
        return run(['test_s3_medication.py','test_s3_records.py','test_s3_session.py'],ROOT,'current')
    if mode=='affected':
        selected=nodes('records_affected.json')+nodes('session_affected.json')
        return run(sorted(set(selected)),ROOT,'affected')
    if mode!='failures':raise SystemExit('Use: python reproduce.py affected|current|failures')
    cases=[('records',{'s3_records.py':'records_initial.py',
                       'test_s3_records.py':'records_lifecycle_added_tests.py'},'records_lifecycle_initial.json'),
           ('session',{'s3_session.py':'session_initial_s3_session.py',
                       'test_s3_session.py':'session_initial_test_s3_session.py'},'session_initial.json'),
           ('boundaries',{'s3_session.py':'session_boundaries_initial_s3_session.py',
                          'test_s3_session.py':'session_boundaries_initial_test_s3_session.py'},'session_boundaries_initial.json')]
    codes=[]
    for name,restore,report in cases:
        with tempfile.TemporaryDirectory(prefix='neurons_r6_failure_') as td:
            dest=Path(td)
            for p in ROOT.glob('*.py'):shutil.copy2(p,dest/p.name)
            for to,old in restore.items():shutil.copy2(ROOT/'revisions'/old,dest/to)
            codes.append(run(nodes(report,True),dest,name+'_failures'))
    print('Expected pytest failure exit codes:',codes)
    return 0 if codes==[1,1,1] else 1

if __name__=='__main__':raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else 'affected'))
