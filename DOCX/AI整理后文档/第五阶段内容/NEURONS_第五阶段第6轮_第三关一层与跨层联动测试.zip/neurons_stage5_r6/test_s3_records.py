from copy import deepcopy
from itertools import product
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s3_records import S3Records
from transfer import Transfer


def transfer_fixture(transferred=True, read=True, identified=True, full=True,
                     photo=True, written=True):
    t = Transfer()
    if identified:
        t.identify_patient()
    if transferred:
        t.issue_patient_order()
        t.start_patient()
        for step in ('handover', 'grab_frame', 'release_fingers', 'depart'):
            assert t.patient_step(step, seen=full)
        if written:
            t.write_departure_record()
            if read:
                t.read_departure_record()
        if photo:
            t.collect_photo()
    return t


@pytest.mark.parametrize('transferred,read,identified,full,photo', product([False, True], repeat=5))
def test_inherited_case_matrix(transferred, read, identified, full, photo):
    t = transfer_fixture(transferred, read, identified, full, photo)
    r = S3Records.from_transfer(t, {'old_attack': '攻击行为'})
    kinds = {d.kind for d in r.documents.values()}
    assert ('shoe_bag' in kinds) == transferred
    assert ('departure' in kinds) == transferred
    assert ('photo_bag' in kinds) == (transferred and photo)
    want = ('no_corresponding_case' if not transferred else
            'inspect_and_match' if not read or not identified else
            'witnessed_challenge' if full else 'ask_document')
    assert r.registration_branch(t.patient_id, t.attempt) == want
    assert r.report_received is False
    assert not any(k[-1] == 'attacked' for k in r.facts)


def test_transfer_without_actual_record_has_no_departure_document():
    r = S3Records.from_transfer(transfer_fixture(written=False))
    assert all(d.kind != 'departure' for d in r.documents.values())
    assert r.registration_branch('S2-wheelchair', 1) == 'inspect_and_match'


def test_materials_survive_real_s2_attempt_without_new_phantom_case():
    t = transfer_fixture()
    t.reset_attempt(2)
    r = S3Records.from_transfer(t)
    assert r.registration_branch(t.patient_id, 1) == 'witnessed_challenge'
    assert r.registration_branch(t.patient_id, 2) == 'no_corresponding_case'
    assert all(d.episode == 1 for d in r.documents.values())


def test_partial_witness_cannot_claim_full_force_sequence():
    t = Transfer()
    t.identify_patient()
    t.issue_patient_order()
    t.start_patient()
    for step in ('handover', 'grab_frame', 'release_fingers', 'depart'):
        t.patient_step(step, seen=step == 'depart')
    t.write_departure_record()
    t.read_departure_record()
    r = S3Records.from_transfer(t)
    assert r.registration_branch(t.patient_id, 1) == 'ask_document'
    assert r.doctor_branch()[0] != 'transfer_experience'


@pytest.mark.parametrize('mask', range(8))
def test_doctor_only_reads_not_record_existence(mask):
    r = S3Records()
    r.identify_subject('case-A')
    for idx, kind in enumerate(('removal', 'death', 'fees')):
        doc = r.add_record(kind, 'case-A')
        if mask & (1 << idx):
            r.read_document(doc)
    assert (r.doctor_branch() == ('full_evidence', 'case-A')) == (mask == 7)


def test_three_different_people_never_form_complete_case():
    r = S3Records()
    for kind, who in zip(('removal', 'death', 'fees'), ('a', 'b', 'c')):
        r.identify_subject(who)
        r.read_document(r.add_record(kind, who))
    assert r.doctor_branch()[0] == 'partial_clues'


def test_unmatched_subject_not_full_evidence():
    r = S3Records()
    for kind in ('removal', 'death', 'fees'):
        r.read_document(r.add_record(kind, 'case-A'))
    assert r.doctor_branch()[0] == 'partial_clues'
    assert not r.identify_subject('case-A', matched=False)
    assert r.doctor_branch()[0] == 'partial_clues'


@pytest.mark.parametrize('refusal,label', product([False, True], repeat=2))
def test_false_swallow_not_just_an_inherited_label(refusal, label):
    r = S3Records()
    r.known_refusal_false_label(refusal, label)
    assert (r.doctor_branch()[0] == 'false_swallow_experience') == (refusal and label)


def test_written_diagnosis_is_not_known_until_read_and_is_not_order():
    r = S3Records()
    assert r.write_diagnosis('unspoken') is None
    r.doctor_statement('st', silent=True)
    assert r.write_diagnosis('st', actual=False) is None
    doc = r.write_diagnosis('st')
    assert doc not in r.read_ids
    assert r.documents[doc].text == '不合作'
    assert not r.orders
    assert not r.facts
    assert r.read_document(doc)
    assert r.write_diagnosis('st') is None


def test_knowledge_immutable_under_pathologizing():
    r = S3Records.from_transfer(transfer_fixture())
    old = deepcopy((r.read_ids, r.source_known, r.facts))
    r.doctor_statement('st')
    r.write_diagnosis('st')
    assert (r.read_ids, r.source_known, r.facts) == old
    assert not r.orders


def test_new_attempt_rejects_unfinished_old_diagnosis_callback():
    r = S3Records()
    r.doctor_statement('old-statement')
    assert r.new_attempt()
    assert r.write_diagnosis('old-statement') is None
    r.doctor_statement('fresh-statement')
    assert r.write_diagnosis('fresh-statement') is not None


def test_completed_diagnosis_survives_but_does_not_reexecute_on_rest():
    r = S3Records()
    r.doctor_statement('st')
    doc = r.write_diagnosis('st')
    r.read_document(doc)
    r.issue_order('unexecuted-order', 'avatar')
    assert r.new_attempt()
    assert doc in r.documents and doc in r.read_ids
    assert r.write_diagnosis('st') is None
    assert r.orders['unexecuted-order']['executed'] is False


@pytest.mark.parametrize('written,signed', product([False, True], repeat=2))
def test_prescription_independent_actual_write_and_signature(written, signed):
    r = S3Records()
    result = r.issue_order('new', 'avatar', actual=written, signed=signed)
    assert result == (written and signed)
    assert not r.diagnoses
    if result:
        assert r.orders['new']['executed'] is False
        assert not r.issue_order('new', 'different')
        assert r.orders['new']['subject'] == 'avatar'


def test_registration_requires_answer_then_followup_then_actual_writing():
    t = transfer_fixture()
    r = S3Records.from_transfer(t)
    assert r.nurse_write_label(t.patient_id, 1) is None
    assert not r.nurse_repeat_question(t.patient_id, 1)
    assert r.nurse_answer(t.patient_id, 1)
    assert r.nurse_write_label(t.patient_id, 1) is None
    assert r.nurse_repeat_question(t.patient_id, 1)
    assert r.nurse_write_label(t.patient_id, 1, actual=False) is None
    doc = r.nurse_write_label(t.patient_id, 1)
    assert doc is not None and doc not in r.read_ids
    assert r.nurse_write_label(t.patient_id, 1) is None
    assert r.facts == t.facts


@pytest.mark.parametrize('injured,photographed', product([False, True], repeat=2))
def test_no_automatic_injury_photo(injured, photographed):
    r = S3Records()
    p = r.add_injury_photo('avatar', 'injury1', injured, photographed)
    assert bool(p) == (injured and photographed)


def test_archive_conflict_read_matching_person_only():
    r = S3Records()
    r.identify_subject('a')
    photo = r.add_injury_photo('a', 'photo', True, True)
    other = r.add_record('no_external_injury', 'b')
    own = r.add_record('no_external_injury', 'a')
    r.read_document(photo)
    r.read_document(other)
    assert not r.photo_record_conflict('a')
    r.read_document(own)
    assert r.photo_record_conflict('a')


def test_file_closing_never_revokes_possession_or_read_memory():
    r = S3Records()
    doc = r.add_record('fees', 'a')
    r.read_document(doc)
    assert r.close_document(doc)
    assert doc in r.read_ids
    assert not r.take_document(doc)
    held = r.add_record('death', 'a')
    assert r.take_document(held)
    assert not r.close_document(held)
    assert r.read_document(held)
    assert held in r.owned


def test_unread_collected_file_does_not_imply_reading():
    r = S3Records()
    doc = r.add_record('fees', 'a')
    assert r.take_document(doc)
    assert not r.read_ids


def test_archive_report_needs_each_actual_step():
    r = S3Records()
    assert not r.archive_stop()
    assert not r.archive_continue()
    assert not r.archive_write()
    assert not r.archive_deliver()
    assert not r.archive_spotted(witnessed=False)
    assert r.archive_spotted()
    assert not r.archive_write()
    assert r.archive_stop()
    assert not r.archive_write()
    assert r.archive_continue()
    assert r.archive_write()
    assert not r.report_received
    assert not r.archive_deliver(guard_present=False)
    assert not r.archive_deliver(guard_busy=True)
    assert not r.archive_deliver(actual=False)
    assert r.archive_state == 'written'
    assert r.archive_deliver()
    assert not r.archive_deliver()


def test_reentry_preserves_report_and_new_attempt_resets_only_action():
    r = S3Records()
    for action in ('archive_spotted', 'archive_stop', 'archive_continue', 'archive_write'):
        assert getattr(r, action)()
    report = ('S3:archive', 1, 'avatar', 'report')
    r.read_document(report)
    r = r.reload()
    assert r.archive_state == 'written'
    assert r.new_attempt(4)
    assert r.archive_state == 'idle'
    assert not r.report_received
    assert report in r.documents and report in r.read_ids
    assert not r.archive_deliver()
    assert not r.new_attempt(4)


@pytest.mark.parametrize('stop', ('paused', 'dead'))
def test_paused_or_dead_prevents_world_side_effects(stop):
    r = S3Records()
    doc = r.add_record('fees', 'a')
    setattr(r, stop, True)
    assert not r.read_document(doc)
    assert not r.identify_subject('a')
    assert not r.take_document(doc)
    assert not r.close_document(doc)
    assert not r.archive_spotted()
    assert r.add_record('death', 'a') is None
    assert r.doctor_statement('st') is None
    assert not r.issue_order('o', 'a')


class RecordsMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.r = S3Records()
        self.exists = {}
        self.read = set()
        self.held = set()
        self.closed = set()
        self.ident = set()
        self.phase = 'idle'
        self.received = False
        self.orders = set()
        self.statements = {}
        self.diagnoses = set()
        self.serial = 0

    @rule(kind=st.sampled_from(['removal','death','fees','no_external_injury','number','clothing']),
          who=st.sampled_from(['a','b','c']), actual=st.booleans())
    def record(self, kind, who, actual):
        result = self.r.add_record(kind, who, actual=actual)
        if actual and self.r.active():
            self.exists[result] = (kind, who)
        else:
            assert result is None

    @rule(index=st.integers(0,50), actual=st.booleans(), clear=st.booleans())
    def read_file(self, index, actual, clear):
        doc = list(self.exists)[index % len(self.exists)] if self.exists else ('missing',)
        valid = self.r.active() and actual and clear and doc in self.exists and (doc not in self.closed or doc in self.held)
        assert self.r.read_document(doc, actual, clear) == valid
        if valid:
            self.read.add(doc)

    @rule(index=st.integers(0,50), own=st.booleans(), actual=st.booleans())
    def alter_access(self, index, own, actual):
        doc = list(self.exists)[index % len(self.exists)] if self.exists else ('missing',)
        valid = self.r.active() and actual and doc in self.exists
        if own:
            valid = valid and doc not in self.closed
            assert self.r.take_document(doc, actual) == valid
            if valid:
                self.held.add(doc)
        else:
            valid = valid and doc not in self.held
            assert self.r.close_document(doc, actual) == valid
            if valid:
                self.closed.add(doc)

    @rule(who=st.sampled_from(['a','b','c']), actual=st.booleans(), match=st.booleans())
    def identify(self, who, actual, match):
        valid = self.r.active() and actual and match
        assert self.r.identify_subject(who, actual, match) == valid
        if valid:
            self.ident.add(who)

    @rule(action=st.sampled_from(['spotted','stop','continue','write','deliver']), actual=st.booleans(),
          available=st.booleans(), busy=st.booleans())
    def archive(self, action, actual, available, busy):
        transition = {'spotted':('idle','seen'), 'stop':('seen','stopped'),
                      'continue':('stopped','continued'), 'write':('continued','written'),
                      'deliver':('written','received')}
        before, after = transition[action]
        valid = self.r.active() and actual and self.phase == before
        if action == 'spotted':
            valid = valid and available
            result = self.r.archive_spotted(actual, witnessed=available)
        elif action == 'deliver':
            valid = valid and available and not busy
            result = self.r.archive_deliver(available, busy, actual)
        else:
            result = getattr(self.r, 'archive_' + action)(actual=actual)
        assert result == valid
        if valid:
            self.phase = after
            if action == 'deliver':
                self.received = True
            if action == 'write':
                doc = ('S3:archive', self.r.attempt, 'avatar', 'report')
                self.exists[doc] = ('report', 'avatar')

    @rule(actual=st.booleans(), signed=st.booleans(), old=st.booleans())
    def order(self, actual, signed, old):
        self.serial += 1
        token = 0 if old else self.serial
        valid = self.r.active() and actual and signed and token not in self.orders
        assert self.r.issue_order(token, 'avatar', actual, signed) == valid
        if valid:
            self.orders.add(token)

    @rule(token=st.integers(0,8), write=st.booleans(), actual=st.booleans())
    def diagnosis(self, token, write, actual):
        if write:
            valid = (self.r.active() and actual and token in self.statements
                     and self.statements[token] == self.r.attempt and token not in self.diagnoses)
            result = self.r.write_diagnosis(token, actual=actual)
            assert bool(result) == valid
            if valid:
                self.diagnoses.add(token)
                self.exists[result] = ('diagnosis', 'avatar')
        else:
            valid = self.r.active() and actual and token not in self.statements
            result = self.r.doctor_statement(token, actual=actual)
            assert bool(result) == valid
            if valid:
                self.statements[token] = self.r.attempt

    @rule(paused=st.booleans())
    def pause(self, paused):
        self.r.paused = paused

    @rule()
    def next_attempt(self):
        assert self.r.new_attempt()
        self.phase, self.received = 'idle', False

    @rule()
    def reload(self):
        self.r = self.r.reload()

    @invariant()
    def knowledge_and_documents_consistent(self):
        assert self.r.read_ids == self.read
        assert self.r.owned == self.held
        assert self.r.inaccessible == self.closed
        assert self.r.known_subjects == self.ident
        assert self.r.archive_state == self.phase
        assert self.r.report_received == self.received
        assert set(self.r.orders) == self.orders
        assert set(self.r.diagnoses) == self.diagnoses
        full = {who for who in self.ident if
                {'removal','death','fees'} <= {kind for doc,(kind,subject) in self.exists.items()
                                             if doc in self.read and subject == who}}
        branch, who = self.r.doctor_branch()
        assert (branch == 'full_evidence') == bool(full)
        if full:
            assert who in full
        assert all(not x['executed'] for x in self.r.orders.values())


TestRecordsMachine = RecordsMachine.TestCase
TestRecordsMachine.settings = settings(max_examples=220, stateful_step_count=60, deadline=None)
