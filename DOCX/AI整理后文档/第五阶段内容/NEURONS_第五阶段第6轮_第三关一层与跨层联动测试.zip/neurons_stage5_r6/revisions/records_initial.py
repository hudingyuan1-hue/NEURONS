"""S3 floor-one records: physical facts, documents and knowledge are separate.

S3:P617-619,T20,T21,P679,P696-698,P735-741,T23,P777.
Actual reads/writing/contact are upstream animation/visibility facts. This model
contains no HP/SP, awakening, fourth-wall, path gating or instant arrest effects.
"""
from dataclasses import dataclass, field
from copy import deepcopy


@dataclass(frozen=True)
class Document:
    id: tuple
    kind: str
    subject: str
    episode: int
    origin: str
    text: str = ''


@dataclass
class S3Records:
    attempt: int = 1
    paused: bool = False
    dead: bool = False
    documents: dict = field(default_factory=dict)
    facts: set = field(default_factory=set)
    read_ids: set = field(default_factory=set)
    known_subjects: set = field(default_factory=set)
    owned: set = field(default_factory=set)
    inaccessible: set = field(default_factory=set)
    answered: set = field(default_factory=set)
    repeated: set = field(default_factory=set)
    nurse_labels: set = field(default_factory=set)
    statements: dict = field(default_factory=dict)
    diagnoses: dict = field(default_factory=dict)
    orders: dict = field(default_factory=dict)
    archive_state: str = 'idle'
    archive_episode: int | None = None
    report_received: bool = False
    history: list = field(default_factory=list)
    source_known: set = field(default_factory=set)

    def active(self):
        return not self.paused and not self.dead

    def _add(self, kind, subject, episode, origin, text=''):
        ident = (origin, episode, subject, kind)
        self.documents.setdefault(ident, Document(ident, kind, subject, episode, origin, text))
        return ident

    @classmethod
    def from_transfer(cls, transfer, inherited_labels=None):
        obj = cls()
        obj.facts.update(transfer.facts)
        obj.source_known.update(transfer.knowledge)
        for episode, subject, kind in transfer.facts:
            if kind != 'transferred':
                continue
            obj._add('shoe_bag', subject, episode, 'S2')
            if (episode, subject, 'false_departure_record') in transfer.facts:
                ident = obj._add('departure', subject, episode, 'S2', '自行离院')
                if (episode, subject, 'departure_record_read') in transfer.knowledge:
                    obj.read_ids.add(ident)
            if (episode, subject, 'photo_collected') in transfer.facts:
                obj._add('photo_bag', subject, episode, 'S2')
        for episode, subject, kind in transfer.knowledge:
            if kind == 'identified':
                obj.known_subjects.add(subject)
        # Inherited paperwork is evidence of a label, not of the alleged action.
        for ident, label in (inherited_labels or {}).items():
            obj._add('old_report', 'avatar', 0, 'S2:' + repr(ident), label)
        return obj

    def add_record(self, kind, subject, episode=1, actual=True, origin='S3', text=''):
        """An upstream real authored record; special physical items use methods below."""
        if not (self.active() and actual and kind in
                ('removal', 'death', 'fees', 'no_external_injury', 'number',
                 'clothing', 'old_report')):
            return None
        return self._add(kind, subject, episode, origin, text)

    def add_injury_photo(self, subject, event_id, actual_injury=False, photographed=False):
        if not (self.active() and actual_injury and photographed):
            return None
        self.facts.add((self.attempt, subject, ('injury_photographed', event_id)))
        return self._add('scar_photo', subject, self.attempt, 'photo:' + repr(event_id))

    def read_document(self, doc_id, actual=True, clear=True):
        if not (self.active() and actual and clear and doc_id in self.documents
                and (doc_id not in self.inaccessible or doc_id in self.owned)):
            return False
        self.read_ids.add(doc_id)
        return True

    def identify_subject(self, subject, actual=True, matched=True):
        if not (self.active() and actual and matched):
            return False
        self.known_subjects.add(subject)
        return True

    def read_kinds(self, subject):
        return {self.documents[i].kind for i in self.read_ids
                if i in self.documents and self.documents[i].subject == subject}

    def registration_branch(self, subject, episode):
        transferred = (episode, subject, 'transferred') in self.facts
        ident = ('S2', episode, subject, 'departure')
        if not transferred:
            return 'no_corresponding_case'
        if subject not in self.known_subjects or ident not in self.read_ids:
            return 'inspect_and_match'
        if (episode, subject, 'full_witness') in self.source_known:
            return 'witnessed_challenge'
        return 'ask_document'

    def nurse_answer(self, subject, episode, actual=True):
        if not (self.active() and actual and self.registration_branch(subject, episode)
                in ('witnessed_challenge', 'ask_document')):
            return False
        self.answered.add((subject, episode))
        return True

    def nurse_repeat_question(self, subject, episode, actual=True):
        if not (self.active() and actual and (subject, episode) in self.answered):
            return False
        self.repeated.add((subject, episode))
        return True

    def nurse_write_label(self, subject, episode, actual=True):
        key = (self.attempt, subject, episode)
        if not (self.active() and actual and (subject, episode) in self.repeated
                and key not in self.nurse_labels):
            return None
        self.nurse_labels.add(key)
        return self._add('nurse_label', 'avatar', self.attempt,
                         'S3:nurse:' + repr((subject, episode)), '反复纠缠')

    def known_refusal_false_label(self, actual_refusal=False, false_label_read=False):
        if not (self.active() and actual_refusal and false_label_read):
            return False
        self.source_known.add(('avatar', 'refusal_and_false_label'))
        return True

    def doctor_branch(self):
        for subject in sorted(self.known_subjects):
            if {'removal', 'death', 'fees'} <= self.read_kinds(subject):
                return ('full_evidence', subject)
        if ('avatar', 'refusal_and_false_label') in self.source_known:
            return ('false_swallow_experience', 'avatar')
        witnessed = sorted(k for k in self.source_known if len(k) == 3
                           and k[2] == 'full_witness')
        if witnessed:
            return ('transfer_experience', witnessed[0][1])
        if self.read_ids or self.known_subjects:
            return ('partial_clues', None)
        return ('ordinary_question', None)

    def doctor_statement(self, event_id, actual=True, silent=False):
        if not (self.active() and actual and event_id not in self.statements):
            return None
        branch = ('silence', None) if silent else self.doctor_branch()
        self.statements[event_id] = branch
        return branch

    def write_diagnosis(self, event_id, actual=True):
        if not (self.active() and actual and event_id in self.statements
                and event_id not in self.diagnoses):
            return None
        branch = self.statements[event_id]
        self.diagnoses[event_id] = branch
        return self._add('diagnosis', 'avatar', self.attempt,
                         'S3:diagnosis:' + repr(event_id),
                         '不合作' if branch[0] == 'silence' else '症状栏记录:' + branch[0])

    def issue_order(self, order_id, subject, actual=True, signed=True):
        if not (self.active() and actual and signed and order_id not in self.orders):
            return False
        self.orders[order_id] = {'subject': subject, 'origin': 'S3', 'executed': False}
        return True

    def photo_record_conflict(self, subject):
        return (subject in self.known_subjects
                and {'scar_photo', 'no_external_injury'} <= self.read_kinds(subject))

    def take_document(self, doc_id, actual=True):
        if not (self.active() and actual and doc_id in self.documents
                and doc_id not in self.inaccessible):
            return False
        self.owned.add(doc_id)
        return True

    def close_document(self, doc_id, actual=True):
        if not (self.active() and actual and doc_id in self.documents):
            return False
        if doc_id in self.owned:
            return False
        self.inaccessible.add(doc_id)
        return True

    def archive_spotted(self, actual=True, witnessed=True):
        if not (self.active() and actual and witnessed and self.archive_state == 'idle'):
            return False
        self.archive_state = 'seen'
        return True

    def archive_stop(self, actual=True):
        if not (self.active() and actual and self.archive_state == 'seen'):
            return False
        self.archive_state = 'stopped'
        return True

    def archive_continue(self, actual=True):
        if not (self.active() and actual and self.archive_state == 'stopped'):
            return False
        self.archive_state = 'continued'
        return True

    def archive_write(self, actual=True):
        if not (self.active() and actual and self.archive_state == 'continued'):
            return False
        self.archive_state, self.archive_episode = 'written', self.attempt
        self._add('report', 'avatar', self.attempt, 'S3:archive', '制止后仍翻阅')
        return True

    def archive_deliver(self, guard_present=True, guard_busy=False, actual=True):
        if not (self.active() and actual and guard_present and not guard_busy
                and self.archive_state == 'written'):
            return False
        self.archive_state, self.report_received = 'received', True
        return True

    def new_attempt(self, attempt=None):
        target = self.attempt + 1 if attempt is None else attempt
        if type(target) is not int or target <= self.attempt:
            return False
        self.history.append((self.attempt, self.archive_state))
        self.attempt = target
        self.answered.clear()
        self.repeated.clear()
        self.archive_state, self.archive_episode = 'idle', None
        self.report_received = False
        self.paused = self.dead = False
        return True

    def reload(self):
        return deepcopy(self)
