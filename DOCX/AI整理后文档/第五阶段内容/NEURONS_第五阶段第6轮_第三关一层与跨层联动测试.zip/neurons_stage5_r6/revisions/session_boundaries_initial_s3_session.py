"""Third-level floor-one/session model. Milliseconds; real contact is input.

S1:P30/P94-101/P135-137; S2:T2/T3/P13-19;
S3:P617-622/T18/P679-709/P735-768; S4:T6/T15/T16/P180-207.
Floor-two NPC stories, geometry and spawn rolls are not implemented here.
"""
from dataclasses import dataclass, field
from copy import deepcopy
from rules import Life, Search, search_ms
from awareness import Awareness
from s3_medication import Medication
from s3_records import S3Records

F1=('reception','ward','exam','treatment','office')
F2=('stairs','corridor','activity','group','quiet','wash','double','work')
EDGES=set()
for room in F1[1:]:EDGES.add(frozenset(((1,'reception'),(1,room))))
EDGES.add(frozenset(((1,'reception'),(2,'stairs'))))
for room in F2:
    if room!='corridor':EDGES.add(frozenset(((2,'corridor'),(2,room))))
POINT_ROOMS=tuple(r for r,n in zip(F2,(1,4,8,6,4,7,7,8)) for _ in range(n))
ACTORS={'orderly':(1,'ward'),'registrar':(1,'reception'),'doctor':(1,'exam'),
        'assistant':(1,'exam'),'pharmacist':(1,'treatment'),'nurse':(1,'treatment'),
        'archivist':(1,'office'),'guard':(1,'office'),'cross_level_patient':(1,'office')}
PROCEDURES={'wrist':('orderly',2000,5,5),'assistant':('assistant',3000,5,0),
            'guard':('guard',6000,5,10)}
PATIENT_ROUTE=((1,'office'),(1,'reception'),(2,'stairs'),(2,'corridor'),(2,'double'))


@dataclass
class S3Session:
    life: Life=field(default_factory=lambda:Life(progress=3,place='S3'))
    search: Search=field(default_factory=lambda:Search(level=3,key_point=13))
    awareness: Awareness=field(default_factory=Awareness)
    medication: Medication=field(default_factory=Medication)
    records: S3Records=field(default_factory=S3Records)
    targets: tuple=tuple(range(14))  # fixture pool, no omniscient AI ordering
    position: tuple=(1,'reception')
    actors: dict=field(default_factory=lambda:dict.fromkeys(ACTORS))
    patient_history: dict=field(default_factory=dict)
    inherited_facts: set=field(default_factory=set)
    paused: bool=False
    loading: bool=False
    feedback: bool=False
    rest_action: bool=False
    seen: set=field(default_factory=set)
    search_elapsed: int=0
    search_duration: int=0
    procedure: dict | None=None
    procedure_done: set=field(default_factory=set)
    procedure_history: list=field(default_factory=list)
    holder: str | None=None
    hold_ms: int=0
    drug_stop: int=0
    hit_stop: int=0
    gap: int=800
    need_gap: bool=False
    effects_applied: set=field(default_factory=set)
    guard_job: str | None=None
    patient_step_index: int=0
    patient_delivered: bool=False
    patient_gripped: bool=False

    def __post_init__(self):
        assert self.life.progress==3 and self.search.level==3
        assert len(self.targets)==14 and len(set(self.targets))==14
        assert all(0<=p<45 for p in self.targets) and self.search.key_point in self.targets
        self._sync()

    @classmethod
    def from_hospital(cls, source):
        if source.life.progress!=3 or source.life.phase!='alive':
            raise ValueError('requires an actual S2 exit')
        obj=cls(life=deepcopy(source.life),awareness=deepcopy(source.awareness),
                records=S3Records.from_transfer(source.transfer,source.people.labels),
                patient_history=deepcopy(source.people.inherited_record()),
                inherited_facts=set(source.transfer.facts))
        h=source.hospital
        if h.prescription:
            status={'consumed':'swallowed','refused':'refused'}.get(h.cup,'pending')
            obj.medication.inherit_order(('S2-order',h.episode,h.prescription),
                patient_id=h.prescription,actual_status=status,
                label_status='taken' if h.false_label else None)
        return obj

    def _sync(self):
        frozen=self.paused or self.loading
        dead=self.life.phase=='dead'
        self.medication.paused=self.records.paused=self.awareness.paused=frozen
        self.medication.dead=self.records.dead=dead
        if dead and self.awareness.alive:self.awareness.transition('death')
        self.medication.floor=self.position[0]

    def active(self):return self.life.phase=='alive' and self.life.progress==3 and not (self.paused or self.loading)

    def node(self,token):
        self._sync()
        if not self.active() or token[0]!=self.life.epoch or token in self.seen:return False
        self.seen.add(token);return True

    def blocked(self):return bool(self.holder or self.drug_stop or self.hit_stop or self.life.stun)
    def present(self,actor):return self.actors.get(actor)==self.position

    def cancel_action(self):
        for ident in list(self.search.pending):self.search.settle(ident,'cancel')
        self.medication.interrupt()
        self.rest_action=False;self.search_elapsed=0

    def decision(self):
        if self.life.phase=='dead':return 'dead'
        if self.life.progress!=3:return 'departed'
        if self.paused or self.loading:return 'paused'
        if self.blocked():return 'wait_effect'
        if self.search.key_owner=='avatar':return 'exit'
        if self.life.sp<50 or self.search.used>=14:return 'bed'
        return 'upstairs' if self.position[0]==1 else 'search'

    def move(self,token,dest,actual=True):
        if not self.node(token) or not actual or self.blocked():return False
        if frozenset((self.position,dest)) not in EDGES:return False
        self.cancel_action();self.position=dest;self.feedback=False
        self.awareness.transition('floor' if dest[0]!=self.medication.floor else 'room')
        self._sync();return True

    def actor_move(self,token,actor,dest,actual=True):
        if not self.node(token) or not actual or actor not in self.actors:return False
        origin=self.actors[actor]
        if origin is None or frozenset((origin,dest)) not in EDGES:return False
        if actor=='guard' and self.guard_job in ('patient','return'):return False
        if actor=='cross_level_patient' and self.guard_job=='patient':return False
        if self.procedure and (actor==self.procedure['actor'] or
                self.procedure['kind']=='assistant' and actor=='doctor'):
            self.finish_procedure(delivered=False)
        self.actors[actor]=dest;return True

    def start_search(self,token,point,kind='normal'):
        if not self.node(token) or self.feedback or self.rest_action or self.blocked():return None
        if self.decision()!='search' or self.medication.cup_state in ('held','raising'):return None
        if point not in self.targets or self.position!=(2,POINT_ROOMS[point]):return None
        ident=self.search.start(point)
        if ident is not None:
            self.search_elapsed=0
            self.search_duration=search_ms(3,kind,self.life.attempts[3],self.life.sp)
        return ident

    def complete_search(self,token,ident):
        if not self.node(token) or self.blocked() or self.search_elapsed<self.search_duration:return False
        info=self.search.pending.get(ident)
        if not info:return False
        self.search.settle(ident);self.feedback=True
        self.life.economy.credit(('S3-search',self.life.attempts[3],info[1]),1)
        return True

    def finish_feedback(self,token):
        if not self.node(token):return False
        self.feedback=False;return True

    def begin_rest(self,token):
        if not self.node(token) or self.position!=(1,'ward') or self.blocked():return False
        if self.search.key_owner=='avatar':return False
        self.cancel_action();self.rest_action=True;return True

    def complete_rest(self,token,actual=True):
        if not self.node(token) or not actual or not self.rest_action or self.blocked():return False
        if not self.life.rest():return False
        self._restart();return True

    def _restart(self):
        self.search.restart(self.search.key_point)
        self.position=(1,'ward');self.actors=dict.fromkeys(ACTORS)
        self.feedback=self.rest_action=False;self.procedure=None;self.procedure_done.clear()
        self.holder=None;self.hold_ms=self.drug_stop=self.hit_stop=0
        self.gap=800;self.need_gap=False
        self.guard_job=None;self.patient_step_index=0;self.patient_delivered=self.patient_gripped=False
        self.medication.new_attempt(self.life.attempts[3]);self.records.new_attempt(self.life.attempts[3])
        self.awareness.new_attempt();self._sync()

    def revive(self):
        if not self.life.revive():return False
        self.life.place='S3';self._restart();return True

    def begin_procedure(self,token,kind,doctor_signal=False,actual=True):
        if not self.node(token) or not actual or kind not in PROCEDURES:return False
        actor,limit,dhp,dsp=PROCEDURES[kind]
        if not self.present(actor) or self.procedure or kind in self.procedure_done:return False
        if self.rest_action or self.blocked() or (self.need_gap and self.gap<800):return False
        if kind=='wrist' and self.position!=(1,'ward'):return False
        if kind=='assistant' and (self.position!=(1,'exam') or not doctor_signal or not self.present('doctor')):return False
        if kind=='guard' and (not self.records.report_received or self.guard_job is not None or self.position[0]!=1):return False
        if kind!='guard' and (self.search.pending or self.feedback or self.decision() in ('exit','bed')):return False
        self.procedure={'kind':kind,'actor':actor,'state':'offered','limit':limit,'hp':dhp,'sp':dsp,'paid':False}
        if kind=='guard':self.guard_job='avatar'
        return True

    def reach(self,token,actual=True,refused=False):
        if not self.node(token) or not self.procedure or self.procedure['state']!='offered' or not actual:return False
        if self.procedure['kind']=='wrist' and not refused:return False
        self.procedure['state']='reaching';return True

    def normal_check(self,token,actual=True):
        if not self.node(token) or not actual or not self.procedure:return False
        if self.procedure['kind']!='wrist' or self.procedure['state']!='offered':return False
        self.finish_procedure(delivered=True);return True

    def grip(self,token,actual=True,tighten=False):
        if not self.node(token) or not self.procedure or self.procedure['state']!='reaching':return False
        if self.holder or not self.present(self.procedure['actor']):return False
        if not actual:self.finish_procedure(delivered=False);return False
        self.procedure['state']='held';self.holder=self.procedure['actor'];self.hold_ms=0
        self.cancel_action()
        if tighten or self.procedure['kind']=='guard':self._pressure(token)
        return True

    def _pressure(self,token):
        p=self.procedure
        if not p or p['paid']:return False
        p['paid']=True
        self._apply(token,[('hp_damage',p['hp']),('sp_damage',p['sp'])],physical=True)
        return True

    def tighten(self,token,actual=True):
        if not self.node(token) or not actual or not self.holder:return False
        return self._pressure(token)

    def finish_procedure(self,delivered=False):
        if not self.procedure:return False
        p=self.procedure
        self.procedure_done.add(p['kind'])
        self.procedure_history.append({'attempt':self.life.attempts[3],
            'kind':p['kind'],'delivered':delivered,'hurt':p['paid']})
        if self.holder:self.need_gap=True;self.gap=0
        self.holder=None;self.hold_ms=0;self.procedure=None
        if p['kind']=='guard':self.guard_job=None
        return True

    def release(self,token,reason='complete',actual=True):
        if not self.node(token) or not actual:return False
        if reason not in ('complete','cancel','actor_left','doctor_left','at_door'):return False
        return self.finish_procedure(delivered=reason in ('complete','at_door'))

    def records_action(self,token,name,**kw):
        if not self.node(token):return False
        role=('registrar' if name.startswith('nurse_') else 'archivist' if name.startswith('archive_') else 'doctor' if name in ('doctor_statement','write_diagnosis','issue_order') else None)
        if role and not self.present(role):return False
        if name=='archive_deliver':
            kw['guard_present']=self.present('guard')
            kw['guard_busy']=self.guard_job is not None
        allowed={'read_document','identify_subject','doctor_statement','write_diagnosis','issue_order',
                 'nurse_answer','nurse_repeat_question','nurse_write_label','archive_spotted','archive_stop',
                 'archive_continue','archive_write','archive_deliver','take_document','close_document'}
        if name not in allowed:return False
        result=getattr(self.records,name)(**kw)
        if result and name=='issue_order':
            self.medication.issue_order(kw['order_id'],patient_id=kw['subject'])
        return result

    def medicine_action(self,token,name,nurse_seen=False,**kw):
        if not self.node(token) or self.blocked():return False
        if name in ('take','raise_cup','swallow','refuse') and (self.search.pending or self.rest_action):return False
        if name=='prepare':kw['pharmacist_present']=self.present('pharmacist')
        if name in ('swallow','refuse'):
            kw.update(event_id=token,nurse_present=self.present('nurse'),nurse_witnessed=nurse_seen)
        if name=='nurse_record':kw['nurse_present']=self.present('nurse')
        if name not in ('prepare','take','raise_cup','interrupt','swallow','refuse','nurse_record'):return False
        result=getattr(self.medication,name)(**kw)
        for effect in self.medication.drain_effects():
            if effect['attempt']==self.life.attempts[3] and effect['id'] not in self.effects_applied:
                self.effects_applied.add(effect['id'])
                self.drug_stop=effect['drug_stop_ms']
                self._apply(token,[('sp_damage',effect['sp_damage'])])
        return result

    def _apply(self,token,events,physical=False):
        result=self.life.frame((self.life.epoch,('S3',token[1])),events)
        if physical and self.life.phase=='alive':
            if not self.hit_stop:self.hit_stop=250
            self.cancel_action()
        if self.life.stun:self.cancel_action()
        if self.need_gap and self.blocked():self.gap=0
        if self.life.phase=='dead':
            self.cancel_action();self.finish_procedure();self.guard_job=None
            self.drug_stop=self.hit_stop=0
        self._sync();return result

    def damage_or_exit(self,token,hp=0,sp=0,exit_actual=False):
        if not self.node(token):return 'ignored'
        ready=(exit_actual and self.position==(2,'stairs') and self.search.key_owner=='avatar' and not self.blocked())
        events=[('hp_damage',hp),('sp_damage',sp)]
        if ready:events.append(('exit',True))
        result=self._apply(token,events,physical=hp>0)
        if result=='exit':
            self.life.finish_exit();self.cancel_action();self.finish_procedure()
            self.awareness.transition('level');self.guard_job=None
        return result

    def tick(self,token,ms):
        assert ms>=0
        if not self.node(token):return False
        remaining=ms
        while remaining and self.active():
            limits=[x for x in (self.life.stun,self.drug_stop,self.hit_stop) if x>0]
            if self.holder:limits.append(self.procedure['limit']-self.hold_ms)
            dt=min([remaining,*limits]);free=not self.blocked()
            if free:
                if self.need_gap:self.gap=min(800,self.gap+dt)
                if self.search.pending:self.search_elapsed+=dt
                self.medication.tick(dt)
            self.life.tick(dt);self.drug_stop=max(0,self.drug_stop-dt);self.hit_stop=max(0,self.hit_stop-dt)
            if self.holder:
                self.hold_ms+=dt
                if self.hold_ms>=self.procedure['limit']:self.finish_procedure(delivered=False)
            remaining-=dt
        self._sync();return True

    def start_patient_escort(self,token,actual_encounter=True):
        if not self.node(token) or not actual_encounter or self.guard_job is not None or self.patient_delivered:return False
        if self.actors['guard']!=(1,'office') or self.actors['cross_level_patient']!=(1,'office'):return False
        if self.records.report_received and 'guard' not in self.procedure_done:return False
        self.guard_job='patient';self.patient_step_index=0;return True

    def patient_grip(self,token,actual=True):
        if not self.node(token) or self.guard_job!='patient' or self.patient_gripped:return False
        if not actual:self.guard_job=None;return False
        self.patient_gripped=True
        self.patient_history.setdefault('scars',set()).add((3,self.life.attempts[3],'actual_grip'))
        return True

    def escort_step(self,token,dest,actual=True,route_available=True):
        if not self.node(token) or not actual or not route_available or self.guard_job!='patient' or not self.patient_gripped:return False
        if dest!=PATIENT_ROUTE[self.patient_step_index+1]:return False
        self.patient_step_index+=1
        self.actors['guard']=self.actors['cross_level_patient']=dest
        self.patient_history.setdefault('scars',set()).add((3,self.life.attempts[3],'actual_drag'))
        if dest==(2,'double'):
            self.patient_delivered=True;self.patient_gripped=False;self.guard_job='return'
        return True

    def guard_return_step(self,token,dest,actual=True):
        if not self.node(token) or not actual or self.guard_job!='return':return False
        if dest!=PATIENT_ROUTE[self.patient_step_index-1]:return False
        self.patient_step_index-=1;self.actors['guard']=dest
        if self.patient_step_index==0:self.guard_job=None
        return True

    def reload(self):return deepcopy(self)
