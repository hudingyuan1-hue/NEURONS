from copy import deepcopy
from collections import deque
import pytest
from hypothesis import given,settings,strategies as st
from hypothesis.stateful import RuleBasedStateMachine,rule,invariant
from s3_session import S3Session,ACTORS,EDGES,POINT_ROOMS,PATIENT_ROUTE
from evidence_session import EvidenceSession
from rules import probability


class Driver:
    def __init__(self,s=None,populated=True):
        self.s=s or S3Session();self.seq=0
        if populated:self.s.actors.update(ACTORS)  # spawn fixtures, not actual 100% rates
    def n(self):self.seq+=1;return (self.s.life.epoch,self.seq)
    def tick(self,ms):return self.s.tick(self.n(),ms)
    def move(self,dest):return self.s.move(self.n(),dest)
    def go(self,dest):
        start=self.s.position;queue=deque([(start,[]) ]);seen={start}
        while queue:
            pos,path=queue.popleft()
            if pos==dest:
                for step in path:assert self.move(step)
                return
            for edge in EDGES:
                if pos in edge:
                    nxt=next(iter(edge-{pos}))
                    if nxt not in seen:seen.add(nxt);queue.append((nxt,path+[nxt]))
        raise AssertionError('no physical route')
    def begin(self,kind,**kw):return self.s.begin_procedure(self.n(),kind,**kw)
    def rec(self,name,**kw):return self.s.records_action(self.n(),name,**kw)
    def med(self,name,**kw):return self.s.medicine_action(self.n(),name,**kw)
    def hurt(self,hp=0,sp=0,exit_actual=False):return self.s.damage_or_exit(self.n(),hp,sp,exit_actual)


def new_report(d):
    d.go((1,'office'))
    for name in ('archive_spotted','archive_stop','archive_continue','archive_write','archive_deliver'):
        assert d.rec(name)


def hold(d,kind,harm=True):
    if kind=='guard':new_report(d)
    else:d.go((1,'ward' if kind=='wrist' else 'exam'))
    assert d.begin(kind,doctor_signal=True)
    assert d.s.reach(d.n(),refused=True)
    assert d.s.grip(d.n(),tighten=harm)


def cup(d,ident='new'):
    d.go((1,'exam'));assert d.rec('issue_order',order_id=ident,subject='avatar')
    d.go((1,'treatment'));assert d.med('prepare',order_id=ident,cup_id=('cup',ident))
    assert d.med('take') and d.med('raise_cup')


def source_exit(cup_state='none'):
    s=EvidenceSession();s.hospital.prescription='avatar';s.hospital.cup=cup_state
    if cup_state=='refused':s.hospital.false_label=True
    s.people.labels['real-record']='攻击行为'
    s.search.key_owner='avatar';assert s.batch((0,1),[('exit',True)])=='exit'
    return s


def test_s2_handoff_preserves_progress_values_evidence_without_replaying_procedures():
    prev=source_exit('refused');prev.awareness.observe('old','skin',('S2:exam','search',1))
    s=S3Session.from_hospital(prev)
    assert (s.life.total,s.life.attempts,s.life.intruder)==(prev.life.total,prev.life.attempts,prev.life.intruder)
    assert (s.life.hp,s.life.sp)==(100,100) and not s.holder and s.guard_job is None
    assert s.position==(1,'reception') and s.awareness.evidence==prev.awareness.evidence
    assert not s.records.report_received and s.patient_history['patient_id']==prev.people.patient_id


@pytest.mark.parametrize('room',['reception','ward','exam','treatment','office'])
def test_floor_one_has_no_search_income_or_key(room):
    d=Driver();d.go((1,room));s=d.s;n=s.life.economy.n
    for p in (0,13,44):assert s.start_search(d.n(),p) is None
    assert s.search.used==s.search.income==0 and s.life.economy.n==n
    assert s.search.key_owner=='hidden'


@pytest.mark.parametrize('k',[1,2,5,6,1000000])
def test_roundtrip_reload_keeps_attempt_resistance_key_and_spawn_probability(k):
    d=Driver();s=d.s;s.life.attempts[3]=k;s.life.economy.skills['skin'].pending=True
    s.search.key_owner='avatar';before=deepcopy((s.life,s.search,s.procedure_done))
    for loc in [(2,'stairs'),(2,'corridor'),(2,'double'),(2,'corridor'),(2,'stairs'),(1,'reception'),(1,'ward')]:assert d.move(loc)
    d.s=s.reload();s=d.s
    assert (s.life,s.search,s.procedure_done)==before
    assert probability('ordinary',s.life.attempts[3])==min(70,50+5*(k-1))


@pytest.mark.parametrize('sp',[0,1,19,20,49])
def test_low_sp_unheld_can_return_to_bed_without_npcs_or_skills(sp):
    d=Driver(populated=False);s=d.s;s.position=(2,'double');s.life.sp=sp;s.life.emptied=sp==0
    s.life.economy.n=s.life.economy.c=0;s.life.economy.global_r=100
    assert s.decision()=='bed'
    d.go((1,'ward'));assert s.begin_rest(d.n());assert s.complete_rest(d.n())
    assert (s.life.hp,s.life.sp,s.life.total,s.life.attempts[2],s.life.attempts[3])==(100,100,2,1,2)
    assert d.move((1,'reception')) and d.move((2,'stairs'))


def test_exhausted_fourteen_searches_return_and_rest_only_once():
    d=Driver(populated=False);s=d.s;d.go((2,'stairs'))
    for i in range(14):
        assert s.start_search(d.n(),0) is not None
        assert d.move((2,'corridor')) and d.move((2,'stairs'))
    assert s.search.used==14 and s.search.income==0 and s.decision()=='bed'
    assert s.start_search(d.n(),0) is None
    d.go((1,'ward'));assert s.begin_rest(d.n());old=d.n()
    assert s.complete_rest(old) and not s.complete_rest(old)
    assert (s.life.total,s.life.attempts[3],s.life.intruder)==(2,2,100000)
    assert not s.search.pending and s.search.used==0


def test_rest_is_interrupted_before_completion_no_early_heal_or_attempt():
    d=Driver();s=d.s;d.go((1,'ward'));s.life.hp=s.life.sp=40
    assert s.begin_rest(d.n())
    assert not d.begin('wrist')
    d.hurt(1);d.tick(250)
    assert not s.complete_rest(d.n()) and s.life.hp==39 and s.life.total==1
    assert s.begin_rest(d.n()) and s.complete_rest(d.n())


@pytest.mark.parametrize('location',[(2,'double'),(1,'treatment'),(2,'quiet')])
def test_other_beds_chairs_do_not_restart(location):
    d=Driver();d.go(location);assert not d.s.begin_rest(d.n())


def test_death_on_second_floor_restarts_third_attempt_at_first_floor_bed():
    d=Driver();s=d.s;d.go((2,'corridor'));s.life.economy.skills['skin'].pending=True
    before_n=s.life.economy.n;assert d.hurt(100)=='death';old_epoch=s.life.epoch
    assert s.revive() and not s.revive()
    assert s.position==(1,'ward') and (s.life.total,s.life.attempts[3],s.life.attempts[2],s.life.intruder)==(4,2,1,100001)
    assert s.life.economy.skills['skin'].resistance==1 and s.life.economy.n==max(5,before_n)
    assert not s.move((old_epoch,999),(1,'reception'))
    assert d.move((1,'reception')) and d.move((2,'stairs'))


@pytest.mark.parametrize('k,expected',[(1,6000),(2,5700),(3,5400),(4,5100),(5,4800),(999,4800)])
def test_search_duration_uses_actual_third_attempt_not_total(k,expected):
    d=Driver();s=d.s;s.life.attempts[3]=k;s.life.total=k*3;d.go((2,'stairs'))
    t=s.start_search(d.n(),0);d.tick(expected-1)
    assert not s.complete_search(d.n(),t)
    d.tick(1);assert s.complete_search(d.n(),t)
    assert s.search.income==1 and s.life.economy.n==6


def test_search_pauses_and_no_repeat_reward_or_same_frame_extra_budget():
    d=Driver();s=d.s;d.go((2,'stairs'));t=s.start_search(d.n(),0)
    s.paused=True;assert not d.tick(999999) and not s.complete_search(d.n(),t)
    s.paused=False;d.tick(6000);assert s.complete_search(d.n(),t)
    assert not s.complete_search(d.n(),t) and s.search.used==1 and s.search.income==1


def test_all_targets_can_be_completed_and_exit_without_any_person():
    d=Driver(populated=False);s=d.s
    for p in range(14):
        d.go((2,POINT_ROOMS[p]));t=s.start_search(d.n(),p);assert t is not None
        d.tick(6000);assert s.complete_search(d.n(),t);s.finish_feedback(d.n())
    assert s.search.key_owner=='avatar' and s.search.income==14
    d.go((2,'stairs'));before=s.life.total
    assert d.hurt(exit_actual=True)=='exit' and s.life.progress==4 and s.life.total==before


@pytest.mark.parametrize('damage,expect',[(0,'exit'),(99,'exit'),(100,'death')])
def test_actual_exit_has_no_medical_gate_and_death_has_priority(damage,expect):
    d=Driver(populated=False);s=d.s;s.position=(2,'stairs');s.search.key_owner='avatar'
    s.life.sp=0;s.life.emptied=True;s.life.economy.n=s.life.economy.c=0;s.life.economy.global_r=100
    s.awareness.stage=3;s.awareness.restriction=True
    assert d.hurt(damage,exit_actual=True)==expect
    assert s.life.progress==(4 if expect=='exit' else 3)


@pytest.mark.parametrize('kind,limit,hp,sp',[('wrist',2000,95,95),('assistant',3000,95,100),('guard',6000,95,90)])
def test_real_contact_damage_once_then_release_at_cap_without_teleport(kind,limit,hp,sp):
    d=Driver();hold(d,kind);s=d.s;pos=s.position
    assert (s.life.hp,s.life.sp)==(hp,sp)
    assert not s.tighten(d.n())
    d.tick(limit-1);assert s.holder
    d.tick(1);assert not s.holder and s.position==pos
    assert s.procedure_history[-1]['delivered'] is False
    assert (s.life.hp,s.life.sp)==(hp,sp)


@pytest.mark.parametrize('kind',['wrist','assistant','guard'])
def test_grip_miss_consumes_this_procedure_without_hurt_or_regrab(kind):
    d=Driver();s=d.s
    if kind=='guard':new_report(d)
    else:d.go((1,'ward' if kind=='wrist' else 'exam'))
    assert d.begin(kind,doctor_signal=True);s.reach(d.n(),refused=True)
    assert not s.grip(d.n(),actual=False)
    assert (s.life.hp,s.life.sp)==(100,100) and not d.begin(kind,doctor_signal=True)


def test_normal_wrist_read_does_not_hurt_and_reentry_does_not_repeat():
    d=Driver();d.go((1,'ward'));assert d.begin('wrist')
    assert d.s.normal_check(d.n());d.go((2,'stairs'));d.go((1,'ward'))
    assert not d.begin('wrist') and (d.s.life.hp,d.s.life.sp)==(100,100)


def test_assistant_normal_contact_no_damage_until_actual_pressure():
    d=Driver();hold(d,'assistant',harm=False);s=d.s
    assert (s.life.hp,s.life.sp)==(100,100)
    assert s.tighten(d.n()) and (s.life.hp,s.life.sp)==(95,100)
    assert not s.tighten(d.n())


@pytest.mark.parametrize('who',['doctor','assistant'])
def test_exam_actor_leaves_releases_real_hold(who):
    d=Driver();hold(d,'assistant');d.tick(250)
    assert d.s.actor_move(d.n(),who,(1,'reception'))
    assert not d.s.holder


def test_unrelated_doctor_movement_does_not_release_guard():
    d=Driver();hold(d,'guard');assert d.s.actor_move(d.n(),'doctor',(1,'reception'))
    assert d.s.holder=='guard'


def test_grips_do_not_overlap_and_recovery_requires_800ms():
    d=Driver();hold(d,'assistant');s=d.s
    assert not d.begin('wrist');d.tick(3000)
    d.go((1,'ward'));d.tick(799);assert not d.begin('wrist')
    d.tick(1);assert d.begin('wrist')


def test_shared_nurse_and_orderly_walk_stairs_keep_single_identity():
    d=Driver();s=d.s
    for actor,origin in [('nurse','treatment'),('orderly','ward')]:
        assert s.actor_move(d.n(),actor,(1,'reception'))
        assert s.actor_move(d.n(),actor,(2,'stairs'))
        assert s.actor_move(d.n(),actor,(2,'corridor'))
        assert s.actors[actor]==(2,'corridor')
        d.go((1,origin));assert not s.present(actor)
    assert len(s.actors)==9


@pytest.mark.parametrize('state',['consumed','refused'])
def test_s2_settled_order_cannot_be_reexecuted_after_level_change(state):
    s=S3Session.from_hospital(source_exit(state));d=Driver(s);d.go((1,'treatment'))
    assert not d.med('prepare',order_id=('S2-order',1,'avatar'),cup_id='new-cup')
    assert (s.life.hp,s.life.sp)==(100,100)


def test_s2_unexecuted_valid_order_can_be_used_without_new_diagnosis():
    s=S3Session.from_hospital(source_exit('none'));d=Driver(s);d.go((1,'treatment'))
    assert d.med('prepare',order_id=('S2-order',1,'avatar'),cup_id='inherited')
    assert d.med('take') and d.med('raise_cup');d.tick(1000)
    assert d.med('swallow') and s.life.sp==80 and s.drug_stop==1500


@pytest.mark.parametrize('sp',[20,19,1,0])
def test_medication_and_empty_stops_run_in_parallel_and_pause(sp):
    d=Driver();cup(d);s=d.s;s.life.sp=sp;s.life.emptied=sp==0
    d.tick(1000);assert d.med('swallow') and s.life.sp==0
    s.paused=True;assert not d.tick(9999) and s.drug_stop==1500
    s.paused=False;d.tick(1000)
    assert s.drug_stop==500 and s.life.stun==0 and s.blocked()
    d.tick(500);assert not s.blocked() and s.decision()=='bed'


def test_refused_false_record_does_not_apply_medicine_and_no_reentry_redose():
    d=Driver();cup(d);s=d.s;out=d.n()
    assert s.medicine_action(out,'refuse',nurse_seen=True)
    assert d.med('nurse_record',event_id='record',outcome_id=out)
    assert s.medication.records[-1]['false'] and (s.life.hp,s.life.sp)==(100,100)
    d.go((2,'corridor'));d.go((1,'exam'))
    assert d.rec('issue_order',order_id='second',subject='avatar')
    d.go((1,'treatment'));assert not d.med('prepare',order_id='second',cup_id='second')


def test_nurse_can_finish_own_record_during_avatar_drug_stop():
    d=Driver();cup(d);d.tick(1000);out=d.n();s=d.s
    assert s.medicine_action(out,'swallow',nurse_seen=True)
    assert s.drug_stop==1500
    assert d.med('nurse_record',event_id='record',outcome_id=out)
    assert s.life.sp==80 and len(s.medication.records)==1


def test_medical_new_invitation_cannot_redirect_key_holder_or_resting_avatar():
    d=Driver();cup(d);s=d.s;s.search.key_owner='avatar'
    # The held cup was already accepted; a NEW take invitation is separately gated.
    s.medication.interrupt();s.medication.cup_state='ready'
    assert not d.med('take')
    assert s.decision()=='exit'


def test_guard_report_waits_when_absent_and_old_report_never_starts_arrest():
    d=Driver(S3Session.from_hospital(source_exit()));s=d.s;d.go((1,'office'))
    assert not d.begin('guard')
    s.actors['guard']=None
    for name in ('archive_spotted','archive_stop','archive_continue','archive_write'):assert d.rec(name)
    assert not d.rec('archive_deliver') and not d.begin('guard')
    assert s.records.archive_state=='written' and (s.life.hp,s.life.sp)==(100,100)
    d.go((2,'stairs'));assert s.position==(2,'stairs')


def test_patient_escort_uses_same_entities_and_actual_stairs_no_timeout_teleport():
    d=Driver();s=d.s;assert s.start_patient_escort(d.n());assert s.patient_grip(d.n())
    assert not s.escort_step(d.n(),(2,'double'))
    assert not s.escort_step(d.n(),(1,'reception'),route_available=False)
    d.tick(100000);assert s.actors['cross_level_patient']==(1,'office')
    for pos in PATIENT_ROUTE[1:]:
        assert s.escort_step(d.n(),pos)
        assert s.actors['guard']==s.actors['cross_level_patient']==pos
    assert s.patient_delivered and s.guard_job=='return'
    for pos in reversed(PATIENT_ROUTE[:-1]):assert s.guard_return_step(d.n(),pos)
    assert s.actors['cross_level_patient']==(2,'double') and s.actors['guard']==(1,'office')
    assert not s.start_patient_escort(d.n()) and (s.life.hp,s.life.sp)==(100,100)


def test_patient_current_escort_not_stolen_by_later_avatar_report():
    d=Driver();s=d.s;s.start_patient_escort(d.n());s.patient_grip(d.n());d.go((1,'office'))
    for name in ('archive_spotted','archive_stop','archive_continue','archive_write'):assert d.rec(name)
    assert not d.rec('archive_deliver') and s.records.archive_state=='written'
    assert not d.begin('guard') and s.guard_job=='patient'


def test_received_avatar_report_has_priority_over_new_patient_encounter():
    d=Driver();new_report(d);s=d.s
    assert not s.start_patient_escort(d.n()) and d.begin('guard')


def test_no_remote_guard_grip_after_avatar_ascends():
    d=Driver();new_report(d);assert d.begin('guard');d.s.reach(d.n())
    d.go((2,'stairs'));assert not d.s.grip(d.n())
    assert not d.s.holder and (d.s.life.hp,d.s.life.sp)==(100,100)


@pytest.mark.parametrize('action',['take','refuse'])
def test_unheld_prepared_cup_cannot_be_taken_or_refused_from_another_room(action):
    d=Driver();d.go((1,'exam'));d.rec('issue_order',order_id='A',subject='avatar')
    d.go((1,'treatment'));assert d.med('prepare',order_id='A',cup_id='cup-A')
    d.go((1,'reception'));assert not d.med(action)
    assert d.s.medication.cup_state=='ready' and not d.s.medication.closed


@pytest.mark.parametrize('reason',['low_sp','feedback'])
def test_new_take_waits_for_feedback_and_does_not_override_return_to_bed(reason):
    d=Driver();d.go((1,'exam'));d.rec('issue_order',order_id='A',subject='avatar')
    d.go((1,'treatment'));assert d.med('prepare',order_id='A',cup_id='cup-A')
    if reason=='low_sp':d.s.life.sp=49
    if reason=='feedback':d.s.feedback=True
    assert not d.med('take')


def test_ascended_avatar_closes_unexecuted_guard_case_instead_of_permanent_busy():
    d=Driver();new_report(d);assert d.begin('guard');d.s.reach(d.n())
    d.go((2,'stairs'))
    assert d.s.guard_job is None and d.s.procedure is None
    assert 'guard' in d.s.procedure_done
    d.go((1,'office'));assert not d.begin('guard')
    assert d.s.start_patient_escort(d.n())


def test_shared_nurse_on_other_floor_cannot_record_actual_refusal():
    d=Driver();cup(d);s=d.s
    for loc in ((1,'reception'),(2,'stairs'),(2,'corridor')):assert s.actor_move(d.n(),'nurse',loc)
    out=d.n();assert s.medicine_action(out,'refuse',nurse_seen=True)
    assert not d.med('nurse_record',event_id='absent',outcome_id=out)
    assert not s.medication.records and s.life.sp==100


class S3SessionMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__();self.d=Driver();self.evidence=set();self.known=set();self.last_total=1

    @rule(loc=st.sampled_from([(1,r) for r in ('reception','ward','exam','treatment','office')]+[(2,r) for r in ('stairs','corridor','activity','double')]))
    def move(self,loc):self.d.move(loc)

    @rule(ms=st.sampled_from([0,1,249,250,799,800,999,1000,1500,1999,2000,3000,6000]))
    def time(self,ms):self.d.tick(ms)

    @rule(kind=st.sampled_from(['wrist','assistant','guard']),actual=st.booleans())
    def procedure(self,kind,actual):self.d.begin(kind,doctor_signal=actual)

    @rule(act=st.sampled_from(['reach','grip','tighten','normal_check','release']),actual=st.booleans())
    def contact(self,act,actual):
        s=self.d.s;kw={'actual':actual}
        if act=='reach':kw['refused']=True
        if act=='grip':kw['tighten']=True
        getattr(s,act)(self.d.n(),**kw)

    @rule(p=st.integers(0,44))
    def search(self,p):self.d.s.start_search(self.d.n(),p)

    @rule()
    def finish_search(self):
        s=self.d.s
        if s.search.pending:s.complete_search(self.d.n(),next(iter(s.search.pending)))
        s.finish_feedback(self.d.n())

    @rule(begin=st.booleans())
    def rest(self,begin):
        s=self.d.s
        if begin:s.begin_rest(self.d.n())
        else:s.complete_rest(self.d.n())

    @rule(hp=st.sampled_from([0,1,99,100]),sp=st.sampled_from([0,1,20,100]))
    def damage(self,hp,sp):self.d.hurt(hp,sp)

    @rule()
    def revive(self):self.d.s.revive()

    @rule()
    def reload(self):self.d.s=self.d.s.reload()

    @rule(paused=st.booleans())
    def pause(self,paused):self.d.s.paused=paused

    @rule(name=st.sampled_from(['archive_spotted','archive_stop','archive_continue','archive_write','archive_deliver']))
    def report(self,name):self.d.rec(name)

    @rule()
    def escort(self):self.d.s.start_patient_escort(self.d.n())

    @rule()
    def exit(self):self.d.hurt(exit_actual=True)

    @invariant()
    def lifecycle_and_idempotency(self):
        s=self.d.s
        assert s.life.attempts[2]==1 and 0<=s.life.hp<=100 and 0<=s.life.sp<=100
        assert 0<=s.search.used<=14 and s.search.income<=s.search.used
        assert s.life.total>=self.last_total;self.last_total=s.life.total
        assert not s.life.economy.awakening
        assert not(s.guard_job=='patient' and s.holder=='guard')
        if s.holder:assert s.procedure is not None
        if s.life.phase=='dead':assert s.holder is None and s.drug_stop==0
        if s.patient_delivered:assert s.actors['cross_level_patient']==(2,'double')


TestS3SessionMachine=S3SessionMachine.TestCase
TestS3SessionMachine.settings=settings(max_examples=250,stateful_step_count=70,deadline=None)
