"""Source-derived boundary and sequence tests, not Unity acceptance."""
from copy import deepcopy
import pytest
from hypothesis import settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from s3_medication import Medication


def cup(m=None, order='rx', cup_id='cup'):
    m = m or Medication()
    assert m.issue_order(order)
    assert m.prepare(order, cup_id)
    assert m.take()
    assert m.raise_cup()
    return m


@pytest.mark.parametrize('elapsed,allowed', [(0,False),(1,False),(999,False),(1000,True),(1001,True),(100000,True)])
def test_swallow_visible_window_boundary(elapsed, allowed):
    m = cup()
    m.tick(elapsed)
    assert m.swallow('consume') is allowed
    assert len(m.drain_effects()) == int(allowed)


@pytest.mark.parametrize('floor', [1,2])
@pytest.mark.parametrize('outcome', ['swallowed','refused'])
def test_both_floors_share_cap_even_new_order(floor,outcome):
    m = cup()
    m.move_floor(floor)
    m.tick(1000)
    assert getattr(m, 'swallow' if outcome == 'swallowed' else 'refuse')('done')
    m.move_floor(3-floor)
    assert m.issue_order('new')
    assert not m.prepare('new','new-cup')
    assert not m.swallow('second')
    assert m.closed


@pytest.mark.parametrize('prior', ['swallowed','refused'])
def test_settled_s2_order_cannot_repeat_in_s3(prior):
    m = Medication()
    assert m.inherit_order('old',actual_status=prior)
    assert not m.prepare('old','cup')
    assert m.issue_order('new')
    assert m.prepare('new','cup')  # S2 use did not consume S3's separate cap.
    assert m.effects == []


def test_false_s2_label_does_not_consume_or_authorize_order():
    m = Medication()
    m.inherited_labels['label-only'] = 'taken'
    assert not m.prepare('label-only','bad')
    assert m.inherit_order('real',actual_status='pending',label_status='taken')
    assert m.prepare('real','real-cup')
    assert m.effects == []


@pytest.mark.parametrize('invalid', ['missing','unsigned','wrong-patient','wrong-project','absent','mismatch'])
def test_invalid_prescription_or_pharmacist_no_cup(invalid):
    m = Medication()
    if invalid != 'missing':
        m.issue_order('rx',patient_id='other' if invalid == 'wrong-patient' else 'avatar',
                      signed=invalid != 'unsigned',
                      project='exam' if invalid == 'wrong-project' else 'numbered_cup')
    assert not m.prepare('rx','cup',pharmacist_present=invalid != 'absent',matched=invalid != 'mismatch')
    assert m.cup_state == 'none' and not m.closed and not m.effects


def test_interruption_resumes_original_cup_not_duplicate():
    m = cup()
    m.tick(999)
    assert m.interrupt()
    assert m.cup_id == 'cup' and not m.closed
    assert not m.prepare('rx','duplicate')
    assert m.raise_cup()
    assert not m.swallow('early')
    m.tick(1000)
    assert m.swallow('actual')
    effects = m.drain_effects()
    assert len(effects) == 1 and effects[0]['cup_id'] == 'cup'
    assert effects[0]['sp_damage'] == 20 and effects[0]['drug_stop_ms'] == 1500
    assert effects[0]['hp_damage'] == 0 and effects[0]['attempt'] == 1


def test_floor_transition_keeps_cup_window_and_cap():
    m = cup()
    m.tick(650)
    assert m.move_floor(2)
    assert m.cup_id == 'cup' and m.raising_ms == 650
    m.tick(350)
    assert m.swallow('upstairs')
    m.move_floor(1)
    assert m.closed and len(m.effects) == 1


@pytest.mark.parametrize('flag', ['paused','dead'])
@pytest.mark.parametrize('action', ['tick','swallow','refuse','interrupt','prepare','raise','take','write'])
def test_paused_dead_no_physical_progress(flag,action):
    m = cup()
    m.tick(1000)
    setattr(m,flag,True)
    before = deepcopy(m)
    operations = {
        'tick':lambda:m.tick(9000),'swallow':lambda:m.swallow('s'),
        'refuse':lambda:m.refuse('r'),'interrupt':m.interrupt,
        'prepare':lambda:m.prepare('rx','another'),'raise':m.raise_cup,
        'take':m.take,'write':lambda:m.nurse_record('write','s')}
    operations[action]()
    assert m == before


@pytest.mark.parametrize('present,witnessed', [(False,False),(False,True),(True,False),(True,True)])
@pytest.mark.parametrize('outcome', ['swallowed','refused'])
def test_nurse_requires_actual_present_witness_at_outcome(present,witnessed,outcome):
    m = cup()
    m.tick(1000)
    assert getattr(m,'swallow' if outcome == 'swallowed' else 'refuse')('result',present,witnessed)
    drained = m.drain_effects()
    assert m.nurse_record('write','result') is (present and witnessed)
    assert m.effects == []
    assert m.settled_orders['rx'] == outcome
    if m.records:
        assert m.records[0]['false'] is (outcome == 'refused')
    assert len(drained) == int(outcome == 'swallowed')


@pytest.mark.parametrize('completed,present', [(False,True),(True,False),(False,False)])
def test_unfinished_or_absent_nurse_writing_no_record(completed,present):
    m = cup()
    assert m.refuse('refuse',True,True)
    assert not m.nurse_record('write','refuse',completed=completed,nurse_present=present)
    assert m.records == [] and m.effects == []


def test_duplicate_swallow_refuse_and_record_callbacks():
    m = cup()
    m.tick(1000)
    assert m.swallow('actual',True,True)
    assert not m.swallow('actual',True,True)
    assert not m.swallow('new-id',True,True)
    assert not m.refuse('undo')
    assert m.nurse_record('paper','actual')
    assert not m.nurse_record('paper','actual')
    assert len(m.drain_effects()) == 1
    assert m.drain_effects() == []


@pytest.mark.parametrize('attempt', [2,10,1000000])
def test_real_new_attempt_reopens_cap_not_old_order(attempt):
    m = cup()
    m.tick(1000)
    assert m.swallow('old')
    first = m.drain_effects()[0]['id']
    assert m.new_attempt(attempt)
    assert not m.prepare('rx','cup2')
    assert m.issue_order('rx2')
    assert m.prepare('rx2','cup2')
    assert m.take() and m.raise_cup()
    m.tick(1000)
    assert m.swallow('new')
    second = m.drain_effects()[0]
    assert first != second['id'] and second['attempt'] == attempt


@pytest.mark.parametrize('attempt', [0,1])
def test_reload_or_same_attempt_cannot_restore_cap(attempt):
    m = cup()
    m.refuse('r')
    assert not m.new_attempt(attempt)
    assert m.closed
    assert deepcopy(m).closed


def test_pending_cup_survives_real_restart_without_copy():
    m = cup()
    m.tick(800)
    assert m.new_attempt(2)
    assert m.cup_id == 'cup' and m.cup_order == 'rx'
    assert m.cup_state == 'held' and m.raising_ms == 0
    assert m.raise_cup()
    m.tick(1000)
    assert m.swallow('finish')


def test_immutable_prescription_cannot_rebind_patient_or_revive_order():
    m = Medication()
    m.inherit_order('rx',actual_status='refused')
    assert not m.issue_order('rx',patient_id='someone-else')
    assert m.orders['rx'].patient_id == 'avatar'
    assert m.settled_orders['rx'] == 'refused'


def test_nurse_cannot_write_based_on_cup_possession_only():
    m = cup()
    assert not m.nurse_record('paper','not-yet-outcome')
    assert not m.effects and not m.records


class MedicationMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.m = Medication()
        self.seq = 0
        self.delivered = []

    def eid(self,kind):
        self.seq += 1
        return (kind,self.seq)

    @rule(prior=st.sampled_from(['pending','swallowed','refused']),
          signed=st.booleans(),matched=st.booleans(),present=st.booleans(),
          false_label=st.booleans())
    def prescribe_prepare(self,prior,signed,matched,present,false_label):
        rx = self.eid('order')
        self.m.inherit_order(rx,actual_status=prior,signed=signed,
                            label_status='taken' if false_label else None)
        before = len(self.m.effects)
        self.m.prepare(rx,self.eid('cup'),pharmacist_present=present,matched=matched)
        assert len(self.m.effects) == before

    @rule()
    def fresh_valid_order(self):
        rx = self.eid('fresh')
        self.m.issue_order(rx)
        self.m.prepare(rx,self.eid('cup'))

    @rule()
    def receive_raise(self):
        self.m.take()
        self.m.raise_cup()

    @rule(ms=st.sampled_from([0,1,500,999,1000,1001,5000]))
    def time(self,ms):
        before = self.m.raising_ms
        frozen = not self.m.active or self.m.cup_state != 'raising'
        self.m.tick(ms)
        if frozen:
            assert self.m.raising_ms == before

    @rule(refuse=st.booleans(),present=st.booleans(),witnessed=st.booleans())
    def outcome(self,refuse,present,witnessed):
        e = self.eid('outcome')
        fun = self.m.refuse if refuse else self.m.swallow
        result = fun(e,present,witnessed)
        if result:
            saved = deepcopy(self.m)
            assert not fun(e,present,witnessed)
            assert self.m == saved

    @rule()
    def interrupt(self):
        self.m.interrupt()

    @rule(present=st.booleans(),complete=st.booleans())
    def paperwork(self,present,complete):
        last = next(reversed(self.m.outcomes),None) if self.m.outcomes else None
        bodily = deepcopy(self.m.settled_orders)
        effects = deepcopy(self.m.effects)
        self.m.nurse_record(self.eid('paper'),last,nurse_present=present,completed=complete)
        assert self.m.settled_orders == bodily and self.m.effects == effects

    @rule(paused=st.booleans())
    def pause(self,paused):
        self.m.paused = paused

    @rule()
    def die(self):
        self.m.dead = True

    @rule(increment=st.sampled_from([0,1,3,100]))
    def restart(self,increment):
        settled = deepcopy(self.m.settled_orders)
        self.m.new_attempt(self.m.attempt+increment)
        assert self.m.settled_orders == settled

    @rule(floor=st.sampled_from([1,2]))
    def floor(self,floor):
        before = (self.m.closed,self.m.cup_id,self.m.cup_order,self.m.raising_ms)
        self.m.move_floor(floor)
        assert (self.m.closed,self.m.cup_id,self.m.cup_order,self.m.raising_ms) == before

    @rule()
    def collect_effects(self):
        self.delivered.extend(self.m.drain_effects())

    @invariant()
    def one_actual_outcome_per_attempt_and_order(self):
        outcomes = list(self.m.outcomes.values())
        assert len({o['attempt'] for o in outcomes}) == len(outcomes)
        assert len({o['order_id'] for o in outcomes}) == len(outcomes)
        combined = self.delivered + self.m.effects
        assert len({e['id'] for e in combined}) == len(combined)
        swallowed = [o for o in outcomes if o['actual'] == 'swallowed']
        assert len(combined) == len(swallowed)
        assert all(e['sp_damage']==20 and e['drug_stop_ms']==1500 and e['hp_damage']==0 for e in combined)
        assert all(self.m.outcomes[r['outcome_id']]['nurse_witnessed'] for r in self.m.records)
        assert all(r['false']==(r['actual']=='refused') for r in self.m.records)


TestMedicationMachine = MedicationMachine.TestCase
TestMedicationMachine.settings = settings(max_examples=225,stateful_step_count=65,deadline=None)
